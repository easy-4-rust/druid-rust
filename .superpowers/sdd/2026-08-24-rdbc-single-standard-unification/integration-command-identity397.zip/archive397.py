from pathlib import Path
import hashlib,json,shutil,zipfile
b=Path(__file__).parent
e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust')
w=Path('F:/codex_build_cache/d177')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
record=json.loads((b/'integration-command-identity396.summary.json').read_text())
assert record['red']['exit_code']==1 and record['red']['failures']==2
assert record['green']['exit_code']==0 and record['green']['tests']==44
assert all(sha(b/name)==h for name,h in record['hashes'].items())
frozen=json.loads((b/'task7-final-candidate-workspace319/frozen-inputs.json').read_text())
assert len(frozen)==1277 and all(sha(w/p)==h for p,h in frozen.items())
names=['integration_preflight387.py','test_integration_preflight388.py','integration_preflight393.py','test_integration_command_identity394.py','test_integration_command_identity394.red.py','build_integration_command_identity395.py','validate_integration_command_identity396.py','integration-command-identity396.summary.json']
files={name:b/name for name in names}
files['archive397.py']=Path(__file__)
entries={name:sha(path) for name,path in files.items()}
z=b/'integration-command-identity397.zip'
assert not z.exists()
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as archive:
 for name,path in files.items():archive.write(path,name)
 archive.writestr('manifest.json',json.dumps(entries,indent=2))
with zipfile.ZipFile(z) as archive:assert all(hashlib.sha256(archive.read(name)).hexdigest()==h for name,h in entries.items())
receipt=b/'integration-command-identity397.summary.json'
receipt.write_text(json.dumps(dict(sha256=sha(z),verified_entries=len(entries),red_tests=44,red_failures=2,green_tests=44,production_applied=False),indent=2)+'\n',encoding='utf-8')
for item in (z,receipt):
 target=e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'/item.name
 assert not target.exists()
 shutil.copyfile(item,target)
 assert sha(item)==sha(target)
note='2026-10-09 集成检查器可执行文件身份草稿393-397：替换Cargo/Python但保留参数及日志hash两个负例实际RED，原21项与扩展23项共44测试GREEN；独立草稿绑定原1.97.1 Cargo与Espressif Python绝对路径，原检查器保留。396实际预览仍拒绝运行中的319，1277候选输入与1257正式preimage复核不变；未apply/认证API/发布，18顶层OPEN。zip397 SHA '+sha(z)+'逐条目和E镜像核验。'
for rel in ('.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md','docs/verification/rdbc-first/status.md','docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md'):
 with (e/rel).open('ab') as out:out.write(('\n\n'+note+'\n').encode('utf-8'))
print(json.dumps(dict(zip_sha256=sha(z),verified_entries=len(entries),production_applied=False)))
