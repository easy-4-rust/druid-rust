from pathlib import Path
b=Path(__file__).parent
source=(b/'integration_preflight387.py').read_text(encoding='utf-8')
source=source.replace('class IntegrationRefused(RuntimeError):\n    pass','from integration_preflight387 import IntegrationRefused')
anchor="        require(command[1:]==arguments,'verification command scope mismatch')"
assert source.count(anchor)==1
replacement="""        expected_executable=Path('C:/Espressif/tools/python/python.exe' if name=='c1-complete-runtime' else 'C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin/cargo.exe')
        require(command and Path(command[0]).resolve()==expected_executable.resolve(),'verification executable identity mismatch')
"""+anchor
target=b/'integration_preflight393.py'
assert not target.exists()
target.write_text(source.replace(anchor,replacement),encoding='utf-8')
test=b/'test_integration_command_identity394.py'
text=test.read_text(encoding='utf-8')
(b/'test_integration_command_identity394.red.py').write_text(text,encoding='utf-8')
text=text.replace('from integration_preflight387 import IntegrationRefused','from integration_preflight393 import IntegrationRefused, validate_preflight')
anchor='    def test_substituted_cargo_executable_rejected(self):'
assert text.count(anchor)==1
text=text.replace(anchor,'    def run_gate(self):\n        return validate_preflight(self.w,self.e,self.f,self.p,self.s)\n\n'+anchor)
test.write_text(text,encoding='utf-8')
print('Independent checker executable identity draft created; frozen candidate unchanged')
