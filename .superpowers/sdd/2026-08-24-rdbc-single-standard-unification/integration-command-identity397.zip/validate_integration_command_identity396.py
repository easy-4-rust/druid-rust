from pathlib import Path
import hashlib,json
from integration_preflight393 import IntegrationRefused,validate_preflight
b=Path(__file__).parent
w=Path('F:/codex_build_cache/d177')
e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
frozen=json.loads((b/'task7-final-candidate-workspace319/frozen-inputs.json').read_text())
snapshot=json.loads((b/'task7-e-integration-current-snapshot383/summary.json').read_text())
summary=json.loads((b/'task7-final-candidate-workspace319/summary.json').read_text())
assert len(frozen)==1277 and all(sha(w/p)==h for p,h in frozen.items())
assert len(snapshot['files'])==1257 and all((sha(e/r['path']) if (e/r['path']).exists() else None)==r['e_preimage_sha256'] for r in snapshot['files'])
try:preview=validate_preflight(w,e,frozen,snapshot,summary)
except IntegrationRefused as error:preview=dict(state='REFUSED',reason=str(error))
record=dict(scope='INDEPENDENT_EXECUTABLE_IDENTITY_CHECKER_DRAFT',red=dict(chunk='b9c74e',tests=44,failures=2,exit_code=1),green=dict(chunk='a765cc',tests=44,failures=0,exit_code=0),actual_preview=preview,frozen_changed=0,formal_preimages_changed=0,production_applied=False,remaining_top_level_tasks=18,hashes={name:sha(b/name) for name in ('integration_preflight393.py','test_integration_command_identity394.py','test_integration_command_identity394.red.py','build_integration_command_identity395.py')})
target=b/'integration-command-identity396.summary.json'
assert not target.exists()
target.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(record,ensure_ascii=False))
