# 当前105条编译覆盖义务预检

原源码哈希统计：{"STALE": 105}。不启动Cargo、不修改清单或校验器，不认证编译器身份。

- original-manifest-load: FAIL coverage requirement source hash is stale: crates\druid-wrapper\tests\duckdb_connection_adapter_test.rs: 821966759410c319a42100f055b6fb28135bfb814b25920c0a1ef189fe81da87 != 4a43bca0123a34fb6468a020ae9891e182e9f37f7f101647417dff267ee6e78f
- canonical-source-preflight: FAIL SQLx actor ownership evidence is incomplete: ['tokio :: sync :: Mutex']

必须用七家族原精确测试的新鲜LLVM profile重新生成105条编译器身份；不能只替换source_sha256。
