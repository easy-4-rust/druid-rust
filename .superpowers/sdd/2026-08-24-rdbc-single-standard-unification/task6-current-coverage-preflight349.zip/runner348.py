from pathlib import Path
from collections import Counter
import hashlib,json,shutil,sys,zipfile
sys.dont_write_bytecode=True
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d177');e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust');d=b/'task6-current-coverage-preflight348';d.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
frozen_path=b/'task7-final-candidate-workspace319/frozen-inputs.json';frozen=json.loads(frozen_path.read_text());assert len(frozen)==1277 and all(sha(w/p)==h for p,h in frozen.items())
sys.path.insert(0,str(w/'scripts'));import verify_wrapper_standard_impls as verifier;import regenerate_task6_coverage_manifest as generator
manifest_path=w/verifier.DEFAULT_COVERAGE_MANIFEST;manifest=json.loads(manifest_path.read_text());assert len(manifest['families'])==7
results=[];source_files=set()
for family in manifest['families']:
 assert len(family['requirements'])==15
 for requirement in family['requirements']:
  path=w/requirement['source_path'];exists=path.is_file();actual=sha(path) if exists else None
  if exists:source_files.add(path)
  results.append(dict(family=family['family'],requirement_id=requirement['requirement_id'],source_path=requirement['source_path'],source_function=requirement['source_function'],recorded_sha256=requirement['source_sha256'],actual_sha256=actual,source_hash_status='MATCH' if actual==requirement['source_sha256'] else 'STALE' if exists else 'MISSING',compiler_function_name=requirement['compiler_function_name'],compiler_identity_certified=False))
assert len(results)==105
checks=[]
for name,run in [('original-manifest-load',lambda:verifier.load_coverage_manifest(w)),('canonical-source-preflight',lambda:generator.validate_canonical_source_requirements(w,generator.canonical_requirements(w)))]:
 try:run();checks.append(dict(name=name,status='PASS_STATIC_ONLY'))
 except (verifier.VerificationError,OSError,ValueError) as error:checks.append(dict(name=name,status='FAIL',error=str(error)))
summary=dict(scope='CURRENT_105_COMPILER_COVERAGE_SOURCE_PREFLIGHT_NO_CARGO_NO_HASH_PROMOTION',production_applied=False,manifest_modified=False,verifier_modified=False,cargo_started=False,compiler_coverage_certified=False,frozen_inputs=1277,manifest_sha256=sha(manifest_path),families=[family['family'] for family in manifest['families']],requirements=105,unique_source_files=len(source_files),source_hash_counts=dict(Counter(row['source_hash_status'] for row in results)),checks=checks,rows=results,required_next_action='After original workspace319 terminal, regenerate all seven original exact runtime coverage families using fresh LLVM profiles and exact compiler names; retain all105 obligations and original test identities/timeouts. A static source preflight pass is not runtime coverage.')
assert all(sha(w/p)==h for p,h in frozen.items());(d/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
report=['# 当前105条编译覆盖义务预检','','原源码哈希统计：'+json.dumps(summary['source_hash_counts'])+'。不启动Cargo、不修改清单或校验器，不认证编译器身份。','']
for check in checks:report.append('- '+check['name']+': '+check['status']+' '+check.get('error',''))
report+=['','必须用七家族原精确测试的新鲜LLVM profile重新生成105条编译器身份；不能只替换source_sha256。']
(d/'report.md').write_text('\n'.join(report)+'\n',encoding='utf-8')
files={'runner348.py':Path(__file__),'summary.json':d/'summary.json','report.md':d/'report.md','original-coverage-manifest.json':manifest_path,'original-verifier.py':w/'scripts/verify_wrapper_standard_impls.py','original-regenerator.py':w/'scripts/regenerate_task6_coverage_manifest.py','frozen319.json':frozen_path}
for path in source_files:files[path.relative_to(w).as_posix()]=path
entries={n:sha(p) for n,p in files.items()};z=b/'task6-current-coverage-preflight349.zip';assert not z.exists()
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as out:
 for n,p in files.items():out.write(p,n)
 out.writestr('manifest.json',json.dumps(entries,indent=2))
with zipfile.ZipFile(z) as out:assert all(hashlib.sha256(out.read(n)).hexdigest()==h for n,h in entries.items())
receipt=b/'task6-current-coverage-preflight349.summary.json';receipt.write_text(json.dumps(dict(scope=summary['scope'],sha256=sha(z),verified_entries=len(entries),source_hash_counts=summary['source_hash_counts'],checks=checks,production_applied=False),indent=2)+'\n',encoding='utf-8')
for p in (z,receipt):
 q=e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'/p.name;assert not q.exists();shutil.copyfile(p,q);assert sha(p)==sha(q)
note='2026-10-09 当前105条compiler coverage源码预检348/349：原七家族每家15义务分母保留，源码hash统计 '+json.dumps(summary['source_hash_counts'])+'；原manifest加载和canonical源码预检结果 '+json.dumps(checks,ensure_ascii=False)+'。未启动Cargo/修改hash或编译器identity，不认证runtime coverage；必须在319终态后用原七精确测试新LLVM profile重生成105义务。1277冻结变化0，zip349 SHA '+sha(z)+'全部条目/E镜像核验，Task6 FIX_REQUIRED/18顶层OPEN。'
for rel in ('.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md','docs/verification/rdbc-first/status.md','docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md'):
 with (e/rel).open('ab') as out:out.write(('\n\n'+note+'\n').encode('utf-8'))
print(json.dumps(dict(source_hash_counts=summary['source_hash_counts'],checks=checks,zip_sha256=sha(z),verified_entries=len(entries)),ensure_ascii=False))
