import hashlib,json,os,re,shutil,subprocess
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');old=Path('F:/codex_build_cache/d105');w=Path('F:/codex_build_cache/d111');d=b/'task7-borrow-clock111';d.mkdir(exist_ok=False);w.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
f=json.loads((b/'task7-event-retry108/frozen-inputs.json').read_text(encoding='utf-8'));assert all(sha(old/r)==h for r,h in f.items())
java_repo='E:/workspaces/workspace-github/druid';commit='33824c3dec1612711f9bb4e409319bcab2e4cd0e';java=None
for java_path in ['core/src/main/java/com/alibaba/druid/pool/DruidDataSource.java','src/main/java/com/alibaba/druid/pool/DruidDataSource.java']:
    result=subprocess.run(['git','-C',java_repo,'show',commit+':'+java_path],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    if result.returncode==0:java=result.stdout;break
assert java is not None
java_text=java.decode('utf-8');pattern=r'if \(removeAbandoned\) \{\s*StackTraceElement\[\] stackTrace = Thread.currentThread\(\).getStackTrace\(\);\s*poolableConnection.connectStackTrace = stackTrace;\s*poolableConnection.setConnectedTimeNano\(\);'
match=re.search(pattern,java_text);assert match is not None
(d/'DruidDataSource.java').write_bytes(java)
java_evidence=dict(commit=commit,path=java_path,sha256=hashlib.sha256(java).hexdigest(),capture_before_clock=match.group(0),start_line=java_text[:match.start()].count('\n')+1)
(d/'java-baseline.json').write_text(json.dumps(java_evidence,indent=2)+'\n',encoding='utf-8')
for rel,h in f.items():
    target=w/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(old/rel,target);assert sha(target)==h
rel='crates/druid/src/pool/active_connection_lease.rs';p=w/rel;raw=p.read_bytes();(d/'before.rs').write_bytes(raw)
source=raw.decode('utf-8');newline='\r\n' if '\r\n' in source else '\n'
needle='        Self {'+newline+'            borrowed_at: Instant::now(),'
assert source.count(needle)==1
source=source.replace(needle,'        // 对齐 Java：先完成借出堆栈捕获，再开始 removeAbandoned 的租约计时。'+newline+'        // 符号解析属于借出诊断成本，不应消耗调用者实际持有连接的超时预算。'+newline+'        let connect_stack_trace = std::backtrace::Backtrace::force_capture().to_string();'+newline+'        Self {'+newline+'            borrowed_at: Instant::now(),')
source=source.replace('connect_stack_trace: std::backtrace::Backtrace::force_capture().to_string(),','connect_stack_trace,')
p.write_bytes(source.encode('utf-8'))
assert [r for r,h in f.items() if sha(w/r)!=h]==[rel]
tool='C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin';env=os.environ.copy();env.update(RUSTC=tool+'/rustc.exe',RUSTDOC=tool+'/rustdoc.exe',RUSTUP_TOOLCHAIN='1.97.1-x86_64-pc-windows-msvc',RUSTUP_AUTO_INSTALL='0',PATH=tool+os.pathsep+env['PATH'],CARGO_TARGET_DIR='F:/codex_build_cache/druid_rust/task6_lifetime_clean_1971_20261008',CARGO_BUILD_JOBS='1',TMP='F:/codex_tmp/task7_standard_cargo13',TEMP='F:/codex_tmp/task7_standard_cargo13',DRUID_RDBC_EXTERNAL_TARGET_ROOT='F:/codex_build_cache/dr111_ext')
log=d/'format.log';cmd=[tool+'/cargo.exe','fmt','--all']
with log.open('xb') as out:r=subprocess.run(cmd,cwd=w,env=env,stdout=out,stderr=subprocess.STDOUT)
assert r.returncode==0
assert [r for r,h in f.items() if sha(w/r)!=h]==[rel]
f={r:sha(w/r) for r in f};(d/'frozen-inputs.json').write_text(json.dumps(f,indent=2)+'\n',encoding='utf-8')
s=dict(terminal=False,production_applied=False,workspace=str(w),frozen_input_count=len(f),java_baseline=java_evidence,changed_from108=[rel],original_tests_assertions_timeouts_unchanged=True,commands=[],pid=os.getpid());save=lambda:(d/'summary.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8');save()
common=['--all-features','--locked','--offline','--no-fail-fast','-j1']
for name,args in [('original-differential',['test','-p','druid','--test','task6_pool_maintenance_differential_test_parity']+common),('maintenance-semantics',['test','-p','druid','--test','task6_pool_maintenance_semantics_test_parity']+common),('format-check',['fmt','--all','--','--check'])]:
    cmd=[tool+'/cargo.exe']+args;log=d/(name+'.log')
    with log.open('xb') as out:r=subprocess.run(cmd,cwd=w,env=env,stdout=out,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
    blocks=re.findall(r'^test result: .*?(\d+) passed; (\d+) failed; (\d+) ignored;',log.read_text(encoding='utf-8'),re.M)
    changed=[rel for rel,h in f.items() if sha(w/rel)!=h]
    s['commands'].append(dict(name=name,command=cmd,exit_code=r.returncode,log=str(log),sha256=sha(log),passed=sum(int(v[0]) for v in blocks),failed=sum(int(v[1]) for v in blocks),changed_inputs=changed));save();print(json.dumps(s['commands'][-1]),flush=True)
    if r.returncode or changed:break
s.update(terminal=True,exit_code=r.returncode,changed_inputs=[rel for rel,h in f.items() if sha(w/rel)!=h]);save();print(json.dumps(dict(terminal=True,exit_code=r.returncode)),flush=True)
