import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

b = Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
w = Path('F:/codex_build_cache/d111')
e = Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
previous = json.loads((b / 'task7-borrow-clock111/summary.json').read_text(encoding='utf-8'))
assert previous['terminal'] and previous['exit_code'] == 0
assert len(previous['commands']) == 3
frozen = json.loads((b / 'task7-borrow-clock111/frozen-inputs.json').read_text(encoding='utf-8'))
assert len(frozen) == 1226 and all(sha(w / rel) == h for rel, h in frozen.items())
d = b / 'task7-converged-validation113'
d.mkdir(exist_ok=False)
(d / 'frozen-inputs.json').write_text(json.dumps(frozen, indent=2) + '\n', encoding='utf-8')
tool = 'C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin'
env = os.environ.copy()
env.update(RUSTC=tool + '/rustc.exe', RUSTDOC=tool + '/rustdoc.exe',
           RUSTUP_TOOLCHAIN='1.97.1-x86_64-pc-windows-msvc', RUSTUP_AUTO_INSTALL='0',
           PATH=tool + os.pathsep + env['PATH'], CARGO_BUILD_JOBS='1',
           CARGO_TARGET_DIR='F:/codex_build_cache/druid_rust/task6_lifetime_clean_1971_20261008',
           TMP='F:/codex_tmp/task7_standard_cargo13', TEMP='F:/codex_tmp/task7_standard_cargo13',
           DRUID_RDBC_EXTERNAL_TARGET_ROOT='F:/codex_build_cache/dr113_ext',
           GIT_DIR=str(e / '.git'), GIT_WORK_TREE=str(w), PYTHONUTF8='1',
           PYTHONDONTWRITEBYTECODE='1')
s = dict(terminal=False, production_applied=False, workspace=str(w),
         frozen_input_count=len(frozen), pid=os.getpid(), commands=[])
def save():
    (d / 'summary.json').write_text(json.dumps(s, indent=2) + '\n', encoding='utf-8')
common = ['--workspace', '--all-features', '--locked', '--offline', '-j1']
commands = [
    ('workspace-complete', [tool + '/cargo.exe', 'test'] + common + ['--no-fail-fast']),
    ('workspace-strict', [tool + '/cargo.exe', 'clippy'] + common + ['--all-targets', '--', '-D', 'warnings']),
    ('workspace-doc', [tool + '/cargo.exe', 'doc'] + common + ['--no-deps']),
    ('format', [tool + '/cargo.exe', 'fmt', '--all', '--', '--check']),
    ('c1-complete-runtime', ['C:/Espressif/tools/python/python.exe', '-X', 'utf8',
                             'scripts/verify_task6_method_parity.py', '--repository-root', str(w)]),
]
save()
for name, command in commands:
    assert all(sha(w / rel) == h for rel, h in frozen.items())
    s['running_command'] = name
    save()
    log = d / (name + '.log')
    with log.open('xb') as out:
        result = subprocess.run(command, cwd=w, env=env, stdout=out, stderr=subprocess.STDOUT,
                                creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
    text = log.read_text(encoding='utf-8')
    blocks = re.findall(r'^test result: .*?(\d+) passed; (\d+) failed; (\d+) ignored;', text, re.M)
    failures = re.findall(r'^test (\S+) \.\.\. FAILED$', text, re.M)
    changed = [rel for rel, h in frozen.items() if sha(w / rel) != h]
    counts = dict(passed=sum(int(v[0]) for v in blocks), failed=sum(int(v[1]) for v in blocks),
                  ignored=sum(int(v[2]) for v in blocks), blocks=len(blocks))
    entry = dict(name=name, command=command, exit_code=result.returncode, log=str(log),
                 sha256=sha(log), results=counts, failing_tests=failures, changed_inputs=changed)
    s['commands'].append(entry)
    save()
    print(json.dumps(entry), flush=True)
    if changed:
        break
s.update(terminal=True, exit_code=0 if all(c['exit_code'] == 0 and not c['changed_inputs'] for c in s['commands']) else 1,
         changed_inputs=[rel for rel, h in frozen.items() if sha(w / rel) != h])
s.pop('running_command', None)
save()
print(json.dumps(dict(terminal=True, exit_code=s['exit_code'])), flush=True)
raise SystemExit(s['exit_code'])
