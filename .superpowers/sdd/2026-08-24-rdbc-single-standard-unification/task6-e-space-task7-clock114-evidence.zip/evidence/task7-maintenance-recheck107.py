import hashlib,json,os,re,subprocess
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d72');d=b/'task7-maintenance-recheck107';d.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
original=json.loads((b/'task7-complete74/summary.json').read_text(encoding='utf-8'));assert original['terminal'] and original['exit_code']==101 and not original['changed_inputs']
f=json.loads((b/'task7-complete74/frozen-inputs.json').read_text(encoding='utf-8'));assert all(sha(w/r)==h for r,h in f.items())
(d/'frozen-inputs.json').write_text(json.dumps(f,indent=2)+'\n',encoding='utf-8')
tool='C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin';env=os.environ.copy();env.update(RUSTC=tool+'/rustc.exe',RUSTDOC=tool+'/rustdoc.exe',RUSTUP_TOOLCHAIN='1.97.1-x86_64-pc-windows-msvc',RUSTUP_AUTO_INSTALL='0',PATH=tool+os.pathsep+env['PATH'],CARGO_TARGET_DIR='F:/codex_build_cache/druid_rust/task6_lifetime_clean_1971_20261008',CARGO_BUILD_JOBS='1',TMP='F:/codex_tmp/task7_standard_cargo13',TEMP='F:/codex_tmp/task7_standard_cargo13',DRUID_RDBC_EXTERNAL_TARGET_ROOT='F:/codex_build_cache/dr74_ext')
cmd=[tool+'/cargo.exe','test','-p','druid','--test','task6_pool_maintenance_differential_test_parity','--all-features','--locked','--offline','--no-fail-fast','-j1'];log=d/'recheck.log'
s=dict(terminal=False,production_applied=False,command=cmd,workspace=str(w),frozen_input_count=len(f),root_cause_certified=False,pid=os.getpid());save=lambda:(d/'summary.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8');save()
with log.open('xb') as out:r=subprocess.run(cmd,cwd=w,env=env,stdout=out,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
blocks=re.findall(r'^test result: .*?(\d+) passed; (\d+) failed; (\d+) ignored;',log.read_text(encoding='utf-8'),re.M)
s.update(terminal=True,exit_code=r.returncode,passed=sum(int(v[0]) for v in blocks),failed=sum(int(v[1]) for v in blocks),log=str(log),sha256=sha(log),changed_inputs=[rel for rel,h in f.items() if sha(w/rel)!=h]);save();print(json.dumps(s,indent=2))
