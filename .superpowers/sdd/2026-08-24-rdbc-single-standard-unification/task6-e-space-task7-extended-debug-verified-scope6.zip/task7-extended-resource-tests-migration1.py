import json,hashlib,re,subprocess,shutil
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');d=b/'task7-extended-resource-tests-candidate1';d.mkdir(exist_ok=False)
repo=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust');src=repo/'crates/druid/tests/task6_rdbc_extended_types_test_parity.rs';p=d/src.name;shutil.copyfile(src,p)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cmd=json.loads((b/'task7-callable-resource-tests-candidate1/summary.json').read_text())['commands'][-2]['command'].copy();cmd[cmd.index('--test')+3]=str(p);cmd[cmd.index('-o')+1]=str(d/'extended.exe')
s={'terminal':False,'production_applied':False,'original_sha256':sha(src),'commands':[]}
def run(name,c,ok):
 log=d/(name+'.log')
 with log.open('xb')as out:r=subprocess.run(c,stdout=out,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
 s['commands'].append({'name':name,'command':c,'exit_code':r.returncode,'log':str(log),'sha256':sha(log)});(d/'summary.json').write_text(json.dumps(s,indent=2));print(name,r.returncode,flush=True);assert (r.returncode==0)==ok
run('old-interface-compile',cmd,False)
t=src.read_text();prefix,tests=t.split('#[tokio::test]',1)
prefix=prefix.replace('RdbcArrayAccess, RdbcRefAccess, RdbcResourceAccess, RdbcSqlXmlAccess, ResourceHandleFactory,','ResourceHandleFactory,')
prefix=prefix.replace('use druid_rdbc::wrapper', 'use druid_rdbc::resource::{Array, Ref, SqlXml};\nuse druid_rdbc::wrapper')
for obj,trait in [('TestArray','Array'),('TestRef','Ref'),('TestSqlXml','SqlXml')]:
 pat=r'#\[async_trait::async_trait\]\nimpl RdbcResourceAccess for '+obj+r' \{(.*?)\n\}\n\n#\[async_trait::async_trait\]\nimpl Rdbc(?:Array|Ref|SqlXml)Access for '+obj+r' \{'
 prefix,n=re.subn(pat,lambda m:'#[async_trait::async_trait]\nimpl '+trait+' for '+obj+' {'+m.group(1),prefix,flags=re.S);assert n==1,obj
prefix=prefix.replace('async fn free(&self)', 'async fn free(&mut self)');prefix=re.sub(r'(async fn \w+\()&self',r'\1&mut self',prefix);prefix=re.sub(r'(async fn \w+\(\n\s*)&self',r'\1&mut self',prefix)
prefix=prefix.replace('_representation: &RdbcXmlRepresentationType','_representation: Option<&RdbcXmlRepresentationType>')
prefix=prefix.replace('ResourceHandleFactory::array(Arc::new(', 'ResourceHandleFactory::array(Box::new(')
tests=tests.replace('ResourceHandleFactory::reference(Arc::new(', 'ResourceHandleFactory::reference(Box::new(').replace('ResourceHandleFactory::sql_xml(Arc::new(', 'ResourceHandleFactory::sql_xml(Box::new(')
tests=tests.replace('xml.source(&RdbcXmlRepresentationType::Dom)','xml.source(Some(&RdbcXmlRepresentationType::Dom))').replace('.result(&RdbcXmlRepresentationType::Stream)', '.result(Some(&RdbcXmlRepresentationType::Stream))')
p.write_text(prefix+'#[tokio::test]'+tests,encoding='utf-8',newline='\n')
run('standard-format',['C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin/rustfmt.exe','--edition','2021',str(p)],True)
run('standard-compile',cmd,True);run('standard-runtime-before-fixture-fix',[str(d/'extended.exe'),'--test-threads=1'],False)
s['terminal']=True;s['source_sha256']=sha(p);(d/'summary.json').write_text(json.dumps(s,indent=2))
