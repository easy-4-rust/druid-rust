import json,hashlib,re,subprocess,shutil
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');d=b/'task7-extended-resource-tests-candidate1';libs=b/'task7-resource-debug-candidate1';p=d/'task6_rdbc_extended_types_test_parity.rs'
s={'terminal':False,'production_applied':False,'commands':[],'ruling':'Each SQLXML read/write representation scenario owns a separately created object. Preserve all original payload, UTF16, identity, Debug and post-free assertions; free each previous scenario before shadowing. Repeated representations on the same object remain forbidden and get explicit alias regression.'};sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def run(name,c,ok=True):
 log=d/('xml-fixture2-'+name+'.log')
 with log.open('xb')as out:r=subprocess.run(c,stdout=out,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
 s['commands'].append({'name':name,'command':c,'exit_code':r.returncode,'log':str(log),'sha256':sha(log)});(d/'xml-fixture2.summary.json').write_text(json.dumps(s,indent=2));print(name,r.returncode,flush=True);assert (r.returncode==0)==ok
shutil.copyfile(p,d/'extended.before-xml-fixture2.rs');t=p.read_text();needle='''    let xml = ResourceHandleFactory::sql_xml(Box::new(TestSqlXml {
        value: Mutex::new(RdbcString::from("<root>值</root>")),
        freed: AtomicBool::new(false),
    }));''';assert t.count(needle)==1
t=t.replace(needle,'    let xml = xml();')
factory='''
fn xml() -> druid::core::RdbcSqlXml {
    ResourceHandleFactory::sql_xml(Box::new(TestSqlXml {
        value: Mutex::new(RdbcString::from("<root>值</root>")),
        freed: AtomicBool::new(false),
    }))
}
'''
t=t.replace('#[tokio::test]',factory+'\n#[tokio::test]',1)
for needle in ['    assert_eq!(\n        xml.character_stream()', '    xml.set_character_stream()', '    xml.set_string(&RdbcString::from_utf16(vec![0xD800]))', '    let source = xml.source(']:
 assert t.count(needle)==1,needle
 t=t.replace(needle,'    // 独立表示场景先释放前一对象，保留同一对象的一次性读写约束。\n    xml.free().await.unwrap();\n    assert!(xml.is_freed());\n    let xml = self::xml();\n'+needle)
# Local variable named xml shadows the factory only after first call; use explicit module path thereafter.
t+='''
/// 克隆共享一次性读取机会及释放确认，不因测试场景分离而重置。
#[tokio::test]
async fn extended_sqlxml_alias_preserves_one_shot_read_and_free_state() {
    let value = xml();
    let alias = value.clone();
    assert_eq!(value, alias);
    assert_eq!(value.string().await.unwrap().to_rust_string().unwrap(), "<root>值</root>");
    assert_eq!(alias.character_stream().await.expect_err("alias shares consumed read").sql_exception().unwrap().sql_state(), Some("HY010"));
    alias.free().await.unwrap();
    assert!(value.is_freed());
    assert!(value.string().await.is_err());
}
'''
p.write_text(t,encoding='utf-8',newline='\n')
run('format',['C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin/rustfmt.exe','--edition','2021',str(p)])
c=json.loads((libs/'retry2.summary.json').read_text())['commands'][-2]['command'].copy();assert str(p) in c;c[c.index('-o')+1]=str(d/'extended-xml2.exe');run('compile',c);run('runtime',[str(d/'extended-xml2.exe'),'--test-threads=1'])
s['terminal']=True;s['source_sha256']=sha(p);s['exe_sha256']=sha(d/'extended-xml2.exe');(d/'xml-fixture2.summary.json').write_text(json.dumps(s,indent=2))
