import json,hashlib,os,shutil,subprocess
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');old=b/'task7-wrapper-buffered-candidate1';d=b/'task7-resource-debug-candidate1';d.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name,source in [('rdbc',old/'rdbc'),('druid',old/'druid'),('wrapper',b/'task7-wrapper-unit-candidate2')]:shutil.copytree(source,d/name,ignore=shutil.ignore_patterns('*.rlib','*.exe','*.log','*.json'))
p=d/'rdbc/src/resource/standard_resource_value.rs';before=p.read_bytes();(d/'standard_resource_value.before.rs').write_bytes(before);t=p.read_text();needle='.field("state", &self.state.load(Ordering::Acquire))';assert t.count(needle)==1
t=t.replace(needle,'''// 保留历史可用/已释放状态的Debug名称，同时准确区分未确认的释放。
            .field("state", &format_args!("{}", match self.state.load(Ordering::Acquire) {
                0 => "Open",
                1 => "Releasing",
                2 => "Freed",
                _ => "ReleaseUnconfirmed",
            }))''');p.write_text(t,encoding='utf-8',newline='\n')
s={'terminal':False,'production_applied':False,'commands':[],'ruling':'Original Array/SQLXML debug assertions observed state: Open; preserve textual Open/Freed while distinguishing in-progress and unconfirmed release. No state-machine or driver behavior change.'}
def save():(d/'summary.json').write_text(json.dumps(s,indent=2))
def run(name,c,ok=True,env=None):
 log=d/(name+'.log')
 with log.open('xb')as out:r=subprocess.run(c,env=env,stdout=out,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
 s['commands'].append({'name':name,'command':c,'exit_code':r.returncode,'log':str(log),'sha256':sha(log)});save();print(name,r.returncode,flush=True);assert (r.returncode==0)==ok
run('format',['C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin/rustfmt.exe','--edition','2021',str(p)])
def remap(c):
 out=[]
 for a in c:
  for name in ['rdbc','druid','wrapper']:a=a.replace(str(old/name),str(d/name))
  a=a.replace(str(b/'task7-wrapper-unit-candidate2'),str(d/'wrapper'));out.append(a)
 return out
old2=json.loads((old/'retry2.summary.json').read_text());old3=json.loads((old/'retry3.summary.json').read_text())
for name,record in [('rdbc',next(c for c in old2['commands']if c['name']=='retry2-full-rdbc-compile')),('druid',next(c for c in old2['commands']if c['name']=='retry2-full-druid-compile')),('wrapper',old3['commands'][0])]:
 c=remap(record['command']);env=os.environ.copy();env.update({'CARGO_MANIFEST_DIR':str(d/name),'CARGO_PKG_NAME':{'rdbc':'druid-rdbc','druid':'druid','wrapper':'druid-wrapper'}[name],'CARGO_PKG_VERSION':'0.0.0-design','CARGO_PKG_RUST_VERSION':'1.95'});run('full-'+name+'-compile',c,env=env)
ex=b/'task7-extended-resource-tests-candidate1';c=remap(json.loads((ex/'summary.json').read_text())['commands'][-2]['command']);c[c.index('-o')+1]=str(d/'extended.exe');run('extended-compile',c);run('extended-runtime-after-debug',[str(d/'extended.exe'),'--test-threads=1'],False)
s['terminal']=True;s['source_hashes']={p.relative_to(d).as_posix():sha(p) for p in d.rglob('*.rs')};save()
