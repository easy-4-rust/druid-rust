import json,hashlib,os,subprocess,shutil
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');d=b/'task7-resource-debug-candidate1';old=b/'task7-wrapper-buffered-candidate1';s={'terminal':False,'production_applied':False,'commands':[]};sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name,source in [('rdbc',old/'rdbc'),('druid',old/'druid'),('wrapper',b/'task7-wrapper-unit-candidate2')]:
 for p in source.rglob('*.json'):
  if 'assets' in p.parts or 'resources' in p.parts:
   target=d/name/p.relative_to(source);target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
def remap(c):
 return [a.replace(str(old),str(d)) for a in c]
def run(name,c,ok=True,env=None):
 log=d/('retry2-'+name+'.log')
 with log.open('xb')as out:r=subprocess.run(c,env=env,stdout=out,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
 s['commands'].append({'name':name,'command':c,'exit_code':r.returncode,'log':str(log),'sha256':sha(log)});(d/'retry2.summary.json').write_text(json.dumps(s,indent=2));print(name,r.returncode,flush=True);assert (r.returncode==0)==ok
c=remap(json.loads((old/'retry3.summary.json').read_text())['commands'][0]['command']);env=os.environ.copy();env.update({'CARGO_MANIFEST_DIR':str(d/'wrapper'),'CARGO_PKG_NAME':'druid-wrapper','CARGO_PKG_VERSION':'0.0.0-design','CARGO_PKG_RUST_VERSION':'1.95'});run('wrapper-compile',c,env=env)
ex=b/'task7-extended-resource-tests-candidate1';c=remap(json.loads((ex/'summary.json').read_text())['commands'][-2]['command']);c[c.index('-o')+1]=str(d/'extended.exe');run('extended-compile',c);run('extended-runtime-after-debug',[str(d/'extended.exe'),'--test-threads=1'],False)
s['terminal']=True;(d/'retry2.summary.json').write_text(json.dumps(s,indent=2))
