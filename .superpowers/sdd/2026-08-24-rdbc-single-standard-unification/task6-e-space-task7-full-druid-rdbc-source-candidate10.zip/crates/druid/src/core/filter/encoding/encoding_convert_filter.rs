//! 对应 Java：`com.alibaba.druid.filter.encoding.EncodingConvertFilter`。

use super::CharsetConvert;
use crate::core::{
    AfterFilter, BeforeFilter, ClobFilterChain, DruidError, ExecContext, ExecResult, RdbcReader,
    RdbcString, ResultSetFilter, Value,
};
use parking_lot::RwLock;
use std::collections::HashMap;
use std::time::Duration;

/// RDBC SQL、参数和结果字符编码转换 Filter。
///
/// 本对象实现 Java 的字符串/Reader 值转换以及 `ResultSet` around-chain。
/// SQL prepare/execute 入参的生产接线由连接/Statement `FilterChain` 继续承接，
/// 不能把此对象的存在误记为整个 `SEM-FLT-015` 已完成。
#[derive(Debug)]
pub struct EncodingConvertFilter {
    charset_convert: RwLock<CharsetConvert>,
}

impl EncodingConvertFilter {
    /// Java 连接属性中保存转换器的键。
    pub const ATTR_CHARSET_CONVERTER: &'static str = "ali.charset.converter";
    /// 客户端编码配置键。
    pub const CLIENT_ENCODING_KEY: &'static str = "clientEncoding";
    /// 服务端编码配置键。
    pub const SERVER_ENCODING_KEY: &'static str = "serverEncoding";

    /// 创建固定于一个物理连接配置的转换 Filter。
    pub fn new(
        client_encoding: Option<&str>,
        server_encoding: Option<&str>,
    ) -> Result<Self, DruidError> {
        Ok(Self {
            charset_convert: RwLock::new(CharsetConvert::new(client_encoding, server_encoding)?),
        })
    }

    /// 编码 SQL 或字符串参数。
    pub fn encode(&self, value: &str) -> Result<String, DruidError> {
        self.charset_convert.read().encode(value)
    }

    /// 解码字符串结果。
    pub fn decode(&self, value: &str) -> Result<String, DruidError> {
        self.charset_convert.read().decode(value)
    }

    /// 编码 RDBC 标量参数；非字符串值原样返回。
    pub fn encode_value(&self, value: Value) -> Result<Value, DruidError> {
        match value {
            Value::String(value) => self.encode(&value).map(Value::String),
            value => Ok(value),
        }
    }

    /// 解码 RDBC 标量结果；非字符串值原样返回。
    pub fn decode_value(&self, value: Value) -> Result<Value, DruidError> {
        match value {
            Value::String(value) => self.decode(&value).map(Value::String),
            value => Ok(value),
        }
    }

    fn encode_rdbc_string(&self, value: &RdbcString) -> Result<RdbcString, DruidError> {
        let value = String::from_utf16_lossy(value.as_utf16());
        self.encode(&value).map(RdbcString::from)
    }

    fn decode_rdbc_string(&self, value: RdbcString) -> Result<RdbcString, DruidError> {
        let value = String::from_utf16_lossy(value.as_utf16());
        self.decode(&value).map(RdbcString::from)
    }
}

impl Clone for EncodingConvertFilter {
    fn clone(&self) -> Self {
        Self {
            charset_convert: RwLock::new(self.charset_convert.read().clone()),
        }
    }
}

#[async_trait::async_trait]
impl BeforeFilter for EncodingConvertFilter {
    fn name(&self) -> &str {
        "encoding"
    }

    async fn before(&self, context: &mut ExecContext<'_>) -> Result<(), DruidError> {
        context.sql = self.encode(&context.sql)?;
        Ok(())
    }

    fn prepare_statement_sql(&self, sql: &str) -> Result<String, DruidError> {
        self.encode(sql)
    }

    fn statement_add_batch_sql(&self, sql: &str) -> Result<String, DruidError> {
        self.encode(sql)
    }

    fn config_from_properties(
        &self,
        properties: &HashMap<String, String>,
    ) -> Result<(), DruidError> {
        let client = properties
            .get(Self::CLIENT_ENCODING_KEY)
            .map(String::as_str);
        let server = properties
            .get(Self::SERVER_ENCODING_KEY)
            .map(String::as_str);
        *self.charset_convert.write() = CharsetConvert::new(client, server)?;
        Ok(())
    }

    async fn clob_position_string(
        &self,
        chain: &mut ClobFilterChain<'_>,
        pattern: &RdbcString,
        start: i64,
    ) -> Result<Option<i64>, DruidError> {
        let pattern = self.encode_rdbc_string(pattern)?;
        chain.clob_position_string(&pattern, start).await
    }

    async fn clob_get_sub_string(
        &self,
        chain: &mut ClobFilterChain<'_>,
        position: i64,
        length: i32,
    ) -> Result<RdbcString, DruidError> {
        self.decode_rdbc_string(chain.clob_get_sub_string(position, length).await?)
    }

    async fn clob_get_character_stream(
        &self,
        chain: &mut ClobFilterChain<'_>,
    ) -> Result<RdbcReader, DruidError> {
        let text = chain.clob_get_character_stream().await?.read_to_string()?;
        self.decode(&text).map(RdbcReader::from_string)
    }

    async fn clob_get_character_stream_range(
        &self,
        chain: &mut ClobFilterChain<'_>,
        position: i64,
        length: i64,
    ) -> Result<RdbcReader, DruidError> {
        let text = chain
            .clob_get_character_stream_range(position, length)
            .await?
            .read_to_string()?;
        self.decode(&text).map(RdbcReader::from_string)
    }

    async fn clob_set_string(
        &self,
        chain: &mut ClobFilterChain<'_>,
        position: i64,
        value: &RdbcString,
    ) -> Result<i32, DruidError> {
        let value = self.encode_rdbc_string(value)?;
        chain.clob_set_string(position, &value).await
    }

    async fn clob_set_string_range(
        &self,
        chain: &mut ClobFilterChain<'_>,
        position: i64,
        value: &RdbcString,
        offset: i32,
        length: i32,
    ) -> Result<i32, DruidError> {
        let value = self.encode_rdbc_string(value)?;
        chain
            .clob_set_string_range(position, &value, offset, length)
            .await
    }
}

#[async_trait::async_trait]
impl AfterFilter for EncodingConvertFilter {
    fn name(&self) -> &str {
        "encoding"
    }

    async fn after(
        &self,
        _context: &ExecContext<'_>,
        _result: &Result<ExecResult, DruidError>,
        _elapsed: Duration,
    ) -> Result<(), DruidError> {
        Ok(())
    }
}

impl ResultSetFilter for EncodingConvertFilter {}
