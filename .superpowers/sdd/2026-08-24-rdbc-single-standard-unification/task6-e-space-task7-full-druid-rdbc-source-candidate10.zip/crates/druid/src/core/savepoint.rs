//! `Savepoint` 旧路径的定向兼容入口。

pub use druid_rdbc::types::Savepoint;
