"""Migrate six real Callable fixtures while preserving complete original matrix source."""
import hashlib,json,re,shutil,subprocess
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');repo=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust')
d=b/'task7-callable-resource-tests-candidate1';assert not d.exists();d.mkdir();shutil.copytree(repo/'crates/druid/tests',d/'tests')
c=b/'task7-wrapper-buffered-candidate1';s=json.loads((c/'retry3.summary.json').read_text());assert s['terminal']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
state={'terminal':False,'production_applied':False,'commands':[],'source_before':{p.relative_to(d).as_posix():sha(p)for p in(d/'tests').rglob('*.rs')}}
def save():(d/'summary.json').write_text(json.dumps(state,indent=2)+'\n',encoding='utf-8')
def run(name,cmd,expected):
    log=d/(name+'.log')
    with log.open('xb')as out:r=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
    state['commands'].append({'name':name,'command':cmd,'exit_code':r.returncode,'log':str(log),'log_sha256':sha(log)});save();print(name,r.returncode,flush=True);assert (r.returncode==0)==expected,name
    return log.read_text(encoding='utf-8',errors='strict')
cmd=list(s['commands'][1]['command']);cmd[cmd.index('--test')+3]=str(d/'tests/task6_callable_canonical_matrix_test.rs')
for i,arg in enumerate(cmd):
    if arg.startswith('druid_wrapper='):cmd[i]='druid='+str(c/'druid/libdruid.rlib')
cmd[cmd.index('-o')+1]=str(d/'callable.exe')
libcmd=next(x['command']for x in json.loads((c/'retry2.summary.json').read_text())['commands']if x['name']=='retry2-full-druid-compile')
existing={cmd[i+1].split('=')[0]for i,x in enumerate(cmd)if x=='--extern'}
for i,x in enumerate(libcmd):
    if x=='--extern'and libcmd[i+1].split('=')[0]not in existing:cmd+=['--extern',libcmd[i+1]]
red=run('original-callable-compile',cmd,False);assert 'E0432'in red and 'RdbcArrayAccess'in red
folder=d/'tests/callable_overload_support';changed=[]
mapping={'blob':'Blob','clob':'Clob','ref':'Ref','sql_xml':'SqlXml','array':'Array'}
for label,trait in mapping.items():
    p=folder/('test_'+label+'_access.rs');text=p.read_text();driver='Test'+trait+'Access'
    first='impl RdbcResourceAccess for '+driver+' {';second='}\n\n#[async_trait::async_trait]\nimpl Rdbc'+trait+'Access for '+driver+' {'
    assert text.count(first)==1 and text.count(second)==1
    text=text.replace(first,'impl '+trait+' for '+driver+' {').replace(second,'')
    if trait in ['Array','SqlXml']:
        needle='impl '+trait+' for '+driver+' {';text=text.replace(needle,needle+'\n    // 原夹具无外部资源，保留原默认free的幂等成功语义。\n    async fn free(&mut self) -> Result<(), RdbcError> { Ok(()) }')
    for old,new in[('RdbcArrayAccess','Array'),('RdbcBlobAccess','Blob'),('RdbcClobAccess','Clob'),('RdbcNClobAccess','NClob'),('RdbcRefAccess','Ref'),('RdbcSqlXmlAccess','SqlXml')]:text=text.replace(old,new)
    text=text.replace('RdbcResourceAccess,','')
    text=re.sub(r'(async fn\s+\w+\s*\(\s*)&self',r'\1&mut self',text)
    text=text.replace('Arc::new('+driver,'Box::new('+driver)
    if trait in ['Blob','Clob']:
        pattern_type=trait+'Pattern';text=text.replace('pattern: &Rdbc'+trait+',','pattern: '+pattern_type+'<\'_>,')
        # Keep existing driver-side materialization for Other; add sound self-pattern handling.
        start=text.index('        let length = i32::try_from(pattern.length().await?)',text.index('async fn position_'+label))
        end=text.index('        self.position_',start)
        previous=text[start:end];value_name='bytes'if trait=='Blob'else'value';getter='get_bytes'if trait=='Blob'else'get_sub_string'
        self_branch=previous.replace('pattern.length()','self.length()').replace('pattern.'+getter+'(','self.'+getter+'(')
        text=text[:start]+'        let '+value_name+' = match pattern {\n            '+pattern_type+'::SameResource => {\n'+self_branch+'                '+value_name+'\n            },\n            '+pattern_type+'::Other(pattern) => {\n'+previous+'                '+value_name+'\n            },\n        };\n'+text[end:]
        text=text.replace('use druid_rdbc::error::RdbcError;','use druid_rdbc::error::RdbcError;\nuse druid_rdbc::resource::'+pattern_type+';')
        text=text.replace('ResourceOperations::'+label+'()','ResourceOperations::READ | ResourceOperations::RANGE | ResourceOperations::STREAM | ResourceOperations::SEARCH | ResourceOperations::FREE')
    elif trait=='Array':text=text.replace('ResourceOperations::array()','ResourceOperations::READ | ResourceOperations::RANGE | ResourceOperations::TYPE_MAP | ResourceOperations::FREE')
    elif trait=='SqlXml':text=text.replace('_representation: &RdbcXmlRepresentationType,','_representation: Option<&RdbcXmlRepresentationType>,')
    assert not re.search(r'Rdbc(?:Resource|Blob|Clob|NClob|Ref|Array|SqlXml)Access',text)
    p.write_text(text,encoding='utf-8',newline='\n');changed.append(p)
p=folder/'test_callable_statement.rs';text=p.read_text()
for old,new in[('RdbcArrayAccess','Array'),('RdbcBlobAccess','Blob'),('RdbcClobAccess','Clob'),('RdbcNClobAccess','NClob'),('RdbcRefAccess','Ref'),('RdbcSqlXmlAccess','SqlXml')]:text=text.replace(old,new)
text=text.replace('RdbcResourceAccess,','')
for driver in['TestRefAccess','TestArrayAccess','TestSqlXmlAccess']:text=text.replace('Arc::new('+driver+')','Box::new('+driver+')')
p.write_text(text,encoding='utf-8',newline='\n');changed.append(p)
run('fixture-format',['C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin/rustfmt.exe','--edition','2021']+[str(p)for p in changed],True)
state['source_after']={p.relative_to(d).as_posix():sha(p)for p in(d/'tests').rglob('*.rs')};state['changed']=[p for p in state['source_before']if state['source_before'][p]!=state['source_after'][p]];assert len(state['changed'])==6
assert (d/'tests/task6_callable_canonical_matrix_test.rs').read_bytes()==(repo/'crates/druid/tests/task6_callable_canonical_matrix_test.rs').read_bytes();save()
run('standard-callable-compile',cmd,True);run('complete-callable-runtime',[str(d/'callable.exe'),'--test-threads=1'],True)
state['terminal']=True;state['exe_sha256']=sha(d/'callable.exe');save()
