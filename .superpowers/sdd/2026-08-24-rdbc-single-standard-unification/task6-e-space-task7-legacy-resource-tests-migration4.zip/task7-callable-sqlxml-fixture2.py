"""Keep original selector payload tests; explicitly prove independent SQLXML values and alias state."""
import hashlib,json,shutil,subprocess
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');d=b/'task7-callable-resource-tests-candidate1';repo=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads((d/'summary.json').read_text());assert old['commands'][-1]['exit_code']==101 and 'HY010'in Path(old['commands'][-1]['log']).read_text()
state={'terminal':False,'production_applied':False,'commands':[],'ruling':'Original indexed/named XML observations request two independent values. Old fixture gratuitously aliased them despite mandatory one-shot read. Distinct OUT entries retain identical payload; per-selector clone identity/read/free remains shared and explicitly tested.'}
def save():(d/'sqlxml-fixture2.summary.json').write_text(json.dumps(state,indent=2)+'\n',encoding='utf-8')
def run(name,cmd,expected):
    log=d/('sqlxml-fixture2-'+name+'.log')
    with log.open('xb')as out:r=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
    state['commands'].append({'name':name,'command':cmd,'exit_code':r.returncode,'log':str(log),'log_sha256':sha(log)});save();print(name,r.returncode,flush=True);assert (r.returncode==0)==expected,name
p=d/'tests/task6_callable_canonical_matrix_test.rs';original=repo/'crates/druid/tests/task6_callable_canonical_matrix_test.rs';assert p.read_bytes()==original.read_bytes();shutil.copyfile(p,d/'callable-matrix.original.rs')
extra='''
/// 同一OUT对象的克隆共享状态；不同OUT值各自持有一次性SQLXML读取机会。
#[tokio::test]
async fn callable_sqlxml_out_values_preserve_independence_and_per_selector_alias_state() {
    let driver = callable_overload_support::TestCallableStatement::new(
        "{call xml()}", std::sync::Arc::new(callable_overload_support::TestCallableState::default()));
    let index = CallableParameter::by_index(19).unwrap();
    let name = CallableParameter::by_name("sql_xml").unwrap();
    let indexed = driver.sql_xml_out_parameter(&index).unwrap().unwrap();
    let indexed_alias = driver.sql_xml_out_parameter(&index).unwrap().unwrap();
    let named = driver.sql_xml_out_parameter(&name).unwrap().unwrap();
    let named_alias = driver.sql_xml_out_parameter(&name).unwrap().unwrap();
    assert_eq!(indexed, indexed_alias);
    assert_eq!(named, named_alias);
    assert_ne!(indexed, named);
    assert_eq!(indexed.string().await.unwrap().to_rust_string().unwrap(), "<x/>");
    assert_eq!(indexed_alias.binary_stream().await.expect_err("same XML cannot be read twice").sql_state(), Some("HY010"));
    indexed.free().await.unwrap();
    assert!(indexed_alias.is_freed());
    assert!(!named.is_freed());
    assert_eq!(named.binary_stream().await.unwrap().read_to_end().unwrap(), b"<x/>");
    assert_eq!(named_alias.string().await.expect_err("named alias shares consumed read").sql_state(), Some("HY010"));
    named.free().await.unwrap();
    assert!(named_alias.is_freed());
}
'''
p.write_bytes(original.read_bytes()+extra.encode());state['original_matrix_sha256']=sha(original);state['expanded_matrix_sha256']=sha(p)
compile_cmd=old['commands'][-2]['command'];assert old['commands'][-2]['name']=='standard-callable-compile'
run('expanded-compile-before-fix',compile_cmd,True)
run('independence-red',[str(d/'callable.exe'),'--exact','callable_sqlxml_out_values_preserve_independence_and_per_selector_alias_state','--test-threads=1'],False)
fixture=d/'tests/callable_overload_support/test_callable_statement.rs';shutil.copyfile(fixture,d/'test_callable_statement.before-sqlxml2.rs');text=fixture.read_text();needle='RdbcObject::SqlXml(sql_xml),';assert text.count(needle)==1
fixture.write_text(text.replace(needle,'// 名称OUT独立拥有同内容SQLXML；不能复用已由索引读取的对象。\n                    RdbcObject::SqlXml(ResourceHandleFactory::sql_xml(Box::new(TestSqlXmlAccess))),'),encoding='utf-8',newline='\n')
run('fixture-format',['C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin/rustfmt.exe','--edition','2021',str(fixture)],True)
assert p.read_bytes().startswith(original.read_bytes()) and sha(original)==state['original_matrix_sha256']
run('expanded-compile-after-fix',compile_cmd,True);run('expanded-full-runtime',[str(d/'callable.exe'),'--test-threads=1'],True)
state['source_after']={p.relative_to(d).as_posix():sha(p)for p in(d/'tests').rglob('*.rs')};state['exe_sha256']=sha(d/'callable.exe');state['terminal']=True;save()
