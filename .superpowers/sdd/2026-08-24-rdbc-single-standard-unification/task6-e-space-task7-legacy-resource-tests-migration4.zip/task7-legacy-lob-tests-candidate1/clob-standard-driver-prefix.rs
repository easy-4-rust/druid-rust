//! java.sql.Clob/NClob 与 java.io.Reader/Writer 的资源语义契约。

use druid::core::{
    CharacterReader, CharacterWriter, RdbcClob, RdbcError, RdbcInputStream, RdbcNClob, RdbcObject,
    RdbcOutputStream, RdbcReader, RdbcString, RdbcWriter,
};
use druid::core::{ResourceHandleFactory, ResourceOperations};
use druid_rdbc::resource::{Clob, ClobPattern, NClob};
use std::io::{Error, Write};
use std::sync::{Arc, Mutex};

#[derive(Debug)]
struct ClobState {
    code_units: Vec<u16>,
    freed: bool,
}

#[derive(Debug)]
struct InMemoryClobAccess {
    state: Arc<Mutex<ClobState>>,
}

impl InMemoryClobAccess {
    fn new(value: RdbcString) -> Self {
        Self {
            state: Arc::new(Mutex::new(ClobState {
                code_units: value.as_utf16().to_vec(),
                freed: false,
            })),
        }
    }

    fn state(&self) -> std::sync::MutexGuard<'_, ClobState> {
        self.state
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
    }

    fn checked_start(state: &ClobState, position: i64) -> Result<usize, RdbcError> {
        if state.freed {
            return Err(RdbcError::DriverError("Clob has been freed".to_string()));
        }
        let start = position
            .checked_sub(1)
            .and_then(|value| usize::try_from(value).ok())
            .ok_or_else(|| RdbcError::DriverError("Clob position must be one-based".to_string()))?;
        if start > state.code_units.len() {
            return Err(RdbcError::DriverError(
                "Clob position exceeds its length".to_string(),
            ));
        }
        Ok(start)
    }

    fn checked_length(length: i64) -> Result<usize, RdbcError> {
        usize::try_from(length)
            .map_err(|_| RdbcError::DriverError("Clob length must be non-negative".to_string()))
    }

    fn write_units(
        state: &mut ClobState,
        position: usize,
        code_units: &[u16],
    ) -> Result<usize, RdbcError> {
        if state.freed {
            return Err(RdbcError::DriverError("Clob has been freed".to_string()));
        }
        let end = position
            .checked_add(code_units.len())
            .ok_or_else(|| RdbcError::DriverError("Clob write range overflow".to_string()))?;
        if end > state.code_units.len() {
            state.code_units.resize(end, 0);
        }
        state.code_units[position..end].copy_from_slice(code_units);
        Ok(code_units.len())
    }
}

#[derive(Debug)]
struct ClobCharacterWriter {
    state: Arc<Mutex<ClobState>>,
    position: usize,
}

impl CharacterWriter for ClobCharacterWriter {
    fn write_utf16(&mut self, code_units: &[u16]) -> Result<usize, RdbcError> {
        let mut state = self
            .state
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner);
        let length = InMemoryClobAccess::write_units(&mut state, self.position, code_units)?;
        self.position += length;
        Ok(length)
    }

    fn flush(&mut self) -> Result<(), RdbcError> {
        Ok(())
    }

    fn close(&mut self) -> Result<(), RdbcError> {
        Ok(())
    }
}

struct ClobAsciiWriter {
    state: Arc<Mutex<ClobState>>,
    position: usize,
}

impl Write for ClobAsciiWriter {
    fn write(&mut self, bytes: &[u8]) -> std::io::Result<usize> {
        let code_units = bytes
            .iter()
            .map(|value| u16::from(*value))
            .collect::<Vec<_>>();
        let mut state = self
            .state
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner);
        let length = InMemoryClobAccess::write_units(&mut state, self.position, &code_units)
            .map_err(|error| Error::other(error.to_string()))?;
        self.position += length;
        Ok(length)
    }

    fn flush(&mut self) -> std::io::Result<()> {
        Ok(())
    }
}

#[async_trait::async_trait]
impl Clob for InMemoryClobAccess {
    fn capabilities(&self) -> ResourceOperations {
        ResourceOperations::clob()
    }

    async fn free(&mut self) -> Result<(), RdbcError> {
        let mut state = self.state();
        state.freed = true;
        state.code_units.clear();
        Ok(())
    }

    async fn length(&mut self) -> Result<i64, RdbcError> {
        let state = self.state();
        if state.freed {
            return Err(RdbcError::DriverError("Clob has been freed".to_string()));
        }
        i64::try_from(state.code_units.len())
            .map_err(|_| RdbcError::DriverError("Clob length exceeds i64".to_string()))
    }

    async fn get_sub_string(
        &mut self,
        position: i64,
        length: i32,
    ) -> Result<RdbcString, RdbcError> {
        let state = self.state();
        let start = Self::checked_start(&state, position)?;
        let length = Self::checked_length(i64::from(length))?;
        let end = start
            .checked_add(length)
            .map(|value| value.min(state.code_units.len()))
            .ok_or_else(|| RdbcError::DriverError("Clob range overflow".to_string()))?;
        Ok(RdbcString::from_utf16(
            state.code_units[start..end].to_vec(),
        ))
    }

    async fn get_character_stream(&mut self) -> Result<RdbcReader, RdbcError> {
        let state = self.state();
        if state.freed {
            return Err(RdbcError::DriverError("Clob has been freed".to_string()));
        }
        Ok(RdbcReader::from_utf16(state.code_units.clone()))
    }

    async fn get_ascii_stream(&mut self) -> Result<RdbcInputStream, RdbcError> {
        let state = self.state();
        if state.freed {
            return Err(RdbcError::DriverError("Clob has been freed".to_string()));
        }
        let bytes = state
            .code_units
            .iter()
            .map(|value| {
                u8::try_from(*value).map_err(|_| {
                    RdbcError::DriverError("test Clob contains non-ASCII data".to_string())
                })
            })
            .collect::<Result<Vec<_>, _>>()?;
        Ok(RdbcInputStream::from_bytes(bytes))
    }

    async fn position_string(
        &mut self,
        pattern: &RdbcString,
        start: i64,
    ) -> Result<Option<i64>, RdbcError> {
        let state = self.state();
        let start = Self::checked_start(&state, start)?;
        let pattern = pattern.as_utf16();
        let position = if pattern.is_empty() {
            Some(start)
        } else {
            state.code_units[start..]
                .windows(pattern.len())
                .position(|window| window == pattern)
                .map(|position| start + position)
        };
        position
            .map(|position| {
                i64::try_from(position + 1)
                    .map_err(|_| RdbcError::DriverError("Clob position exceeds i64".to_string()))
            })
            .transpose()
    }

    async fn position_clob(
        &mut self,
        pattern: ClobPattern<'_>,
        start: i64,
    ) -> Result<Option<i64>, RdbcError> {
        // 保留UTF-16模式与1-based搜索，驱动自行处理自身模式。
        let value = match pattern {
            ClobPattern::SameResource => {
                let length = i32::try_from(self.length().await?)
                    .map_err(|_| RdbcError::DriverError("pattern Clob is too large".to_string()))?;
                self.get_sub_string(1, length).await?
            }
            ClobPattern::Other(pattern) => {
                let length = i32::try_from(pattern.length().await?)
                    .map_err(|_| RdbcError::DriverError("pattern Clob is too large".to_string()))?;
                pattern.get_sub_string(1, length).await?
            }
        };
        self.position_string(&value, start).await
    }

    async fn set_string(&mut self, position: i64, value: &RdbcString) -> Result<i32, RdbcError> {
        let length = i32::try_from(value.len())
            .map_err(|_| RdbcError::DriverError("Clob write is too large".to_string()))?;
        self.set_string_range(position, value, 0, length).await
    }

    async fn set_string_range(
        &mut self,
        position: i64,
        value: &RdbcString,
        offset: i32,
        length: i32,
    ) -> Result<i32, RdbcError> {
        let mut state = self.state();
        let position = Self::checked_start(&state, position)?;
        let offset = Self::checked_length(i64::from(offset))?;
        let length = Self::checked_length(i64::from(length))?;
        let source_end = offset
            .checked_add(length)
            .filter(|end| *end <= value.len())
            .ok_or_else(|| RdbcError::DriverError("Clob source range is invalid".to_string()))?;
        Self::write_units(&mut state, position, &value.as_utf16()[offset..source_end])?;
        i32::try_from(length)
            .map_err(|_| RdbcError::DriverError("Clob write exceeds i32".to_string()))
    }

    async fn set_ascii_stream(&mut self, position: i64) -> Result<RdbcOutputStream, RdbcError> {
        let state = self.state();
        let position = Self::checked_start(&state, position)?;
        drop(state);
        Ok(RdbcOutputStream::new(ClobAsciiWriter {
            state: self.state.clone(),
            position,
        }))
    }

    async fn set_character_stream(&mut self, position: i64) -> Result<RdbcWriter, RdbcError> {
        let state = self.state();
        let position = Self::checked_start(&state, position)?;
        drop(state);
        Ok(RdbcWriter::new(ClobCharacterWriter {
            state: self.state.clone(),
            position,
        }))
    }

    async fn truncate(&mut self, length: i64) -> Result<(), RdbcError> {
        let mut state = self.state();
        if state.freed {
            return Err(RdbcError::DriverError("Clob has been freed".to_string()));
        }
        let length = Self::checked_length(length)?;
        if length > state.code_units.len() {
            return Err(RdbcError::DriverError(
                "Clob truncate length exceeds current length".to_string(),
            ));
        }
        state.code_units.truncate(length);
        Ok(())
    }

    async fn get_character_stream_range(
        &mut self,
        position: i64,
        length: i64,
    ) -> Result<RdbcReader, RdbcError> {
        let state = self.state();
        let start = Self::checked_start(&state, position)?;
        let length = Self::checked_length(length)?;
        let end = start
            .checked_add(length)
            .filter(|end| *end <= state.code_units.len())
            .ok_or_else(|| RdbcError::DriverError("Clob range is invalid".to_string()))?;
        Ok(RdbcReader::from_utf16(
            state.code_units[start..end].to_vec(),
        ))
    }
}

impl NClob for InMemoryClobAccess {}

fn clob(value: impl Into<RdbcString>) -> RdbcClob {
    ResourceHandleFactory::clob(Box::new(InMemoryClobAccess::new(value.into())))
}

fn n_clob(value: impl Into<RdbcString>) -> RdbcNClob {
    ResourceHandleFactory::n_clob(Box::new(InMemoryClobAccess::new(value.into())))
}

#[derive(Debug)]
struct FailingReader {
    fail_close: bool,
}

impl CharacterReader for FailingReader {
    fn read_utf16(&mut self, _buffer: &mut [u16]) -> Result<usize, RdbcError> {
        Err(RdbcError::DriverError(
            "injected Reader failure".to_string(),
        ))
    }

    fn close(&mut self) -> Result<(), RdbcError> {
        if self.fail_close {
            Err(RdbcError::DriverError(
                "injected Reader close failure".to_string(),
            ))
        } else {
            Ok(())
        }
    }
}

#[derive(Debug)]
struct FailingWriter;

impl CharacterWriter for FailingWriter {
    fn write_utf16(&mut self, _code_units: &[u16]) -> Result<usize, RdbcError> {
        Err(RdbcError::DriverError(
            "injected Writer failure".to_string(),
        ))
    }

    fn flush(&mut self) -> Result<(), RdbcError> {
        Err(RdbcError::DriverError(
            "injected Writer flush failure".to_string(),
        ))
    }

    fn close(&mut self) -> Result<(), RdbcError> {
        Err(RdbcError::DriverError(
            "injected Writer close failure".to_string(),
        ))
    }
}
