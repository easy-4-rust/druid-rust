"""Migrate original Blob/Clob test drivers; keep every original test-body byte."""
import hashlib,json,os,re,subprocess
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');repo=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust')
dest=b/'task7-legacy-lob-tests-candidate1';assert not dest.exists();dest.mkdir()
candidate=b/'task7-wrapper-buffered-candidate1'
prior=json.loads((candidate/'retry3.summary.json').read_text());assert prior['terminal']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
state={'terminal':False,'production_applied':False,'commands':[],'files':{}}
def save():(dest/'summary.json').write_text(json.dumps(state,indent=2)+'\n',encoding='utf-8')
def run(name,cmd,expect):
    log=dest/(name+'.log')
    with log.open('xb')as out:r=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
    state['commands'].append({'name':name,'command':cmd,'exit_code':r.returncode,'log':str(log),'log_sha256':sha(log)});save();print(name,r.returncode,flush=True)
    assert (r.returncode==0)==expect,name
    return log.read_text(encoding='utf-8',errors='strict')
original_command=prior['commands'][1]['command'];rust=original_command[0]
def command(source,output):
    cmd=list(original_command);cmd[cmd.index('--test')+3]=str(source)
    for i,arg in enumerate(cmd):
        if arg.startswith('druid_wrapper='):cmd[i]='druid='+str(candidate/'druid/libdruid.rlib')
    cmd[cmd.index('-o')+1]=str(output);return cmd
for label in['blob','clob']:
    original=repo/('crates/druid/tests/rdbc_'+label+'_test.rs');raw=original.read_bytes();source=dest/original.name;source.write_bytes(raw)
    red=run(label+'-old-interface-compile',command(source,dest/(label+'-red.exe')),False)
    assert 'E0432'in red and ('Rdbc'+label.title()+'Access')in red
    tail=raw[raw.index(b'#[test]'):];text=raw[:raw.index(b'#[test]')].decode().replace('\r\n','\n')
    trait=label.title();driver='InMemory'+trait+'Access'
    if label=='blob':
        text=text.replace('use druid::core::{RdbcBlobAccess, RdbcResourceAccess, ResourceHandleFactory, ResourceOperations};','use druid_rdbc::resource::{Blob, BlobPattern};\nuse druid::core::{ResourceHandleFactory, ResourceOperations};')
    else:
        text=text.replace('RdbcClobAccess, RdbcNClobAccess, RdbcResourceAccess, ResourceHandleFactory, ResourceOperations,','ResourceHandleFactory, ResourceOperations,')
        text=text.replace('use std::io::{Error, Write};','use druid_rdbc::resource::{Clob, NClob, ClobPattern};\nuse std::io::{Error, Write};')
    first='impl RdbcResourceAccess for '+driver+' {';second='}\n\n#[async_trait::async_trait]\nimpl Rdbc'+trait+'Access for '+driver+' {'
    assert text.count(first)==1 and text.count(second)==1
    text=text.replace(first,'impl '+trait+' for '+driver+' {').replace(second,'')
    text=re.sub(r'(async fn\s+\w+\s*\(\s*)&self',r'\1&mut self',text)
    text=text.replace('pattern: &Rdbc'+trait+',','pattern: '+trait+'Pattern<\'_>,')
    if label=='blob':
        before='''        let length = pattern.length().await?;
        let length = i32::try_from(length)
            .map_err(|_| RdbcError::DriverError("pattern Blob is too large".to_string()))?;
        let bytes = pattern.get_bytes(1, length).await?;'''
        after='''        // 驱动夹具自行读取模式；共享值句柄保留标准对象及自身别名。
        let bytes = match pattern {
            BlobPattern::SameResource => {
                let length = i32::try_from(self.length().await?).map_err(|_| RdbcError::DriverError("pattern Blob is too large".to_string()))?;
                self.get_bytes(1, length).await?
            }
            BlobPattern::Other(pattern) => {
                let length = i32::try_from(pattern.length().await?).map_err(|_| RdbcError::DriverError("pattern Blob is too large".to_string()))?;
                pattern.get_bytes(1, length).await?
            }
        };'''
    else:
        before='''        let length = i32::try_from(pattern.length().await?)
            .map_err(|_| RdbcError::DriverError("pattern Clob is too large".to_string()))?;
        let value = pattern.get_sub_string(1, length).await?;'''
        after='''        // 保留UTF-16模式与1-based搜索，驱动自行处理自身模式。
        let value = match pattern {
            ClobPattern::SameResource => {
                let length = i32::try_from(self.length().await?).map_err(|_| RdbcError::DriverError("pattern Clob is too large".to_string()))?;
                self.get_sub_string(1, length).await?
            }
            ClobPattern::Other(pattern) => {
                let length = i32::try_from(pattern.length().await?).map_err(|_| RdbcError::DriverError("pattern Clob is too large".to_string()))?;
                pattern.get_sub_string(1, length).await?
            }
        };'''
        text=text.replace('impl RdbcNClobAccess for '+driver+' {}','impl NClob for '+driver+' {}')
    assert text.count(before)==1;text=text.replace(before,after)
    text=text.replace('Arc::new('+driver+'::new','Box::new('+driver+'::new')
    assert not re.search(r'Rdbc(?:Resource|Blob|Clob|NClob)Access',text)
    prefix=dest/(label+'-standard-driver-prefix.rs');prefix.write_text(text,encoding='utf-8',newline='\n')
    run(label+'-driver-format',['C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin/rustfmt.exe','--edition','2021',str(prefix)],True)
    source.write_bytes(prefix.read_bytes()+tail)
    assert source.read_bytes().endswith(tail) and sha(original)==hashlib.sha256(raw).hexdigest()
    state['files'][label]={'original_sha256':sha(original),'migrated_sha256':sha(source),'test_suffix_sha256':hashlib.sha256(tail).hexdigest(),'test_suffix_bytes':len(tail),'original_test_names':re.findall(rb'(?:async )?fn (\w+)\(',tail).decode()if False else re.findall(r'(?:async )?fn (\w+)\(',tail.decode())};save()
    run(label+'-standard-compile',command(source,dest/(label+'-green.exe')),True)
    run(label+'-standard-runtime',[str(dest/(label+'-green.exe')),'--test-threads=1'],True)
state['terminal']=True;save()
