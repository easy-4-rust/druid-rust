"""Keep original release counter and capability assertions with owned standard resources."""
import hashlib,json,re,subprocess
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');repo=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust');c=b/'task7-wrapper-buffered-candidate1'
d=b/'task7-resource-context-tests-candidate1';assert not d.exists();d.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
original=repo/'crates/druid/tests/rdbc_resource_context_test.rs';p=d/original.name;p.write_bytes(original.read_bytes())
s=json.loads((c/'retry3.summary.json').read_text());cmd=list(s['commands'][1]['command']);cmd[cmd.index('--test')+3]=str(p);cmd[cmd.index('-o')+1]=str(d/'context.exe')
for i,arg in enumerate(cmd):
    if arg.startswith('druid_wrapper='):cmd[i]='druid='+str(c/'druid/libdruid.rlib')
state={'terminal':False,'production_applied':False,'commands':[],'original_sha256':sha(original)}
def save():(d/'summary.json').write_text(json.dumps(state,indent=2)+'\n',encoding='utf-8')
def run(name,cmd,expect):
    log=d/(name+'.log')
    with log.open('xb')as out:r=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
    state['commands'].append({'name':name,'command':cmd,'exit_code':r.returncode,'log':str(log),'log_sha256':sha(log)});save();print(name,r.returncode,flush=True);assert (r.returncode==0)==expect,name
    return log.read_text(encoding='utf-8')
assert 'E0432'in run('old-interface-compile',cmd,False)
text=original.read_text();text=text.replace('RdbcBlobAccess, RdbcRefAccess, RdbcResourceAccess, ResourceHandleFactory, ResourceOperations,','ResourceHandleFactory, ResourceOperations,')
text='use druid_rdbc::resource::{Blob, BlobPattern, Ref, RdbcInputStream, RdbcOutputStream};\n'+text
for driver,trait in[('CountingAccess','Blob'),('ReadOnlyRefAccess','Ref')]:
    first='impl RdbcResourceAccess for '+driver+' {';second='}\n\n#[async_trait::async_trait]\nimpl Rdbc'+trait+'Access for '+driver+' {'
    assert text.count(first)==1 and text.count(second)==1;text=text.replace(first,'impl '+trait+' for '+driver+' {').replace(second,'')
text=re.sub(r'(async fn\s+\w+\s*\(\s*)&self',r'\1&mut self',text)
text=text.replace('free_count: AtomicUsize,','free_count: Arc<AtomicUsize>,').replace('free_count: AtomicUsize::new(0),','free_count: Arc::new(AtomicUsize::new(0)),')
text=text.replace('ResourceHandleFactory::blob(access.clone())','ResourceHandleFactory::blob(Box::new(CountingAccess { free_count: Arc::clone(&access.free_count) }))').replace('ResourceHandleFactory::reference(Arc::new(ReadOnlyRefAccess))','ResourceHandleFactory::reference(Box::new(ReadOnlyRefAccess))')
std=(c/'rdbc/src/resource/blob.rs').read_text();signatures=re.findall(r'async fn\s+(\w+)\s*(\(.*?\)\s*->\s*.*?);',std,re.S);missing=[]
for name,sig in signatures:
    if name in ['free','length','get_bytes']:continue
    sig=re.sub(r'\b(\w+)\s*:',lambda m:'_'+m.group(1)+':',sig)
    missing.append('async fn '+name+sig+' {Err(RdbcError::feature_not_supported("Blob#'+name+'"))}\n')
assert len(missing)==8
needle='impl Blob for CountingAccess {';text=text.replace(needle,needle+'\n'+''.join(missing))
p.write_text(text,encoding='utf-8',newline='\n')
run('format',['C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin/rustfmt.exe','--edition','2021',str(p)],True)
state['migrated_sha256']=sha(p);save();run('standard-compile',cmd,True);run('standard-runtime',[str(d/'context.exe'),'--test-threads=1'],True)
state['terminal']=True;state['exe_sha256']=sha(d/'context.exe');save()
