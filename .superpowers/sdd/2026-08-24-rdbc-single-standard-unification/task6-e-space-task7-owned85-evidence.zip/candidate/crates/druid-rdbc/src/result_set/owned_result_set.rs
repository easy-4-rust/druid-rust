use super::ResultSet;

/// 保证 owning Stream 在任意丢弃或取消位置交接唯一标准游标。
/// 对应 Java: java.sql.ResultSet#close 的 Rust 所有权保护，不定义第二套游标接口。
pub(super) struct OwnedResultSet<T: ResultSet + ?Sized> {
    cursor: Option<Box<T>>,
}

impl<T: ResultSet + ?Sized> OwnedResultSet<T> {
    pub(super) fn new(cursor: Box<T>) -> Self {
        Self {
            cursor: Some(cursor),
        }
    }

    pub(super) fn as_ref(&self) -> &T {
        self.cursor.as_deref().expect("live stream owns its cursor")
    }

    pub(super) fn as_mut(&mut self) -> &mut T {
        self.cursor
            .as_deref_mut()
            .expect("live stream owns its cursor")
    }
}

impl<T: ResultSet + ?Sized> Drop for OwnedResultSet<T> {
    fn drop(&mut self) {
        if let Some(cursor) = self.cursor.take() {
            cursor.release_owned();
        }
    }
}
