import hashlib
import json
from pathlib import Path

b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
w=b/'task7-external-resource-consumer-candidate1/workspace'
p=w/'crates/druid/tests/task7_pooled_stream_drop_test.rs'
prior=json.loads((b/'task7-pooled-drop80/summary.json').read_text(encoding='utf-8'))
assert prior['terminal'] and prior['results']==[['0','1','0']]
d=b/'task7-drop-offthread81'
d.mkdir(exist_ok=False)
original=p.read_bytes()
(d/'pooled-drop80-original.rs').write_bytes(original)
body=original.decode('utf-8').split('#[tokio::test]',1)[1]
body=body.replace('dropping_pooled_owning_stream_releases_cursor_while_statement_stays_alive','dropping_pooled_owning_stream_on_plain_thread_uses_owner_runtime')
assert body.count('    drop(stream);')==1
body=body.replace('    drop(stream);','    std::thread::spawn(move || drop(stream)).join().unwrap();')
p.write_bytes(original+b'\n#[tokio::test]'+body.encode('utf-8'))
assert p.read_bytes().startswith(original)
(d/'summary.json').write_text(json.dumps(dict(production_applied=False,original_single_test_sha256=hashlib.sha256(original).hexdigest(),two_test_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),original_test_byte_prefix_preserved=True),indent=2)+'\n',encoding='utf-8')
runner=(b/'task7-pooled-drop80.py').read_text(encoding='utf-8').replace("d=b/'task7-pooled-drop80'","d=b/'task7-drop-red82'")
(b/'task7-drop-red82.py').write_text(runner,encoding='utf-8')
print('Original test preserved; additional plain-thread owning Stream Drop contract prepared.')
