import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
w=b/'task7-external-resource-consumer-candidate1/workspace'
d=b/'task7-drop-red82'
d.mkdir(exist_ok=False)
tool='C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin'
env=os.environ.copy()
env.update(RUSTC=tool+'/rustc.exe',RUSTDOC=tool+'/rustdoc.exe',RUSTUP_TOOLCHAIN='1.97.1-x86_64-pc-windows-msvc',RUSTUP_AUTO_INSTALL='0',PATH=tool+os.pathsep+env['PATH'],CARGO_TARGET_DIR='F:/codex_build_cache/druid_rust/task7_standard_cargo13_1971',CARGO_BUILD_JOBS='1',TMP='F:/codex_tmp/task7_standard_cargo13',TEMP='F:/codex_tmp/task7_standard_cargo13',DRUID_RDBC_EXTERNAL_TARGET_ROOT='F:/codex_build_cache/druid_rust/t7_rdbc23')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
frozen={p.relative_to(w).as_posix():sha(p) for p in w.rglob('*') if p.is_file() and 'target' not in p.relative_to(w).parts and (p.suffix in ['.rs','.toml','.json','.inc'] or p.name=='Cargo.lock')}
(d/'frozen-inputs.json').write_text(json.dumps(frozen,indent=2)+'\n',encoding='utf-8')
cmd=[tool+'/cargo.exe','test','-p','druid','--test','task7_pooled_stream_drop_test','--all-features','--locked','--offline','-j1']
s=dict(terminal=False,production_applied=False,command=cmd,frozen_input_count=len(frozen))
def save(): (d/'summary.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
save()
log=d/'pooled-stream-drop.log'
with log.open('xb') as output:
    r=subprocess.run(cmd,cwd=w,env=env,stdout=output,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
blocks=re.findall(r'^test result: .*?(\d+) passed; (\d+) failed; (\d+) ignored;',log.read_text(encoding='utf-8'),re.M)
s.update(terminal=True,exit_code=r.returncode,log=str(log),sha256=sha(log),results=blocks,changed_inputs=[rel for rel,h in frozen.items() if sha(w/rel)!=h])
save()
print(json.dumps(s),flush=True)
