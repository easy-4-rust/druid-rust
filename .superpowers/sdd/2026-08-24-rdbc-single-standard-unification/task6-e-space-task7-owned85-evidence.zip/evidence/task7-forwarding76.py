import hashlib
import json
from pathlib import Path

b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
w=Path('F:/codex_build_cache/d72')
q=b/'task7-standard-cargo-candidate1/workspace'
d=b/'task7-forwarding76'
d.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=w/'crates/druid/tests/task6_complete_row_set_contract_test.rs'
data=source.read_bytes()
assert b'use druid::' not in data and b'druid_wrapper::' not in data
paths=['crates/druid-rdbc/src/extensions/'+name+'.rs' for name in ['shared_result_set','shared_result_set_borrow','shared_result_set_borrow_future','shared_result_set_state','buffered_row_set']]
identity={}
for rel in paths:
    assert (w/rel).read_bytes()==(q/rel).read_bytes(),rel
    identity[rel]=sha(w/rel)
target=q/'crates/druid-rdbc/tests/task7_shared_result_set_contract_test.rs'
assert not target.exists()
target.write_bytes(data)
assert target.read_bytes()==source.read_bytes()
(d/'summary.json').write_text(json.dumps(dict(production_applied=False,original_test_source=str(source),test_source_sha256=sha(source),new_target=str(target),byte_identical_original_test=True,production_source_identity=identity,ruling='Run complete existing BASE forwarding/RowSet contract as an independent druid-rdbc target without Druid/Wrapper imports. Original Druid target remains unchanged. This proves standard ownership rather than using BufferedRowSet as forwarding identity; final mapping/API/SemVer acceptance remains open.'),indent=2)+'\n',encoding='utf-8')
runner=(b/'task7-druid-recheck64.py').read_text(encoding='utf-8')
runner=runner.replace("w=b/'task7-external-resource-consumer-candidate1/workspace'", "w=b/'task7-standard-cargo-candidate1/workspace'")
runner=runner.replace("d=b/'task7-druid-recheck64'", "d=b/'task7-forwarding77'")
runner=runner.replace("'F:/codex_build_cache/druid_rust/task6_lifetime_clean_1971_20261008'", "'F:/codex_build_cache/druid_rust/task7_standard_cargo13_1971'")
runner=runner.replace("'test','-p','druid','--test','task6_pooled_connection_exception_paths_test_parity'", "'test','-p','druid-rdbc','--test','task7_shared_result_set_contract_test'")
runner=runner.replace("log=d/'exception-paths.log'", "log=d/'shared-forwarding.log'")
(b/'task7-forwarding77.py').write_text(runner,encoding='utf-8')
print(json.dumps(dict(independent_standard_test_prepared=True,production_sources_equal=len(paths))))
