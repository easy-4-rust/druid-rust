import hashlib
import json
import subprocess
from pathlib import Path
import zipfile

b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
w=b/'task7-external-resource-consumer-candidate1/workspace'
red=json.loads((b/'task7-drop-red82/summary.json').read_text(encoding='utf-8'))
assert red['terminal'] and red['exit_code']==101 and red['results']==[['0','2','0']] and not red['changed_inputs']
d=b/'task7-owned-release83'
d.mkdir(exist_ok=True)
sha=lambda data:hashlib.sha256(data).hexdigest()
before={}
def update(rel, transform):
    p=w/rel
    data=p.read_bytes()
    before[rel]=data
    text=data.decode('utf-8')
    new=transform(text)
    assert new!=text,rel
    p.write_bytes(new.encode('utf-8'))

def result_set(text):
    needle='    /// 关闭游标并释放其 owned actor/native handle。'
    assert text.count(needle)==1
    addition='''    /// 交接唯一拥有的游标以执行非阻塞释放；无参数、无返回值。
    /// 默认直接丢弃驱动对象，沿用驱动自身的 Drop；池化代理应把异步关闭
    /// 提交给已有所有者监管队列，保留失败与重试，不在 Drop 中阻塞等待。
    /// 仅 owning Stream 的所有权适配调用，不改变普通共享视图的生命周期。
    /// 对应 Java: java.sql.ResultSet#close 的 Rust 拥有型消费扩展。
    fn release_owned(self: Box<Self>) {
        drop(self);
    }

'''
    return text.replace(needle,addition+needle)
update('crates/druid-rdbc/src/result_set/result_set.rs',result_set)

guard='''use super::ResultSet;

/// 保证 owning Stream 在任意丢弃或取消位置交接唯一标准游标。
/// 对应 Java: java.sql.ResultSet#close 的 Rust 所有权保护，不定义第二套游标接口。
pub(super) struct OwnedResultSet<T: ResultSet + ?Sized> {
    cursor: Option<Box<T>>,
}

impl<T: ResultSet + ?Sized> OwnedResultSet<T> {
    pub(super) fn new(cursor: Box<T>) -> Self {
        Self { cursor: Some(cursor) }
    }

    pub(super) fn as_ref(&self) -> &T {
        self.cursor.as_deref().expect("live stream owns its cursor")
    }

    pub(super) fn as_mut(&mut self) -> &mut T {
        self.cursor.as_deref_mut().expect("live stream owns its cursor")
    }
}

impl<T: ResultSet + ?Sized> Drop for OwnedResultSet<T> {
    fn drop(&mut self) {
        if let Some(cursor) = self.cursor.take() {
            cursor.release_owned();
        }
    }
}
'''
new_guard=w/'crates/druid-rdbc/src/result_set/owned_result_set.rs'
assert not new_guard.exists()
new_guard.write_text(guard,encoding='utf-8',newline='')
update('crates/druid-rdbc/src/result_set/mod.rs',lambda text:text.replace('mod result_set;','mod owned_result_set;\nmod result_set;',1))
def extension(text):
    text='use super::owned_result_set::OwnedResultSet;\n'+text
    text=text.replace('提前丢弃 Stream 会丢弃其拥有的游标，具体驱动负责在 Drop 中监管异步释放。','提前丢弃 Stream 通过 release_owned 交接游标，池化实现沿既有所有者监管释放。')
    old='''            (self, map),
            |(mut cursor, mut map)| async move {
                match cursor.next().await {'''
    new='''            (OwnedResultSet::new(self), map),
            |(mut cursor, mut map)| async move {
                match cursor.as_mut().next().await {'''
    assert text.count(old)==1
    text=text.replace(old,new)
    head,tail=text.split('    /// 读取可空 String。',1)
    head=head.replace('cursor.close().await','cursor.as_mut().close().await')
    return head+'    /// 读取可空 String。'+tail
update('crates/druid-rdbc/src/result_set/result_set_ext.rs',extension)

def registry(text):
    text=text.replace('    shutdown: Arc<Notify>,\n}', '    shutdown: Arc<Notify>,\n    // 资源拥有者创建时的执行器，允许调用方在普通线程丢弃 owning Stream。\n    coordinator_runtime: Option<tokio::runtime::Handle>,\n}',1)
    text=text.replace('            shutdown: Arc::new(Notify::new()),\n', '            shutdown: Arc::new(Notify::new()),\n            coordinator_runtime: tokio::runtime::Handle::try_current().ok(),\n',1)
    start=text.index('    async fn close_registered_inner(')
    body=text.index('        let mut receivers = Vec::new();',start)
    end=text.index('        Self::await_cleanup(receivers).await\n    }',body)
    queue_body=text[body:end]
    signature=text[start:body]
    replacement=signature+'''        let receivers = self.queue_registered_cleanup(registrations, admission);
        Self::await_cleanup(receivers).await
    }

    /// 同步移交已登记资源的关闭请求；参数为同一 registry 的令牌，无返回值。
    /// 不等待驱动或重试，具体结果继续由 registry 与父级 close/drain 保管。
    pub(crate) fn request_registered_cleanup(
        self: &Arc<Self>,
        registration: &StandardResourceRegistration,
    ) {
        if !registration.belongs_to(self) {
            return;
        }
        // 与显式 close 共用同一入队段；丢弃等待者不会取消已监管的 actor。
        drop(self.queue_registered_cleanup(std::slice::from_ref(registration), None));
    }

    fn queue_registered_cleanup(
        self: &Arc<Self>,
        registrations: &[StandardResourceRegistration],
        admission: Option<&StandardResourceAdmission>,
    ) -> Vec<oneshot::Receiver<Result<(), RdbcError>>> {
'''+queue_body+'''        receivers
    }'''
    text=text[:start]+replacement+text[end+len('        Self::await_cleanup(receivers).await\n    }'):]
    old='''        tokio::spawn(async move {
            Self::run_coordinator(registry, generation).await;
        });'''
    new='''        if let Some(runtime) = &self.coordinator_runtime {
            runtime.spawn(async move {
                Self::run_coordinator(registry, generation).await;
            });
        } else {
            // 保留纯同步构造后首次进入 Tokio 的原路径。
            tokio::spawn(async move {
                Self::run_coordinator(registry, generation).await;
            });
        }'''
    assert text.count(old)==1
    return text.replace(old,new)
update('crates/druid/src/core/standard_resource_registry.rs',registry)
def registration(text):
    needle='    /// 返回 registry 是否已把该 actor 转入 close/retry ownership。'
    assert text.count(needle)==1
    addition='''    /// 向原所有者交接非阻塞清理；无参数，无返回值。
    /// generation 与 registry 身份在原队列内校验，错误及重试继续归所有者保管。
    pub(crate) fn request_cleanup(&self) {
        if let Some(registry) = self.registry.upgrade() {
            registry.request_registered_cleanup(self);
        }
    }

'''
    return text.replace(needle,addition+needle)
update('crates/druid/src/core/standard_resource_registration.rs',registration)
def pooled(text):
    needle='    async fn close(&mut self) -> Result<(), RdbcError> {'
    head,text=text.split('impl ResultSet for DruidPooledResultSet {',1)
    assert text.count(needle)==1
    addition='''    /// Stream 唯一拥有型消费结束后交接原 registry；无参数、无返回值。
    /// 对应 Java: DruidPooledResultSet#close 的 Rust 异步 Drop 适配。
    fn release_owned(self: Box<Self>) {
        if !self.shared.closed.load(Ordering::Acquire) {
            if let Some(registration) = self.resource.registration.get() {
                registration.request_cleanup();
            }
        }
    }

'''
    return head+'impl ResultSet for DruidPooledResultSet {'+text.replace(needle,addition+needle)
update('crates/druid/src/core/druid_pooled_result_set.rs',pooled)

with zipfile.ZipFile(d/'before.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
    for rel,data in before.items():z.writestr(rel,data)
with zipfile.ZipFile(d/'before.zip') as z:
    assert all(z.read(rel)==data for rel,data in before.items())
tool='C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin'
cmd=[tool+'/rustfmt.exe','--edition','2021']+[str(w/rel) for rel in before]+[str(new_guard)]
r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(d/'rustfmt.log').write_bytes(r.stdout)
assert r.returncode==0
paths=list(before)+[new_guard.relative_to(w).as_posix()]
s=dict(production_applied=False,source_changes={rel:dict(before=sha(before[rel]) if rel in before else None,after=sha((w/rel).read_bytes())) for rel in paths},ruling='Keep one canonical ResultSet. Add object-safe Rust owned-consumer release_owned with default drop; only owning Stream guard dispatches it. Druid queues the same registration through existing supervised coordinator, preserving failure/retry and normal shared-view Drop semantics. Capture owner Tokio handle for plain-thread Drop. This is additive pre-release API and must enter final public API/compiler/SemVer evidence; no final Task7/API certification inferred.',red82=red,short_complete74_inputs_unmodified=True,original_stream_and_pooled_assertions_preserved=True)
(d/'summary.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(changed_paths=paths,production_applied=False),indent=2))
