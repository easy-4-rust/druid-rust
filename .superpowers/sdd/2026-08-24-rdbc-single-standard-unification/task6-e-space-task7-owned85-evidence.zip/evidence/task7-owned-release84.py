import hashlib,json,os,re,subprocess
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
w=b/'task7-external-resource-consumer-candidate1/workspace'
d=b/'task7-owned-release84'; d.mkdir(exist_ok=False)
tool='C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin'
env=os.environ.copy()
env.update(RUSTC=tool+'/rustc.exe',RUSTDOC=tool+'/rustdoc.exe',RUSTUP_TOOLCHAIN='1.97.1-x86_64-pc-windows-msvc',RUSTUP_AUTO_INSTALL='0',PATH=tool+os.pathsep+env['PATH'],CARGO_TARGET_DIR='F:/codex_build_cache/druid_rust/task7_standard_cargo13_1971',CARGO_BUILD_JOBS='1',TMP='F:/codex_tmp/task7_standard_cargo13',TEMP='F:/codex_tmp/task7_standard_cargo13',DRUID_RDBC_EXTERNAL_TARGET_ROOT='F:/codex_build_cache/dr84_ext')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rels=set(json.loads((b/'task7-complete74/frozen-inputs.json').read_text(encoding='utf-8')))
rels.update(p.relative_to(w).as_posix() for p in w.rglob('*') if p.is_file() and 'target' not in p.relative_to(w).parts and (p.suffix in ['.rs','.toml','.json','.inc'] or p.name=='Cargo.lock'))
frozen={rel:sha(w/rel) for rel in sorted(rels)}
(d/'frozen-inputs.json').write_text(json.dumps(frozen,indent=2)+'\n',encoding='utf-8')
s=dict(terminal=False,production_applied=False,workspace=str(w),frozen_input_count=len(frozen),commands=[])
save=lambda:(d/'summary.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
save()
common=['--all-features','--locked','--offline','-j1']
targets=['--test','task7_pooled_stream_drop_test','--test','task7_pooled_async_result_set_test','--test','resource_owner_cancellation_test']
for name,args in [
 ('pooled-owned-release',['test','-p','druid']+targets+common),
 ('rdbc-stream',['test','-p','druid-rdbc','--test','result_set_stream_test']+common),
 ('registry-lib',['test','-p','druid','--lib']+common),
 ('pooled-strict',['clippy','-p','druid']+targets+common+['--','-D','warnings']),
 ('rdbc-stream-strict',['clippy','-p','druid-rdbc','--test','result_set_stream_test']+common+['--','-D','warnings']),
]:
 cmd=[tool+'/cargo.exe']+args; log=d/(name+'.log')
 with log.open('xb') as out:r=subprocess.run(cmd,cwd=w,env=env,stdout=out,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
 blocks=re.findall(r'^test result: .*?(\d+) passed; (\d+) failed; (\d+) ignored;',log.read_text(encoding='utf-8'),re.M)
 changes=[rel for rel,h in frozen.items() if sha(w/rel)!=h]
 counts=dict(passed=sum(int(v[0]) for v in blocks),failed=sum(int(v[1]) for v in blocks),ignored=sum(int(v[2]) for v in blocks),blocks=len(blocks))
 s['commands'].append(dict(name=name,command=cmd,exit_code=r.returncode,log=str(log),sha256=sha(log),results=counts,changed_inputs=changes));save()
 print(json.dumps(dict(name=name,exit_code=r.returncode,results=counts)),flush=True)
 if r.returncode or changes:break
s.update(terminal=True,exit_code=r.returncode,changed_inputs=[rel for rel,h in frozen.items() if sha(w/rel)!=h]);save()
print(json.dumps(dict(terminal=True,exit_code=r.returncode)),flush=True)
