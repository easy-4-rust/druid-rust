import hashlib,json,zipfile
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
w=b/'task7-external-resource-consumer-candidate1/workspace'
s=b/'task7-async-stream-candidate35/workspace'
f=json.loads((b/'task7-drop-red82/frozen-inputs.json').read_text())
paths=['crates/druid-rdbc/src/result_set/'+x for x in ['result_set.rs','mod.rs','result_set_ext.rs']]+['crates/druid/src/core/'+x for x in ['standard_resource_registry.rs','standard_resource_registration.rs','druid_pooled_result_set.rs']]
sha=lambda data:hashlib.sha256(data).hexdigest()
with zipfile.ZipFile(b/'task7-owned-release83/partial-setup-failure.zip','x') as z:
 for rel in paths:z.writestr(rel,(w/rel).read_bytes())
guard=w/'crates/druid-rdbc/src/result_set/owned_result_set.rs'
with zipfile.ZipFile(b/'task7-owned-release83/before-recovered.zip','x') as z:
 for rel in paths:
  data=(s/rel).read_bytes()
  assert sha(data)==f[rel],rel
  z.writestr(rel,data)
  (w/rel).write_bytes(data)
guard.rename(b/'task7-owned-release83/partial-owned_result_set.rs')
p=b/'task7-owned-release83.py'
t=p.read_text()
t=t.replace('d.mkdir(exist_ok=False)','d.mkdir(exist_ok=True)')
t=t.replace("    assert text.count(needle)==1\n    addition='''    /// Stream", "    head,text=text.split('impl ResultSet for DruidPooledResultSet {',1)\n    assert text.count(needle)==1\n    addition='''    /// Stream")
t=t.replace("    return text.replace(needle,addition+needle)\nupdate('crates/druid/src/core/druid_pooled_result_set.rs',pooled)","    return head+'impl ResultSet for DruidPooledResultSet {'+text.replace(needle,addition+needle)\nupdate('crates/druid/src/core/druid_pooled_result_set.rs',pooled)")
p.write_text(t,encoding='utf-8')
print('Recovered six original files against RED82 hashes; preserved partial edit and corrected trait-specific insertion.')
