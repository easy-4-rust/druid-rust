import hashlib,json,re,subprocess,zipfile
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
w=b/'task7-external-resource-consumer-candidate1/workspace'
d=b/'task7-owned-quality88';d.mkdir(exist_ok=False)
s=json.loads((b/'task7-owned-release84/summary.json').read_text(encoding='utf-8'))
assert s['terminal'] and s['exit_code']==101 and not s['changed_inputs']
assert [(c['name'],c['exit_code']) for c in s['commands']]==[('pooled-owned-release',0),('rdbc-stream',0),('registry-lib',0),('pooled-strict',101)]
paths=['crates/druid-rdbc/src/result_set/mod.rs','crates/druid-rdbc/src/result_set/owned_result_set.rs','crates/druid/tests/task7_pooled_stream_drop_test.rs']
before={rel:(w/rel).read_bytes() for rel in paths}
with zipfile.ZipFile(d/'before.zip','x') as z:
 for rel,data in before.items():z.writestr(rel,data)
p=w/paths[0];t=p.read_text(encoding='utf-8')
assert t.count('mod owned_result_set;')==1
t=t.replace('mod owned_result_set;\n','')
idx=t.index('#[expect(')
t=t[:idx]+'mod owned_result_set;\n\n'+t[idx:]
p.write_text(t,encoding='utf-8',newline='')
p=w/paths[1];t=p.read_text(encoding='utf-8')
for needle,doc in [
 ('    pub(super) fn new(', '    /// 接收唯一标准游标；参数为拥有型句柄，返回供 Stream 持有的释放保护。\n'),
 ('    pub(super) fn as_ref(', '    /// 借用当前标准游标；无参数，返回只读引用，不转移所有权。\n'),
 ('    pub(super) fn as_mut(', '    /// 可变借用当前标准游标；无参数，返回供推进或关闭使用的引用。\n'),
]:
 assert t.count(needle)==1;t=t.replace(needle,doc+needle)
p.write_text(t,encoding='utf-8',newline='')
p=w/paths[2];extra=(b/'task7-drop-extra-contracts87.rs').read_bytes()
p.write_bytes(before[paths[2]]+extra)
assert p.read_bytes().startswith(before[paths[2]])
tool='C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin'
r=subprocess.run([tool+'/rustfmt.exe','--edition','2021']+[str(w/rel) for rel in paths],capture_output=True)
(d/'rustfmt.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0
old_ids=re.findall(rb'async fn (\w+)',before[paths[2]])
new_ids=re.findall(rb'async fn (\w+)',p.read_bytes())
assert new_ids[:len(old_ids)]==old_ids and len(new_ids)==4
sha=lambda data:hashlib.sha256(data).hexdigest()
summary=dict(production_applied=False,changes={rel:dict(before=sha(before[rel]),after=sha((w/rel).read_bytes())) for rel in paths},ruling='Move the new private module declaration before the existing module_inception expectation so the expectation stays attached to mod result_set; no allow added. Add Chinese private API docs. Preserve both original drop contracts and add unpolled/pending-first-row Drop cases without changing production behavior.',original_drop_test_identities=[v.decode() for v in old_ids],new_drop_test_count=4,prior84='112/0 + RDBC5/0 + Druidlib153/0; strict module attribute placement RED retained; not complete Task7')
(d/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
runner=(b/'task7-owned-release84.py').read_text(encoding='utf-8').replace("d=b/'task7-owned-release84'","d=b/'task7-owned-release89'")
start=runner.index('for name,args in [')
end=runner.index(']:\n',start)
runner=runner[:start]+'''for name,args in [
 ('rdbc-stream-strict',['clippy','-p','druid-rdbc','--test','result_set_stream_test']+common+['--','-D','warnings']),
 ('pooled-strict',['clippy','-p','druid']+targets+common+['--','-D','warnings']),
 ('pooled-owned-release',['test','-p','druid']+targets+common),
 ('rdbc-stream',['test','-p','druid-rdbc','--test','result_set_stream_test']+common),
 ('registry-lib',['test','-p','druid','--lib']+common),
'''+runner[end:]
(b/'task7-owned-release89.py').write_text(runner,encoding='utf-8')
print(json.dumps(summary,indent=2))
