import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess

b = Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
d = b / 'task7-owner-cargo-quality27'
d.mkdir(exist_ok=False)
w = b / 'task7-standard-cargo-candidate1/workspace'
prior = json.loads((w.parent / 'quality22.summary.json').read_text(encoding='utf-8'))
assert prior['terminal'] and prior['clippy_certified']
source = b / 'task7-owner-quality-candidate1/resource_owner_cancellation_test.rs'
target = w / 'crates/druid/tests/resource_owner_cancellation_test.rs'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
original = target.read_bytes()
(d / 'owner-before.rs').write_bytes(original)
shutil.copyfile(source, target)
manifest = w / 'Cargo.toml'
(d / 'Cargo-before.toml').write_bytes(manifest.read_bytes())
t = manifest.read_text(encoding='utf-8')
cfgs = sorted(set(re.findall(r'#\[cfg\((task7_[a-z_]+)\)\]', source.read_text(encoding='utf-8'))))
assert len(cfgs) == 7
pattern = r'unexpected_cfgs = \{ level = "warn", check-cfg = \[[^\n]+\] \}'
replacement = 'unexpected_cfgs = { level = "warn", check-cfg = [' + ', '.join('"cfg(' + cfg + ')"' for cfg in cfgs) + '] }'
t, count = re.subn(pattern, replacement, t)
assert count == 1
manifest.write_text(t, encoding='utf-8', newline='\n')
tool = 'C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin'
env = os.environ.copy()
env.update(RUSTC=tool+'/rustc.exe', RUSTDOC=tool+'/rustdoc.exe',
           RUSTUP_TOOLCHAIN='1.97.1-x86_64-pc-windows-msvc', RUSTUP_AUTO_INSTALL='0',
           PATH=tool+os.pathsep+env['PATH'], CARGO_TARGET_DIR='F:/codex_build_cache/druid_rust/task7_standard_cargo13_1971',
           CARGO_BUILD_JOBS='1', RUST_TEST_THREADS='1', TMP='F:/codex_tmp/task7_standard_cargo13', TEMP='F:/codex_tmp/task7_standard_cargo13')
cmd = [tool+'/cargo.exe','clippy','-p','druid','--test','resource_owner_cancellation_test',
       '--all-features','--locked','--offline','-j1','--','-D','warnings']
inputs = {str(p):sha(p) for p in [source, target, manifest]}
s = dict(terminal=False, production_applied=False, command=cmd, declared_negative_cfgs=cfgs,
         frozen_inputs=inputs, ruling='Independent idle final-source candidate workspace only; preserve all104 original tests and added Send contract. Declare seven actual negative cfgs, without lint allow. Strict Cargo Clippy target, including final-source Druid/RDBC libraries; main integrated23 workspace unchanged.')
def save():
    (d/'summary.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
save()
log = d/'clippy27.log'
with log.open('xb') as output:
    result = subprocess.run(cmd,cwd=w,env=env,stdout=output,stderr=subprocess.STDOUT,
                            creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
s.update(terminal=True,exit_code=result.returncode,log=str(log),log_sha256=sha(log),
         changed_inputs=[p for p,digest in inputs.items() if sha(Path(p)) != digest])
save()
print('clippy27',result.returncode,flush=True)
raise SystemExit(result.returncode)
