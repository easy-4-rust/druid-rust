import hashlib
import json
from pathlib import Path
import subprocess

b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
d=b/'task7-owner-negative28'
d.mkdir(exist_ok=False)
prior=json.loads((b/'task7-owner-quality-retry26/summary.json').read_text(encoding='utf-8'))
assert prior['terminal'] and prior['exit_code']==0 and prior['runtime_tests']==105
cmd=list(prior['commands'][0]['command'])
source=Path(prior['source'])
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(source)==prior['source_sha256']
cfgs=json.loads((b/'task7-owner-quality-candidate1/summary.json').read_text(encoding='utf-8'))['declared_negative_cfgs']
s=dict(terminal=False,production_applied=False,cargo_certified=False,source_sha256=sha(source),commands=[],
       scope='Seven retained owner negative contracts on exactly the strict105 passing source and coherent library family; direct rustc, not final-source Cargo certification.')
def save():
    (d/'summary.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
save()
for cfg in cfgs:
    negative=list(cmd)
    negative[negative.index('-o')+1]=str(d/(cfg+'.exe'))
    negative+=['--cfg',cfg]
    log=d/(cfg+'.log')
    with log.open('xb') as output:
        result=subprocess.run(negative,stdout=output,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
    text=log.read_text(encoding='utf-8')
    expected='E0432' if '_old_' in cfg else 'E0277'
    passed=result.returncode!=0 and ('error['+expected+']') in text
    s['commands'].append(dict(cfg=cfg,command=negative,exit_code=result.returncode,expected=expected,
                              rejected_as_expected=passed,log=str(log),sha256=sha(log)))
    save()
    print(cfg,result.returncode,expected,passed,flush=True)
    if not passed:
        s.update(terminal=True,exit_code=1)
        save()
        raise SystemExit(1)
s.update(terminal=True,exit_code=0,negative_contracts=7,source_unchanged=sha(source)==s['source_sha256'])
save()
