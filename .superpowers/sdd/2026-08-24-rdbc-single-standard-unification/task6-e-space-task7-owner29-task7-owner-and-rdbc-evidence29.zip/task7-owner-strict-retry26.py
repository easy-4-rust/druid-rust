import hashlib
import json
from pathlib import Path
import subprocess

b = Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
d = b / 'task7-owner-quality-retry26'
d.mkdir(exist_ok=False)
previous = b / 'task7-owner-quality-candidate1'
old = json.loads((previous / 'summary.json').read_text(encoding='utf-8'))
source = previous / 'resource_owner_cancellation_test.rs'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
assert sha(source) == old['source_sha256']
cmd = list(old['commands'][-1]['command'])
assert old['commands'][-1]['name'] == 'strict-green'
assert old['commands'][-1]['exit_code'] == 1
failure = (previous / 'strict-green.log').read_text(encoding='utf-8')
assert 'unexpected `cfg` condition name: `test`' in failure
assert 'aborting due to 105 previous errors' in failure
assert '-A' not in cmd
cmd += ['--check-cfg', 'cfg(test)']
cmd[cmd.index('-o') + 1] = str(d / 'owner26.exe')
s = dict(terminal=False, production_applied=False, cargo_certified=False,
         prior_runner_terminal_exit=1, prior_failure='Direct rustc check-cfg omitted built-in test cfg; all105 test macros rejected. Original logs preserved.',
         source=str(source), source_sha256=sha(source), commands=[],
         scope='Strict direct rustc against original coherent pre-alias library family; final-source Cargo and Clippy certification remain required.')
def save():
    (d / 'summary.json').write_text(json.dumps(s, indent=2) + '\n', encoding='utf-8')
def run(name, command):
    log = d / (name + '.log')
    with log.open('xb') as output:
        result = subprocess.run(command, stdout=output, stderr=subprocess.STDOUT,
                                creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
    s['commands'].append(dict(name=name, command=list(command), exit_code=result.returncode,
                              log=str(log), sha256=sha(log)))
    save()
    print(name, result.returncode, flush=True)
    return result.returncode, log.read_text(encoding='utf-8')
save()
code, output = run('strict-green26', cmd)
if code == 0:
    code, output = run('runtime-green26', [str(d / 'owner26.exe'), '--test-threads=1'])
    assert code == 0 and '105 passed; 0 failed;' in output
    s.update(strict_rustc=True, runtime_tests=105)
s.update(terminal=True, exit_code=code, source_unchanged=sha(source) == s['source_sha256'])
save()
assert code == 0, output[-3000:]
