import hashlib
import json
from pathlib import Path
import re
import subprocess

b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
d=b/'task7-owner-quality-candidate1'
d.mkdir(exist_ok=False)
original=b/'task7-planned-contract-tests-candidate1/crates/druid/tests/resource_owner_cancellation_test.rs'
p=d/'resource_owner_cancellation_test.rs'
p.write_bytes(original.read_bytes())
base=json.loads((b/'task7-resource-debug-candidate1/coherent8.summary.json').read_text(encoding='utf-8'))
cmd=base['commands'][0]['command'].copy()
allow=cmd.index('-A')
assert cmd[allow+1]=='dead_code'
del cmd[allow:allow+2]
cmd[cmd.index('--test')+3]=str(p)
cmd[cmd.index('-o')+1]=str(d/'owner25.exe')
cmd+=['--check-cfg','cfg()']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
s=dict(terminal=False,production_applied=False,cargo_certified=False,commands=[],
    original_source_sha256=sha(original),
    ruling='Only independent owner test source is changed. Compile against the coherent pre-alias library family; formal Cargo against final sources remains required. Preserve104 existing tests and negative probes; exercise existing unused Send helpers as an additional positive contract.')
def save():
    (d/'summary.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
def run(name,command):
    log=d/(name+'.log')
    with log.open('xb') as f:
        r=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
    s['commands'].append(dict(name=name,command=command,exit_code=r.returncode,log=str(log),sha256=sha(log)))
    save()
    print(name,r.returncode,flush=True)
    return r.returncode,log.read_text(encoding='utf-8')
save()
code,red=run('strict-red',cmd)
assert code!=0 and 'unexpected `cfg` condition name' in red and 'never used' in red
t=p.read_text(encoding='utf-8')
for name,fields in [('XmlSourceValue','representation:Option<RdbcXmlRepresentationType>,units:Vec<u16>'),
                    ('XmlResultValue','representation:Option<RdbcXmlRepresentationType>,units:Arc<Mutex<Vec<u16>>>')]:
    old='#[derive(Debug)]\nstruct '+name+' {'+fields+'}'
    assert t.count(old)==1
    new=('struct '+name+' {'+fields+'}\n'
         'impl std::fmt::Debug for '+name+' {\n'
         '    fn fmt(&self, formatter: &mut std::fmt::Formatter<\'_>) -> std::fmt::Result {\n'
         '        formatter.debug_struct("'+name+'").field("representation", &self.representation).field("units", &self.units).finish()\n'
         '    }\n}\n')
    t=t.replace(old,new)
marker='#[cfg(task7_require_driver_sync)]'
assert t.count(marker)==1
positive=('/// 标准驱动及借用Future保留Send能力；配合负向Sync探针验证约束边界。\n'
          '#[tokio::test]\nasync fn send_only_driver_and_borrowed_future_keep_send_contract() {\n'
          '    send_static::<SendOnlyBlob>();\n'
          '    let mut driver = blob();\n'
          '    assert_eq!(send_future(Blob::length(&mut driver)).await.unwrap(), 4);\n'
          '}\n')
t=t.replace(marker,positive+marker)
assert t.count('#[tokio::test]')+t.count('#[test]')==105
p.write_text(t,encoding='utf-8',newline='\n')
cfgs=sorted(set(re.findall(r'#\[cfg\((task7_[a-z_]+)\)\]',t)))
assert len(cfgs)==7
for cfg in cfgs:
    cmd+=['--check-cfg','cfg('+cfg+')']
s.update(declared_negative_cfgs=cfgs,source_sha256=sha(p))
save()
code,green=run('strict-green',cmd)
assert code==0,green[-5000:]
code,runtime=run('runtime-green',[str(d/'owner25.exe'),'--test-threads=1'])
assert code==0 and '105 passed; 0 failed;' in runtime
assert sha(p)==s['source_sha256']
s.update(terminal=True,runtime_tests=105,strict_rustc=True,source_unchanged=True)
save()
