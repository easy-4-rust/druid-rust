import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
d=b/'task7-owner-clippy-repair31'
d.mkdir(exist_ok=False)
w=b/'task7-standard-cargo-candidate1/workspace'
prior=json.loads((b/'task7-owner-cargo-quality27/summary.json').read_text(encoding='utf-8'))
assert prior['terminal'] and prior['exit_code']==101 and not prior['changed_inputs']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
changes={}
paths=[]
for name in ['druid_array.rs','druid_blob.rs','druid_clob.rs','druid_sql_xml.rs']:
    p=w/'crates/druid/src/core'/name
    before=p.read_bytes()
    (d/('before-'+name)).write_bytes(before)
    t=before.decode('utf-8')
    old='.is_none_or(|registration| registration.cleanup_requested())'
    assert t.count(old)==1
    t=t.replace(old,'.is_none_or(super::standard_resource_registration::StandardResourceRegistration::cleanup_requested)')
    p.write_text(t,encoding='utf-8',newline='\n')
    changes[p.relative_to(w).as_posix()]={'before_sha256':hashlib.sha256(before).hexdigest()}
    paths.append(p)
p=w/'crates/druid/src/core/external_connection_lease.rs'
before=p.read_bytes()
(d/('before-'+p.name)).write_bytes(before)
t=before.decode('utf-8')
comment='    /// 原样委托类型名与元素数组，返回独占 Array；对应 Java: Connection#createArrayOf。\n'
assert t.count(comment)==1
t=t.replace(comment+'\n','')
marker='    async fn create_array_of('
assert t.count(marker)==1
t=t.replace(marker,comment+marker)
p.write_text(t,encoding='utf-8',newline='\n')
changes[p.relative_to(w).as_posix()]={'before_sha256':hashlib.sha256(before).hexdigest()}
paths.append(p)
owner=w/'crates/druid/tests/resource_owner_cancellation_test.rs'
before=owner.read_bytes()
(d/'owner-before-format.rs').write_bytes(before)
names=lambda text:re.findall(r'#\[(?:tokio::)?test\]\s*(?:async\s+)?fn\s+(\w+)',text)
tests=names(before.decode('utf-8'))
assert len(tests)==105
changes[owner.relative_to(w).as_posix()]={'before_sha256':hashlib.sha256(before).hexdigest()}
paths.append(owner)
tool='C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin'
env=os.environ.copy()
env.update(RUSTC=tool+'/rustc.exe',RUSTDOC=tool+'/rustdoc.exe',RUSTUP_TOOLCHAIN='1.97.1-x86_64-pc-windows-msvc',RUSTUP_AUTO_INSTALL='0',
    PATH=tool+os.pathsep+env['PATH'],CARGO_TARGET_DIR='F:/codex_build_cache/druid_rust/task7_standard_cargo13_1971',
    CARGO_BUILD_JOBS='1',RUST_TEST_THREADS='1',TMP='F:/codex_tmp/task7_standard_cargo13',TEMP='F:/codex_tmp/task7_standard_cargo13')
subprocess.run([tool+'/rustfmt.exe','--edition','2021']+[str(p) for p in paths],env=env,check=True)
assert names(owner.read_text(encoding='utf-8'))==tests
for p in paths:changes[p.relative_to(w).as_posix()]['after_sha256']=sha(p)
s=dict(terminal=False,production_applied=False,changes=changes,retained_test_identities=tests,
       ruling='Equivalent method item references replace four redundant closures; relocate Array doc to Array method. Rustfmt only the five changed library files and owner test. Preserve105 test identities and original negative probes. No lint allow; main integrated23 untouched.')
def save():
    (d/'summary.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
save()
cmd=list(prior['command'])
log=d/'clippy31.log'
with log.open('xb') as output:
    result=subprocess.run(cmd,cwd=w,env=env,stdout=output,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
s.update(terminal=True,exit_code=result.returncode,command=cmd,log=str(log),log_sha256=sha(log),
         changed_during_command=[name for name,value in changes.items() if sha(w/name)!=value['after_sha256']])
save()
print('clippy31',result.returncode,flush=True)
raise SystemExit(result.returncode)
