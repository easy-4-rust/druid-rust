import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
d=b/'task7-owner-clippy-repair32'
d.mkdir(exist_ok=False)
w=b/'task7-standard-cargo-candidate1/workspace'
prior=json.loads((b/'task7-owner-clippy-repair31/summary.json').read_text(encoding='utf-8'))
assert prior['terminal'] and prior['exit_code']==101 and not prior['changed_during_command']
p=w/'crates/druid/tests/resource_owner_cancellation_test.rs'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before=p.read_bytes()
(d/'owner-before.rs').write_bytes(before)
t=before.decode('utf-8')
old='    struct_args: Mutex<Vec<(Option<String>, Option<Vec<RdbcObject>>)>>,'
assert t.count(old)==1
t=t.replace(old,'    struct_args: Mutex<Vec<StructFactoryArguments>>,')
marker='#[derive(Debug, Default)]\nstruct Control {'
assert t.count(marker)==1
t=t.replace(marker,'/// 保留结构工厂nullable类型名和有序属性的原始入参。\ntype StructFactoryArguments = (Option<String>, Option<Vec<RdbcObject>>);\n\n'+marker)
for old in [
    '    let probes = control.arrays.lock().unwrap();\n    assert_eq!(probes[1].args, (None, None));\n    assert_eq!(probes[2].args, (Some("".into()), Some(vec![])));\n    drop(probes);',
    '    let args = control.struct_args.lock().unwrap();\n    assert_eq!(args[0], (Some("vendor.Empty".into()), None));\n    assert_eq!(args[1], (Some("vendor.Empty".into()), Some(vec![])));\n    assert_eq!(args[2], (None, None));\n    drop(args);']:
    assert t.count(old)==1
    body='\n'.join('    '+line for line in old.splitlines()[:-1])
    t=t.replace(old,'    {\n'+body+'\n    }')
pattern=r'if (self\.probe\.panic_(?:free|read|write)\.swap\(false, Ordering::SeqCst\)) \{\s+panic!\("(controlled (?:Blob|Clob|XML) (?:free|read|write) panic)"\);\s+\}'
t,count=re.subn(pattern,lambda m:'assert!(!'+m[1]+', "'+m[2]+'");',t)
assert count==5
names=lambda text:re.findall(r'#\[(?:tokio::)?test\]\s*(?:async\s+)?fn\s+(\w+)',text)
assert names(t)==prior['retained_test_identities']
p.write_text(t,encoding='utf-8',newline='\n')
tool='C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin'
env=os.environ.copy()
env.update(RUSTC=tool+'/rustc.exe',RUSTDOC=tool+'/rustdoc.exe',RUSTUP_TOOLCHAIN='1.97.1-x86_64-pc-windows-msvc',RUSTUP_AUTO_INSTALL='0',
    PATH=tool+os.pathsep+env['PATH'],CARGO_TARGET_DIR='F:/codex_build_cache/druid_rust/task7_standard_cargo13_1971',
    CARGO_BUILD_JOBS='1',RUST_TEST_THREADS='1',TMP='F:/codex_tmp/task7_standard_cargo13',TEMP='F:/codex_tmp/task7_standard_cargo13')
subprocess.run([tool+'/rustfmt.exe','--edition','2021',str(p)],env=env,check=True)
assert names(p.read_text(encoding='utf-8'))==prior['retained_test_identities']
s=dict(terminal=False,production_applied=False,source_sha256=sha(p),before_sha256=hashlib.sha256(before).hexdigest(),commands=[],
       ruling='Preserve105 test identities and all assertions; two explicit drop guards become lexical scopes before the same await points, alias exact Struct argument tuple, and five equivalent assert panic injections preserve atomic swaps/order/messages. No lint allow. Final-source formal Cargo/Clippy and31 standard resource regression use independent workspace.')
def save():
    (d/'summary.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
save()
commands=[('clippy32',list(prior['command'])),
          ('owner-runtime32',[tool+'/cargo.exe','test','-p','druid','--test','resource_owner_cancellation_test','--all-features','--locked','--offline','-j1','--','--test-threads=1']),
          ('standard-runtime32',[tool+'/cargo.exe','test','-p','druid-rdbc','--test','resource_standard_contract_test','--all-features','--locked','--offline','-j1','--','--test-threads=1'])]
for name,cmd in commands:
    log=d/(name+'.log')
    with log.open('xb') as output:
        result=subprocess.run(cmd,cwd=w,env=env,stdout=output,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
    output=log.read_text(encoding='utf-8')
    s['commands'].append(dict(name=name,command=cmd,exit_code=result.returncode,log=str(log),sha256=sha(log)))
    save()
    print(name,result.returncode,flush=True)
    if result.returncode:
        s.update(terminal=True,exit_code=result.returncode)
        save()
        raise SystemExit(result.returncode)
    if name=='clippy32':
        assert not re.search(r'^warning:',output,re.M)
        s['clippy_certified']=True
    elif name=='owner-runtime32':
        assert '105 passed; 0 failed;' in output
        s['owner_runtime_tests']=105
    else:
        assert '31 passed; 0 failed;' in output
        s['standard_runtime_tests']=31
    assert sha(p)==s['source_sha256']
    save()
s.update(terminal=True,exit_code=0,cargo_certified=True)
save()
