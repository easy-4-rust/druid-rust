use super::druid_clob_state::DruidClobState;
use super::resource_context::ResourceContext;
use super::resource_runtime_capabilities::ResourceRuntimeCapabilities;
use super::standard_resource_admission::StandardResourceAdmission;
use super::standard_resource_handle::StandardResourceHandle;
use super::standard_resource_registry::StandardResourceRegistry;
use druid_rdbc::error::RdbcError;
use druid_rdbc::resource::{
    Clob, ClobPattern, RdbcInputStream, RdbcOutputStream, RdbcReader, RdbcWriter,
    ResourceOperations,
};
use druid_rdbc::types::RdbcString;
use std::sync::Arc;

/// 连接监管的标准字符大对象代理；驱动操作独占借用，释放交给 registry。
/// 对应 Java: com.alibaba.druid.proxy.jdbc.ClobProxyImpl。
pub(crate) struct DruidClob {
    state: Arc<DruidClobState>,
    registry: Arc<StandardResourceRegistry>,
    capabilities: ResourceOperations,
}
impl std::fmt::Debug for DruidClob {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("DruidClob")
            .field("state", &self.state.context.state())
            .field("capabilities", &self.capabilities)
            .finish_non_exhaustive()
    }
}
impl DruidClob {
    /// 接管 payload、上下文及 registry；在 admission 中登记后返回独占标准代理。
    /// 拒绝登记时由 registry 清理对象，并返回原始登记错误。
    pub(crate) async fn register(
        payload: Box<dyn Clob>,
        context: Arc<ResourceContext>,
        registry: Arc<StandardResourceRegistry>,
        admission: &StandardResourceAdmission,
    ) -> Result<Self, RdbcError> {
        let driver_capabilities = payload.capabilities();
        let mut capabilities = ResourceOperations::empty();
        if driver_capabilities.contains(ResourceOperations::READ)
            && context
                .capabilities()
                .contains(ResourceRuntimeCapabilities::READ)
        {
            capabilities |= ResourceOperations::READ;
        }
        if driver_capabilities.contains(ResourceOperations::WRITE)
            && context
                .capabilities()
                .contains(ResourceRuntimeCapabilities::WRITE)
        {
            capabilities |= ResourceOperations::WRITE;
        }
        if driver_capabilities.contains(ResourceOperations::SEARCH)
            && context
                .capabilities()
                .contains(ResourceRuntimeCapabilities::SEARCH)
        {
            capabilities |= ResourceOperations::SEARCH;
        }
        if driver_capabilities.contains(ResourceOperations::TRUNCATE)
            && context
                .capabilities()
                .contains(ResourceRuntimeCapabilities::TRUNCATE)
        {
            capabilities |= ResourceOperations::TRUNCATE;
        }
        if driver_capabilities.contains(ResourceOperations::STREAM)
            && context
                .capabilities()
                .contains(ResourceRuntimeCapabilities::STREAM)
        {
            capabilities |= ResourceOperations::STREAM;
        }
        if driver_capabilities.contains(ResourceOperations::RANGE)
            && context
                .capabilities()
                .contains(ResourceRuntimeCapabilities::RANGE)
        {
            capabilities |= ResourceOperations::RANGE;
        }
        if driver_capabilities.contains(ResourceOperations::FREE)
            && context
                .capabilities()
                .contains(ResourceRuntimeCapabilities::FREE)
        {
            capabilities |= ResourceOperations::FREE;
        }
        let state = Arc::new(DruidClobState::new(payload, context));
        let actor: Arc<dyn StandardResourceHandle> = state.clone();
        let result = registry.register_batch(admission, vec![actor]).await;
        admission.finish();
        result?;
        Ok(Self {
            state,
            registry,
            capabilities,
        })
    }
    fn require(
        &self,
        capability: ResourceOperations,
        operation: &'static str,
    ) -> Result<(), RdbcError> {
        // 先检查生命周期，再检查能力，保证关闭错误优先且不触碰底层资源。
        self.state
            .context
            .require(ResourceRuntimeCapabilities::empty(), operation)?;
        if self.state.registration().is_none_or(
            super::standard_resource_registration::StandardResourceRegistration::cleanup_requested,
        ) {
            return Err(RdbcError::rdbc_resource_closed(
                self.state.context.kind().standard_name(),
            ));
        }
        if !self.capabilities.contains(capability) {
            return Err(RdbcError::feature_not_supported(operation));
        }
        Ok(())
    }
    async fn payload(
        &self,
        capability: ResourceOperations,
        operation: &'static str,
    ) -> Result<tokio::sync::MutexGuard<'_, Box<dyn Clob>>, RdbcError> {
        self.require(capability, operation)?;
        let payload = self.state.payload.lock().await;
        // 等待锁期间父级可能开始清理，因此持锁后再次验证。
        self.require(capability, operation)?;
        Ok(payload)
    }
}
#[async_trait::async_trait]
impl Clob for DruidClob {
    fn capabilities(&self) -> ResourceOperations {
        self.capabilities
    }
    async fn length(&mut self) -> Result<i64, RdbcError> {
        let result = self
            .payload(ResourceOperations::READ, "Clob#length")
            .await?
            .length()
            .await;
        self.state.context.classify_operation_result(result)
    }
    async fn get_sub_string(
        &mut self,
        position: i64,
        length: i32,
    ) -> Result<RdbcString, RdbcError> {
        let result = self
            .payload(ResourceOperations::READ, "Clob#get_sub_string")
            .await?
            .get_sub_string(position, length)
            .await;
        self.state.context.classify_operation_result(result)
    }
    async fn get_character_stream(&mut self) -> Result<RdbcReader, RdbcError> {
        let result = self
            .payload(
                ResourceOperations::READ | ResourceOperations::STREAM,
                "Clob#get_character_stream",
            )
            .await?
            .get_character_stream()
            .await;
        self.state.context.classify_operation_result(result)
    }
    async fn get_ascii_stream(&mut self) -> Result<RdbcInputStream, RdbcError> {
        let result = self
            .payload(
                ResourceOperations::READ | ResourceOperations::STREAM,
                "Clob#get_ascii_stream",
            )
            .await?
            .get_ascii_stream()
            .await;
        self.state.context.classify_operation_result(result)
    }
    async fn position_string(
        &mut self,
        pattern: &RdbcString,
        start: i64,
    ) -> Result<Option<i64>, RdbcError> {
        let result = self
            .payload(ResourceOperations::SEARCH, "Clob#position_string")
            .await?
            .position_string(pattern, start)
            .await;
        self.state.context.classify_operation_result(result)
    }
    async fn position_clob(
        &mut self,
        pattern: ClobPattern<'_>,
        start: i64,
    ) -> Result<Option<i64>, RdbcError> {
        let result = self
            .payload(ResourceOperations::SEARCH, "Clob#position_clob")
            .await?
            .position_clob(pattern, start)
            .await;
        self.state.context.classify_operation_result(result)
    }
    async fn set_string(&mut self, position: i64, value: &RdbcString) -> Result<i32, RdbcError> {
        let result = self
            .payload(ResourceOperations::WRITE, "Clob#set_string")
            .await?
            .set_string(position, value)
            .await;
        self.state.context.classify_operation_result(result)
    }
    async fn set_string_range(
        &mut self,
        position: i64,
        value: &RdbcString,
        offset: i32,
        length: i32,
    ) -> Result<i32, RdbcError> {
        let result = self
            .payload(
                ResourceOperations::WRITE | ResourceOperations::RANGE,
                "Clob#set_string_range",
            )
            .await?
            .set_string_range(position, value, offset, length)
            .await;
        self.state.context.classify_operation_result(result)
    }
    async fn set_ascii_stream(&mut self, position: i64) -> Result<RdbcOutputStream, RdbcError> {
        let result = self
            .payload(
                ResourceOperations::WRITE | ResourceOperations::STREAM,
                "Clob#set_ascii_stream",
            )
            .await?
            .set_ascii_stream(position)
            .await;
        self.state.context.classify_operation_result(result)
    }
    async fn set_character_stream(&mut self, position: i64) -> Result<RdbcWriter, RdbcError> {
        let result = self
            .payload(
                ResourceOperations::WRITE | ResourceOperations::STREAM,
                "Clob#set_character_stream",
            )
            .await?
            .set_character_stream(position)
            .await;
        self.state.context.classify_operation_result(result)
    }
    async fn truncate(&mut self, length: i64) -> Result<(), RdbcError> {
        let result = self
            .payload(ResourceOperations::TRUNCATE, "Clob#truncate")
            .await?
            .truncate(length)
            .await;
        self.state.context.classify_operation_result(result)
    }
    async fn get_character_stream_range(
        &mut self,
        position: i64,
        length: i64,
    ) -> Result<RdbcReader, RdbcError> {
        let result = self
            .payload(
                ResourceOperations::READ | ResourceOperations::STREAM | ResourceOperations::RANGE,
                "Clob#get_character_stream_range",
            )
            .await?
            .get_character_stream_range(position, length)
            .await;
        self.state.context.classify_operation_result(result)
    }
    async fn free(&mut self) -> Result<(), RdbcError> {
        if let Some(result) = self.state.completed_release().await {
            return result;
        }
        let registration = self
            .state
            .registration()
            .ok_or(RdbcError::ConnectionDiscarded)?;
        self.registry
            .close_registered(std::slice::from_ref(registration))
            .await
    }
}
