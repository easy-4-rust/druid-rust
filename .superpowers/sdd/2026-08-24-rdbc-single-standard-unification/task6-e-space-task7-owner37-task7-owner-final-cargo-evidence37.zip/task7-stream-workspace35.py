import hashlib
import json
from pathlib import Path
import shutil

b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
d=b/'task7-async-stream-candidate35'
d.mkdir(exist_ok=False)
w=d/'workspace'
w.mkdir()
main=b/'task7-external-resource-consumer-candidate1'
frozen=json.loads((main/'integrated23-frozen-inputs.json').read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert all(sha(main/'workspace'/name)==digest for name,digest in frozen.items())
for name in frozen:
    target=w/name
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(main/'workspace'/name,target)
quality=json.loads((b/'task7-owner-strict-clippy33.summary.json').read_text(encoding='utf-8'))
q=b/'task7-standard-cargo-candidate1/workspace'
for name,digest in quality['source_hashes'].items():
    assert sha(q/name)==digest
    shutil.copyfile(q/name,w/name)
test=w/'crates/druid-wrapper/tests/async_result_set_test.rs'
assert not test.exists()
shutil.copyfile(b/'async_result_set_contract34.rs',test)
inputs={name:sha(w/name) for name in frozen}
inputs[test.relative_to(w).as_posix()]=sha(test)
(d/'baseline-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf-8')
(d/'preparation.summary.json').write_text(json.dumps(dict(terminal=True,source_files=len(inputs),
    independent_workspace=True,production_applied=False,baseline='integrated23 RDBC510 passing snapshot + owner strict quality33',
    ruling='No mutation of original40390 or15012 running sources. ForwardOnly + positive fetch hint opts into demand-driven bounded cursor; scroll/default0 and generic execute preserve existing eager semantics. ResultSet remains sole canonical cursor; Stream is an owning extension. This chooses scheduling policy within ADR-RDBC-006 Task7, does not reduce its eight obligations.'),indent=2)+'\n',encoding='utf-8')
e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust')
line=('\n\n2026-10-08 Task7流式实现调度决定：Ruling：ForwardOnly且正fetch_size通过既有标准Statement/PreparedStatement入口选择真实需求驱动有界游标；零hint/滚动查询及generic execute保留原缓冲行数语义。ResultSet仍唯一canonical，Stream仅拥有游标的扩展，不新增driver端口。依据ADR-RDBC-006 Task7；若错误将影响既有fetch hint语义，须完整BASE/参数/生成键/取消回归，八项义务不缩减。独立workspace35从主集成1149冻结及quality33源码建立，新增async_result_set_test.rs五真实SQLite合同；先观察原12642基线RED，未修改生产或两个运行workspace。\n')
for p in [e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md',e/'docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md']:
    with p.open('a',encoding='utf-8',newline='') as output:output.write(line)
print('prepared',len(inputs),flush=True)
