import hashlib
import json
from pathlib import Path

b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
main=b/'task7-external-resource-consumer-candidate1/workspace'
stream=b/'task7-async-stream-candidate35/workspace'
red=json.loads((b/'task7-pooled-red66/summary.json').read_text(encoding='utf-8'))
assert red['terminal'] and red['exit_code']==101 and red['results']==[['0','5','0']] and not red['changed_inputs']
audit=json.loads((b/'task7-convergence-audit67/summary.json').read_text(encoding='utf-8'))
d=b/'task7-converge68'
d.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
preserve='crates/druid/tests/task6_pooled_connection_exception_paths_test_parity.rs'
applied=[]
for item in audit['convergence_changes']:
    rel=item['path']
    if rel==preserve:
        continue
    destination=main/rel
    assert (sha(destination) if destination.exists() else None)==item['main']
    assert sha(stream/rel)==item['stream']
    if destination.exists():
        old=d/'before'/rel
        old.parent.mkdir(parents=True,exist_ok=True)
        old.write_bytes(destination.read_bytes())
    destination.parent.mkdir(parents=True,exist_ok=True)
    destination.write_bytes((stream/rel).read_bytes())
    applied.append(item)
assert sha(main/preserve)==json.loads((b/'task7-resume62/summary.json').read_text(encoding='utf-8'))['after_sha256']
assert (main/'crates/druid/tests/task7_pooled_async_result_set_test.rs').read_bytes()==(b/'task7_pooled_async_result_set_test65.rs').read_bytes()
(d/'summary.json').write_text(json.dumps(dict(production_applied=False,applied=applied,preserved_signature_fix=True,preserved_five_pooled_contracts=True,stream_workspace_unmodified=True),indent=2)+'\n',encoding='utf-8')
runner=(b/'task7-pooled-red66.py').read_text(encoding='utf-8')
runner=runner.replace("d=b/'task7-pooled-red66'", "d=b/'task7-pooled-green69'")
old="frozen={p.relative_to(w).as_posix():sha(p) for p in w.rglob('*') if p.is_file() and 'target' not in p.relative_to(w).parts and (p.suffix in ['.rs','.toml','.json','.inc'] or p.name=='Cargo.lock')}"
new=old+"\noriginal=json.loads((b/'task7-external-resource-consumer-candidate1/integrated23-frozen-inputs.json').read_text(encoding='utf-8'))\nfrozen.update({rel:sha(w/rel) for rel in original})"
assert old in runner
runner=runner.replace(old,new)
(b/'task7-pooled-green69.py').write_text(runner,encoding='utf-8')
print(json.dumps(dict(converged_paths=len(applied),signature_fix_preserved=True,pooled_tests_unchanged=True)))
