import hashlib
import json
from pathlib import Path

b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
main=b/'task7-external-resource-consumer-candidate1/workspace'
stream=b/'task7-async-stream-candidate35/workspace'
d=b/'task7-convergence-audit67'
d.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
current=json.loads((b/'task7-druid-recheck64/frozen-inputs.json').read_text(encoding='utf-8'))
original=json.loads((b/'task7-external-resource-consumer-candidate1/integrated23-frozen-inputs.json').read_text(encoding='utf-8'))
excluded=[rel for rel in original if rel not in current]
assert all((main/rel).is_file() and sha(main/rel)==original[rel] for rel in excluded)
assert all((stream/rel).is_file() and sha(stream/rel)==original[rel] for rel in excluded)
changed_original=[rel for rel,h in original.items() if 'target' not in Path(rel).parts and sha(main/rel)!=h]
assert changed_original==['crates/druid/tests/task6_pooled_connection_exception_paths_test_parity.rs']
source=json.loads((b/'task7-stream-regression63/frozen-inputs.json').read_text(encoding='utf-8'))
changed=[dict(path=rel,main=sha(main/rel) if (main/rel).is_file() else None,stream=h) for rel,h in source.items() if not (main/rel).is_file() or sha(main/rel)!=h]
removed=[rel for rel in current if rel not in source]
s=dict(production_applied=False,old_denominator=len(original),rust_manifest_json_subset_count=len(current),omitted_assets_and_docs=excluded,omitted_assets_match_original_both_workspaces=True,original_source_changes=changed_original,convergence_changes=changed,main_only=removed,setup_correction='Initial assertion incorrectly assumed the 60 excluded original inputs were target artifacts. They are README/assets/properties/proto/cert fixtures; all remain byte-identical to original1149 in both workspaces. Subset freezes64/66 do not replace original denominator.')
(d/'summary.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(original=len(original),subset=len(current),assets_verified=len(excluded),convergence_paths=[x['path'] for x in changed]),indent=2))
