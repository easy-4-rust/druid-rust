from pathlib import Path
import json

b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
prior=json.loads((b/'task7-druid-recheck64/summary.json').read_text(encoding='utf-8'))
assert prior['terminal'] and prior['exit_code']==0 and not prior['changed_inputs']
w=b/'task7-external-resource-consumer-candidate1/workspace'
source=b/'task7_pooled_async_result_set_test65.rs'
target=w/'crates/druid/tests/task7_pooled_async_result_set_test.rs'
assert not target.exists()
target.write_bytes(source.read_bytes())
runner=(b/'task7-druid-recheck64.py').read_text(encoding='utf-8')
runner=runner.replace("d=b/'task7-druid-recheck64'", "d=b/'task7-pooled-red66'")
runner=runner.replace("'task6_pooled_connection_exception_paths_test_parity'", "'task7_pooled_async_result_set_test'")
runner=runner.replace("log=d/'exception-paths.log'", "log=d/'pooled-stream.log'")
(b/'task7-pooled-red66.py').write_text(runner,encoding='utf-8')
compile(runner,'task7-pooled-red66.py','exec')
print('Five pooled SQLite contracts installed only in stopped baseline candidate.')
