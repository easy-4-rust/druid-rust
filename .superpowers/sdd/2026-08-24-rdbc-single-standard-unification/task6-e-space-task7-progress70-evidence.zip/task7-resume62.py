import hashlib
import json
from pathlib import Path

b = Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
d = b / 'task7-resume62'
d.mkdir(exist_ok=False)
sha = lambda data: hashlib.sha256(data).hexdigest()
receipts = [b/'task7-external-resource-consumer-candidate1/integrated23.summary.json', b/'task7-stream-regression60/summary.json']
for receipt in receipts:
    value = json.loads(receipt.read_text(encoding='utf-8'))
    assert value['terminal'] and value['exit_code'] == 101
    for command in value['commands']:
        assert sha(Path(command['log']).read_bytes()) == command['sha256']
    (d/receipt.parent.name).mkdir()
    (d/receipt.parent.name/'summary.json').write_bytes(receipt.read_bytes())

w = b/'task7-external-resource-consumer-candidate1/workspace'
rel = 'crates/druid/tests/task6_pooled_connection_exception_paths_test_parity.rs'
p = w/rel
before = p.read_bytes()
after = before
pairs = []
for old_type, new_type in [('RdbcBlob', 'Blob'), ('RdbcClob', 'Clob'), ('RdbcNClob', 'NClob')]:
    old = f'Result<druid_rdbc::types::{old_type}, RdbcError>'.encode()
    new = f'Result<Box<dyn druid_rdbc::resource::{new_type}>, RdbcError>'.encode()
    assert after.count(old) == 1
    after = after.replace(old, new)
    pairs.append((old,new))
reverse = after
for old,new in pairs:
    reverse = reverse.replace(new,old)
assert reverse == before
(d/'exception_paths.before.rs').write_bytes(before)
p.write_bytes(after)
(d/'exception_paths.after.rs').write_bytes(after)
(d/'summary.json').write_text(json.dumps(dict(production_applied=False,source=rel,before_sha256=sha(before),after_sha256=sha(after),reverse_byte_identical=True,changes='Exactly three resource factory return signatures; original bodies, identities and assertions unchanged.'),indent=2)+'\n',encoding='utf-8')

runner = (b/'task7-stream-regression60.py').read_text(encoding='utf-8')
runner = runner.replace("d=b/'task7-stream-regression60'", "d=b/'task7-stream-regression63'")
runner = runner.replace("env=os.environ.copy()", "env=os.environ.copy()\nenv['DRUID_RDBC_EXTERNAL_TARGET_ROOT']='F:/codex_build_cache/druid_rust/t7_rdbc63'")
runner = runner.replace("if p.is_file() and (p.suffix", "if p.is_file() and 'target' not in p.relative_to(w).parts and (p.suffix")
assert "d=b/'task7-stream-regression60'" not in runner
assert "'target' not in" in runner
(b/'task7-stream-regression63.py').write_text(runner,encoding='utf-8')
compile(runner,'task7-stream-regression63.py','exec')
print('Three signatures migrated with reverse byte identity; two original terminal receipts verified; retry63 prepared without source changes.')
