import hashlib,json,os,subprocess
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust')
source=b/'task7-external-resource-consumer-candidate1/workspace'
w=Path('F:/codex_build_cache/d91');w.mkdir(exist_ok=False)
d=b/'task7-parity-source91';d.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
f=json.loads((b/'task7-owned-release89/frozen-inputs.json').read_text(encoding='utf-8'))
assert all(sha(source/rel)==h for rel,h in f.items())
for rel,h in f.items():
 p=w/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((source/rel).read_bytes());assert sha(p)==h
controls={}
for base in ['scripts','docs/verification/rdbc-first']:
 for p in (e/base).rglob('*'):
  if not p.is_file() or p.suffix not in ['.py','.tsv','.json']:continue
  rel=p.relative_to(e).as_posix()
  if rel in f:
   assert sha(p)==f[rel],rel
   continue
  dst=w/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(p.read_bytes());controls[rel]=sha(dst)
f.update(controls)
(d/'frozen-inputs.json').write_text(json.dumps(f,indent=2)+'\n',encoding='utf-8')
env=os.environ.copy();env.update(GIT_DIR=str(e/'.git'),GIT_WORK_TREE=str(w),PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1')
python='C:/Espressif/tools/python/python.exe'
s=dict(terminal=False,production_applied=False,workspace=str(w),source_input_count=1158,control_input_count=len(controls),frozen_input_count=len(f),baseline_history='Read-only Git queries use original E Git database through process-local GIT_DIR/GIT_WORK_TREE; no branch, checkout, index or history mutation.',commands=[])
save=lambda:(d/'summary.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
save()
for name,args in [('c2-source',['scripts/verify_task6_deleted_test_parity.py','--root',str(w),'--no-execute']),('c1-source',['scripts/verify_task6_method_parity.py','--repository-root',str(w),'--no-execute'])]:
 cmd=[python,'-X','utf8']+args;log=d/(name+'.log')
 with log.open('xb') as out:r=subprocess.run(cmd,cwd=w,env=env,stdout=out,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
 changes=[rel for rel,h in f.items() if sha(w/rel)!=h]
 s['commands'].append(dict(name=name,command=cmd,exit_code=r.returncode,log=str(log),sha256=sha(log),changed_inputs=changes));save()
 print(json.dumps(dict(name=name,exit_code=r.returncode,changed_inputs=changes)),flush=True)
s.update(terminal=True,changed_inputs=[rel for rel,h in f.items() if sha(w/rel)!=h]);save()
