import csv,hashlib,io,json,sys
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
w=Path('F:/codex_build_cache/d91');d=b/'task7-signature-audit92';d.mkdir(exist_ok=False)
sys.dont_write_bytecode=True;sys.path.insert(0,str(w/'scripts'))
import verify_task6_method_parity as m
p=w/m.DEFAULT_MATRIX;data=p.read_bytes();rows=list(csv.DictReader(io.StringIO(data.decode('utf-8')),delimiter='\t'))
differences=[]
for row in rows:
 if row['method'] not in ['create_blob','create_clob','create_n_clob']:continue
 path=w/row['target_path'];method=row['target_symbol'].rsplit('::',1)[-1]
 actual=m.parse_target_method(path.read_text(encoding='utf-8'),row['target_trait'],method)
 if (row['target_signature'],row['target_signature_sha256'])!=(actual.signature,actual.signature_sha256):
  differences.append(dict(method=row['method'],source_object=row['source_object'],target_path=row['target_path'],old_signature=row['target_signature'],actual_signature=actual.signature,old_sha256=row['target_signature_sha256'],actual_sha256=actual.signature_sha256))
assert len(rows)==479 and differences
(d/'matrix-before.tsv').write_bytes(data)
s=dict(production_applied=False,read_only=True,formal_c1_source91_still_pending=True,mapped_rows=len(rows),differences=differences,ruling='This is a focused current-source signature comparison, not the complete C1 verdict. Preserve all479 retired-method rows, original behavior selectors, baseline signatures and denominator; refresh only actual canonical target signature/hash after original source91 reaches terminal. Do not mutate any running frozen workspace.')
(d/'summary.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8');print(json.dumps(s,ensure_ascii=False,indent=2))
