import csv,hashlib,io,json
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
w=Path('F:/codex_build_cache/d91');d=b/'task7-signature-refresh93';d.mkdir(exist_ok=False)
prior=json.loads((b/'task7-parity-source91/summary.json').read_text(encoding='utf-8'))
assert prior['terminal'] and not prior['changed_inputs']
assert [(c['name'],c['exit_code']) for c in prior['commands']]==[('c2-source',0),('c1-source',1)]
audit=json.loads((b/'task7-signature-audit92/summary.json').read_text(encoding='utf-8'))
p=w/'docs/verification/rdbc-first/task6-method-migration.tsv';before=p.read_bytes()
assert before==(b/'task7-signature-audit92/matrix-before.tsv').read_bytes()
reader=csv.DictReader(io.StringIO(before.decode('utf-8')),delimiter='\t');fields=reader.fieldnames;rows=list(reader)
original=[dict(row) for row in rows]
for change in audit['differences']:
 matches=[row for row in rows if row['method']==change['method'] and row['source_object']==change['source_object']]
 assert len(matches)==1;row=matches[0]
 assert row['target_signature']==change['old_signature'] and row['target_signature_sha256']==change['old_sha256']
 row['target_signature']=change['actual_signature'];row['target_signature_sha256']=change['actual_sha256']
def render(values):
 output=io.StringIO();writer=csv.DictWriter(output,fieldnames=fields,delimiter='\t',lineterminator='\n');writer.writeheader();writer.writerows(values);return output.getvalue().encode('utf-8')
assert render(original)==before
assert len(rows)==479
changes=[]
for old,new in zip(original,rows):
 differing=[key for key in fields if old[key]!=new[key]]
 if differing:
  assert differing==['target_signature','target_signature_sha256'];changes.append(old['method'])
assert sorted(changes)==['create_blob','create_clob','create_n_clob']
(d/'matrix-before.tsv').write_bytes(before);p.write_bytes(render(rows));(d/'matrix-after.tsv').write_bytes(p.read_bytes())
sha=lambda data:hashlib.sha256(data).hexdigest()
s=dict(production_applied=False,changed_file=str(p),before_sha256=sha(before),after_sha256=sha(p.read_bytes()),rows=479,changed_methods=changes,changed_columns=['target_signature','target_signature_sha256'],preserved='All baseline source signatures, target paths/owners/UFCS, behavior selectors, dispositions, approval refs and other columns byte-for-byte; canonical rendering reverse check equals original.',ruling='Refresh actual standard resource factory target signatures after formal C1 source RED. The retired-method denominator remains479; new release_owned is additive API evidence, not a fabricated retired method. No source/runtime/API completion inferred.')
(d/'summary.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8');print(json.dumps(s,indent=2))
