//! Tests for the immutable client-side sequence/ACK frame window.

use druid_metrics::sequence_window::{PendingFrame, SequenceWindow, SequenceWindowError};

#[test]
fn push_encodes_once_and_retains_exact_frame_bytes() {
    let mut window = SequenceWindow::new(2);

    let inserted = window
        .push_with(|sequence| format!("complete-frame-{sequence}").into_bytes())
        .expect("first frame fits");

    assert_eq!(inserted.sequence, 1);
    assert_eq!(inserted.encoded_frame, b"complete-frame-1");
    assert_eq!(window.pending_frames(), vec![inserted]);
}

#[test]
fn ack_removes_only_the_matching_frame_and_frees_capacity() {
    let mut window = SequenceWindow::new(2);
    window.push_with(|_| b"frame-1".to_vec()).unwrap();
    window.push_with(|_| b"frame-2".to_vec()).unwrap();

    assert!(window.is_full());
    assert!(window.push_with(|_| b"must-not-run".to_vec()).is_err());

    window.ack(1).expect("known ACK succeeds");
    let third = window.push_with(|_| b"frame-3".to_vec()).unwrap();

    assert_eq!(third.sequence, 3);
    assert_eq!(
        window
            .pending_frames()
            .into_iter()
            .map(|frame| frame.sequence)
            .collect::<Vec<_>>(),
        vec![2, 3]
    );
}

#[test]
fn restore_preserves_bytes_and_advances_the_stream_sequence() {
    let mut window = SequenceWindow::new(3);
    let restored = PendingFrame {
        sequence: 7,
        encoded_frame: b"wire-identical-frame".to_vec(),
    };

    window.restore(restored.clone()).expect("restore fits");
    let next = window
        .push_with(|sequence| format!("frame-{sequence}").into_bytes())
        .unwrap();

    assert_eq!(window.pending_frames()[0], restored);
    assert_eq!(next.sequence, 8);
}

#[test]
fn restore_rejects_zero_duplicate_and_full_sequences() {
    let mut window = SequenceWindow::new(1);
    assert!(window
        .restore(PendingFrame {
            sequence: 0,
            encoded_frame: vec![0],
        })
        .is_err());

    let frame = PendingFrame {
        sequence: 3,
        encoded_frame: vec![3],
    };
    window.restore(frame.clone()).unwrap();
    assert!(window.restore(frame).is_err());
    assert!(window
        .restore(PendingFrame {
            sequence: 4,
            encoded_frame: vec![4],
        })
        .is_err());
}

#[test]
fn unknown_and_duplicate_ack_are_errors() {
    let mut window = SequenceWindow::new(1);
    window.push_with(|_| b"frame".to_vec()).unwrap();

    assert!(window.ack(99).is_err());
    window.ack(1).unwrap();
    assert!(window.ack(1).is_err());
    assert!(window.is_empty());
}

#[test]
fn out_of_order_ack_retains_the_entire_gap() {
    let mut window = SequenceWindow::new(2);
    window.push_with(|_| b"frame-1".to_vec()).unwrap();
    window.push_with(|_| b"frame-2".to_vec()).unwrap();

    let error = window
        .ack(2)
        .expect_err("ACK must advance from the oldest frame");

    assert_eq!(
        error,
        SequenceWindowError::OutOfOrderAck {
            expected: 1,
            received: 2,
        }
    );
    assert_eq!(window.len(), 2);
    assert_eq!(
        window
            .pending_frames()
            .into_iter()
            .map(|frame| frame.sequence)
            .collect::<Vec<_>>(),
        vec![1, 2]
    );
}

#[test]
fn client_never_allocates_or_restores_server_rejected_max_sequence() {
    let mut at_boundary = SequenceWindow::with_next_sequence(2, Some(u64::MAX));
    let error = at_boundary
        .push_with(|_| b"must-not-be-encoded".to_vec())
        .expect_err("u64::MAX is reserved because the server rejects it");
    assert_eq!(error, SequenceWindowError::SequenceExhausted);
    assert!(at_boundary.is_empty());

    let mut restore = SequenceWindow::new(2);
    assert_eq!(
        restore
            .restore(PendingFrame {
                sequence: u64::MAX,
                encoded_frame: b"server-rejected-max".to_vec(),
            })
            .expect_err("server-rejected max sequence cannot be replayed"),
        SequenceWindowError::InvalidSequence(u64::MAX)
    );

    let last_valid = PendingFrame {
        sequence: u64::MAX - 1,
        encoded_frame: b"last-valid-sequence".to_vec(),
    };
    restore.restore(last_valid.clone()).unwrap();
    assert_eq!(
        restore
            .push_with(|_| b"must-not-be-encoded".to_vec())
            .expect_err("no client sequence follows u64::MAX - 1"),
        SequenceWindowError::SequenceExhausted
    );
    assert_eq!(restore.pending_frames(), vec![last_valid]);
}
