//! Canonical standard compile-time conformance for every wrapper adapter family.

use druid_rdbc::connection::Connection;
use druid_rdbc::driver::ConnectionFactory;
use druid_rdbc::metadata::DatabaseMetaData;
use druid_rdbc::statement::PreparedStatement;
use druid_rdbc::wrapper::Wrapper;
use static_assertions::assert_impl_all;

#[test]
fn configured_core_adapter_families_implement_the_single_standard_directly() {
    assert_impl_all!(druid_wrapper::sqlx::SqlxConnectionAdapter: Connection);
    assert_impl_all!(druid_wrapper::sqlx::SqlxConnectionFactory: ConnectionFactory);
    assert_impl_all!(druid_wrapper::sqlx::SqlxPreparedStatement: PreparedStatement);
    assert_impl_all!(druid_wrapper::sqlx::SqlxDatabaseMetaData: DatabaseMetaData);

    assert_impl_all!(druid_wrapper::rbdc::RbdcConnectionAdapter: Connection);
    assert_impl_all!(druid_wrapper::rbdc::RbdcConnectionFactory: ConnectionFactory);
    assert_impl_all!(druid_wrapper::rbdc::RbdcDatabaseMetaData: DatabaseMetaData);

    assert_impl_all!(druid_wrapper::toasty::ToastyConnectionAdapter: Connection);
    assert_impl_all!(druid_wrapper::toasty::ToastyConnectionFactory: ConnectionFactory);
    assert_impl_all!(druid_wrapper::toasty::ToastyDatabaseMetaData: DatabaseMetaData);
}

#[test]
fn catalog_data_sources_implement_canonical_wrapper_identity() {
    let druid_wrapper_method: fn(
        &druid_wrapper::rdbc::DruidRdbcDataSource,
        Option<std::any::TypeId>,
    ) -> Result<bool, druid_rdbc::error::RdbcError> =
        <druid_wrapper::rdbc::DruidRdbcDataSource as Wrapper>::is_wrapper_for;
    let dynamic_wrapper_method: fn(
        &druid_wrapper::rdbc::DynamicRdbcDataSource,
        Option<std::any::TypeId>,
    ) -> Result<bool, druid_rdbc::error::RdbcError> =
        <druid_wrapper::rdbc::DynamicRdbcDataSource as Wrapper>::is_wrapper_for;

    assert_ne!(std::mem::size_of_val(&druid_wrapper_method), 0);
    assert_ne!(std::mem::size_of_val(&dynamic_wrapper_method), 0);
}

#[cfg(feature = "duckdb-native")]
#[test]
fn duckdb_family_implements_the_single_standard_directly() {
    assert_impl_all!(druid_wrapper::duckdb::DuckDbConnectionAdapter: Connection);
    assert_impl_all!(druid_wrapper::duckdb::DuckDbConnectionFactory: ConnectionFactory);
}

#[cfg(feature = "http-sql")]
#[test]
fn http_sql_family_implements_the_single_standard_directly() {
    assert_impl_all!(druid_wrapper::http_sql::HttpSqlConnectionAdapter: Connection);
    assert_impl_all!(druid_wrapper::http_sql::HttpSqlConnectionFactory: ConnectionFactory);
}

#[cfg(feature = "libsql-native")]
#[test]
fn libsql_family_implements_the_single_standard_directly() {
    assert_impl_all!(druid_wrapper::libsql::LibSqlConnectionAdapter: Connection);
    assert_impl_all!(druid_wrapper::libsql::LibSqlConnectionFactory: ConnectionFactory);
}

#[cfg(feature = "jdbc-agent")]
#[test]
fn jdbc_agent_family_implements_the_single_standard_directly() {
    assert_impl_all!(druid_wrapper::jdbc_agent::JdbcAgentConnection: Connection);
    assert_impl_all!(druid_wrapper::jdbc_agent::JdbcAgentConnectionFactory: ConnectionFactory);
    assert_impl_all!(druid_wrapper::jdbc_agent::JdbcAgentDatabaseMetaData: DatabaseMetaData);
}
