import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
from datetime import datetime,timezone

b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
d=b/'task7-external-resource-consumer-candidate1'
w=d/'workspace'
q=b/'task7-standard-cargo-candidate1'
e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust')
ledger=e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads((d/'integrated17.summary.json').read_text(encoding='utf-8'))
assert old['terminal'] and old['exit_code']==101
frozen=json.loads((d/'integrated17-frozen-inputs.json').read_text(encoding='utf-8'))
assert all(sha(w/p)==digest for p,digest in frozen.items())
red=(d/'integrated17-rdbc-complete.log').read_text(encoding='utf-8')
assert 'LNK1181' in red and 'LNK1104' in red
blocks=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',red)
terminal=dict(terminal=True,original_session=37404,exit_code=101,changed_inputs=[],
    results=dict(passed=sum(int(x[0]) for x in blocks),failed=sum(int(x[1]) for x in blocks),ignored=sum(int(x[2]) for x in blocks),blocks=len(blocks)),
    log_sha256=sha(d/'integrated17-rdbc-complete.log'),
    ruling='Two external fixture targets failed at long-path linker setup, not their expected semantic compiler diagnostics. All generated435 tests ran and passed. Subsequent Wrapper/Druid targets not run.')
terminal_path=b/'task7-integrated17-terminal23.summary.json'
assert not terminal_path.exists()
terminal_path.write_text(json.dumps(terminal,indent=2)+'\n',encoding='utf-8')
for p in [terminal_path,d/'integrated17-rdbc-complete.log']:
    target=ledger/('task6-e-space-task7-terminal23-'+p.name)
    assert not target.exists()
    shutil.copyfile(p,target)
quality=json.loads((q/'quality22.summary.json').read_text(encoding='utf-8'))
assert quality['terminal'] and quality['runtime_tests']==31 and quality['clippy_certified']
changes={}
paths=['Cargo.toml','crates/druid-rdbc/src/resource/standard_resource_value.rs',
    'crates/druid-rdbc/tests/resource_standard_contract_test.rs',
    'crates/druid-rdbc/tests/resource_standard_support/array_contract.rs',
    'crates/druid-rdbc/tests/resource_standard_support/sql_xml_contract.rs']
for name in paths:
    source=q/'workspace'/name
    target=w/name
    changes[name]=dict(before_sha256=sha(target),after_sha256=sha(source))
    shutil.copyfile(source,target)
for name,family in [('no_physical_public_surface_test.rs','no-physical-public-surface'),
                    ('standard_wrapper_contract_test.rs','external-wrapper-fixtures')]:
    p=w/'crates/druid-rdbc/tests'/name
    before=p.read_text(encoding='utf-8')
    t=before
    needle='manifest_dir.join("target/'+family+'")'
    assert t.count(needle)==1
    replacement=('std::env::var_os("DRUID_RDBC_EXTERNAL_TARGET_ROOT").map_or_else(\n'
        '                || '+needle+',\n'
        '                |root| std::path::PathBuf::from(root).join("'+family+'"),\n'
        '            )')
    t=t.replace(needle,replacement)
    assert t[t.index('#[test]'):]==before[before.index('#[test]'):]
    changes[p.relative_to(w).as_posix()]=dict(before_sha256=sha(p))
    p.write_text(t,encoding='utf-8',newline='\n')
    changes[p.relative_to(w).as_posix()]['after_sha256']=sha(p)
inputs={name:sha(w/name) for name in frozen}
(d/'integrated23-frozen-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf-8')
toolchain='C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin'
env=os.environ.copy()
env.update(RUSTC=toolchain+'/rustc.exe',RUSTDOC=toolchain+'/rustdoc.exe',
    RUSTUP_TOOLCHAIN='1.97.1-x86_64-pc-windows-msvc',RUSTUP_AUTO_INSTALL='0',
    PATH=toolchain+os.pathsep+env['PATH'],CARGO_TARGET_DIR='F:/codex_build_cache/druid_rust/task6_lifetime_clean_1971_20261008',
    CARGO_BUILD_JOBS='1',RUST_TEST_THREADS='1',TMP='F:/codex_tmp/task7_integrated23',TEMP='F:/codex_tmp/task7_integrated23',
    DRUID_RDBC_EXTERNAL_TARGET_ROOT='F:/codex_build_cache/druid_rust/t7_rdbc23')
Path(env['TMP']).mkdir(parents=True,exist_ok=True)
s=dict(terminal=False,production_applied=False,commands=[],changes=changes,frozen_input_count=len(inputs),
    started=datetime.now(timezone.utc).isoformat(),
    ruling='Merge actually Clippy/Cargo-verified31 contract improvements and private callback alias. External fixture helpers accept a short target root with unchanged fallback and byte-identical test bodies. Preserve exact E0499/E0515/E0277 and canonical/SPI assertions; do not turn linker failures into semantic RED. Owner quality still incomplete.')
def save():
    (d/'integrated23.summary.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
save()
for name,package in [('rdbc-complete','druid-rdbc'),('wrapper-complete','druid-wrapper'),('druid-complete','druid')]:
    cmd=[toolchain+'/cargo.exe','test','-p',package,'--all-features','--locked','--offline','--no-fail-fast','-j1']
    log=d/('integrated23-'+name+'.log')
    with log.open('xb') as f:
        r=subprocess.run(cmd,cwd=w,env=env,stdout=f,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
    changed=[name for name,digest in inputs.items() if not (w/name).is_file() or sha(w/name)!=digest]
    s['commands'].append(dict(name=name,command=cmd,exit_code=r.returncode,log=str(log),sha256=sha(log),changed_inputs=changed))
    save()
    print(name,r.returncode,flush=True)
    if r.returncode or changed:
        s.update(terminal=True,exit_code=r.returncode or 1,ended=datetime.now(timezone.utc).isoformat())
        save()
        raise SystemExit(s['exit_code'])
s.update(terminal=True,exit_code=0,ended=datetime.now(timezone.utc).isoformat())
save()
