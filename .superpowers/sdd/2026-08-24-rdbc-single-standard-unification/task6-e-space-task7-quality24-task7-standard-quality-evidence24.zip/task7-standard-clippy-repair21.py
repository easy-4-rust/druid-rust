import hashlib
import json
import os
from pathlib import Path
import subprocess

b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
d=b/'task7-standard-cargo-candidate1'
w=d/'workspace'
prior=json.loads((d/'clippy20.summary.json').read_text(encoding='utf-8'))
assert prior['terminal'] and prior['exit_code']!=0 and not prior['changed_inputs']
assert 'type-complexity' in (d/'clippy20.log').read_text(encoding='utf-8')
p=w/'crates/druid-rdbc/src/resource/standard_resource_value.rs'
t=p.read_text(encoding='utf-8')
old="release: for<'a> fn(\n            &'a mut T,\n        )\n            -> Pin<Box<dyn Future<Output = Result<(), RdbcError>> + Send + 'a>>,"
assert t.count(old)==1
before=p.read_bytes()
t=t.replace(old,'release: StandardResourceRelease<T>,')
marker='/// 唯一标准资源对象的共享值容器'
alias=("/// 标准资源的异步释放回调；保留驱动借用生命周期及Send约束。\n"
       "type StandardResourceRelease<T> =\n"
       "    for<'a> fn(&'a mut T) -> Pin<Box<dyn Future<Output = Result<(), RdbcError>> + Send + 'a>>;\n\n")
assert t.count(marker)==1
t=t.replace(marker,alias+marker)
p.write_text(t,encoding='utf-8',newline='\n')
toolchain='C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin'
env=os.environ.copy()
env.update(RUSTC=toolchain+'/rustc.exe',RUSTDOC=toolchain+'/rustdoc.exe',
    RUSTUP_TOOLCHAIN='1.97.1-x86_64-pc-windows-msvc',RUSTUP_AUTO_INSTALL='0',PATH=toolchain+os.pathsep+env['PATH'],
    CARGO_TARGET_DIR='F:/codex_build_cache/druid_rust/task7_standard_cargo13_1971',CARGO_BUILD_JOBS='1',
    TMP='F:/codex_tmp/task7_standard_cargo13',TEMP='F:/codex_tmp/task7_standard_cargo13')
cmd=prior['commands'][0]['command']
log=d/'clippy21.log'
with log.open('xb') as f:
    r=subprocess.run(cmd,cwd=w,env=env,stdout=f,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
s=dict(terminal=True,exit_code=r.returncode,command=cmd,log_sha256=sha(log),
    source_before_sha256=hashlib.sha256(before).hexdigest(),source_after_sha256=sha(p),
    production_applied=False,ruling='Private release callback type alias; no public API or runtime behavior change; do not allow type_complexity.')
(d/'clippy21.summary.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
print('strict Clippy after callback alias',r.returncode,flush=True)
