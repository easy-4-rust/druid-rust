import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
d=b/'task7-standard-cargo-candidate1'
w=d/'workspace'
prior=json.loads((d/'clippy21.summary.json').read_text(encoding='utf-8'))
assert prior['terminal'] and prior['exit_code']!=0
root=w/'crates/druid-rdbc/tests/resource_standard_contract_test.rs'
xml=w/'crates/druid-rdbc/tests/resource_standard_support/sql_xml_contract.rs'
array=xml.with_name('array_contract.rs')
before={p:p.read_bytes() for p in [root,xml,array]}
t=xml.read_text(encoding='utf-8')
for kind in ['free','read','write']:
    old='if self.probe.panic_'+kind+'.swap(false,Ordering::SeqCst){panic!("controlled XML '+kind+' panic");}'
    assert t.count(old)==1
    t=t.replace(old,'assert!(!self.probe.panic_'+kind+'.swap(false,Ordering::SeqCst), "controlled XML '+kind+' panic");')
xml.write_text(t,encoding='utf-8',newline='\n')
t=root.read_text(encoding='utf-8')
assert t.count('mod ref_contract;')==1
root.write_text(t.replace('mod ref_contract;','mod ref_standard_contract;'),encoding='utf-8',newline='\n')
toolchain='C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin'
env=os.environ.copy()
env.update(RUSTC=toolchain+'/rustc.exe',RUSTDOC=toolchain+'/rustdoc.exe',
    RUSTUP_TOOLCHAIN='1.97.1-x86_64-pc-windows-msvc',RUSTUP_AUTO_INSTALL='0',PATH=toolchain+os.pathsep+env['PATH'],
    CARGO_TARGET_DIR='F:/codex_build_cache/druid_rust/task7_standard_cargo13_1971',CARGO_BUILD_JOBS='1',
    RUST_TEST_THREADS='1',TMP='F:/codex_tmp/task7_standard_cargo13',TEMP='F:/codex_tmp/task7_standard_cargo13')
subprocess.run([toolchain+'/rustfmt.exe','--edition','2021',str(xml),str(array)],env=env,check=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
s=dict(terminal=False,commands=[],production_applied=False,
    changes={p.relative_to(w).as_posix():dict(before_sha256=hashlib.sha256(data).hexdigest(),after_sha256=sha(p)) for p,data in before.items()},
    ruling='Equivalent assert panic injection retains atomic swap/order/messages; rustfmt distinguishes sequential if statements. Rename only the new outer Ref module to avoid module inception; inner original7 source stays byte-identical. No lint allow or test removal.')
def save():
    (d/'quality22.summary.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
save()
commands=[('clippy',[toolchain+'/cargo.exe','clippy','-p','druid-rdbc','--test','resource_standard_contract_test',
    '--all-features','--locked','--offline','-j1','--','-D','warnings']),
    ('runtime',[toolchain+'/cargo.exe','test','-p','druid-rdbc','--test','resource_standard_contract_test',
    '--all-features','--locked','--offline','-j1','--','--test-threads=1'])]
for name,cmd in commands:
    log=d/(name+'22.log')
    with log.open('xb') as f:
        r=subprocess.run(cmd,cwd=w,env=env,stdout=f,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
    s['commands'].append(dict(name=name,command=cmd,exit_code=r.returncode,log=str(log),sha256=sha(log)))
    save()
    print(name,r.returncode,flush=True)
    assert r.returncode==0,log.read_text(encoding='utf-8')[-5000:]
    assert not re.search(r'^warning:',log.read_text(encoding='utf-8'),re.M)
assert '31 passed; 0 failed;' in (d/'runtime22.log').read_text(encoding='utf-8')
s.update(terminal=True,runtime_tests=31,clippy_certified=True)
save()
