import hashlib
import json
import os
from pathlib import Path
import subprocess

b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
d=b/'task7-standard-cargo-candidate1'
w=d/'workspace'
prior=json.loads((d/'warning18.summary.json').read_text(encoding='utf-8'))
assert prior['terminal'] and prior['runtime_tests']==31 and prior['strict_rustc']
toolchain='C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin'
env=os.environ.copy()
env.update(RUSTC=toolchain+'/rustc.exe',RUSTDOC=toolchain+'/rustdoc.exe',
    RUSTUP_TOOLCHAIN='1.97.1-x86_64-pc-windows-msvc',RUSTUP_AUTO_INSTALL='0',
    PATH=toolchain+os.pathsep+env['PATH'],
    CARGO_TARGET_DIR='F:/codex_build_cache/druid_rust/task7_standard_cargo13_1971',
    CARGO_BUILD_JOBS='1',RUST_TEST_THREADS='1',TMP='F:/codex_tmp/task7_standard_cargo13',TEMP='F:/codex_tmp/task7_standard_cargo13')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs={p.relative_to(w).as_posix():sha(p) for p in w.rglob('*') if p.is_file()}
s=dict(terminal=False,production_applied=False,commands=[],frozen_input_count=len(inputs))
out=d/'clippy20.summary.json'
assert not out.exists()
def save():
    out.write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
save()
cmd=[toolchain+'/cargo.exe','clippy','-p','druid-rdbc','--test','resource_standard_contract_test',
    '--all-features','--locked','--offline','-j1','--','-D','warnings']
log=d/'clippy20.log'
with log.open('xb') as f:
    r=subprocess.run(cmd,cwd=w,env=env,stdout=f,stderr=subprocess.STDOUT,
        creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
changed=[name for name,digest in inputs.items() if not (w/name).is_file() or sha(w/name)!=digest]
s.update(terminal=True,exit_code=r.returncode,changed_inputs=changed,
    commands=[dict(command=cmd,exit_code=r.returncode,log=str(log),sha256=sha(log))])
save()
assert not changed
print('strict scoped Clippy',r.returncode,flush=True)
