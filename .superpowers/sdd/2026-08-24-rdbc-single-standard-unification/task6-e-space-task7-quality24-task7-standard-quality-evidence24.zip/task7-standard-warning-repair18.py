import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
d=b/'task7-standard-cargo-candidate1'
w=d/'workspace'
previous=json.loads((d/'retry13.summary.json').read_text(encoding='utf-8'))
assert previous['terminal'] and previous['exit_code']==0
toolchain='C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin'
env=os.environ.copy()
env.update(RUSTC=toolchain+'/rustc.exe',RUSTDOC=toolchain+'/rustdoc.exe',
    RUSTUP_TOOLCHAIN='1.97.1-x86_64-pc-windows-msvc',RUSTUP_AUTO_INSTALL='0',
    CARGO_TARGET_DIR='F:/codex_build_cache/druid_rust/task7_standard_cargo13_1971',
    CARGO_BUILD_JOBS='1',RUST_TEST_THREADS='1',TMP='F:/codex_tmp/task7_standard_cargo13',TEMP='F:/codex_tmp/task7_standard_cargo13')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
s=dict(terminal=False,commands=[],production_applied=False,
    ruling='Declare the two actual negative-probe cfg names without allowing unexpected cfgs; preserve probes. Replace derived Debug on opaque XML fixtures with equivalent explicit field Debug to retain payload diagnostics and remove dead-field warnings. Preserve all31 tests.')
def save():
    (d/'warning18.summary.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
def run(name,cmd):
    log=d/(name+'18.log')
    with log.open('xb') as f:
        r=subprocess.run(cmd,cwd=w,env=env,stdout=f,stderr=subprocess.STDOUT,
            creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
    s['commands'].append(dict(name=name,command=cmd,exit_code=r.returncode,log=str(log),sha256=sha(log)))
    save()
    print(name,r.returncode,flush=True)
    return r.returncode,log.read_text(encoding='utf-8')
cmd=[toolchain+'/cargo.exe','rustc','-p','druid-rdbc','--test','resource_standard_contract_test',
    '--all-features','--locked','--offline','-j1','--','-D','warnings']
save()
code,red=run('strict-red',cmd)
assert code!=0 and 'unexpected `cfg` condition name' in red and 'fields `representation` and `units` are never read' in red
manifest=w/'Cargo.toml'
old_manifest=manifest.read_bytes()
t=old_manifest.decode('utf-8')
needle='unsafe_code = "forbid"'
assert t.count(needle)==1
t=t.replace(needle,needle+'\nunexpected_cfgs = { level = "warn", check-cfg = ["cfg(task7_require_xml_value_sync)", "cfg(task7_require_old_xml_access)"] }')
manifest.write_bytes(t.encode('utf-8'))
xml=w/'crates/druid-rdbc/tests/resource_standard_support/sql_xml_contract.rs'
before=xml.read_text(encoding='utf-8')
text=before
for name,fields in [('XmlSourceValue','representation:Option<RdbcXmlRepresentationType>,units:Vec<u16>'),
                    ('XmlResultValue','representation:Option<RdbcXmlRepresentationType>,units:Arc<Mutex<Vec<u16>>>')]:
    old='#[derive(Debug)]\nstruct '+name+' {'+fields+'}'
    assert text.count(old)==1
    new=('struct '+name+' {'+fields+'}\n'
         'impl std::fmt::Debug for '+name+' {\n'
         '    fn fmt(&self, formatter: &mut std::fmt::Formatter<\'_>) -> std::fmt::Result {\n'
         '        formatter.debug_struct("'+name+'").field("representation", &self.representation).field("units", &self.units).finish()\n'
         '    }\n}\n')
    text=text.replace(old,new)
suffix='mod xml_value_contract {'
assert text[text.index(suffix):]==before[before.index(suffix):]
xml.write_text(text,encoding='utf-8',newline='\n')
s['changes']={str(manifest.relative_to(w)):dict(before_sha256=hashlib.sha256(old_manifest).hexdigest(),after_sha256=sha(manifest)),
    str(xml.relative_to(w)):dict(before_sha256=hashlib.sha256(before.encode()).hexdigest(),after_sha256=sha(xml))}
save()
code,green=run('strict-green',cmd)
assert code==0 and not re.search(r'^warning:',green,re.M)
code,runtime=run('runtime-green',[toolchain+'/cargo.exe','test','-p','druid-rdbc','--test','resource_standard_contract_test',
    '--all-features','--locked','--offline','-j1','--','--test-threads=1'])
assert code==0 and '31 passed; 0 failed;' in runtime and not re.search(r'^warning:',runtime,re.M)
s.update(terminal=True,runtime_tests=31,strict_rustc=True,clippy_certified=False)
save()
