use druid_rdbc::resource;
pub fn probe_array<T: resource::Array + ?Sized>() {}
pub fn probe_blob<T: resource::Blob + ?Sized>() {}
pub fn probe_clob<T: resource::Clob + ?Sized>() {}
pub fn probe_nclob<T: resource::NClob + ?Sized>() {}
pub fn probe_ref<T: resource::Ref + ?Sized>() {}
pub fn probe_sqlxml<T: resource::SqlXml + ?Sized>() {}
