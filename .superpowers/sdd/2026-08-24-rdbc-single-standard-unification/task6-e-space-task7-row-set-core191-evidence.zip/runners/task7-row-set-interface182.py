from pathlib import Path
import json,re
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d177');out=w/'crates/druid-rdbc/src/extensions/row_set.rs'
assert not out.exists()
src=json.loads((b/'task7-row-set-parameters163/java-methods.json').read_text())[0]['methods']
imports='''use super::RowSetListener;
use crate::connection::TransactionIsolation;
use crate::error::RdbcError;
use crate::result_set::ResultSet;
use crate::statement::{ParameterIndex, PreparedInputParameter, PreparedTypeNameArgument};
use crate::types::{RdbcArray, RdbcBigDecimal, RdbcBlob, RdbcCalendar, RdbcCalendarArgument, RdbcCharacterLength, RdbcClob, RdbcInputStream, RdbcNClob, RdbcNaiveDate, RdbcNaiveDateTime, RdbcNaiveTime, RdbcObject, RdbcReader, RdbcRef, RdbcRowId, RdbcSqlXml, RdbcStreamLength, RdbcTypeMap, RdbcUrl};
use std::sync::{Arc, Mutex};

/// 继承唯一标准 ResultSet 的行集接口，完整保存连接属性及 JDBC 参数重载。
/// 对应 Java: javax.sql.RowSet；不继承 Statement/PreparedStatement。
#[async_trait::async_trait]
pub trait RowSet: ResultSet {
    /// 按参数 index 绑定无损 setter 描述符；返回成功或 SQL 状态错误，不消费流。
    fn set_parameter(&mut self, index: ParameterIndex, parameter: PreparedInputParameter) -> Result<(), RdbcError>;
    /// 绑定原始参数 name 的描述符；返回成功或 SQL 错误，最终位置由 provider 解析。
    fn set_named_parameter(&mut self, name: Option<&str>, parameter: PreparedInputParameter) -> Result<(), RdbcError>;
    /// 清除全部参数引用；无参数，不隐式关闭调用者流。对应 Java: RowSet#clearParameters。
    fn clear_parameters(&mut self) -> Result<(), RdbcError>;
    /// 执行当前命令并原子发布完整结果；无参数，保留 provider 原错误。对应 Java: RowSet#execute。
    async fn execute(&mut self) -> Result<(), RdbcError>;
    /// 登记参数 listener 的同一身份；无返回值。对应 Java: RowSet#addRowSetListener。
    fn add_row_set_listener(&mut self, listener: Arc<dyn RowSetListener>);
    /// 移除参数 listener 的登记身份；无返回值。对应 Java: RowSet#removeRowSetListener。
    fn remove_row_set_listener(&mut self, listener: &Arc<dyn RowSetListener>);
'''
text=imports
properties=[('url','Option<String>','url','Option<&str>','getUrl','setUrl'),('data_source_name','Option<String>','name','Option<&str>','getDataSourceName','setDataSourceName'),('username','Option<String>','name','Option<&str>','getUsername','setUsername'),('password','Option<String>','password','Option<&str>','getPassword','setPassword'),('transaction_isolation','TransactionIsolation','level','i32','getTransactionIsolation','setTransactionIsolation'),('type_map','Arc<Mutex<RdbcTypeMap>>','map','Arc<Mutex<RdbcTypeMap>>','getTypeMap','setTypeMap'),('command','Option<String>','command','Option<&str>','getCommand','setCommand'),('is_read_only','bool','value','bool','isReadOnly','setReadOnly'),('max_field_size','i32','max','i32','getMaxFieldSize','setMaxFieldSize'),('max_rows','i32','max','i32','getMaxRows','setMaxRows'),('escape_processing','bool','enable','bool','getEscapeProcessing','setEscapeProcessing'),('query_timeout','i32','seconds','i32','getQueryTimeout','setQueryTimeout')]
excluded={'setType','setConcurrency'}
for name,ret,arg,typ,jget,jset in properties:
 setter='set_read_only' if name=='is_read_only' else 'set_'+name
 text+=f'    /// 获取当前属性，无参数，返回原请求值。对应 Java: RowSet#{jget}。\n    fn {name}(&self) -> {ret};\n    /// 使用参数 {arg} 设置请求属性，返回成功或原校验错误。对应 Java: RowSet#{jset}。\n    fn {setter}(&mut self, {arg}: {typ}) -> Result<(), RdbcError>;\n'
 excluded.add(jset)
text+='    /// 设置参数 type_code 的 JDBC 游标类型，返回成功或 SQL 错误。对应 Java: RowSet#setType。\n    fn set_type(&mut self, type_code: i32) -> Result<(), RdbcError>;\n    /// 设置参数 concurrency 的 JDBC 并发模式，返回成功或 SQL 错误。对应 Java: RowSet#setConcurrency。\n    fn set_concurrency(&mut self, concurrency: i32) -> Result<(), RdbcError>;\n'
types={'boolean':'bool','byte':'i8','short':'i16','int':'i32','long':'i64','float':'f32','double':'f64','BigDecimal':'Option<RdbcBigDecimal>','String':'Option<&str>','byte[]':'Option<Vec<u8>>','java.sql.Date':'Option<RdbcNaiveDate>','java.sql.Time':'Option<RdbcNaiveTime>','java.sql.Timestamp':'Option<RdbcNaiveDateTime>','Calendar':'Option<RdbcCalendar>','java.io.InputStream':'Option<RdbcInputStream>','InputStream':'Option<RdbcInputStream>','Reader':'Option<RdbcReader>','java.io.Reader':'Option<RdbcReader>','Object':'Option<RdbcObject>','Ref':'Option<RdbcRef>','Blob':'Option<RdbcBlob>','Clob':'Option<RdbcClob>','NClob':'Option<RdbcNClob>','Array':'Option<RdbcArray>','RowId':'Option<RdbcRowId>','SQLXML':'Option<RdbcSqlXml>','java.net.URL':'Option<RdbcUrl>'}
mapping=[];names=set()
for declaration in src:
 m=re.search(r'\b(set\w+)\s*\((.*?)\)',declaration)
 if not m or m[1] in excluded:continue
 java,args=m.groups();params=[]
 for arg in args.split(','):
  x=re.fullmatch(r'\s*(.*?)\s+(\w+)(\[\])?\s*',arg);assert x,(declaration,arg)
  params.append(x[1]+(x[3] or ''))
 named=params[0]=='String';rest=params[1:];kind=java[3:]
 name=re.sub(r'(?<!^)(?=[A-Z])','_',kind).lower()
 if kind=='SQLXML':name='sql_xml'
 if kind=='URL':name='parameter_url'
 names_args=['value']
 if kind=='Null':
  names_args=['sql_type']+(['type_name'] if len(rest)==2 else [])
  expr='PreparedInputParameter::Null { sql_type, type_name: '+('PreparedTypeNameArgument::Specified(type_name.map(str::to_owned))' if len(rest)==2 else 'PreparedTypeNameArgument::Unspecified')+' }'
  if len(rest)==2:name+='_with_type_name'
 elif kind in ['Date','Time','Timestamp']:
  names_args=['value']+(['calendar'] if len(rest)==2 else [])
  expr=f'PreparedInputParameter::{kind} {{ value, calendar: '+('RdbcCalendarArgument::Specified(calendar)' if len(rest)==2 else 'RdbcCalendarArgument::Unspecified')+' }'
  if len(rest)==2:name+='_with_calendar'
 elif kind=='Object':
  names_args=['value']+(['target_sql_type'] if len(rest)>1 else [])+(['scale_or_length'] if len(rest)>2 else [])
  expr='PreparedInputParameter::Object { value, target_sql_type: '+('Some(target_sql_type)' if len(rest)>1 else 'None')+', scale_or_length: '+('Some(scale_or_length)' if len(rest)>2 else 'None')+' }'
  if len(rest)>1:name+='_with_type'
  if len(rest)>2:name+='_and_scale_or_length'
 elif 'Stream' in kind or (kind in ['Blob','Clob','NClob'] and rest[0] not in ['Blob','Clob','NClob']):
  character=kind in ['CharacterStream','NCharacterStream','Clob','NClob'];field='reader' if character else 'stream'
  variant={'Blob':'BlobStream','Clob':'ClobReader','NClob':'NClobReader'}.get(kind,kind)
  if kind in ['Blob','Clob','NClob']:name+=('_reader' if character else '_stream')
  names_args=[field]+(['length'] if len(rest)>1 else [])
  length_type='RdbcCharacterLength' if character else 'RdbcStreamLength'
  length=f'{length_type}::'+('Unspecified' if len(rest)==1 else ('Int(length)' if rest[1]=='int' else 'Long(length)'))
  if len(rest)>1:name+='_with_length'
  expr=f'PreparedInputParameter::{variant} {{ {field}, length: {length} }}'
 else:
  variant={'SQLXML':'SqlXml','URL':'Url'}.get(kind,kind)
  value='value.map(str::to_owned)' if rest[0]=='String' else 'value'
  expr=f'PreparedInputParameter::{variant}({value})'
 if named:name+='_by_name'
 method='set_'+name;assert method not in names,(method,declaration);names.add(method)
 first='name: Option<&str>' if named else 'index: ParameterIndex'
 signature=first+', '+', '.join(f'{a}: {types[t]}' for a,t in zip(names_args,rest))
 call=f'self.set_named_parameter(name, {expr})' if named else f'self.set_parameter(index, {expr})'
 text+=f'    /// 按原 selector 和参数保存对应重载，返回绑定结果，不提前读取或关闭资源。\n    /// 对应 Java: javax.sql.RowSet#{declaration}\n    fn {method}(&mut self, {signature}) -> Result<(), RdbcError> {{ {call} }}\n'
 mapping.append(dict(java=declaration,rust=method))
assert len(mapping)==85
text+='}\n';out.write_text(text,encoding='utf-8')
(b/'task7-row-set-complete179/row-set-setter-mapping182.json').write_text(json.dumps(mapping,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('RowSet: 26 properties, 4 lifecycle/listener methods, 85 exact typed setter overloads; mandatory rich binding ports')
