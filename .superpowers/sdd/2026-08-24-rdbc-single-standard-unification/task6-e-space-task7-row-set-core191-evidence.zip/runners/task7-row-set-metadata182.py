from pathlib import Path
import re
w=Path('F:/codex_build_cache/d177');base=w/'crates/druid-rdbc/src'
path=base/'extensions/shared_row_set_meta_data.rs';assert not path.exists()
s='''use super::RowSetMetaData;
use crate::error::RdbcError;
use crate::metadata::{ColumnDescriptor, ColumnNullability, ResultSetColumnType, ResultSetMetaData};
use crate::result_set::ColumnIndex;
use std::sync::{Arc, Mutex, MutexGuard};

/// 保留同一安装对象身份的可变行集元数据共享代理。
/// 对应 Java: RowSetInternal#setMetaData 传入的 javax.sql.RowSetMetaData 引用。
#[derive(Clone)]
pub struct SharedRowSetMetaData { inner: Arc<Mutex<Box<dyn RowSetMetaData>>> }
impl SharedRowSetMetaData {
    /// 接管参数 metadata 的对象引用；返回共享代理，不读取或复制列定义。
    pub fn new(metadata: Box<dyn RowSetMetaData>) -> Self { Self { inner: Arc::new(Mutex::new(metadata)) } }
    fn lock(&self) -> MutexGuard<'_, Box<dyn RowSetMetaData>> { self.inner.lock().unwrap_or_else(std::sync::PoisonError::into_inner) }
}
impl PartialEq for SharedRowSetMetaData { fn eq(&self, other: &Self) -> bool { Arc::ptr_eq(&self.inner, &other.inner) } }
impl Eq for SharedRowSetMetaData {}
impl std::fmt::Debug for SharedRowSetMetaData { fn fmt(&self,f:&mut std::fmt::Formatter<'_>)->std::fmt::Result { f.debug_struct("SharedRowSetMetaData").finish_non_exhaustive() } }
crate::impl_standard_wrapper!(SharedRowSetMetaData => RowSetMetaData);
'''
counts={}
for trait,file in [('ResultSetMetaData','metadata/result_set_meta_data.rs'),('RowSetMetaData','extensions/row_set_meta_data.rs')]:
 source=(base/file).read_text();source=source[source.index('pub trait '+trait):]
 opening=source.index('{');depth=1;end=opening+1
 while depth:
  if source[end]=='{':depth+=1
  elif source[end]=='}':depth-=1
  end+=1
 source=source[opening+1:end-1]
 s+='impl '+trait+' for SharedRowSetMetaData {\n';count=0
 for match in re.finditer(r'\bfn\s+(\w+)\s*\((.*?)\)\s*->\s*([^\{;]+)[\{;]',source,re.S):
  name,args,ret=match.groups();args=' '.join(args.split());ret=' '.join(ret.split());inputs=[a.strip() for a in args.split(',') if a.strip() and 'self' not in a];names=[a.split(':')[0].strip().lstrip('_') for a in inputs]
  for a,n in zip(inputs,names):args=args.replace(a.split(':')[0].strip()+':',n+':')
  s+=f'    /// 委托同一底层对象的 {name}，保持参数、返回值及原错误；不创建元数据副本。\n    fn {name}({args}) -> {ret} {{ self.lock().{name}('+', '.join(names)+') }\n';count+=1
 s+='}\n';counts[trait]=count
assert counts=={'ResultSetMetaData':22,'RowSetMetaData':17},counts
path.write_text(s,encoding='utf-8');print(counts)
