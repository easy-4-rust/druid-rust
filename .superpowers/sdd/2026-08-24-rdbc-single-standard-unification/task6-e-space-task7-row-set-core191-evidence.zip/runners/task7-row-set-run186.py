import hashlib,json,os,re,subprocess,time
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d177');d=b/'task7-row-set-implementation186';d.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
parent=json.loads((b/'task7-row-set-implementation185/frozen-inputs.json').read_text());test='crates/druid-rdbc/tests/standard_row_set_complete_contract_test.rs';original=(b/'task7-row-set-implementation182/original-fourteen.rs').read_bytes();marker=b'#[tokio::test]';assert (w/test).read_bytes().split(marker,1)[1]==original.split(marker,1)[1]
tool='C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin';env=os.environ.copy();env.update(RUSTUP_TOOLCHAIN='1.97.1',RUSTUP_AUTO_INSTALL='0',RUSTC=tool+'/rustc.exe',RUSTDOC=tool+'/rustdoc.exe',CARGO_TARGET_DIR='F:/codex_build_cache/druid_rust/task7_row_set177_target',DRUID_RDBC_EXTERNAL_TARGET_ROOT='F:/codex_build_cache/druid_rust/task7_row_set177_external',TMP='F:/codex_tmp/task7_standard_cargo13',TEMP='F:/codex_tmp/task7_standard_cargo13');env['PATH']=tool+os.pathsep+env['PATH']
cmd=[tool+'/cargo.exe','fmt','--all'];p=subprocess.run(cmd,cwd=w,env=env,capture_output=True);(d/'format.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0;assert (w/test).read_bytes().split(marker,1)[1]==original.split(marker,1)[1]
f={r:sha(w/r) for r in parent}
for p in (w/'crates/druid-rdbc/src/extensions').glob('*.rs'):f[p.relative_to(w).as_posix()]=sha(p)
assert len(f)==1268,len(f)
delta={r:h for r,h in f.items() if parent.get(r)!=h};assert len(delta)==2,len(delta)
(d/'frozen-inputs.json').write_text(json.dumps(f,indent=2)+'\n',encoding='utf-8');(d/'delta.json').write_text(json.dumps(delta,indent=2)+'\n',encoding='utf-8')
s=dict(terminal=False,production_applied=False,workspace=str(w),pid=os.getpid(),frozen_input_count=len(f),commands=[],original_fourteen_assertions_preserved=True,fixture_error_construction_corrected=True,quality_fix_only=True)
summary=d/'summary.json'
def save():summary.write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
commands=[('row-set-green',['test','-p','druid-rdbc','--test','standard_row_set_complete_contract_test','--all-features','--locked','--offline','-j1']),('row-set-strict',['clippy','-p','druid-rdbc','--test','standard_row_set_complete_contract_test','--all-features','--locked','--offline','-j1','--','-D','warnings'])]
for name,args in commands:
 log=d/(name+'.log');command=[tool+'/cargo.exe']+args;start=time.time();s['running_command']=name;save()
 with log.open('wb') as output:
  p=subprocess.Popen(command,cwd=w,env=env,stdout=output,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS);s['cargo_pid']=p.pid;save();code=p.wait()
 text=log.read_text(encoding='utf-8',errors='replace');counts=re.findall(r'test result: \w+\. (\d+) passed; (\d+) failed;',text);changed=[r for r,h in f.items() if sha(w/r)!=h]
 record=dict(name=name,command=command,exit_code=code,elapsed_seconds=time.time()-start,log=str(log),sha256=sha(log),passed=sum(int(a) for a,_ in counts),failed=sum(int(a) for _,a in counts),changed_inputs=changed);s['commands'].append(record);save();print(json.dumps(record),flush=True)
 if code or changed:s.update(terminal=True,exit_code=code or 97);save();raise SystemExit(code or 97)
s.update(terminal=True,exit_code=0);save()
