from pathlib import Path
w=Path('F:/codex_build_cache/d177');base=w/'crates/druid-rdbc/src'
path=base/'extensions/shared_row_set.rs';s=path.read_text();assert '// PROPERTY_METHODS' in s
properties=[('url','Option<String>','url','Option<&str>'),('data_source_name','Option<String>','name','Option<&str>'),('username','Option<String>','name','Option<&str>'),('password','Option<String>','password','Option<&str>'),('transaction_isolation','TransactionIsolation','level','i32'),('type_map','Arc<Mutex<RdbcTypeMap>>','map','Arc<Mutex<RdbcTypeMap>>'),('command','Option<String>','command','Option<&str>'),('is_read_only','bool','value','bool'),('max_field_size','i32','max','i32'),('max_rows','i32','max','i32'),('escape_processing','bool','enable','bool'),('query_timeout','i32','seconds','i32')]
methods=''
for name,ret,arg,typ in properties:
 setter='set_read_only' if name=='is_read_only' else 'set_'+name
 getter='self.lock().properties.'+name+'()'+('.map(str::to_owned)' if ret=='Option<String>' else '')
 methods+=f'fn {name}(&self)->{ret}{{{getter}}}\nfn {setter}(&mut self,{arg}:{typ})->Result<(),RdbcError>{{self.modify_properties(|properties|properties.{setter}({arg}))}}\n'
methods+='fn set_type(&mut self,type_code:i32)->Result<(),RdbcError>{self.modify_properties(|properties|properties.set_type(type_code))}\nfn set_concurrency(&mut self,concurrency:i32)->Result<(),RdbcError>{self.modify_properties(|properties|properties.set_concurrency(concurrency))}'
path.write_text(s.replace('// PROPERTY_METHODS',methods),encoding='utf-8')
modules=['row_set','row_set_reader','row_set_writer','row_set_listener','row_set_event','row_set_internal','shared_row_set_meta_data','shared_row_set','row_set_parameter_resolver','row_set_cursor','row_set_state','row_set_execution_guard','row_set_provider_context']
public={name:''.join(word.title() for word in name.split('_')) for name in modules[:9]}
path=base/'extensions/mod.rs';s=path.read_text()
for name in modules:
 assert ('mod '+name+';') not in s;s+='\nmod '+name+';\n'
 if name in public:s+='pub use '+name+'::'+public[name]+';\n'
path.write_text(s,encoding='utf-8')
for file,mutable in [('wrapper/standard_unwrapped.rs',False),('wrapper/standard_unwrapped_mut.rs',True)]:
 path=base/file;s=path.read_text();s=s.replace('use crate::extensions::RowSetMetaData;','use crate::extensions::{RowSet,RowSetMetaData};')
 needle="    ResultSet(&'a "+('mut ' if mutable else '')+"dyn ResultSet),"
 assert needle in s;s=s.replace(needle,needle+'\n    /// 同一行集的标准接口，继承 ResultSet。\n    RowSet(&\'a '+('mut ' if mutable else '')+'dyn RowSet),')
 if not mutable:s=s.replace('Self::ResultSet(_) => TypeId::of::<dyn ResultSet>(),','Self::ResultSet(_) => TypeId::of::<dyn ResultSet>(),\n            Self::RowSet(_) => TypeId::of::<dyn RowSet>(),')
 path.write_text(s,encoding='utf-8')
print('Wired 13 one-object files; canonical RowSet leaf and ResultSet parent views')
