from pathlib import Path
import subprocess,os,json,hashlib
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');d=b/'task7-row-set-cursor-admission-red198';d.mkdir(exist_ok=False)
source=d/'cursor-admission-contract.rs';source.write_text('''//! 外部 clone 在 provider 已实际 Pending 时不得改变已发布游标。
use druid_rdbc::error::RdbcError;
use druid_rdbc::extensions::{RowSet,RowSetInternal,RowSetReader,RowSetWriter,SharedRowSet};
use druid_rdbc::result_set::ResultSet;
use std::future::{pending,poll_fn,Future};
use std::task::Poll;
use std::sync::{Arc,atomic::{AtomicBool,Ordering}};
struct PendingReader(Arc<AtomicBool>);
#[async_trait::async_trait]
impl RowSetReader for PendingReader {
 async fn read_data(&mut self,_caller:&mut dyn RowSetInternal)->Result<(),RdbcError> {
  self.0.store(true,Ordering::SeqCst);pending().await
 }
}
struct PendingWriter(Arc<AtomicBool>);
#[async_trait::async_trait]
impl RowSetWriter for PendingWriter {
 async fn write_data(&mut self,_caller:&mut dyn RowSetInternal)->Result<bool,RdbcError> {
  self.0.store(true,Ordering::SeqCst);pending().await
 }
}
#[test]
fn external_cursor_return_is_rejected_while_reader_is_actually_pending() {
 tokio::runtime::Builder::new_current_thread().enable_time().build().unwrap().block_on(async {
  let entered=Arc::new(AtomicBool::new(false));let mut source=SharedRowSet::new();
  source.set_reader(Some(Box::new(PendingReader(Arc::clone(&entered))))).unwrap();
  let mut external=source.clone();let mut execution=Box::pin(source.execute());
  poll_fn(|cx| { assert!(execution.as_mut().poll(cx).is_pending());Poll::Ready(()) }).await;
  assert!(entered.load(Ordering::SeqCst));
  let result=external.move_to_current_row();drop(execution);
  assert!(matches!(result,Err(RdbcError::SqlException(_))),"busy Reader must reject external cursor movement: {result:?}");
  external.move_to_current_row().unwrap();
 });
}
#[test]
fn external_cursor_return_is_rejected_while_writer_is_actually_pending() {
 tokio::runtime::Builder::new_current_thread().enable_time().build().unwrap().block_on(async {
  let entered=Arc::new(AtomicBool::new(false));let mut source=SharedRowSet::new();
  source.set_writer(Some(Box::new(PendingWriter(Arc::clone(&entered))))).unwrap();
  let mut external=source.clone();let mut execution=Box::pin(source.accept_changes());
  poll_fn(|cx| { assert!(execution.as_mut().poll(cx).is_pending());Poll::Ready(()) }).await;
  assert!(entered.load(Ordering::SeqCst));
  let result=external.move_to_current_row();drop(execution);
  assert!(matches!(result,Err(RdbcError::SqlException(_))),"busy Writer must reject external cursor movement: {result:?}");
  external.move_to_current_row().unwrap();
 });
}
''',encoding='utf-8')
deps=Path('F:/codex_build_cache/druid_rust/task7_row_set177_target/debug/deps');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();paths=[source];cmd=['C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin/rustc.exe','--edition=2024','--test','--crate-name','row_set_cursor_admission',str(source),'-L','dependency='+str(deps),'-o',str(d/'cursor-admission.exe')]
for name,glob in [('druid_rdbc','libdruid_rdbc*.rlib'),('async_trait','*async_trait*.dll'),('tokio','libtokio-*.rlib')]:
 found=list(deps.glob(glob));assert len(found)==1;paths+=found;cmd+=['--extern',name+'='+str(found[0])]
inputs={str(p):sha(p) for p in paths};env=os.environ.copy();env['TMP']=env['TEMP']='F:/codex_tmp/task7_standard_cargo13';p=subprocess.run(cmd,capture_output=True,env=env);(d/'compile.log').write_bytes(p.stdout+p.stderr);s=dict(compile_exit_code=p.returncode,command=cmd,frozen_inputs=inputs,production_modified=False)
if not p.returncode:
 p=subprocess.run([str(d/'cursor-admission.exe')],capture_output=True,env=env);(d/'test.log').write_bytes(p.stdout+p.stderr);s['test_exit_code']=p.returncode;print((p.stdout+p.stderr).decode(errors='replace'))
else:print((p.stdout+p.stderr).decode(errors='replace'))
s['changed_inputs']=[n for n,h in inputs.items() if sha(Path(n))!=h];(d/'summary.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
