原第14合同测试 after_last，但未请求可滚动类型。固定 Java ResultSet 明确禁止 TYPE_FORWARD_ONLY 调用 afterLast。只在该测试设置 set_type(1004)，原全部断言保持不变；不能用此前错误接受滚动的实现维持错误前置条件。后续必须独立验证前向拒绝与可滚动成功。
