from pathlib import Path
import subprocess,os,json,hashlib
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');d=b/'task7-row-set-forward-capability-red207';d.mkdir(exist_ok=False);source=d/'forward-capability-contract.rs';source.write_text('''//! 固定 Java ResultSet 的前向游标导航与 fetchDirection 能力合同。
use druid_rdbc::error::RdbcError;
use druid_rdbc::extensions::{RowSet,RowSetInternal,RowSetMetaData,RowSetMetaDataBuffer,SharedRowSet,SharedRowSetMetaData};
use druid_rdbc::result_set::{ColumnIndex,ResultSet,ResultSetNavigation,ResultSetUpdate};
use druid_rdbc::statement::{FetchDirection,ResultSetType};
fn one_row()->SharedRowSet {
 let mut source=SharedRowSet::new();source.set_type(1003).unwrap();source.set_read_only(false).unwrap();source.set_concurrency(1008).unwrap();
 let mut metadata=RowSetMetaDataBuffer::new();metadata.set_column_count(1).unwrap();source.set_meta_data(SharedRowSetMetaData::new(Box::new(metadata))).unwrap();
 source.move_to_insert_row().unwrap();source.update_value(ColumnIndex::new(1).unwrap(),ResultSetUpdate::Int(37)).unwrap();source.insert_row().unwrap();source.move_to_current_row().unwrap();source
}
#[test]
fn declared_forward_only_rejects_every_scroll_operation_without_moving() {
 tokio::runtime::Builder::new_current_thread().build().unwrap().block_on(async {
  let mut source=one_row();assert_eq!(source.result_set_type().unwrap(),ResultSetType::ForwardOnly);assert!(source.next().await.unwrap());
  for navigation in [ResultSetNavigation::Previous,ResultSetNavigation::First,ResultSetNavigation::Last,ResultSetNavigation::BeforeFirst,ResultSetNavigation::AfterLast,ResultSetNavigation::Absolute(1),ResultSetNavigation::Relative(1)] {
   let result=source.navigate(navigation).await;
   assert!(matches!(result,Err(RdbcError::SqlException(_))),"forward-only must reject {navigation:?}: {result:?}");assert_eq!(source.row().unwrap(),1);
  }
 });
}
#[test]
fn declared_forward_only_rejects_non_forward_fetch_direction_atomically() {
 let mut source=one_row();source.set_fetch_direction(FetchDirection::Forward).unwrap();
 for direction in [FetchDirection::Reverse,FetchDirection::Unknown] {
  let result=source.set_fetch_direction(direction);assert!(matches!(result,Err(RdbcError::SqlException(_))),"forward-only must reject {direction:?}: {result:?}");assert_eq!(source.fetch_direction().unwrap(),FetchDirection::Forward);
 }
}
#[test]
fn declared_scroll_insensitive_allows_scroll_and_fetch_hints() {
 tokio::runtime::Builder::new_current_thread().build().unwrap().block_on(async {
  let mut source=one_row();source.set_type(1004).unwrap();assert!(source.first().await.unwrap());assert!(source.last().await.unwrap());source.before_first().await.unwrap();assert_eq!(source.row().unwrap(),0);source.after_last().await.unwrap();assert_eq!(source.row().unwrap(),0);assert!(source.absolute(-1).await.unwrap());assert!(!source.previous().await.unwrap());assert!(source.relative(1).await.unwrap());assert_eq!(source.row().unwrap(),1);
  source.set_fetch_direction(FetchDirection::Reverse).unwrap();assert_eq!(source.fetch_direction().unwrap(),FetchDirection::Reverse);source.set_fetch_direction(FetchDirection::Unknown).unwrap();assert_eq!(source.fetch_direction().unwrap(),FetchDirection::Unknown);
 });
}
''',encoding='utf-8')
deps=Path('F:/codex_build_cache/druid_rust/task7_row_set177_target/debug/deps');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();paths=[source];cmd=['C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin/rustc.exe','--edition=2024','--test','--crate-name','row_set_forward_capability',str(source),'-L','dependency='+str(deps),'-o',str(d/'forward-capability.exe')]
for name,glob in [('druid_rdbc','libdruid_rdbc*.rlib'),('tokio','libtokio-*.rlib')]:
 found=list(deps.glob(glob));assert len(found)==1;paths+=found;cmd+=['--extern',name+'='+str(found[0])]
java=b/'task8-java-jdbc42-source/jdk/src/share/classes/java/sql/ResultSet.java';paths.append(java);inputs={str(p):sha(p) for p in paths};env=os.environ.copy();env['TMP']=env['TEMP']='F:/codex_tmp/task7_standard_cargo13';p=subprocess.run(cmd,capture_output=True,env=env);(d/'compile.log').write_bytes(p.stdout+p.stderr);s=dict(compile_exit_code=p.returncode,command=cmd,frozen_inputs=inputs,production_modified=False,java_contract_lines=[1123,1138,1241,1266,1317])
if not p.returncode:
 p=subprocess.run([str(d/'forward-capability.exe')],capture_output=True,env=env);(d/'test.log').write_bytes(p.stdout+p.stderr);s['test_exit_code']=p.returncode;print((p.stdout+p.stderr).decode(errors='replace'))
else:print((p.stdout+p.stderr).decode(errors='replace'))
s['changed_inputs']=[n for n,h in inputs.items() if sha(Path(n))!=h];(d/'summary.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
