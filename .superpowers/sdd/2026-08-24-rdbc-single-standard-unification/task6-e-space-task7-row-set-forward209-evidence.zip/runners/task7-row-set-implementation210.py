import hashlib,json,os,re,subprocess,time
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d177');d=b/'task7-row-set-implementation210'
prior=json.loads((b/'task7-row-set-implementation204/summary.json').read_text());assert prior['terminal'] and prior['exit_code']==0
probes=json.loads((b/'task7-row-set-public-probes205/summary.json').read_text());assert probes['terminal'] and not probes['changed_inputs']
d.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
parent=json.loads((b/'task7-row-set-implementation204/frozen-inputs.json').read_text());assert all(sha(w/r)==h for r,h in parent.items())
forward='crates/druid-rdbc/tests/standard_row_set_forward_capability_contract_test.rs';assert not (w/forward).exists()
(w/forward).write_bytes((b/'task7-row-set-forward-capability-red207/forward-capability-contract.rs').read_bytes())
(w/'crates/druid-rdbc/src/extensions/shared_row_set.rs').write_bytes((b/'task7-row-set-forward-fix208/shared-row-set-with-forward-contract.rs').read_bytes())
(w/'crates/druid-rdbc/tests/standard_row_set_complete_contract_test.rs').write_bytes((b/'task7-row-set-forward-fix208/fourteen-with-scroll-precondition.rs').read_bytes())
test='crates/druid-rdbc/tests/standard_row_set_complete_contract_test.rs';original=(b/'task7-row-set-implementation182/original-fourteen.rs').read_bytes();marker=b'#[tokio::test]';assert re.sub(rb'    source\.set_type\(1004\)\.unwrap\(\);\r?\n',b'',(w/test).read_bytes().split(marker,1)[1],count=1)==original.split(marker,1)[1]
tool='C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin';env=os.environ.copy();env.update(RUSTUP_TOOLCHAIN='1.97.1',RUSTUP_AUTO_INSTALL='0',RUSTC=tool+'/rustc.exe',RUSTDOC=tool+'/rustdoc.exe',CARGO_TARGET_DIR='F:/codex_build_cache/druid_rust/task7_row_set177_target',DRUID_RDBC_EXTERNAL_TARGET_ROOT='F:/codex_build_cache/druid_rust/task7_row_set177_external',TMP='F:/codex_tmp/task7_standard_cargo13',TEMP='F:/codex_tmp/task7_standard_cargo13');env['PATH']=tool+os.pathsep+env['PATH']
cmd=[tool+'/cargo.exe','fmt','--all'];p=subprocess.run(cmd,cwd=w,env=env,capture_output=True);(d/'format.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0;assert re.sub(rb'    source\.set_type\(1004\)\.unwrap\(\);\r?\n',b'',(w/test).read_bytes().split(marker,1)[1],count=1)==original.split(marker,1)[1]
f={r:sha(w/r) for r in parent};f[forward]=sha(w/forward)
for p in (w/'crates/druid-rdbc/src/extensions').glob('*.rs'):f[p.relative_to(w).as_posix()]=sha(p)
assert len(f)==1272,len(f)
delta={r:h for r,h in f.items() if parent.get(r)!=h};assert len(delta)==3,len(delta)
(d/'frozen-inputs.json').write_text(json.dumps(f,indent=2)+'\n',encoding='utf-8');(d/'delta.json').write_text(json.dumps(delta,indent=2)+'\n',encoding='utf-8')
s=dict(terminal=False,production_applied=False,workspace=str(w),pid=os.getpid(),frozen_input_count=len(f),commands=[],original_fourteen_assertions_preserved=True,fixture_error_construction_corrected=True,explicit_scroll_precondition_correction=True,forward_capability_validation=True)
summary=d/'summary.json'
def save():summary.write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
commands=[('forward-capability-green', ['test', '-p', 'druid-rdbc', '--test', 'standard_row_set_forward_capability_contract_test', '--all-features', '--locked', '--offline', '-j1']), ('original-fourteen-green', ['test', '-p', 'druid-rdbc', '--test', 'standard_row_set_complete_contract_test', '--all-features', '--locked', '--offline', '-j1']), ('row-set-strict', ['clippy', '-p', 'druid-rdbc', '--test', 'standard_row_set_complete_contract_test', '--test', 'standard_row_set_full_surface_contract_test', '--test', 'standard_row_set_external_wrapper_contract_test', '--test', 'standard_row_set_cursor_admission_contract_test', '--test', 'standard_row_set_forward_capability_contract_test', '--all-features', '--locked', '--offline', '-j1', '--', '-D', 'warnings']), ('rdbc-full', ['test', '-p', 'druid-rdbc', '--all-features', '--locked', '--offline', '-j1']), ('format-check', ['fmt', '--all', '--', '--check'])]
for name,args in commands:
 log=d/(name+'.log');command=[tool+'/cargo.exe']+args;start=time.time();s['running_command']=name;save()
 with log.open('wb') as output:
  p=subprocess.Popen(command,cwd=w,env=env,stdout=output,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS);s['cargo_pid']=p.pid;save();code=p.wait()
 text=log.read_text(encoding='utf-8',errors='replace');counts=re.findall(r'test result: \w+\. (\d+) passed; (\d+) failed;',text);changed=[r for r,h in f.items() if sha(w/r)!=h]
 record=dict(name=name,command=command,exit_code=code,elapsed_seconds=time.time()-start,log=str(log),sha256=sha(log),passed=sum(int(a) for a,_ in counts),failed=sum(int(a) for _,a in counts),changed_inputs=changed);s['commands'].append(record);save();print(json.dumps(record),flush=True)
 if code or changed:s.update(terminal=True,exit_code=code or 97);save();raise SystemExit(code or 97)
s.update(terminal=True,exit_code=0);save()
