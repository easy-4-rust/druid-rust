import hashlib,json,os,subprocess
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d177')
previous=json.loads((b/'task7-row-set-implementation204/summary.json').read_text());assert previous['terminal'] and previous['exit_code']==0
d=b/'task7-row-set-public-probes205';d.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
f=json.loads((b/'task7-row-set-implementation204/frozen-inputs.json').read_text(encoding='utf-8'))
changes=lambda:[r for r,h in f.items() if sha(w/r)!=h]
assert len(f)==1271 and not changes()
(d/'frozen-inputs.json').write_text(json.dumps(f,indent=2)+'\n',encoding='utf-8')
old=json.loads((b/'task8-canonical-identity-probes3.summary.json').read_text(encoding='utf-8-sig'))
assert old['semantic_rows']==69 and len(old['results'])==68
tool='C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin'
env=os.environ.copy();env.update(RUSTC=tool+'/rustc.exe',RUSTDOC=tool+'/rustdoc.exe',RUSTUP_TOOLCHAIN='1.97.1-x86_64-pc-windows-msvc',RUSTUP_AUTO_INSTALL='0',PATH=tool+os.pathsep+env['PATH'],CARGO_TARGET_DIR='F:/codex_build_cache/druid_rust/task7_row_set177_target',TMP='F:/codex_tmp/task7_standard_cargo13',TEMP='F:/codex_tmp/task7_standard_cargo13',CARGO_BUILD_JOBS='1',CARGO_NET_OFFLINE='true',PYTHONUTF8='1')
cmd=[tool+'/cargo.exe','build','-p','druid-rdbc','--all-features','--lib','--locked','--offline','--message-format=json','-j1']
s=dict(terminal=False,production_applied=False,pid=os.getpid(),workspace=str(w),frozen_input_count=len(f),cargo_command=cmd,results=[])
save=lambda:(d/'summary.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
save()
with (d/'cargo-artifact.jsonl').open('xb') as out,(d/'cargo-build.log').open('xb') as err:
    result=subprocess.run(cmd,cwd=w,env=env,stdout=out,stderr=err,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
s['cargo_exit_code']=result.returncode;save()
assert result.returncode==0
artifacts=[]
for line in (d/'cargo-artifact.jsonl').read_text(encoding='utf-8').splitlines():
    try:x=json.loads(line)
    except ValueError:continue
    if x.get('reason')=='compiler-artifact' and x.get('target',{}).get('name')=='druid_rdbc':artifacts.append(x)
assert len(artifacts)==1
libs=[Path(p) for p in artifacts[0]['filenames'] if p.endswith('.rlib')];assert len(libs)==1
artifact=libs[0];artifact_hash=sha(artifact);s.update(artifact=str(artifact),artifact_sha256=artifact_hash,compiler_artifact=artifacts[0]);save()
for i,row in enumerate(old['results']):
    original=Path(row['command'][-3]);assert sha(original)==row['probe_sha256']
    source=d/f'probe_{i:02}.rs';source.write_bytes(original.read_bytes())
    command=[tool+'/rustc.exe','--edition=2021','--crate-type=lib','--emit=metadata','--crate-name',f'jdbc42_probe_{i}','-L','dependency='+str(artifact.parent/'deps'),'--extern','druid_rdbc='+str(artifact),str(source),'-o',str(source.with_suffix('.rmeta'))]
    r=subprocess.run(command,cwd=w,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
    s['results'].append(dict(item_key=row['item_key'],rust_shape=row['rust_shape'],target=row['target'],scope=row['scope'],probe_sha256=sha(source),probe_source=row['probe_source'],command=command,exit_code=r.returncode,status='PASS' if r.returncode==0 else 'FAIL',stdout=r.stdout.decode('utf-8',errors='replace'),stderr=r.stderr.decode('utf-8',errors='replace')));save()
assert sha(artifact)==artifact_hash and not changes()
s.update(terminal=True,semantic_rows=69,compiled_rows=68,passed=sum(r['exit_code']==0 for r in s['results']),failed=sum(r['exit_code']!=0 for r in s['results']),not_rust_target=1,changed_inputs=changes(),task8_complete=False,scope='Original68 unchanged import/trait-bound probes only; enum/module exact shape, Java behavior, SemVer and host item not certified.')
save();print(json.dumps({k:v for k,v in s.items() if k not in ['results','compiler_artifact']},indent=2),flush=True)
print(json.dumps(dict(failed_targets=[r['target'] for r in s['results'] if r['exit_code']!=0])),flush=True)
