import hashlib,json,zipfile,subprocess
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d146');e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust');d=b/'task7-row-set-metadata-checkpoint155';d.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=b/'task7-row-set-metadata-fix153';raw=(source/'summary.json').read_bytes();s=json.loads(raw)
assert [(c['name'],c['exit_code']) for c in s['commands'][:2]]==[('metadata-green',0),('metadata-strict',0)]
assert s['commands'][0]['passed']==5 and all(not c['changed_inputs'] and sha(Path(c['log']))==c['sha256'] for c in s['commands'])
f=json.loads((source/'frozen-inputs.json').read_text(encoding='utf-8'));parent=json.loads((b/'task7-type-map-fix149/frozen-inputs.json').read_text(encoding='utf-8'));assert len(f)==1242 and all(sha(w/r)==h for r,h in f.items())
delta={r:h for r,h in f.items() if parent.get(r)!=h};assert len(delta)==8
observation=subprocess.check_output(['powershell','-NoProfile','-Command',f'Get-CimInstance Win32_Process | Where-Object {{ $_.ProcessId -eq {s["pid"]} -or $_.ParentProcessId -eq {s["pid"]} }} | Select-Object ProcessId,ParentProcessId,Name | ConvertTo-Json -Compress'],encoding='utf-8')
if not s['terminal'] and 'python.exe' not in observation:
    s=json.loads((source/'summary.json').read_text(encoding='utf-8'));assert s['terminal']
assert sha(b/'task7-type-map-terminal150.zip')=='ce995c8c640fc44d37867734103a5174aac17a0dedc7768bf1199329eb8bd3bf'
(d/'observed-summary.json').write_bytes(raw);(d/'process-observation.json').write_text(observation,encoding='utf-8')
if (source/'rdbc-complete.log').exists():(d/'rdbc-complete.partial.log').write_bytes((source/'rdbc-complete.log').read_bytes())
files={}
for folder in ['task7-row-set-metadata-red152','task7-row-set-metadata-checkpoint155']:
    for p in (b/folder).rglob('*'):
        if p.is_file():files[str(p.relative_to(b)).replace('\\','/')]=p
for n in ['metadata-green.log','metadata-strict.log','frozen-inputs.json','original-five-contracts.rs','format-setup.log']:files['task7-row-set-metadata-fix153/'+n]=source/n
for n in ['task7-row-set-metadata152.rs','task7-row-set-metadata-red152.py','task7-row-set-metadata-fix153.py','task7-row-set-metadata-probes154.py','task7-row-set-metadata-checkpoint155.py','task7-row-set-meta-data-impl151.java']:files[n]=b/n
for r in delta:files['candidate-delta/'+r]=w/r
manifest={n:sha(p) for n,p in files.items()};z=b/'task7-row-set-metadata-checkpoint155.zip';assert not z.exists()
with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED) as out:
    for n,p in files.items():out.write(p,n)
    out.writestr('archive-manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(z) as inp:assert all(hashlib.sha256(inp.read(n)).hexdigest()==h for n,h in manifest.items())
result=dict(scope='PARTIAL_CHECKPOINT_NOT_FINAL_STANDARD_CERTIFICATION',production_applied=False,archive=str(z),archive_sha256=sha(z),parent_archive='task7-type-map-terminal150.zip',parent_sha256='ce995c8c640fc44d37867734103a5174aac17a0dedc7768bf1199329eb8bd3bf',frozen_input_count=1242,delta=delta,verified_commands=s['commands'],observed_terminal=s['terminal'],full_regression_pass_claim=False,canonical_probes154_executed=False,java_method_count=17,top_level_open=18)
local=b/'task7-row-set-metadata-checkpoint155.summary.json';local.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');dest=e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'
for original,name in [(z,'task6-e-space-task7-row-set-metadata155-evidence.zip'),(local,'task6-e-space-task7-row-set-metadata155-summary.json')]:
    target=dest/name;assert not target.exists();target.write_bytes(original.read_bytes());assert sha(target)==sha(original)
note=f'''\n\n2026-10-09 RowSetMetaData标准候选阶段证据：固定OpenJDK7373384725418fa645fb4508ec05a869bc7fc3e7 javax.sql.RowSetMetaData原件与69来源oracle SHA匹配，完整17个setter身份留存。原152生产不改仅增五合同，实际E0432公开面RED，1239冻结变化0。153新增唯一RowSetMetaData必需方法trait、真实RowSetMetaDataBuffer稀疏实现及私有一列状态；同一ResultSetMetaData标准getter/owned快照/Wrapper leaf-parent-concrete-mutable身份闭包，原五合同含完整17setter、非法值不变、nullable名称、列隔离/重置及i32MAX惰性状态，实际5/0、指定严格Clippy0，1242冻结变化0。完整RDBC原session50786控制Python61956及直属Cargo运行状态已现场观察，未取得本检查点完整PASS；初次编译增量缓存AccessDenied note保留原日志，不据此重启。原68入口探针154已准备但尚未执行，不推定62/6或认证RowSetMetaData精确kind。Ruling: 这是标准接口与Rust缓冲实现，默认flags false/nullable Unknown/空名称遵循接口；不冒充另一个Java RowSetMetaDataImpl具体类（其未初始化nullable String及MAX特殊分配行为未认证）。追加固定源码仅供setter校验参考，不改69原oracle分母。zip155 SHA {sha(z)}为150终态父链的八路径delta，保存原RED、两已完成GREEN、完整冻结清单、Java原件/17方法/简报及明确标记的部分回归日志，逐项解压及E镜像SHA核验。其余六RowSet入口、provider type-map接入、完整API/SemVer/MSRV/compiler/全仓及18顶层任务仍开放，正式Rust未apply，Task6 FIX_REQUIRED/Task8 INCOMPLETE。\n'''
for rel in ['.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md','docs/verification/rdbc-first/status.md','docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md']:
    p=e/rel;raw=p.read_bytes();assert b'zip155 SHA' not in raw;p.write_bytes(raw+note.encode('utf-8'))
print(json.dumps(dict(archive=str(z),sha256=sha(z),frozen_input_count=1242,verified_commands=[c['name'] for c in s['commands']],original_job_terminal=s['terminal'],mirrored=True)),flush=True)
