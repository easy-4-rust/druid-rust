import json
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
s=json.loads((b/'task7-row-set-metadata-fix153/summary.json').read_text(encoding='utf-8'))
assert s['terminal'] and s['exit_code']==0 and len(s['commands'])==4
assert all(c['exit_code']==0 and not c['changed_inputs'] for c in s['commands'])
source=(b/'task7-canonical-probes103.py').read_text(encoding='utf-8')
for old,new in [("w=Path('F:/codex_build_cache/d91')","w=Path('F:/codex_build_cache/d146')"),("d=b/'task7-canonical-probes103'","d=b/'task7-row-set-metadata-probes154'"),('task7-finalize99/frozen-inputs.json','task7-row-set-metadata-fix153/frozen-inputs.json'),('len(f)==1221','len(f)==1242'),("CARGO_TARGET_DIR='F:/codex_build_cache/dr103_target'","CARGO_TARGET_DIR='F:/codex_build_cache/druid_rust/task7_type_map146_target'")]:
    assert source.count(old)==1;source=source.replace(old,new)
exec(compile(source,str(b/'task7-row-set-metadata-probes154.py'),'exec'))
