import hashlib,json,os,re,subprocess,time
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d146');d=b/'task7-row-set-metadata-red152'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
s0=json.loads((b/'task7-type-map-fix149/summary.json').read_text(encoding='utf-8'));assert s0['terminal'] and s0['exit_code']==0
f=json.loads((b/'task7-type-map-fix149/frozen-inputs.json').read_text(encoding='utf-8'));assert len(f)==1238 and all(sha(w/r)==h for r,h in f.items());d.mkdir(exist_ok=False)
oracle=json.loads((b/'task8-java-jdbc42-source-acquisition1.summary.json').read_text(encoding='utf-8'));j=next(x for x in oracle['sources'] if x['fqcn']=='javax.sql.RowSetMetaData');java=Path(j['local_path']);assert sha(java)==j['sha256']
raw=java.read_text(encoding='utf-8');methods=re.findall(r'void\s+(\w+)\(([^)]*)\)\s+throws SQLException',raw);assert len(methods)==17
(d/'RowSetMetaData.java').write_bytes(java.read_bytes());(d/'java-methods.json').write_text(json.dumps(dict(oracle_commit=oracle['oracle_commit'],sha256=j['sha256'],methods=methods),indent=2)+'\n',encoding='utf-8')
brief='''P04 standard surface / Task8 canonical RowSetMetaData brief
Authority: fixed OpenJDK7373384725418fa645fb4508ec05a869bc7fc3e7 javax.sql.RowSetMetaData, all17 required setters and ResultSetMetaData inheritance; existing canonical Wrapper identity contract.
Implement one object-safe RowSetMetaData trait, no alias, no unsupported default stubs. All setters are required. Add RowSetMetaDataBuffer as a real Rust in-memory implementation; optional names normalize None to empty. All1-based checks and invalid count/nullable/dimension/type checks return structured SQL errors and preserve earlier state. ColumnDescriptor snapshots remain immutable copies.
Wrapper leaf/parent/concrete/mutable views all access the same object. Extend canonical StandardUnwrapped/Mut and impl_standard_wrapper, not a parallel reflection tree.
Ruling: this is the Java interface contract with a Rust buffer implementation, not a claimed port of Java RowSetMetaDataImpl. Source of that additional class was read for validation ordering and setter normalization. Its uninitialized nullable String fields and max-width allocation quirks are not silently asserted equivalent to existing String-based ResultSetMetaData. Full concrete-class parity is unproven. Rust buffer defaults use the interface documented false flags/Unknown nullability and empty string metadata. Sparse column state supports the full positive i32 count without eager huge allocation; setting count resets all state.
Original five tests cover all17 setters and inherited getters,1-based/invalid no mutation, nullable reset/owned snapshots, canonical Wrapper closure and sparse MAX width. Do not replace BufferedRowSet with an alias for javax.sql.RowSet. Other six RowSet canonical entries and original all68 probes remain required.
Only test is added for initial RED; production unchanged from149 frozen1238. E business Rust remains unchanged.
'''
(d/'brief.txt').write_text(brief,encoding='utf-8')
r='crates/druid-rdbc/tests/standard_row_set_metadata_contract_test.rs';(w/r).write_bytes((b/'task7-row-set-metadata152.rs').read_bytes());f[r]=sha(w/r);(d/'frozen-inputs.json').write_text(json.dumps(f,indent=2)+'\n',encoding='utf-8')
tool='C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin';env=os.environ.copy();env.update(RUSTUP_TOOLCHAIN='1.97.1',RUSTUP_AUTO_INSTALL='0',RUSTC=tool+'/rustc.exe',RUSTDOC=tool+'/rustdoc.exe',CARGO_TARGET_DIR='F:/codex_build_cache/druid_rust/task7_type_map146_target',TMP='F:/codex_tmp/task7_standard_cargo13',TEMP='F:/codex_tmp/task7_standard_cargo13');env['PATH']=tool+os.pathsep+env['PATH']
command=[tool+'/cargo.exe','test','-p','druid-rdbc','--test','standard_row_set_metadata_contract_test','--all-features','--locked','--offline','-j1'];s=dict(terminal=False,production_applied=False,workspace=str(w),pid=os.getpid(),frozen_input_count=len(f),command=command,java_method_count=17);summary=d/'summary.json';summary.write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
log=d/'red.log';start=time.time()
with log.open('wb') as output:
    p=subprocess.Popen(command,cwd=w,env=env,stdout=output,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS);s['cargo_pid']=p.pid;summary.write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8');code=p.wait()
text=log.read_text(encoding='utf-8',errors='replace');changed=[r for r,h in f.items() if sha(w/r)!=h];clean=code==101 and 'unresolved imports' in text and 'RowSetMetaDataBuffer' in text and 'RowSetMetaData' in text and not changed
s.update(terminal=True,exit_code=code,elapsed_seconds=time.time()-start,log=str(log),log_sha256=sha(log),changed_inputs=changed,expected_public_surface_red=clean);summary.write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8');print(json.dumps(s),flush=True);assert clean
