import hashlib,json,zipfile,subprocess
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d146');e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust');d=b/'task7-row-set-metadata-terminal156';d.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=b/'task7-row-set-metadata-fix153';raw=(source/'summary.json').read_bytes();s=json.loads(raw)
assert s['terminal'] and s['exit_code']==0 and len(s['commands'])==4
assert [(c['name'],c['exit_code']) for c in s['commands']]==[('metadata-green',0),('metadata-strict',0),('rdbc-complete',0),('fmt',0)]
assert s['commands'][2]['passed']==555 and s['commands'][2]['failed']==0
probes=json.loads((b/'task7-row-set-metadata-probes154/summary.json').read_text(encoding='utf-8'))
assert probes['terminal'] and probes['passed']==62 and probes['failed']==6 and not probes['changed_inputs']
original=json.loads((b/'task8-canonical-identity-probes3.summary.json').read_text(encoding='utf-8-sig'))
assert len(probes['results'])==len(original['results'])==68
assert all(all(a[k]==o[k] for k in ['item_key','rust_shape','target','scope','probe_sha256']) for a,o in zip(probes['results'],original['results']))
assert s['commands'][0]['passed']==5 and all(not c['changed_inputs'] and sha(Path(c['log']))==c['sha256'] for c in s['commands'])
f=json.loads((source/'frozen-inputs.json').read_text(encoding='utf-8'));parent=json.loads((b/'task7-type-map-fix149/frozen-inputs.json').read_text(encoding='utf-8'));assert len(f)==1242 and all(sha(w/r)==h for r,h in f.items())
delta={r:h for r,h in f.items() if parent.get(r)!=h};assert len(delta)==8
observation=subprocess.check_output(['powershell','-NoProfile','-Command',f'Get-CimInstance Win32_Process | Where-Object {{ $_.ProcessId -eq {s["pid"]} -or $_.ParentProcessId -eq {s["pid"]} }} | Select-Object ProcessId,ParentProcessId,Name | ConvertTo-Json -Compress'],encoding='utf-8')
if not s['terminal'] and 'python.exe' not in observation:
    s=json.loads((source/'summary.json').read_text(encoding='utf-8'));assert s['terminal']
assert sha(b/'task7-type-map-terminal150.zip')=='ce995c8c640fc44d37867734103a5174aac17a0dedc7768bf1199329eb8bd3bf'
(d/'observed-summary.json').write_bytes(raw);(d/'process-observation.json').write_text(observation,encoding='utf-8')
assert sha(Path(probes['artifact']))==probes['artifact_sha256']
files={}
for folder in ['task7-row-set-metadata-red152','task7-row-set-metadata-fix153','task7-row-set-metadata-probes154','task7-row-set-metadata-terminal156']:
    for p in (b/folder).rglob('*'):
        if p.is_file():files[str(p.relative_to(b)).replace('\\','/')]=p
for n in ['metadata-green.log','metadata-strict.log','frozen-inputs.json','original-five-contracts.rs','format-setup.log']:files['task7-row-set-metadata-fix153/'+n]=source/n
for n in ['task7-row-set-metadata152.rs','task7-row-set-metadata-red152.py','task7-row-set-metadata-fix153.py','task7-row-set-metadata-probes154.py','task7-row-set-metadata-terminal156.py','task7-row-set-meta-data-impl151.java']:files[n]=b/n
for r in delta:files['candidate-delta/'+r]=w/r
manifest={n:sha(p) for n,p in files.items()};z=b/'task7-row-set-metadata-terminal156.zip';assert not z.exists()
with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED) as out:
    for n,p in files.items():out.write(p,n)
    out.writestr('archive-manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(z) as inp:assert all(hashlib.sha256(inp.read(n)).hexdigest()==h for n,h in manifest.items())
result=dict(scope='LOCAL_TERMINAL_NOT_FINAL_STANDARD_CERTIFICATION',production_applied=False,archive=str(z),archive_sha256=sha(z),parent_archive='task7-type-map-terminal150.zip',parent_sha256='ce995c8c640fc44d37867734103a5174aac17a0dedc7768bf1199329eb8bd3bf',frozen_input_count=1242,delta=delta,verified_commands=s['commands'],observed_terminal=s['terminal'],full_rdbc_regression_pass_claim=True,whole_workspace_pass_claim=False,canonical_probes154_executed=True,public_entry_pass=62,public_entry_fail=6,java_method_count=17,top_level_open=18)
local=b/'task7-row-set-metadata-terminal156.summary.json';local.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');dest=e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'
for original,name in [(z,'task6-e-space-task7-row-set-metadata156-evidence.zip'),(local,'task6-e-space-task7-row-set-metadata156-summary.json')]:
    target=dest/name;assert not target.exists();target.write_bytes(original.read_bytes());assert sha(target)==sha(original)
note=f'''\n\n2026-10-09 RowSetMetaData候选局部终态：153原四命令全部实际exit0，五项metadata合同5/0、指定严格Clippy0、完整RDBC allfeatures555/0、fmt0，1242冻结变化0。154以新Cargo JSON唯一rlib执行原完整68公开入口探针，原身份/形态声明/目标/范围/源码SHA逐项不变，实际62PASS6FAIL，另1host未认证；较125的61/7仅改善RowSetMetaData，剩六RowSet项保留。入口解析不等于精确kind、Java行为或SemVer认证。原152 E0432 RED、17setter来源、全部153/154日志及清单、相对150父链八路径delta归档zip156 SHA {sha(z)}，逐项解压与E镜像核验；155仅阶段快照保留。补充Java RowSetMetaDataImpl仅参考验证，不声称具体类完整对等、不改69oracle。正式Rust未apply；provider接入、其余RowSet及完整API/SemVer/MSRV/compiler/全仓仍开放，Task6 FIX_REQUIRED/Task7八义务/Task8 INCOMPLETE/18顶层OPEN。\n'''
for rel in ['.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md','docs/verification/rdbc-first/status.md','docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md']:
    p=e/rel;raw=p.read_bytes();assert b'zip156 SHA' not in raw;p.write_bytes(raw+note.encode('utf-8'))
print(json.dumps(dict(archive=str(z),sha256=sha(z),frozen_input_count=1242,verified_commands=[c['name'] for c in s['commands']],original_job_terminal=s['terminal'],mirrored=True)),flush=True)
