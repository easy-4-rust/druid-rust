import hashlib,json,os,re,subprocess,time
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d163');d=b/'task7-row-set-parameters-fix164';d.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
red=json.loads((b/'task7-row-set-parameters163/summary.json').read_text(encoding='utf-8'));assert red['terminal'] and red['expected_missing_public_entry_red'] and not red['changed_inputs']
f=json.loads((b/'task7-row-set-parameters163/frozen-inputs.json').read_text(encoding='utf-8'))
assert [r for r,h in f.items() if sha(w/r)!=h]==['crates/druid-rdbc/src/extensions/mod.rs']
test='crates/druid-rdbc/tests/standard_row_set_parameter_contract_test.rs'
(d/'original-six-contracts.rs').write_bytes((w/test).read_bytes())
tool='C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin'
env=os.environ.copy();env.update(RUSTUP_TOOLCHAIN='1.97.1',RUSTUP_AUTO_INSTALL='0',RUSTC=tool+'/rustc.exe',RUSTDOC=tool+'/rustdoc.exe',CARGO_TARGET_DIR='F:/codex_build_cache/druid_rust/task7_type_map146_target',TMP='F:/codex_tmp/task7_standard_cargo13',TEMP='F:/codex_tmp/task7_standard_cargo13');env['PATH']=tool+os.pathsep+env['PATH']
new=['crates/druid-rdbc/src/extensions/row_set_binding_key.rs','crates/druid-rdbc/src/extensions/row_set_parameter_store.rs']
format_files=new+[test]
p=subprocess.run([tool+'/rustfmt.exe','--edition','2021','--config','skip_children=true',*[str(w/r) for r in format_files]],cwd=w,env=env,capture_output=True);(d/'format-setup.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0
for r in list(f)+new:f[r]=sha(w/r)
(d/'frozen-inputs.json').write_text(json.dumps(f,indent=2)+'\n',encoding='utf-8')
s=dict(terminal=False,production_applied=False,workspace=str(w),pid=os.getpid(),frozen_input_count=len(f),commands=[],original_five_contracts_preserved=True,ruling='Instance-scoped constructors adapt reflection; canonical Custom identity protects a Send-only SQLData behind its object mutex; nested input inherits explicit mapping')
summary=d/'summary.json'
def save():summary.write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
commands=[('mapping-green',['test','-p','druid-rdbc','--test','standard_row_set_parameter_contract_test','--all-features','--locked','--offline','-j1']),('mapping-strict',['clippy','-p','druid-rdbc','--test','standard_row_set_parameter_contract_test','--all-features','--locked','--offline','-j1','--','-D','warnings']),('rdbc-complete',['test','-p','druid-rdbc','--all-features','--locked','--offline','-j1']),('fmt',['fmt','--all','--','--check'])]
for name,args in commands:
    s['running_command']=name;save();log=d/(name+'.log');command=[tool+'/cargo.exe']+args;start=time.time()
    with log.open('wb') as output:
        p=subprocess.Popen(command,cwd=w,env=env,stdout=output,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS);s['cargo_pid']=p.pid;save();code=p.wait()
    text=log.read_text(encoding='utf-8',errors='replace');counts=re.findall(r'test result: \w+\. (\d+) passed; (\d+) failed;',text);changed=[r for r,h in f.items() if sha(w/r)!=h]
    record=dict(name=name,command=command,exit_code=code,elapsed_seconds=time.time()-start,log=str(log),sha256=sha(log),passed=sum(int(a) for a,_ in counts),failed=sum(int(a) for _,a in counts),changed_inputs=changed);s['commands'].append(record);save();print(json.dumps(record),flush=True)
    if code or changed:s.update(terminal=True,exit_code=code or 97);save();raise SystemExit(code or 97)
s.update(terminal=True,exit_code=0);s.pop('running_command',None);save();print(json.dumps(s),flush=True)
