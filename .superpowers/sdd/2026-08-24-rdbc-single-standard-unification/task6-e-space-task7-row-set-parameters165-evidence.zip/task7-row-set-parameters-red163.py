import hashlib,json,os,subprocess
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d163');d=b/'task7-row-set-parameters163';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
f=json.loads((d/'parent-inputs.json').read_text(encoding='utf-8'));assert len(f)==1245 and all(sha(w/r)==h for r,h in f.items())
test='crates/druid-rdbc/tests/standard_row_set_parameter_contract_test.rs';f[test]=sha(w/test);(d/'frozen-inputs.json').write_text(json.dumps(f,indent=2)+'\n',encoding='utf-8')
tool='C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin';env=os.environ.copy();env.update(RUSTUP_TOOLCHAIN='1.97.1',RUSTUP_AUTO_INSTALL='0',RUSTC=tool+'/rustc.exe',RUSTDOC=tool+'/rustdoc.exe',CARGO_TARGET_DIR='F:/codex_build_cache/druid_rust/task7_type_map146_target',PATH=tool+os.pathsep+env['PATH'])
cmd=[tool+'/cargo.exe','test','-p','druid-rdbc','--test','standard_row_set_parameter_contract_test','--all-features','--locked','--offline','-j1']
with (d/'red.log').open('wb') as out:r=subprocess.run(cmd,cwd=w,env=env,stdout=out,stderr=subprocess.STDOUT)
changed=[p for p,h in f.items() if sha(w/p)!=h];text=(d/'red.log').read_text(encoding='utf-8',errors='replace');expected=r.returncode==101 and 'E0432' in text and 'RowSetParameterStore' in text
s=dict(terminal=True,command=cmd,exit_code=r.returncode,expected_missing_public_entry_red=expected,changed_inputs=changed,log_sha256=sha(d/'red.log'),production_applied=False)
(d/'summary.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8');print(json.dumps(s),flush=True)
assert expected and not changed
