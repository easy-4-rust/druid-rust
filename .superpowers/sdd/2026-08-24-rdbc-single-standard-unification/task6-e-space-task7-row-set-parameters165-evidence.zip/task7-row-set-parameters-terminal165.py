import hashlib,json,zipfile
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d163');e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust');d=b/'task7-row-set-parameters-fix164';red=b/'task7-row-set-parameters163'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
s=json.loads((d/'summary.json').read_text(encoding='utf-8'));assert s['terminal'] and s['exit_code']==0 and len(s['commands'])==4
assert [c['passed'] for c in s['commands']]==[6,0,565,0]
assert all(c['exit_code']==0 and not c['changed_inputs'] and sha(Path(c['log']))==c['sha256'] for c in s['commands'])
r=json.loads((red/'summary.json').read_text(encoding='utf-8'));assert r['terminal'] and r['expected_missing_public_entry_red'] and not r['changed_inputs']
f=json.loads((d/'frozen-inputs.json').read_text(encoding='utf-8'));parent=json.loads((red/'parent-inputs.json').read_text(encoding='utf-8'));assert len(f)==1248 and len(parent)==1245
assert all(sha(w/p)==h for p,h in f.items())
delta={p:h for p,h in f.items() if parent.get(p)!=h}
assert set(delta)=={'crates/druid-rdbc/src/extensions/mod.rs','crates/druid-rdbc/src/extensions/row_set_binding_key.rs','crates/druid-rdbc/src/extensions/row_set_parameter_store.rs','crates/druid-rdbc/tests/standard_row_set_parameter_contract_test.rs'}
oracle=json.loads((w/'docs/verification/rdbc-first/jdbc42-oracle.json').read_text(encoding='utf-8'));java=[]
for package in oracle['packages'].values():
 for record in package['objects']:
  if record['fqcn'] in {'javax.sql.RowSet','javax.sql.RowSetInternal'}:
   p=b/'task8-java-jdbc42-source'/record['source_path'];assert sha(p)==record['source_sha256'];java.append(p)
assert len(java)==2
files={}
for directory in [d,red]:
 for p in directory.rglob('*'):
  if p.is_file():files[str(p.relative_to(b)).replace('\\','/')]=p
for p in delta:files['candidate-delta/'+p]=w/p
for p in java:files['java-source/'+p.name]=p
for name in ['task7-row-set-parameters-red163.py','task7-row-set-parameters-fix164.py','task7-row-set-parameters-terminal165.py']:
 files[name]=b/name
manifest={n:sha(p) for n,p in files.items()};z=b/'task7-row-set-parameters-terminal165.zip';assert not z.exists()
with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED) as out:
 for n,p in files.items():out.write(p,n)
 out.writestr('archive-manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(z) as inp:assert all(hashlib.sha256(inp.read(n)).hexdigest()==h for n,h in manifest.items())
parentzip=b/'task7-type-map-failure-terminal162.zip';assert sha(parentzip)=='ac5122cb78b768bedded5928c29b0e87a52c3d2af703809dc21319c680bd867a'
result=dict(scope='ROW_SET_PARAMETER_STATE_LOCAL_TERMINAL',production_applied=False,archive=str(z),archive_sha256=sha(z),parent_archive=str(parentzip),parent_sha256=sha(parentzip),frozen_input_count=1248,delta=delta,verified_commands=s['commands'],original_six_contracts_preserved=True,runner_metadata_note='Inherited SQLData ruling and original_five_contracts field in original runner are retained as history; authoritative RowSet ruling is stage163 brief.md; original six parameter contracts are retained.',row_set_complete=False,task7_complete=False,top_level_open=18)
p=b/'task7-row-set-parameters-terminal165.summary.json';p.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');dest=e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'
for original,name in [(z,'task6-e-space-task7-row-set-parameters165-evidence.zip'),(p,'task6-e-space-task7-row-set-parameters165-summary.json')]:
 t=dest/name;assert not t.exists();t.write_bytes(original.read_bytes());assert sha(t)==sha(original)
note=f'''
2026-10-09 RowSet参数状态候选局部终态：原163冻结1246实际E0432标准入口RED；164新增真实RowSetParameterStore与私有RowSetBindingKey，复用完整PreparedInputParameter，保存32描述符族及NULL/Calendar/长度重载/原流身份。名称仅由provider解析，同一实际位置最后setter生效，重复selector不积累历史，极端稀疏index在分配前拒绝；get/snapshot不消费，clear不隐式close调用者资源。原六合同保留，最终6/0、指定严格Clippy0、完整RDBC allfeatures565/0、fmt0，1248冻结变化0。zip165 SHA {sha(z)}保存干净RED、最终完整日志/命令、两固定Java原件/115+5方法清单、简报及相对162父链四路径delta，全部解压SHA与E镜像核验。原runner继承SQLData ruling与original_five字段属于历史元数据，本归档明确六RowSet合同及163简报为本阶段解释依据。Ruling: 参数组件是完整RowSet的组成部分，不替代RowSet；execute/events/source identity/original rows/provider writeback及六公开入口仍开放。正式Rust未apply；原113/129全仓作业现场确认原Python仍存活，不改变输入或重启。Task6 FIX_REQUIRED/Task7八义务/Task8 INCOMPLETE/18顶层OPEN。
'''
for rel in ['.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md','docs/verification/rdbc-first/status.md','docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md']:
 p=e/rel;raw=p.read_bytes();assert b'zip165 SHA' not in raw;p.write_bytes(raw+note.encode('utf-8'))
print(json.dumps(dict(archive=str(z),sha256=sha(z),contracts=6,rdbc=565,mirrored=True)),flush=True)

