# P04 Task7 RowSet 参数状态实施简报

规格事实源：现有 single-standard-trait-tree；不新建规格体系。
固定来源：OpenJDK7373384725418fa645fb4508ec05a869bc7fc3e7，RowSet和RowSetInternal原件SHA匹配69oracle，完整方法清单独立保留。

本阶段实现完整RowSet所需的真实参数状态组件，复用PreparedInputParameter保存全部setter/NULL/Calendar/长度重载和原流身份；不以新类代替RowSet，不改变68公开探针，不将公开RowSet声明或execute/events/original-row认作已完成。

Ruling: 命名参数只能经provider显式回调解析到标准ParameterIndex；未解析名字时get_params明确拒绝，不以字典顺序创造位置。下标和名称最终指向同一位置时按最后setter顺序生效；重复同一selector不累计历史。缺槽必须在分配最大index大小的Vec前拒绝。参数读取不消费，clear仅释放自身引用，不隐式close调用者的流。

验收：六项真实合同；首先缺少公开参数组件E0432 RED，再实现并执行同六合同、严格Clippy、原映射合同和fmt。完整RowSet、Reader/Writer/Internal、事件/source身份及执行原始行/回写仍在原范围内，须继续实现，不得凭参数组件通过关闭Task7/Task8。
