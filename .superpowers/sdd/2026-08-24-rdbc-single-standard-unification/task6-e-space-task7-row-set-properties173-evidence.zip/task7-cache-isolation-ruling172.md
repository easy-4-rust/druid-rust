# RDBC 候选编译缓存隔离裁定（172）

事实：
- 属性候选167固定1250源码输入，原完整RDBC回归实际570 PASS/1 FAIL，Cargo101；失败为ConnectionCapabilities doctest编译时找不到 libdruid_rdbc-74ae33e7e3ce0c83.rlib，不是该doctest断言失败。
- 167与169/170使用相同CARGO_TARGET_DIR=task7_type_map146_target，源根分别d166和d169；作业交叠。
- 失败后只读观察同名rlib重新存在，LastWriteTime为2026-10-09 06:46:07，Length42715160。170的原行状态六合同已经6/0。
- 所有原失败日志与冻结输入保留；不修改源码、原断言、超时、测试分母或质量门禁。

推断：交叠的不同源根构建复用了同名RDBC产物，doc阶段未受到外层Cargo构建锁完整保护。缺失产物诊断和共享缓存交叠已证明，具体删除动作没有系统追踪，不能把推断称作逐系统调用认证。

执行裁定：
- 此后不同候选源根必须使用独立CARGO_TARGET_DIR及独立DRUID_RDBC_EXTERNAL_TARGET_ROOT。
- 同源根的TDD阶段可顺序复用自己的缓存；不得在原full/doc作业还运行时让另一源根进入该缓存。
- source freeze不能代替compiler artifact隔离；final compiler证据仍须绑定真实当前产物。
- 172对原d166/1250原字节使用新建独立target与external target，完整同命令RDBC/allfeatures/locked/offline/-j1和fmt。
- 172通过前不宣称父候选完整PASS；167的570/1永远保留，不改写为成功，不把环境修复计作业务源码修复。

