import hashlib,json,shutil
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d166');src=Path('F:/codex_build_cache/d163');d=b/'task7-row-set-properties166'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
s=json.loads((b/'task7-row-set-parameters-fix164/summary.json').read_text(encoding='utf-8'));assert s['terminal'] and s['exit_code']==0
f=json.loads((b/'task7-row-set-parameters-fix164/frozen-inputs.json').read_text(encoding='utf-8'));assert len(f)==1248
assert not w.exists() and not d.exists();w.mkdir();d.mkdir()
for r,h in f.items():
 assert sha(src/r)==h,r
 p=w/r;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src/r,p);assert sha(p)==h
(d/'parent-inputs.json').write_text(json.dumps(f,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(copied=len(f),workspace=str(w))),flush=True)

