import hashlib,json,subprocess,zipfile
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d166');e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust');d=b/'task7-row-set-properties-fix167';red=b/'task7-row-set-properties166'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
s=json.loads((d/'summary.json').read_text(encoding='utf-8'));assert s['terminal'] and s['exit_code']==101 and len(s['commands'])==3
assert [c['passed'] for c in s['commands']]==[6,0,570] and [c['exit_code'] for c in s['commands']]==[0,0,101]
assert all(not c['changed_inputs'] and sha(Path(c['log']))==c['sha256'] for c in s['commands'])
assert s['commands'][-1]['failed']==1 and 'extern location for druid_rdbc does not exist' in Path(s['commands'][-1]['log']).read_text(encoding='utf-8')
r=json.loads((red/'summary.json').read_text(encoding='utf-8'));assert r['terminal'] and r['expected_missing_public_entry_red'] and r['error_codes']==['E0432'] and not r['changed_inputs']
f=json.loads((d/'frozen-inputs.json').read_text(encoding='utf-8'));parent=json.loads((red/'parent-inputs.json').read_text(encoding='utf-8'));assert len(f)==1250 and len(parent)==1248
assert all(sha(w/p)==h for p,h in f.items())
delta={p:h for p,h in f.items() if parent.get(p)!=h};assert set(delta)=={'crates/druid-rdbc/src/extensions/mod.rs','crates/druid-rdbc/src/extensions/row_set_properties.rs','crates/druid-rdbc/tests/standard_row_set_properties_contract_test.rs'}
tool='C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin/rustfmt.exe'
p=subprocess.run([tool,'--edition','2021','--config','skip_children=true','--emit','stdout',str(d/'original-six-contracts.rs')],capture_output=True);assert p.returncode==0
original=p.stdout.decode('utf-8').replace('\r\n','\n');assert original.splitlines()[0].endswith('original-six-contracts.rs:')
assert original.split('\n\n',1)[1]==(w/'crates/druid-rdbc/tests/standard_row_set_properties_contract_test.rs').read_text(encoding='utf-8')
mapping=json.loads((d/'property-methods.json').read_text(encoding='utf-8'));assert len(mapping['mapping'])==26 and mapping['rust_sha256']==sha(w/'crates/druid-rdbc/src/extensions/row_set_properties.rs')
java=b/'task8-java-jdbc42-source/jdk/src/share/classes/javax/sql/RowSet.java';assert sha(java)==mapping['java_sha256']=='e291f57cb492eaa457977611a1556e4cfe73304c79517ef9dfb7783bf1132aa0'
files={}
for directory in [d,red]:
 for p in directory.rglob('*'):
  if p.is_file():files[str(p.relative_to(b)).replace('\\','/')]=p
for p in delta:files['candidate-delta/'+p]=w/p
files['java-source/RowSet.java']=java
for name in ['task7-row-set-properties-clone166.py','task7-row-set-properties-red166.py','task7-row-set-properties-fix167.py','task7-row-set-properties-source167.py','task7-row-set-properties-terminal168.py','task7-row-set-properties-isolated172.py','task7-cache-isolation-ruling172.md','task7-row-set-properties-failed173.py']:files[name]=b/name
manifest={n:sha(p) for n,p in files.items()};z=b/'task7-row-set-properties-failed173.zip';assert not z.exists()
with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED) as out:
 for n,p in files.items():out.write(p,n)
 out.writestr('archive-manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(z) as inp:assert all(hashlib.sha256(inp.read(n)).hexdigest()==h for n,h in manifest.items())
parentzip=b/'task7-row-set-parameters-terminal165.zip';assert sha(parentzip)=='f92741de75ba53e79c2b228631104b5f8142ac8b9cb70136d9ed4e7aae7ee9d7'
result=dict(scope='PROPERTY_LOCAL_CONTRACT_GREEN_FULL_RDBC_ARTIFACT_FAILURE',production_applied=False,archive=str(z),archive_sha256=sha(z),parent_archive=str(parentzip),parent_sha256=sha(parentzip),frozen_input_count=1250,delta=delta,verified_commands=s['commands'],original_six_contracts_preserved_after_official_format=True,source_property_declarations_mapped=26,full_rdbc_passed=False,fmt_not_run=True,prepared_archive168_not_executed=True,isolated172_result_pending=True,cache_overlap_cause_is_inference=True,full_row_set_complete=False,task7_complete=False,top_level_open=18)
p=b/'task7-row-set-properties-failed173.summary.json';p.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');dest=e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'
for original,name in [(z,'task6-e-space-task7-row-set-properties173-evidence.zip'),(p,'task6-e-space-task7-row-set-properties173-summary.json')]:
 t=dest/name;assert not t.exists();t.write_bytes(original.read_bytes());assert sha(t)==sha(original)
note=f'''
2026-10-09 RowSet属性候选与完整RDBC失败终态：166干净E0432 RED后，167新增单对象RowSetProperties及mod，26固定Java属性声明逐项映射，原六合同仅官方fmt且源码核验。实际6/0、指定严格Clippy0；完整RDBC实际570PASS1FAIL/Cargo101，唯一ConnectionCapabilities doctest编译缺libdruid_rdbc-74ae33e7e3ce0c83.rlib，不是断言失败；fmt后继未执行，1250冻结输入变化0。原167与169/170不同源根共享target交叠，失败后同名rlib于06:46:07重新存在；缓存覆盖为有事实支持的推断，具体删除动作未追踪，不夸大认证根因。zip173 SHA {sha(z)}保留真实RED/6GREEN/严格GREEN/完整失败日志、Java原件/26映射/简报/原未执行168脚本及相对165父链三路径delta，全部解压与E镜像SHA核验。172已用原d166/1250原字节、全新独立target及external-target运行同一完整RDBC与fmt，尚无终态；不改原断言/测试分母/超时，不把后续成功倒写167。Ruling: 此后不同候选源根必须隔离编译与external-consumer缓存；源码冻结不能替代产物隔离。完整RowSet执行/事件/原始行/provider写回及最终API/MSRV/实库仍开放；正式Rust未apply，Task6 FIX_REQUIRED/Task7八义务/Task8 INCOMPLETE/18顶层OPEN。
'''
for rel in ['.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md','docs/verification/rdbc-first/status.md','docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md']:
 p=e/rel;raw=p.read_bytes();assert b'zip173 SHA' not in raw;p.write_bytes(raw+note.encode('utf-8'))
print(json.dumps(dict(archive=str(z),sha256=sha(z),contracts=6,full_rdbc_passed=False,full_rdbc_result='570/1',mirrored=True)),flush=True)

