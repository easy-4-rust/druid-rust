import hashlib,json,os,re,subprocess,time
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d166');d=b/'task7-row-set-properties-isolated172';d.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads((b/'task7-row-set-properties-fix167/summary.json').read_text(encoding='utf-8'));assert old['terminal'] and old['exit_code']==101
assert old['commands'][-1]['name']=='rdbc-complete' and old['commands'][-1]['passed']==570 and old['commands'][-1]['failed']==1
assert 'extern location for druid_rdbc does not exist' in Path(old['commands'][-1]['log']).read_text(encoding='utf-8')
f=json.loads((b/'task7-row-set-properties-fix167/frozen-inputs.json').read_text(encoding='utf-8'));assert len(f)==1250 and all(sha(w/r)==h for r,h in f.items())
(d/'frozen-inputs.json').write_text(json.dumps(f,indent=2)+'\n',encoding='utf-8')
tool='C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin';target='F:/codex_build_cache/druid_rust/task7_properties172_target';external='F:/codex_build_cache/druid_rust/task7_properties172_external'
assert not Path(target).exists() and not Path(external).exists()
env=os.environ.copy();env.update(RUSTUP_TOOLCHAIN='1.97.1',RUSTUP_AUTO_INSTALL='0',RUSTC=tool+'/rustc.exe',RUSTDOC=tool+'/rustdoc.exe',CARGO_TARGET_DIR=target,DRUID_RDBC_EXTERNAL_TARGET_ROOT=external,TMP='F:/codex_tmp/task7_standard_cargo13',TEMP='F:/codex_tmp/task7_standard_cargo13');env['PATH']=tool+os.pathsep+env['PATH']
s=dict(terminal=False,production_applied=False,workspace=str(w),pid=os.getpid(),frozen_input_count=len(f),commands=[],source_changed=False,isolated_target=target,isolated_external_target=external,prior_failed_summary=str(b/'task7-row-set-properties-fix167/summary.json'),ruling='Preserve original 570/1 doctest missing-rlib failure; same frozen source and assertions are verified in dedicated build and external-consumer caches; no source fix or relaxed gate.')
summary=d/'summary.json'
def save():summary.write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
commands=[('rdbc-complete',['test','-p','druid-rdbc','--all-features','--locked','--offline','-j1']),('fmt',['fmt','--all','--','--check'])]
for name,args in commands:
 s['running_command']=name;save();log=d/(name+'.log');command=[tool+'/cargo.exe']+args;start=time.time()
 with log.open('wb') as output:
  p=subprocess.Popen(command,cwd=w,env=env,stdout=output,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS);s['cargo_pid']=p.pid;save();code=p.wait()
 text=log.read_text(encoding='utf-8',errors='replace');counts=re.findall(r'test result: \w+\. (\d+) passed; (\d+) failed;',text);changed=[r for r,h in f.items() if sha(w/r)!=h]
 record=dict(name=name,command=command,exit_code=code,elapsed_seconds=time.time()-start,log=str(log),sha256=sha(log),passed=sum(int(a) for a,_ in counts),failed=sum(int(a) for _,a in counts),changed_inputs=changed);s['commands'].append(record);save();print(json.dumps(record),flush=True)
 if code or changed:s.update(terminal=True,exit_code=code or 97);save();raise SystemExit(code or 97)
s.update(terminal=True,exit_code=0);s.pop('running_command',None);save();print(json.dumps(s),flush=True)

