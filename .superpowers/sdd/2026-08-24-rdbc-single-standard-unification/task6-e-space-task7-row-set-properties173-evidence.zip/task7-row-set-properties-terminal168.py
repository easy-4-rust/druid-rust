import hashlib,json,subprocess,zipfile
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d166');e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust');d=b/'task7-row-set-properties-fix167';red=b/'task7-row-set-properties166'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
s=json.loads((d/'summary.json').read_text(encoding='utf-8'));assert s['terminal'] and s['exit_code']==0 and len(s['commands'])==4
assert [c['passed'] for c in s['commands']]==[6,0,571,0]
assert all(c['exit_code']==0 and not c['changed_inputs'] and sha(Path(c['log']))==c['sha256'] for c in s['commands'])
r=json.loads((red/'summary.json').read_text(encoding='utf-8'));assert r['terminal'] and r['expected_missing_public_entry_red'] and r['error_codes']==['E0432'] and not r['changed_inputs']
f=json.loads((d/'frozen-inputs.json').read_text(encoding='utf-8'));parent=json.loads((red/'parent-inputs.json').read_text(encoding='utf-8'));assert len(f)==1250 and len(parent)==1248
assert all(sha(w/p)==h for p,h in f.items())
delta={p:h for p,h in f.items() if parent.get(p)!=h};assert set(delta)=={'crates/druid-rdbc/src/extensions/mod.rs','crates/druid-rdbc/src/extensions/row_set_properties.rs','crates/druid-rdbc/tests/standard_row_set_properties_contract_test.rs'}
tool='C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin/rustfmt.exe'
p=subprocess.run([tool,'--edition','2021','--config','skip_children=true','--emit','stdout',str(d/'original-six-contracts.rs')],capture_output=True);assert p.returncode==0
original=p.stdout.decode('utf-8').replace('\r\n','\n');assert original.splitlines()[0].endswith('original-six-contracts.rs:')
assert original.split('\n\n',1)[1]==(w/'crates/druid-rdbc/tests/standard_row_set_properties_contract_test.rs').read_text(encoding='utf-8')
mapping=json.loads((d/'property-methods.json').read_text(encoding='utf-8'));assert len(mapping['mapping'])==26 and mapping['rust_sha256']==sha(w/'crates/druid-rdbc/src/extensions/row_set_properties.rs')
java=b/'task8-java-jdbc42-source/jdk/src/share/classes/javax/sql/RowSet.java';assert sha(java)==mapping['java_sha256']=='e291f57cb492eaa457977611a1556e4cfe73304c79517ef9dfb7783bf1132aa0'
files={}
for directory in [d,red]:
 for p in directory.rglob('*'):
  if p.is_file():files[str(p.relative_to(b)).replace('\\','/')]=p
for p in delta:files['candidate-delta/'+p]=w/p
files['java-source/RowSet.java']=java
for name in ['task7-row-set-properties-clone166.py','task7-row-set-properties-red166.py','task7-row-set-properties-fix167.py','task7-row-set-properties-source167.py','task7-row-set-properties-terminal168.py']:files[name]=b/name
manifest={n:sha(p) for n,p in files.items()};z=b/'task7-row-set-properties-terminal168.zip';assert not z.exists()
with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED) as out:
 for n,p in files.items():out.write(p,n)
 out.writestr('archive-manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(z) as inp:assert all(hashlib.sha256(inp.read(n)).hexdigest()==h for n,h in manifest.items())
parentzip=b/'task7-row-set-parameters-terminal165.zip';assert sha(parentzip)=='f92741de75ba53e79c2b228631104b5f8142ac8b9cb70136d9ed4e7aae7ee9d7'
result=dict(scope='ROW_SET_PROPERTY_STATE_LOCAL_TERMINAL',production_applied=False,archive=str(z),archive_sha256=sha(z),parent_archive=str(parentzip),parent_sha256=sha(parentzip),frozen_input_count=1250,delta=delta,verified_commands=s['commands'],original_six_contracts_preserved_after_official_format=True,source_property_declarations_mapped=26,full_row_set_complete=False,task7_complete=False,top_level_open=18)
p=b/'task7-row-set-properties-terminal168.summary.json';p.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');dest=e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'
for original,name in [(z,'task6-e-space-task7-row-set-properties168-evidence.zip'),(p,'task6-e-space-task7-row-set-properties168-summary.json')]:
 t=dest/name;assert not t.exists();t.write_bytes(original.read_bytes());assert sha(t)==sha(original)
note=f'''
2026-10-09 RowSet属性状态候选局部终态：原166干净E0432缺RowSetProperties入口RED，1249冻结无变化。167新增单对象RowSetProperties及mod导出，26固定Java属性声明有逐项来源映射；保留null/空串/Unicode/原空白、URL/数据源最近非null优先与清空回退、同一Arc可变Map身份及克隆共享。四隔离值/游标/并发代码校验，负数限制拒绝且原子不变，0无限/i32MAX保留；Debug不输出连接串/数据源/用户名/密码/SQL/Map，未派生serde。原六合同仅经官方fmt且源码逐字核验，最终6/0、指定严格Clippy0、完整RDBC allfeatures571/0、fmt0，1250冻结变化0。zip168 SHA {sha(z)}包含原RED/全部终态命令日志、固定Java原件/26声明映射/简报及相对165父链三路径delta，全部解压及E镜像SHA一致。Ruling: 属性存储不等于执行，实际provider选择/能力/timeout/maxRows/maxFieldSize/typeMap应用仍须完整RowSet处理；保留两来源当前值是接口级Rust策略，不认证BaseRowSet具体类。六标准入口、事件source重入、Reader通知抑制、原始行与Writer冲突/写回仍开放。正式Rust未apply；Task6 FIX_REQUIRED/Task7八义务/Task8 INCOMPLETE/18顶层OPEN。
'''
for rel in ['.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md','docs/verification/rdbc-first/status.md','docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md']:
 p=e/rel;raw=p.read_bytes();assert b'zip168 SHA' not in raw;p.write_bytes(raw+note.encode('utf-8'))
print(json.dumps(dict(archive=str(z),sha256=sha(z),contracts=6,rdbc=571,mirrored=True)),flush=True)

