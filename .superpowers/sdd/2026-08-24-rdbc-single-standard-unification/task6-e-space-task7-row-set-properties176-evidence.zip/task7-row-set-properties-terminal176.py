import hashlib,json,zipfile
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d166');e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust');d=b/'task7-row-set-properties-isolated172'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
s=json.loads((d/'summary.json').read_text(encoding='utf-8'));assert s['terminal'] and s['exit_code']==0 and len(s['commands'])==2
assert [c['passed'] for c in s['commands']]==[571,0] and all(c['exit_code']==0 and not c['changed_inputs'] and sha(Path(c['log']))==c['sha256'] for c in s['commands'])
old=json.loads((b/'task7-row-set-properties-fix167/summary.json').read_text(encoding='utf-8'));assert old['terminal'] and old['exit_code']==101
assert old['commands'][-1]['passed']==570 and old['commands'][-1]['failed']==1
f=json.loads((d/'frozen-inputs.json').read_text(encoding='utf-8'));original=json.loads((b/'task7-row-set-properties-fix167/frozen-inputs.json').read_text(encoding='utf-8'))
assert f==original and len(f)==1250 and all(sha(w/r)==h for r,h in f.items())
assert s['isolated_target']=='F:/codex_build_cache/druid_rust/task7_properties172_target' and s['isolated_external_target']=='F:/codex_build_cache/druid_rust/task7_properties172_external'
files={str(p.relative_to(b)).replace('\\','/'):p for p in d.rglob('*') if p.is_file()}
for name in ['task7-row-set-properties-isolated172.py','task7-cache-isolation-ruling172.md','task7-row-set-properties-terminal176.py']:files[name]=b/name
files['original-failed167/summary.json']=b/'task7-row-set-properties-fix167/summary.json'
files['original-failed167/rdbc-complete.log']=b/'task7-row-set-properties-fix167/rdbc-complete.log'
manifest={n:sha(p) for n,p in files.items()};z=b/'task7-row-set-properties-terminal176.zip';assert not z.exists()
with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED) as out:
 for n,p in files.items():out.write(p,n)
 out.writestr('archive-manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(z) as inp:assert all(hashlib.sha256(inp.read(n)).hexdigest()==h for n,h in manifest.items())
parentzip=b/'task7-row-set-properties-failed173.zip';assert sha(parentzip)=='3c94cf55601c1cfd0140e4abd67e7abed7b4f69059c592caaa4509b49d68bbe3'
result=dict(scope='ROW_SET_PROPERTY_STATE_ISOLATED_FULL_RDBC_TERMINAL',production_applied=False,source_changed=False,archive=str(z),archive_sha256=sha(z),parent_archive=str(parentzip),parent_sha256=sha(parentzip),frozen_input_count=1250,delta={},verified_commands=old['commands'][:2]+s['commands'],prior_failure_preserved=dict(passed=570,failed=1,exit_code=101,reason='doctest compiler missing rlib'),compiler_cache_isolated=True,full_row_set_complete=False,task7_complete=False,top_level_open=18)
p=b/'task7-row-set-properties-terminal176.summary.json';p.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');dest=e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'
for original_path,name in [(z,'task6-e-space-task7-row-set-properties176-evidence.zip'),(p,'task6-e-space-task7-row-set-properties176-summary.json')]:
 t=dest/name;assert not t.exists();t.write_bytes(original_path.read_bytes());assert sha(t)==sha(original_path)
note=f'''
2026-10-09 RowSet属性候选独立缓存终态：原167完整570/1/Cargo101及缺rlib诊断保留在173失败终态归档，不删除或改写。172使用原d166同一1250冻结源码/测试/工具原字节，新建独立CARGO_TARGET_DIR及DRUID_RDBC_EXTERNAL_TARGET_ROOT，完整同命令RDBC allfeatures/locked/offline/-j1实际571PASS0FAIL（含此前doctest）、fmt0，终态输入变化0。结合原六属性合同6/0和指定严格Clippy0，取得此属性候选局部完整证据；无业务源码修复或放宽断言/超时声明。zip176 SHA {sha(z)}为173父链零源码delta验证补充，保存172完整命令/日志/清单、缓存隔离裁定及原167失败，全部解压与E镜像SHA核验。Ruling: 不同候选源根必须隔离编译及external-consumer缓存；本次独立缓存成功支持隔离措施有效，不冒充逐系统调用删除根因认证。170原始行候选及完整RowSet六入口/执行/事件/provider写回、最终全仓/API/MSRV/实库仍开放；正式Rust未apply，Task6 FIX_REQUIRED/Task7八义务/Task8 INCOMPLETE/18顶层OPEN。
'''
for rel in ['.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md','docs/verification/rdbc-first/status.md','docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md']:
 p=e/rel;raw=p.read_bytes();assert b'zip176 SHA' not in raw;p.write_bytes(raw+note.encode('utf-8'))
print(json.dumps(dict(archive=str(z),sha256=sha(z),full_rdbc=571,failed=0,source_changed=False,mirrored=True)),flush=True)

