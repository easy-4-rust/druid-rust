# P04 完整 RowSet 标准合同实施简报

规格事实源仍为 single-standard-trait-tree、JDBC42 semantic contract 与现有 P04 计划；不改变最终验收范围。

本阶段直接覆盖 RowSet、RowSetInternal、RowSetReader、RowSetWriter、RowSetListener、RowSetEvent 六标准对象，以及保留逻辑身份的真实 Rust RowSet 与共享 metadata 实现。参数、属性、行状态组件只是组成部分，不可替代标准对象。

11 项执行合同：Reader 填充后只通知一次 RowSetChanged、事件 source 为同一逻辑对象、回调无锁重入；共享 metadata 修改可见；原始结果集 before-first 和独立游标；参数族、长度、UTF16 流身份与命名解析；执行失败和递归执行；真正 poll 后取消；Writer false/错误/成功的原始基线；调用者连接仅借用不关闭；null 事件源拒绝；移除监听器、只读和 close；实际 maxRows/maxFieldSize；实际 queryTimeout 与取消后恢复。

Ruling: provider 的 RowSetInternal 暴露同一 RowSet 逻辑 facet，对应 Java provider 对 caller 的接口转换，禁止创造第二份 RowSet。连接通过 execute_with_connection 生命周期借用，不放入拥有型字段。事件 source 持有真实可用句柄，回调前释放内部锁。Reader/Writer 错误或 future drop 恢复执行状态，Writer 未成功不得 accept 原基线；不宣称数据库事务已经回滚。

Ruling: 独立源根 d177 使用独立 Cargo target 与 external-consumer target；父快照 clone 时若仍验证中，明确记录未认证状态，不能继承父级尚未完成的 PASS。

初始 RED 只能在确认无夹具错误后作为产品缺失证据。11 项合同不替代 RowSet 全 115 声明及继承 ResultSet 合同映射；完整 API/kind、Java 差分、真实 provider/数据库、取消/关闭全矩阵及 P04/P07 最终验收仍必须执行。不得仅添加六个可导入名字便宣称完成。
