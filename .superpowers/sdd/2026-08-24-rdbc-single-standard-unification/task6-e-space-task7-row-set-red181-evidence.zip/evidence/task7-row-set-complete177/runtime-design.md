# 完整 RowSet 实施约束：执行与发布边界

这是既有 P04 实施阶段的设计记录，不是另一套规格，也不代表实现已完成。

## 逻辑身份与 provider 视图

SharedRowSet 的 clone 共享同一 Arc 身份。RowSetEvent 保留该真实 source，不能改成字符串、数字 ID 或无法保证存活的 weak source。SharedRowSetMetaData 共享同一安装对象，不能每次 getter 复制一份 metadata 后声称修改可见。

Reader 填充在执行上下文的暂存行与 metadata 上进行。外部 SharedRowSet clone 在等待 provider 时仍只能观察已发布的基线，不能短暂读到半成品，再靠错误后的恢复掩盖。provider 的 RowSet facet 具有同一逻辑 source 身份，但将填充操作路由到本次暂存状态；它是同一对象的操作视图，不是第二个独立 RowSet。事件仅在成功发布后创建并通知。

```mermaid
sequenceDiagram
    participant App as 应用
    participant Owner as SharedRowSet 逻辑 owner
    participant Context as 本次执行上下文
    participant Reader as RowSetReader
    participant Listener as 监听器
    App->>Owner: execute / execute_with_connection
    Owner->>Owner: 校验 closed/busy，登记操作 token
    Owner->>Context: 创建暂存状态、参数快照、借用连接
    Context->>Reader: read_data(RowSetInternal)
    Reader->>Context: metadata / insert / 参数读取
    Note over Owner,Reader: await 期间不持有同步锁；外部读取仍为旧基线
    alt provider 失败、超时或 future 被 drop
        Context->>Owner: 丢弃暂存状态，释放 busy token
        Note over Owner: 保留旧行与 metadata，不发成功事件
    else provider 成功
        Context->>Owner: 原子发布完整行与 metadata，游标 before-first
        Owner->>Owner: 清除 busy，复制 listener 列表，释放锁
        Owner->>Listener: 一次 RowSetChanged，source 为同一 owner
        Listener->>Owner: 允许重入读取及属性修改
    end
```

## 取消、递归与锁

- busy 检查必须在等待 Reader/Writer 锁之前完成，递归 execute 返回 SQL 异常，不能等待自己。
- 操作 guard 的 Drop 只执行短同步状态收尾，不阻塞等待异步任务。token 必须只清除自己的操作，不能误清后续执行。
- callback 前释放 source、provider 和 listener 列表的所有锁；listener 的添加/删除以登记 Arc 身份判断，通知使用当前轮快照。
- close 幂等。调用者通过 execute_with_connection 借出的标准连接不能被 RowSet、context 或 guard close/free。
- SQLTimeoutException 来自真实 tokio timeout；零表示不设置时限。不能用 mock 标志或 setter 存储代替超时行为。

## 数据、原始行与 Writer

原始结果集必须是标准 ResultSet，使用独立 before-first 游标和 rich RdbcObject 值；不能用 Vec<Value> 丢失 Struct、Custom、Reader 或资源身份。getOriginalRow 在 before-first、after-last、insert-row 状态应给出原合同规定的错误；新增行没有原始行，删除的原始行仍供冲突检查。

Writer false、SQL 异常、timeout 或取消均不能 accept 新基线。Writer true 才允许接受当前值、清除已确认删除的槽位并建立新基线。此规则只描述本地 RowSet 状态；数据库事务、冲突策略和外部 side effects 必须由 provider 的真实合同证明，不能宣称 guard 完成数据库回滚。

maxRows 在成功发布时限制行数；maxFieldSize 只处理适用的字符/二进制列，不能主动消费 LOB/Reader。字符截断必须保留合法编码边界，并明确字节预算与 national 字符语义。完整参数 setter 映射继续复用既有 32 个 PreparedInputParameter 描述符族，保留 NULL、Calendar、长度重载和调用者流引用。

## 完成门禁

11 项初始合同只是核心行为底线。还须补充并实际验证：执行期间外部 clone 的原子可见性、Writer 真正 poll 后取消、getOriginalRow 游标错误、新增/删除原始行、逐 115 声明与继承 ResultSet 的映射、全部六标准对象的 Wrapper/kind/API 身份。独立 target 的完整 RDBC、严格 Clippy、fmt 以及真实 provider/数据库和 P04/P07 门禁均保留。
