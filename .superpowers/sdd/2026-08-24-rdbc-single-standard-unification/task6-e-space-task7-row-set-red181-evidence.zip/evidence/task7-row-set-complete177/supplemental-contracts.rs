// 补充合同草稿：须在原177终态后，保留原11合同并建立新冻结输入再运行。

#[tokio::test]
async fn pending_reader_never_exposes_partial_rows_to_an_external_clone() {
    let mut source = SharedRowSet::new();
    install_reader(&mut source, vec![values(1, "baseline")], ReadMode::Load);
    source.execute().await.unwrap();
    assert!(source.next().await.unwrap());
    let observer = source.clone();
    let (_, entered, _, _) = install_reader(&mut source, vec![values(99, "partial"), values(100, "partial")], ReadMode::Pending);
    let mut future = Box::pin(source.execute());
    poll_fn(|cx| {
        assert!(future.as_mut().poll(cx).is_pending());
        Poll::Ready(())
    }).await;
    assert!(entered.load(Ordering::Acquire));
    assert_eq!(observer.known_row_count(), Some(1));
    assert_eq!(observer.row().unwrap(), 1);
    assert_eq!(observer.object(column(1)).unwrap(), RdbcObject::Integer(1));
    drop(future);
    assert_eq!(source.object(column(1)).unwrap(), RdbcObject::Integer(1));
}

struct PendingWriter { entered: Arc<AtomicBool> }
#[async_trait::async_trait]
impl RowSetWriter for PendingWriter {
    async fn write_data(&mut self, caller: &mut dyn RowSetInternal) -> Result<bool, RdbcError> {
        let mut original = caller.original()?;
        assert!(original.next().await?);
        assert_eq!(original.object(column(1))?, RdbcObject::Integer(1));
        self.entered.store(true, Ordering::Release);
        pending().await
    }
}

#[tokio::test]
async fn cancellation_after_real_writer_poll_preserves_updates_and_original_baseline() {
    let mut source = SharedRowSet::new();
    install_reader(&mut source, vec![values(1, "baseline")], ReadMode::Load);
    source.execute().await.unwrap();
    source.set_read_only(false).unwrap();
    source.set_concurrency(1008).unwrap();
    assert!(source.next().await.unwrap());
    source.update_value(column(1), ResultSetUpdate::Int(7)).unwrap();
    source.update_row().unwrap();
    let entered = Arc::new(AtomicBool::new(false));
    source.set_writer(Some(Box::new(PendingWriter { entered: Arc::clone(&entered) }))).unwrap();
    let mut future = Box::pin(source.accept_changes());
    poll_fn(|cx| {
        assert!(future.as_mut().poll(cx).is_pending());
        Poll::Ready(())
    }).await;
    assert!(entered.load(Ordering::Acquire));
    drop(future);
    assert_eq!(source.object(column(1)).unwrap(), RdbcObject::Integer(7));
    let mut original = source.original().unwrap();
    assert!(original.next().await.unwrap());
    assert_eq!(original.object(column(1)).unwrap(), RdbcObject::Integer(1));
    let originals = Arc::new(Mutex::new(Vec::new()));
    source.set_writer(Some(Box::new(Writer {
        outcomes: Arc::new(Mutex::new(VecDeque::from([WriteOutcome::Success]))),
        originals: Arc::clone(&originals),
    }))).unwrap();
    assert!(source.accept_changes().await.unwrap());
    assert_eq!(*originals.lock().unwrap(), vec![vec![RdbcObject::Integer(1)]]);
}

#[tokio::test]
async fn original_row_rejects_non_row_cursor_and_preserves_deleted_original() {
    let mut source = SharedRowSet::new();
    install_reader(&mut source, vec![values(1, "baseline")], ReadMode::Load);
    source.execute().await.unwrap();
    assert_sql_error(source.original_row());
    assert!(source.next().await.unwrap());
    let mut original = source.original_row().unwrap();
    assert_eq!(original.row().unwrap(), 0);
    assert!(original.next().await.unwrap());
    assert_eq!(original.object(column(1)).unwrap(), RdbcObject::Integer(1));
    assert!(!original.next().await.unwrap());
    source.set_read_only(false).unwrap();
    source.set_concurrency(1008).unwrap();
    source.delete_row().unwrap();
    let mut deleted = source.original().unwrap();
    assert!(deleted.next().await.unwrap());
    assert_eq!(deleted.object(column(1)).unwrap(), RdbcObject::Integer(1));
    source.move_to_insert_row().unwrap();
    assert_sql_error(source.original_row());
    source.update_value(column(1), ResultSetUpdate::Int(2)).unwrap();
    source.update_value(column(2), ResultSetUpdate::String(Some("inserted".into()))).unwrap();
    source.insert_row().unwrap();
    source.move_to_current_row().unwrap();
    source.after_last().await.unwrap();
    assert_sql_error(source.original_row());
}
