import hashlib,json,os,re,shutil,subprocess,time
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
parent=Path('F:/codex_build_cache/d169');w=Path('F:/codex_build_cache/d177');d=b/'task7-row-set-complete177'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
f=json.loads((b/'task7-row-set-rows-format178/frozen-inputs.json').read_text())
assert len(f)==1254 and all(sha(parent/r)==h for r,h in f.items())
assert not w.exists();w.mkdir()
for r,h in f.items():
 target=w/r;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(parent/r,target);assert sha(target)==h
assert all(sha(parent/r)==h for r,h in f.items())
(d/'parent-inputs.json').write_text(json.dumps(f,indent=2)+'\n',encoding='utf-8')
parent_status=json.loads((b/'task7-row-set-rows-format178/summary.json').read_text())
(d/'clone-parent-validation.json').write_text(json.dumps(dict(parent_terminal_at_clone=parent_status['terminal'],parent_exit_at_clone=parent_status.get('exit_code'),same_source_verified=True,cache_shared=False),indent=2)+'\n',encoding='utf-8')
test='crates/druid-rdbc/tests/standard_row_set_complete_contract_test.rs'
shutil.copyfile(d/'contract.rs',w/test);f[test]=sha(w/test)
tool='C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin'
target='F:/codex_build_cache/druid_rust/task7_row_set177_target';external='F:/codex_build_cache/druid_rust/task7_row_set177_external'
assert not Path(target).exists() and not Path(external).exists()
env=os.environ.copy();env.update(RUSTUP_TOOLCHAIN='1.97.1',RUSTUP_AUTO_INSTALL='0',RUSTC=tool+'/rustc.exe',RUSTDOC=tool+'/rustdoc.exe',CARGO_TARGET_DIR=target,DRUID_RDBC_EXTERNAL_TARGET_ROOT=external,TMP='F:/codex_tmp/task7_standard_cargo13',TEMP='F:/codex_tmp/task7_standard_cargo13');env['PATH']=tool+os.pathsep+env['PATH']
# 测试只应用官方格式化；原合同断言和生产源码保持不变。
fmt=subprocess.run([tool+'/rustfmt.exe','--edition','2021',str(w/test)],env=env,cwd=w,capture_output=True)
(d/'test-rustfmt.log').write_bytes(fmt.stdout+fmt.stderr);assert fmt.returncode==0
f[test]=sha(w/test);(d/'frozen-inputs.json').write_text(json.dumps(f,indent=2)+'\n',encoding='utf-8')
java=b/'task8-java-jdbc42-source/jdk/src/share/classes/javax/sql';sources={}
for name in ['RowSet','RowSetInternal','RowSetReader','RowSetWriter','RowSetListener','RowSetEvent']:
 p=java/(name+'.java');sources[name]=dict(source=str(p),sha256=sha(p));shutil.copyfile(p,d/(name+'.java'))
(d/'java-sources.json').write_text(json.dumps(sources,indent=2)+'\n',encoding='utf-8')
cmd=[tool+'/cargo.exe','test','-p','druid-rdbc','--test','standard_row_set_complete_contract_test','--all-features','--locked','--offline','-j1']
s=dict(terminal=False,phase='RED',workspace=str(w),pid=os.getpid(),command=cmd,production_applied=False,frozen_input_count=len(f),cache_target=target,external_target=external)
summary=d/'summary.json'
def save():summary.write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
save();start=time.time()
with (d/'red.log').open('wb') as out:
 p=subprocess.Popen(cmd,cwd=w,env=env,stdout=out,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS);s['cargo_pid']=p.pid;save();code=p.wait()
log=(d/'red.log').read_text(encoding='utf-8',errors='replace');codes=sorted(set(re.findall(r'error\[(E\d+)\]',log)))
changed=[r for r,h in f.items() if sha(w/r)!=h]
expected=code==101 and codes==['E0432'] and all(name in log for name in ['RowSetInternal','RowSetReader','RowSetWriter','SharedRowSet'])
s.update(terminal=True,exit_code=code,elapsed_seconds=time.time()-start,error_codes=codes,expected_missing_public_entry_red=expected,changed_inputs=changed,log_sha256=sha(d/'red.log'));save();print(json.dumps(s),flush=True)
assert expected and not changed, 'Mixed fixture failure must be fixed before product implementation'
