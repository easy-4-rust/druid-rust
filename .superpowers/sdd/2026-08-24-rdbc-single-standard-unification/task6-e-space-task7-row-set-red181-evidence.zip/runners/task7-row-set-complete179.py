import hashlib,json,os,re,subprocess,time
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d177');previous=b/'task7-row-set-complete177'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
s0=json.loads((previous/'summary.json').read_text());assert s0['terminal'] and s0['expected_missing_public_entry_red'] and not s0['changed_inputs']
f=json.loads((previous/'frozen-inputs.json').read_text());assert len(f)==1255 and all(sha(w/r)==h for r,h in f.items())
d=b/'task7-row-set-complete179';d.mkdir(exist_ok=False)
r='crates/druid-rdbc/tests/standard_row_set_complete_contract_test.rs';original=(w/r).read_bytes();(d/'original-eleven.rs').write_bytes(original)
extra=(previous/'supplemental-contracts.rs').read_bytes();(w/r).write_bytes(original+b'\n'+extra)
tool='C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin'
env=os.environ.copy();env.update(RUSTUP_TOOLCHAIN='1.97.1',RUSTUP_AUTO_INSTALL='0',RUSTC=tool+'/rustc.exe',RUSTDOC=tool+'/rustdoc.exe',CARGO_TARGET_DIR='F:/codex_build_cache/druid_rust/task7_row_set177_target',DRUID_RDBC_EXTERNAL_TARGET_ROOT='F:/codex_build_cache/druid_rust/task7_row_set177_external',TMP='F:/codex_tmp/task7_standard_cargo13',TEMP='F:/codex_tmp/task7_standard_cargo13');env['PATH']=tool+os.pathsep+env['PATH']
p=subprocess.run([tool+'/rustfmt.exe','--edition','2021',str(w/r)],cwd=w,env=env,capture_output=True);(d/'test-rustfmt.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0
assert (w/r).read_bytes().startswith(original.rstrip())
assert [path for path,h in f.items() if sha(w/path)!=h]==[r]
f[r]=sha(w/r);(d/'frozen-inputs.json').write_text(json.dumps(f,indent=2)+'\n',encoding='utf-8')
cmd=[tool+'/cargo.exe','test','-p','druid-rdbc','--test','standard_row_set_complete_contract_test','--all-features','--locked','--offline','-j1']
s=dict(terminal=False,phase='EXPANDED_RED',workspace=str(w),pid=os.getpid(),command=cmd,production_applied=False,original_eleven_preserved=True,total_contracts=14)
summary=d/'summary.json'
def save():summary.write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
save();start=time.time()
with (d/'red.log').open('wb') as out:
 p=subprocess.Popen(cmd,cwd=w,env=env,stdout=out,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS);s['cargo_pid']=p.pid;save();code=p.wait()
log=(d/'red.log').read_text(encoding='utf-8',errors='replace');codes=sorted(set(re.findall(r'error\[(E\d+)\]',log)));changed=[path for path,h in f.items() if sha(w/path)!=h]
expected=code==101 and codes==['E0432'] and all(name in log for name in ['RowSetInternal','RowSetReader','RowSetWriter','SharedRowSet'])
s.update(terminal=True,exit_code=code,elapsed_seconds=time.time()-start,error_codes=codes,expected_missing_public_entry_red=expected,changed_inputs=changed,log_sha256=sha(d/'red.log'));save();print(json.dumps(s),flush=True);assert expected and not changed
