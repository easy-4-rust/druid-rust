import hashlib,json,os,re,subprocess,time
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d169');old_d=b/'task7-row-set-rows-fix170'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads((old_d/'summary.json').read_text(encoding='utf-8'))
assert old['terminal'] and old['exit_code']!=0, 'Original170 must finish before modifying its frozen source'
assert len(old['commands'])==4 and [c['name'] for c in old['commands']]==['rows-green','rows-strict','rdbc-complete','fmt']
assert [c['exit_code'] for c in old['commands']]==[0,0,0,1] and old['commands'][2]['passed']==577 and old['commands'][2]['failed']==0
assert all(not c['changed_inputs'] and sha(Path(c['log']))==c['sha256'] for c in old['commands'])
f=json.loads((old_d/'frozen-inputs.json').read_text(encoding='utf-8'));assert len(f)==1254 and all(sha(w/r)==h for r,h in f.items())
d=b/'task7-row-set-rows-format171';d.mkdir(exist_ok=False);r='crates/druid-rdbc/src/extensions/mod.rs'
(d/'original-mod.rs').write_bytes((w/r).read_bytes())
tool='C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin';external='F:/codex_build_cache/druid_rust/task7_rows171_external';assert not Path(external).exists()
env=os.environ.copy();env.update(RUSTUP_TOOLCHAIN='1.97.1',RUSTUP_AUTO_INSTALL='0',RUSTC=tool+'/rustc.exe',RUSTDOC=tool+'/rustdoc.exe',CARGO_TARGET_DIR='F:/codex_build_cache/druid_rust/task7_type_map146_target',DRUID_RDBC_EXTERNAL_TARGET_ROOT=external,TMP='F:/codex_tmp/task7_standard_cargo13',TEMP='F:/codex_tmp/task7_standard_cargo13');env['PATH']=tool+os.pathsep+env['PATH']
p=subprocess.run([tool+'/rustfmt.exe','--edition','2021','--config','skip_children=true',str(w/r)],cwd=w,env=env,capture_output=True);(d/'format-repair.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0
assert sha(w/r)==sha(old_d/'extensions.mod.formatted.rs')
assert [p for p,h in f.items() if sha(w/p)!=h]==[r]
f[r]=sha(w/r);(d/'frozen-inputs.json').write_text(json.dumps(f,indent=2)+'\n',encoding='utf-8')
s=dict(terminal=False,production_applied=False,workspace=str(w),pid=os.getpid(),frozen_input_count=len(f),commands=[],source_delta_from170=[r],ruling='Original170 functional6/0 strict0 full577/0 and fmt1 retained; official rustfmt only reorders three new module declarations, original six contracts and production method bodies unchanged; source modified only after original runner terminal.')
summary=d/'summary.json'
def save():summary.write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
commands=[('rows-green',['test','-p','druid-rdbc','--test','standard_row_set_rows_contract_test','--all-features','--locked','--offline','-j1']),('rows-strict',['clippy','-p','druid-rdbc','--test','standard_row_set_rows_contract_test','--all-features','--locked','--offline','-j1','--','-D','warnings']),('rdbc-complete',['test','-p','druid-rdbc','--all-features','--locked','--offline','-j1']),('fmt',['fmt','--all','--','--check'])]
for name,args in commands:
 s['running_command']=name;save();log=d/(name+'.log');command=[tool+'/cargo.exe']+args;start=time.time()
 with log.open('wb') as output:
  p=subprocess.Popen(command,cwd=w,env=env,stdout=output,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS);s['cargo_pid']=p.pid;save();code=p.wait()
 text=log.read_text(encoding='utf-8',errors='replace');counts=re.findall(r'test result: \w+\. (\d+) passed; (\d+) failed;',text);changed=[r for r,h in f.items() if sha(w/r)!=h]
 record=dict(name=name,command=command,exit_code=code,elapsed_seconds=time.time()-start,log=str(log),sha256=sha(log),passed=sum(int(a) for a,_ in counts),failed=sum(int(a) for _,a in counts),changed_inputs=changed);s['commands'].append(record);save();print(json.dumps(record),flush=True)
 if code or changed:s.update(terminal=True,exit_code=code or 97);save();raise SystemExit(code or 97)
s.update(terminal=True,exit_code=0);s.pop('running_command',None);save();print(json.dumps(s),flush=True)

