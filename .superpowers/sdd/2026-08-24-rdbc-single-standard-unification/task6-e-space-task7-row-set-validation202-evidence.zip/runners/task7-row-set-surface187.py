from pathlib import Path
import json,re,hashlib
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');d=b/'task7-row-set-surface187';d.mkdir(exist_ok=False)
oracle=json.loads((b/'task7-row-set-parameters163/java-methods.json').read_text())[0]
assert hashlib.sha256(Path(oracle['source_path']).read_bytes()).hexdigest()==oracle['sha256']
names={x['java']:x['rust'] for x in json.loads((b/'task7-row-set-complete179/row-set-setter-mapping182.json').read_text())}
s='''//! 固定 Java RowSet 的完整 85 setter 重载与标准身份/属性合同。
use druid_rdbc::connection::TransactionIsolation;
use druid_rdbc::extensions::{RowSet, RowSetInternal, SharedRowSet};
use druid_rdbc::result_set::ResultSet;
use druid_rdbc::statement::{ParameterIndex, PreparedInputParameter, PreparedStatement, PreparedTypeNameArgument, ResultSetConcurrency, ResultSetType};
use druid_rdbc::types::{RdbcCalendarArgument, RdbcCharacterLength, RdbcObject, RdbcStreamLength, RdbcTypeMap};
use druid_rdbc::wrapper::{StandardUnwrapped, StandardUnwrappedMut, Wrapper};
use std::any::TypeId;
use std::sync::{Arc, Mutex};

#[test]
fn every_fixed_java_row_set_setter_preserves_its_family_and_overload() {
    let mut source = SharedRowSet::new();
    source.set_named_parameter_resolver(Some(Arc::new(|_, name| {
        assert_eq!(name, " 参数原名 ");
        ParameterIndex::new(1)
    }))).unwrap();
'''
count=0
for declaration in oracle['methods']:
 if declaration not in names:continue
 method=names[declaration];m=re.search(r'\b(set\w+)\s*\((.*?)\)',declaration);kind=m[1][3:];params=[]
 for argument in m[2].split(','):
  x=re.fullmatch(r'\s*(.*?)\s+(\w+)(\[\])?\s*',argument);params.append(x[1]+(x[3] or ''))
 named=params[0]=='String';types=params[1:];args=[]
 for i,typ in enumerate(types):
  if typ=='String':value='Some(" 类型或字符串 ")'
  elif typ=='boolean':value='true'
  elif typ in ['byte','short','int','long']:value='-3' if i>0 and kind not in ['Null','Object'] else '37'
  elif typ in ['float','double']:value='1.25'
  elif typ=='byte[]':value='Some(vec![0, 255, 3])'
  elif typ=='Object':value='Some(RdbcObject::String("对象".into()))'
  else:value='None'
  args.append(value)
 if kind=='Null':expected='PreparedInputParameter::Null { sql_type:37, type_name:'+('PreparedTypeNameArgument::Specified(Some(" 类型或字符串 ".into()))' if len(types)==2 else 'PreparedTypeNameArgument::Unspecified')+' }'
 elif kind in ['Date','Time','Timestamp']:expected=f'PreparedInputParameter::{kind} {{ value:None, calendar:'+('RdbcCalendarArgument::Specified(None)' if len(types)==2 else 'RdbcCalendarArgument::Unspecified')+' }'
 elif kind=='Object':expected='PreparedInputParameter::Object { value:Some(RdbcObject::String("对象".into())), target_sql_type:'+('Some(37)' if len(types)>1 else 'None')+', scale_or_length:'+('Some(37)' if len(types)>2 else 'None')+' }'
 elif 'Stream' in kind or (kind in ['Blob','Clob','NClob'] and types[0] not in ['Blob','Clob','NClob']):
  character=kind in ['CharacterStream','NCharacterStream','Clob','NClob'];variant={'Blob':'BlobStream','Clob':'ClobReader','NClob':'NClobReader'}.get(kind,kind);length_type='RdbcCharacterLength' if character else 'RdbcStreamLength';length=length_type+'::'+('Unspecified' if len(types)==1 else ('Int(-3)' if types[1]=='int' else 'Long(-3)'));expected=f'PreparedInputParameter::{variant} {{ '+('reader' if character else 'stream')+':None, length:'+length+' }'
 else:
  variant={'SQLXML':'SqlXml','URL':'Url'}.get(kind,kind);value=args[0]
  if types[0]=='String':value='Some(" 类型或字符串 ".into())'
  expected=f'PreparedInputParameter::{variant}({value})'
 selector='Some(" 参数原名 ")' if named else 'ParameterIndex::new(1).unwrap()'
 s+=f'    // Java 固定声明：{declaration}\n    source.clear_parameters().unwrap();\n    {{ let row_set: &mut dyn RowSet = &mut source; row_set.{method}({selector}, '+', '.join(args)+f').unwrap(); }}\n    assert_eq!(source.params().unwrap(), vec![{expected}], "{method}");\n';count+=1
assert count==85
s+='''}

#[test]
fn canonical_row_set_wrapper_preserves_leaf_parent_and_mutable_identity() {
    let mut source = SharedRowSet::new();
    for target in [TypeId::of::<dyn RowSet>(), TypeId::of::<dyn ResultSet>(), TypeId::of::<SharedRowSet>(), TypeId::of::<dyn Wrapper>()] {
        assert!(source.is_wrapper_for(Some(target)).unwrap());
    }
    assert!(!source.is_wrapper_for(Some(TypeId::of::<dyn PreparedStatement>())).unwrap());
    let StandardUnwrapped::RowSet(leaf) = source.unwrap(Some(TypeId::of::<dyn RowSet>())).unwrap() else { panic!("RowSet leaf required") };
    assert!(std::ptr::eq(leaf, &source as &dyn RowSet));
    let StandardUnwrapped::ResultSet(parent) = source.unwrap(Some(TypeId::of::<dyn ResultSet>())).unwrap() else { panic!("ResultSet parent required") };
    assert!(std::ptr::eq(parent, &source as &dyn ResultSet));
    let StandardUnwrappedMut::RowSet(leaf) = source.unwrap_mut(Some(TypeId::of::<SharedRowSet>())).unwrap() else { panic!("same mutable leaf required") };
    leaf.set_command(Some("通过同一可变视图")).unwrap();
    assert_eq!(source.command(), Some("通过同一可变视图".into()));
}

#[test]
fn canonical_row_set_properties_forward_all_requests_and_validate_atomically() {
    let mut source = SharedRowSet::new();
    let map=Arc::new(Mutex::new(RdbcTypeMap::new()));
    let row_set: &mut dyn RowSet = &mut source;
    row_set.set_url(Some(" jdbc:exact ")).unwrap();
    row_set.set_data_source_name(Some(" 名称 ")).unwrap();
    row_set.set_username(Some("用户")).unwrap();
    row_set.set_password(Some("不能出现在Debug的密码")).unwrap();
    row_set.set_command(Some(" select ? ")).unwrap();
    row_set.set_transaction_isolation(8).unwrap();
    row_set.set_type_map(Arc::clone(&map)).unwrap();
    row_set.set_read_only(false).unwrap();
    row_set.set_max_field_size(17).unwrap();
    row_set.set_max_rows(19).unwrap();
    row_set.set_escape_processing(false).unwrap();
    row_set.set_query_timeout(23).unwrap();
    row_set.set_type(1004).unwrap();
    row_set.set_concurrency(1008).unwrap();
    assert_eq!(row_set.url(),Some(" jdbc:exact ".into()));
    assert_eq!(row_set.data_source_name(),Some(" 名称 ".into()));
    assert_eq!(row_set.username(),Some("用户".into()));
    assert_eq!(row_set.password(),Some("不能出现在Debug的密码".into()));
    assert_eq!(row_set.command(),Some(" select ? ".into()));
    assert_eq!(row_set.transaction_isolation(),TransactionIsolation::SERIALIZABLE);
    assert!(Arc::ptr_eq(&row_set.type_map(),&map));
    assert!(!row_set.is_read_only());
    assert_eq!(row_set.max_field_size(),17);
    assert_eq!(row_set.max_rows(),19);
    assert!(!row_set.escape_processing());
    assert_eq!(row_set.query_timeout(),23);
    assert_eq!(row_set.result_set_type().unwrap(),ResultSetType::ScrollInsensitive);
    assert_eq!(row_set.concurrency().unwrap(),ResultSetConcurrency::Updatable);
    assert!(row_set.set_max_rows(-1).is_err());
    assert!(row_set.set_max_field_size(-1).is_err());
    assert!(row_set.set_query_timeout(-1).is_err());
    assert!(row_set.set_transaction_isolation(0).is_err());
    assert!(row_set.set_type(1002).is_err());
    assert!(row_set.set_concurrency(1006).is_err());
    assert_eq!(row_set.max_rows(),19);
    assert_eq!(row_set.transaction_isolation(),TransactionIsolation::SERIALIZABLE);
    assert_eq!(row_set.result_set_type().unwrap(),ResultSetType::ScrollInsensitive);
    assert_eq!(row_set.concurrency().unwrap(),ResultSetConcurrency::Updatable);
    assert!(!format!("{source:?}").contains("不能出现在Debug的密码"));
}
'''
(d/'surface-contract.rs').write_text(s,encoding='utf-8')
(d/'source.json').write_text(json.dumps(dict(java_sha256=oracle['sha256'],java_method_count=115,setter_calls=count,new_contracts=3),indent=2)+'\n',encoding='utf-8')
print('Prepared independent fixed-Java 85 setter calls plus Wrapper identity and 26 property declaration checks')
