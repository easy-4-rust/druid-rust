pub use druid_rdbc::{extensions,result_set,wrapper};
#[macro_export]
macro_rules! impl_standard_wrapper_candidate {
    // RowSet 的 canonical leaf 自动包含 ResultSet 父接口，并保留同一可变对象身份。
    (@emit [$($g:tt)*] $t:ty => RowSet) => {
        impl $($g)* $crate::wrapper::Wrapper for $t {
            fn wrapper_view(&self) -> &dyn $crate::wrapper::Wrapper { self }
            fn canonical_unwrap(&self, target: std::any::TypeId) -> Option<$crate::wrapper::StandardUnwrapped<'_>> {
                if target == std::any::TypeId::of::<dyn $crate::extensions::RowSet>() || target == std::any::TypeId::of::<Self>() {
                    Some($crate::wrapper::StandardUnwrapped::RowSet(self))
                } else if target == std::any::TypeId::of::<dyn $crate::result_set::ResultSet>() {
                    Some($crate::wrapper::StandardUnwrapped::ResultSet(self))
                } else { None }
            }
            fn canonical_unwrap_mut(&mut self, target: std::any::TypeId) -> Option<$crate::wrapper::StandardUnwrappedMut<'_>> {
                if target == std::any::TypeId::of::<dyn $crate::wrapper::Wrapper>() {
                    Some($crate::wrapper::StandardUnwrappedMut::Wrapper(self))
                } else if target == std::any::TypeId::of::<dyn $crate::extensions::RowSet>() || target == std::any::TypeId::of::<Self>() {
                    Some($crate::wrapper::StandardUnwrappedMut::RowSet(self))
                } else if target == std::any::TypeId::of::<dyn $crate::result_set::ResultSet>() {
                    Some($crate::wrapper::StandardUnwrappedMut::ResultSet(self))
                } else { None }
            }
        }
    };
    (@emit [$($g:tt)*] $t:ty where [$($w:tt)*] => RowSet) => {
        impl $($g)* $crate::wrapper::Wrapper for $t where $($w)* {
            fn wrapper_view(&self) -> &dyn $crate::wrapper::Wrapper { self }
            fn canonical_unwrap(&self, target: std::any::TypeId) -> Option<$crate::wrapper::StandardUnwrapped<'_>> {
                if target == std::any::TypeId::of::<dyn $crate::extensions::RowSet>() || target == std::any::TypeId::of::<Self>() {
                    Some($crate::wrapper::StandardUnwrapped::RowSet(self))
                } else if target == std::any::TypeId::of::<dyn $crate::result_set::ResultSet>() {
                    Some($crate::wrapper::StandardUnwrapped::ResultSet(self))
                } else { None }
            }
            fn canonical_unwrap_mut(&mut self, target: std::any::TypeId) -> Option<$crate::wrapper::StandardUnwrappedMut<'_>> {
                if target == std::any::TypeId::of::<dyn $crate::wrapper::Wrapper>() {
                    Some($crate::wrapper::StandardUnwrappedMut::Wrapper(self))
                } else if target == std::any::TypeId::of::<dyn $crate::extensions::RowSet>() || target == std::any::TypeId::of::<Self>() {
                    Some($crate::wrapper::StandardUnwrappedMut::RowSet(self))
                } else if target == std::any::TypeId::of::<dyn $crate::result_set::ResultSet>() {
                    Some($crate::wrapper::StandardUnwrappedMut::ResultSet(self))
                } else { None }
            }
        }
    };
    (@emit [$($g:tt)*] $t:ty => RowSetMetaData) => {
        impl $($g)* $crate::wrapper::Wrapper for $t {
            fn wrapper_view(&self) -> &dyn $crate::wrapper::Wrapper { self }
            fn canonical_unwrap(&self, target: std::any::TypeId) -> Option<$crate::wrapper::StandardUnwrapped<'_>> {
                if target == std::any::TypeId::of::<dyn $crate::extensions::RowSetMetaData>() || target == std::any::TypeId::of::<Self>() {
                    Some($crate::wrapper::StandardUnwrapped::RowSetMetaData(self))
                } else if target == std::any::TypeId::of::<dyn $crate::metadata::ResultSetMetaData>() {
                    Some($crate::wrapper::StandardUnwrapped::ResultSetMetaData(self))
                } else { None }
            }
            fn canonical_unwrap_mut(&mut self, target: std::any::TypeId) -> Option<$crate::wrapper::StandardUnwrappedMut<'_>> {
                if target == std::any::TypeId::of::<dyn $crate::wrapper::Wrapper>() {
                    Some($crate::wrapper::StandardUnwrappedMut::Wrapper(self))
                } else if target == std::any::TypeId::of::<dyn $crate::extensions::RowSetMetaData>() || target == std::any::TypeId::of::<Self>() {
                    Some($crate::wrapper::StandardUnwrappedMut::RowSetMetaData(self))
                } else if target == std::any::TypeId::of::<dyn $crate::metadata::ResultSetMetaData>() {
                    Some($crate::wrapper::StandardUnwrappedMut::ResultSetMetaData(self))
                } else { None }
            }
        }
    };
    (generics [$($generics:tt)*] for $target:ty where [$($where_clause:tt)*] => $kind:ident) => {
        $crate::impl_standard_wrapper_candidate!(@emit [<$($generics)*>] $target where [$($where_clause)*] => $kind);
    };
    (impl<$generic:ident : $bound:path> $target:ty => $kind:ident) => {
        $crate::impl_standard_wrapper_candidate!(@emit [<$generic: $bound>] $target => $kind);
    };
    ($target:ty => $kind:ident) => {
        $crate::impl_standard_wrapper_candidate!(@emit [] $target => $kind);
    };
    (@emit [$($impl_generics:tt)*] $target:ty => Connection) => {
        impl $($impl_generics)* $crate::wrapper::Wrapper for $target {
            fn wrapper_view(&self) -> &dyn $crate::wrapper::Wrapper { self }
            fn canonical_unwrap(&self, target: std::any::TypeId) -> Option<$crate::wrapper::StandardUnwrapped<'_>> {
                (target == std::any::TypeId::of::<dyn $crate::connection::Connection>())
                    .then_some($crate::wrapper::StandardUnwrapped::Connection(self))
            } fn canonical_unwrap_mut(&mut self, target: std::any::TypeId) -> Option<$crate::wrapper::StandardUnwrappedMut<'_>> { if target == std::any::TypeId::of::<dyn $crate::wrapper::Wrapper>() { return Some($crate::wrapper::StandardUnwrappedMut::Wrapper(self)); }
                (target == std::any::TypeId::of::<dyn $crate::connection::Connection>())
                    .then_some($crate::wrapper::StandardUnwrappedMut::Connection(self))
             }
        }
    };
    (@emit [$($impl_generics:tt)*] $target:ty where [$($where_clause:tt)*] => Connection) => {
        impl $($impl_generics)* $crate::wrapper::Wrapper for $target where $($where_clause)* {
            fn wrapper_view(&self) -> &dyn $crate::wrapper::Wrapper { self }
            fn canonical_unwrap(&self, target: std::any::TypeId) -> Option<$crate::wrapper::StandardUnwrapped<'_>> {
                (target == std::any::TypeId::of::<dyn $crate::connection::Connection>()).then_some($crate::wrapper::StandardUnwrapped::Connection(self))
            } fn canonical_unwrap_mut(&mut self, target: std::any::TypeId) -> Option<$crate::wrapper::StandardUnwrappedMut<'_>> { if target == std::any::TypeId::of::<dyn $crate::wrapper::Wrapper>() { return Some($crate::wrapper::StandardUnwrappedMut::Wrapper(self)); }
                (target == std::any::TypeId::of::<dyn $crate::connection::Connection>()).then_some($crate::wrapper::StandardUnwrappedMut::Connection(self))
             }
        }
    };
    (@emit [$($g:tt)*] $t:ty where [$($w:tt)*] => ResultSet) => {
        impl $($g)* $crate::wrapper::Wrapper for $t where $($w)* {
            fn wrapper_view(&self)->&dyn $crate::wrapper::Wrapper { self }
            fn canonical_unwrap(&self,x:std::any::TypeId)->Option<$crate::wrapper::StandardUnwrapped<'_>> {
                (x==std::any::TypeId::of::<dyn $crate::result_set::ResultSet>()).then_some($crate::wrapper::StandardUnwrapped::ResultSet(self))
            } fn canonical_unwrap_mut(&mut self, x: std::any::TypeId) -> Option<$crate::wrapper::StandardUnwrappedMut<'_>> { if x == std::any::TypeId::of::<dyn $crate::wrapper::Wrapper>() { return Some($crate::wrapper::StandardUnwrappedMut::Wrapper(self)); }
                (x==std::any::TypeId::of::<dyn $crate::result_set::ResultSet>()).then_some($crate::wrapper::StandardUnwrappedMut::ResultSet(self))
             }
        }
    };
    (@emit [$($impl_generics:tt)*] $target:ty => Statement) => {
        impl $($impl_generics)* $crate::wrapper::Wrapper for $target {
            fn wrapper_view(&self) -> &dyn $crate::wrapper::Wrapper { self }
            fn canonical_unwrap(&self, target: std::any::TypeId) -> Option<$crate::wrapper::StandardUnwrapped<'_>> {
                (target == std::any::TypeId::of::<dyn $crate::statement::Statement>())
                    .then_some($crate::wrapper::StandardUnwrapped::Statement(self))
            } fn canonical_unwrap_mut(&mut self, target: std::any::TypeId) -> Option<$crate::wrapper::StandardUnwrappedMut<'_>> { if target == std::any::TypeId::of::<dyn $crate::wrapper::Wrapper>() { return Some($crate::wrapper::StandardUnwrappedMut::Wrapper(self)); }
                (target == std::any::TypeId::of::<dyn $crate::statement::Statement>())
                    .then_some($crate::wrapper::StandardUnwrappedMut::Statement(self))
             }
        }
    };
    (@emit [$($impl_generics:tt)*] $target:ty => PreparedStatement) => {
        impl $($impl_generics)* $crate::wrapper::Wrapper for $target {
            fn wrapper_view(&self) -> &dyn $crate::wrapper::Wrapper { self }
            fn canonical_unwrap(&self, target: std::any::TypeId) -> Option<$crate::wrapper::StandardUnwrapped<'_>> {
                if target == std::any::TypeId::of::<dyn $crate::statement::PreparedStatement>() { Some($crate::wrapper::StandardUnwrapped::PreparedStatement(self)) }
                else if target == std::any::TypeId::of::<dyn $crate::statement::Statement>() { Some($crate::wrapper::StandardUnwrapped::Statement(self)) }
                else { None }
            } fn canonical_unwrap_mut(&mut self, target: std::any::TypeId) -> Option<$crate::wrapper::StandardUnwrappedMut<'_>> { if target == std::any::TypeId::of::<dyn $crate::wrapper::Wrapper>() { return Some($crate::wrapper::StandardUnwrappedMut::Wrapper(self)); }
                if target == std::any::TypeId::of::<dyn $crate::statement::PreparedStatement>() { Some($crate::wrapper::StandardUnwrappedMut::PreparedStatement(self)) }
                else if target == std::any::TypeId::of::<dyn $crate::statement::Statement>() { Some($crate::wrapper::StandardUnwrappedMut::Statement(self)) }
                else { None }
             }
        }
    };
    (@emit [$($g:tt)*] $t:ty => ResultSet) => { impl $($g)* $crate::wrapper::Wrapper for $t { fn wrapper_view(&self) -> &dyn $crate::wrapper::Wrapper { self } fn canonical_unwrap(&self, x: std::any::TypeId)->Option<$crate::wrapper::StandardUnwrapped<'_>> { (x==std::any::TypeId::of::<dyn $crate::result_set::ResultSet>()).then_some($crate::wrapper::StandardUnwrapped::ResultSet(self)) } fn canonical_unwrap_mut(&mut self, x: std::any::TypeId) -> Option<$crate::wrapper::StandardUnwrappedMut<'_>> { if x == std::any::TypeId::of::<dyn $crate::wrapper::Wrapper>() { return Some($crate::wrapper::StandardUnwrappedMut::Wrapper(self)); }  (x==std::any::TypeId::of::<dyn $crate::result_set::ResultSet>()).then_some($crate::wrapper::StandardUnwrappedMut::ResultSet(self))  }  } };
    (@emit [$($g:tt)*] $t:ty => ResultSetMetaData) => { impl $($g)* $crate::wrapper::Wrapper for $t { fn wrapper_view(&self) -> &dyn $crate::wrapper::Wrapper { self } fn canonical_unwrap(&self, x: std::any::TypeId)->Option<$crate::wrapper::StandardUnwrapped<'_>> { (x==std::any::TypeId::of::<dyn $crate::metadata::ResultSetMetaData>() || x==std::any::TypeId::of::<Self>()).then_some($crate::wrapper::StandardUnwrapped::ResultSetMetaData(self)) } fn canonical_unwrap_mut(&mut self, x: std::any::TypeId) -> Option<$crate::wrapper::StandardUnwrappedMut<'_>> { if x == std::any::TypeId::of::<dyn $crate::wrapper::Wrapper>() { return Some($crate::wrapper::StandardUnwrappedMut::Wrapper(self)); }  (x==std::any::TypeId::of::<dyn $crate::metadata::ResultSetMetaData>() || x==std::any::TypeId::of::<Self>()).then_some($crate::wrapper::StandardUnwrappedMut::ResultSetMetaData(self))  }  } };
    (@emit [$($g:tt)*] $t:ty => ParameterMetaData) => { impl $($g)* $crate::wrapper::Wrapper for $t { fn wrapper_view(&self) -> &dyn $crate::wrapper::Wrapper { self } fn canonical_unwrap(&self, x: std::any::TypeId)->Option<$crate::wrapper::StandardUnwrapped<'_>> { (x==std::any::TypeId::of::<dyn $crate::metadata::ParameterMetaData>()).then_some($crate::wrapper::StandardUnwrapped::ParameterMetaData(self)) } fn canonical_unwrap_mut(&mut self, x: std::any::TypeId) -> Option<$crate::wrapper::StandardUnwrappedMut<'_>> { if x == std::any::TypeId::of::<dyn $crate::wrapper::Wrapper>() { return Some($crate::wrapper::StandardUnwrappedMut::Wrapper(self)); }  (x==std::any::TypeId::of::<dyn $crate::metadata::ParameterMetaData>()).then_some($crate::wrapper::StandardUnwrappedMut::ParameterMetaData(self))  }  } };
    (@emit [$($g:tt)*] $t:ty => DatabaseMetaData) => { impl $($g)* $crate::wrapper::Wrapper for $t { fn wrapper_view(&self) -> &dyn $crate::wrapper::Wrapper { self } fn canonical_unwrap(&self, x: std::any::TypeId)->Option<$crate::wrapper::StandardUnwrapped<'_>> { (x==std::any::TypeId::of::<dyn $crate::metadata::DatabaseMetaData>()).then_some($crate::wrapper::StandardUnwrapped::DatabaseMetaData(self)) } fn canonical_unwrap_mut(&mut self, x: std::any::TypeId) -> Option<$crate::wrapper::StandardUnwrappedMut<'_>> { if x == std::any::TypeId::of::<dyn $crate::wrapper::Wrapper>() { return Some($crate::wrapper::StandardUnwrappedMut::Wrapper(self)); }  (x==std::any::TypeId::of::<dyn $crate::metadata::DatabaseMetaData>()).then_some($crate::wrapper::StandardUnwrappedMut::DatabaseMetaData(self))  }  } };
    (@emit [$($g:tt)*] $t:ty => DataSource) => { impl $($g)* $crate::wrapper::Wrapper for $t { fn wrapper_view(&self) -> &dyn $crate::wrapper::Wrapper { self } fn canonical_unwrap(&self, x: std::any::TypeId)->Option<$crate::wrapper::StandardUnwrapped<'_>> { if x==std::any::TypeId::of::<dyn $crate::data_source::DataSource>() {Some($crate::wrapper::StandardUnwrapped::DataSource(self))} else if x==std::any::TypeId::of::<dyn $crate::data_source::CommonDataSource>() {Some($crate::wrapper::StandardUnwrapped::CommonDataSource(self))} else {None} } fn canonical_unwrap_mut(&mut self, x: std::any::TypeId) -> Option<$crate::wrapper::StandardUnwrappedMut<'_>> { if x == std::any::TypeId::of::<dyn $crate::wrapper::Wrapper>() { return Some($crate::wrapper::StandardUnwrappedMut::Wrapper(self)); }  if x==std::any::TypeId::of::<dyn $crate::data_source::DataSource>() {Some($crate::wrapper::StandardUnwrappedMut::DataSource(self))} else if x==std::any::TypeId::of::<dyn $crate::data_source::CommonDataSource>() {Some($crate::wrapper::StandardUnwrappedMut::CommonDataSource(self))} else {None}  }  } };
    (@emit [$($g:tt)*] $t:ty => CallableStatement) => { impl $($g)* $crate::wrapper::Wrapper for $t { fn wrapper_view(&self) -> &dyn $crate::wrapper::Wrapper { self } fn canonical_unwrap(&self,x:std::any::TypeId)->Option<$crate::wrapper::StandardUnwrapped<'_>> { if x==std::any::TypeId::of::<dyn $crate::statement::CallableStatement>() {Some($crate::wrapper::StandardUnwrapped::CallableStatement(self))} else if x==std::any::TypeId::of::<dyn $crate::statement::PreparedStatement>() {Some($crate::wrapper::StandardUnwrapped::PreparedStatement(self))} else if x==std::any::TypeId::of::<dyn $crate::statement::Statement>() {Some($crate::wrapper::StandardUnwrapped::Statement(self))} else {None} } fn canonical_unwrap_mut(&mut self, x: std::any::TypeId) -> Option<$crate::wrapper::StandardUnwrappedMut<'_>> { if x == std::any::TypeId::of::<dyn $crate::wrapper::Wrapper>() { return Some($crate::wrapper::StandardUnwrappedMut::Wrapper(self)); }  if x==std::any::TypeId::of::<dyn $crate::statement::CallableStatement>() {Some($crate::wrapper::StandardUnwrappedMut::CallableStatement(self))} else if x==std::any::TypeId::of::<dyn $crate::statement::PreparedStatement>() {Some($crate::wrapper::StandardUnwrappedMut::PreparedStatement(self))} else if x==std::any::TypeId::of::<dyn $crate::statement::Statement>() {Some($crate::wrapper::StandardUnwrappedMut::Statement(self))} else {None}  }  } };
    (@emit [$($g:tt)*] $t:ty => CommonDataSource) => { impl $($g)* $crate::wrapper::Wrapper for $t { fn wrapper_view(&self) -> &dyn $crate::wrapper::Wrapper { self } fn canonical_unwrap(&self,x:std::any::TypeId)->Option<$crate::wrapper::StandardUnwrapped<'_>> {(x==std::any::TypeId::of::<dyn $crate::data_source::CommonDataSource>()).then_some($crate::wrapper::StandardUnwrapped::CommonDataSource(self))} fn canonical_unwrap_mut(&mut self, x: std::any::TypeId) -> Option<$crate::wrapper::StandardUnwrappedMut<'_>> { if x == std::any::TypeId::of::<dyn $crate::wrapper::Wrapper>() { return Some($crate::wrapper::StandardUnwrappedMut::Wrapper(self)); } (x==std::any::TypeId::of::<dyn $crate::data_source::CommonDataSource>()).then_some($crate::wrapper::StandardUnwrappedMut::CommonDataSource(self)) }  } };
    (@emit [$($g:tt)*] $t:ty => PooledConnection) => { impl $($g)* $crate::wrapper::Wrapper for $t { fn wrapper_view(&self) -> &dyn $crate::wrapper::Wrapper { self } fn canonical_unwrap(&self,x:std::any::TypeId)->Option<$crate::wrapper::StandardUnwrapped<'_>> {(x==std::any::TypeId::of::<dyn $crate::data_source::PooledConnection>()).then_some($crate::wrapper::StandardUnwrapped::PooledConnection(self))} fn canonical_unwrap_mut(&mut self, x: std::any::TypeId) -> Option<$crate::wrapper::StandardUnwrappedMut<'_>> { if x == std::any::TypeId::of::<dyn $crate::wrapper::Wrapper>() { return Some($crate::wrapper::StandardUnwrappedMut::Wrapper(self)); } (x==std::any::TypeId::of::<dyn $crate::data_source::PooledConnection>()).then_some($crate::wrapper::StandardUnwrappedMut::PooledConnection(self)) }  } };
    (@emit [$($g:tt)*] $t:ty => ConnectionPoolDataSource) => { impl $($g)* $crate::wrapper::Wrapper for $t { fn wrapper_view(&self) -> &dyn $crate::wrapper::Wrapper { self } fn canonical_unwrap(&self,x:std::any::TypeId)->Option<$crate::wrapper::StandardUnwrapped<'_>> {if x==std::any::TypeId::of::<dyn $crate::data_source::ConnectionPoolDataSource>() {Some($crate::wrapper::StandardUnwrapped::ConnectionPoolDataSource(self))} else if x==std::any::TypeId::of::<dyn $crate::data_source::CommonDataSource>() {Some($crate::wrapper::StandardUnwrapped::CommonDataSource(self))} else {None}} fn canonical_unwrap_mut(&mut self, x: std::any::TypeId) -> Option<$crate::wrapper::StandardUnwrappedMut<'_>> { if x == std::any::TypeId::of::<dyn $crate::wrapper::Wrapper>() { return Some($crate::wrapper::StandardUnwrappedMut::Wrapper(self)); } if x==std::any::TypeId::of::<dyn $crate::data_source::ConnectionPoolDataSource>() {Some($crate::wrapper::StandardUnwrappedMut::ConnectionPoolDataSource(self))} else if x==std::any::TypeId::of::<dyn $crate::data_source::CommonDataSource>() {Some($crate::wrapper::StandardUnwrappedMut::CommonDataSource(self))} else {None} }  } };
    (@emit [$($g:tt)*] $t:ty => XaConnection) => { impl $($g)* $crate::wrapper::Wrapper for $t { fn wrapper_view(&self) -> &dyn $crate::wrapper::Wrapper { self } fn canonical_unwrap(&self,x:std::any::TypeId)->Option<$crate::wrapper::StandardUnwrapped<'_>> {if x==std::any::TypeId::of::<dyn $crate::data_source::XaConnection>() {Some($crate::wrapper::StandardUnwrapped::XaConnection(self))} else if x==std::any::TypeId::of::<dyn $crate::data_source::PooledConnection>() {Some($crate::wrapper::StandardUnwrapped::PooledConnection(self))} else {None}} fn canonical_unwrap_mut(&mut self, x: std::any::TypeId) -> Option<$crate::wrapper::StandardUnwrappedMut<'_>> { if x == std::any::TypeId::of::<dyn $crate::wrapper::Wrapper>() { return Some($crate::wrapper::StandardUnwrappedMut::Wrapper(self)); } if x==std::any::TypeId::of::<dyn $crate::data_source::XaConnection>() {Some($crate::wrapper::StandardUnwrappedMut::XaConnection(self))} else if x==std::any::TypeId::of::<dyn $crate::data_source::PooledConnection>() {Some($crate::wrapper::StandardUnwrappedMut::PooledConnection(self))} else {None} }  } };
    (@emit [$($g:tt)*] $t:ty => XaDataSource) => { impl $($g)* $crate::wrapper::Wrapper for $t { fn wrapper_view(&self) -> &dyn $crate::wrapper::Wrapper { self } fn canonical_unwrap(&self,x:std::any::TypeId)->Option<$crate::wrapper::StandardUnwrapped<'_>> {if x==std::any::TypeId::of::<dyn $crate::data_source::XaDataSource>() {Some($crate::wrapper::StandardUnwrapped::XaDataSource(self))} else if x==std::any::TypeId::of::<dyn $crate::data_source::CommonDataSource>() {Some($crate::wrapper::StandardUnwrapped::CommonDataSource(self))} else {None}} fn canonical_unwrap_mut(&mut self, x: std::any::TypeId) -> Option<$crate::wrapper::StandardUnwrappedMut<'_>> { if x == std::any::TypeId::of::<dyn $crate::wrapper::Wrapper>() { return Some($crate::wrapper::StandardUnwrappedMut::Wrapper(self)); } if x==std::any::TypeId::of::<dyn $crate::data_source::XaDataSource>() {Some($crate::wrapper::StandardUnwrappedMut::XaDataSource(self))} else if x==std::any::TypeId::of::<dyn $crate::data_source::CommonDataSource>() {Some($crate::wrapper::StandardUnwrappedMut::CommonDataSource(self))} else {None} }  } };
    (@emit [$($g:tt)*] $t:ty => Driver) => { impl $($g)* $crate::wrapper::Wrapper for $t { fn wrapper_view(&self) -> &dyn $crate::wrapper::Wrapper { self } fn canonical_unwrap(&self,x:std::any::TypeId)->Option<$crate::wrapper::StandardUnwrapped<'_>> {(x==std::any::TypeId::of::<dyn $crate::driver::Driver>()).then_some($crate::wrapper::StandardUnwrapped::Driver(self))} fn canonical_unwrap_mut(&mut self, x: std::any::TypeId) -> Option<$crate::wrapper::StandardUnwrappedMut<'_>> { if x == std::any::TypeId::of::<dyn $crate::wrapper::Wrapper>() { return Some($crate::wrapper::StandardUnwrappedMut::Wrapper(self)); } (x==std::any::TypeId::of::<dyn $crate::driver::Driver>()).then_some($crate::wrapper::StandardUnwrappedMut::Driver(self)) }  } };
    (@emit [$($g:tt)*] $t:ty => ConnectionFactory) => { impl $($g)* $crate::wrapper::Wrapper for $t { fn wrapper_view(&self) -> &dyn $crate::wrapper::Wrapper { self } fn canonical_unwrap(&self,x:std::any::TypeId)->Option<$crate::wrapper::StandardUnwrapped<'_>> {(x==std::any::TypeId::of::<dyn $crate::driver::ConnectionFactory>()).then_some($crate::wrapper::StandardUnwrapped::ConnectionFactory(self))} fn canonical_unwrap_mut(&mut self, x: std::any::TypeId) -> Option<$crate::wrapper::StandardUnwrappedMut<'_>> { if x == std::any::TypeId::of::<dyn $crate::wrapper::Wrapper>() { return Some($crate::wrapper::StandardUnwrappedMut::Wrapper(self)); } (x==std::any::TypeId::of::<dyn $crate::driver::ConnectionFactory>()).then_some($crate::wrapper::StandardUnwrappedMut::ConnectionFactory(self)) }  } };
    (@emit [$($g:tt)*] $t:ty => Wrapper) => { impl $($g)* $crate::wrapper::Wrapper for $t { fn wrapper_view(&self) -> &dyn $crate::wrapper::Wrapper { self } fn canonical_unwrap(&self,x:std::any::TypeId)->Option<$crate::wrapper::StandardUnwrapped<'_>> {(x==std::any::TypeId::of::<dyn $crate::wrapper::Wrapper>()).then_some($crate::wrapper::StandardUnwrapped::Wrapper(self))} fn canonical_unwrap_mut(&mut self, x: std::any::TypeId) -> Option<$crate::wrapper::StandardUnwrappedMut<'_>> { (x==std::any::TypeId::of::<dyn $crate::wrapper::Wrapper>()).then_some($crate::wrapper::StandardUnwrappedMut::Wrapper(self)) }  } };
}

// 外部 RowSet 实现者的 canonical Wrapper 宏继承闭包。
use druid_rdbc::connection::TransactionIsolation;
use druid_rdbc::error::RdbcError;
use druid_rdbc::extensions::{RowSet, RowSetListener, SharedRowSet};
use druid_rdbc::result_set::ResultSet;
use druid_rdbc::statement::{ParameterIndex, PreparedInputParameter};
use druid_rdbc::types::RdbcTypeMap;
use druid_rdbc::wrapper::{StandardUnwrapped, StandardUnwrappedMut, Wrapper};
use std::any::TypeId;
use std::sync::{Arc, Mutex};
struct ExternalRowSet { inner: SharedRowSet }
impl_standard_wrapper_candidate!(ExternalRowSet => RowSet);
#[async_trait::async_trait]
impl ResultSet for ExternalRowSet {
 async fn next(&mut self)->Result<bool,RdbcError> { self.inner.next().await }
}
#[async_trait::async_trait]
impl RowSet for ExternalRowSet {
fn set_parameter(
        &mut self,
        index: ParameterIndex,
        parameter: PreparedInputParameter,
    ) -> Result<(), RdbcError> { RowSet::set_parameter(&mut self.inner, index, parameter) }
fn set_named_parameter(
        &mut self,
        name: Option<&str>,
        parameter: PreparedInputParameter,
    ) -> Result<(), RdbcError> { RowSet::set_named_parameter(&mut self.inner, name, parameter) }
fn clear_parameters(&mut self) -> Result<(), RdbcError> { RowSet::clear_parameters(&mut self.inner) }
async fn execute(&mut self) -> Result<(), RdbcError> { RowSet::execute(&mut self.inner).await }
fn add_row_set_listener(&mut self, listener: Arc<dyn RowSetListener>)  { RowSet::add_row_set_listener(&mut self.inner, listener) }
fn remove_row_set_listener(&mut self, listener: &Arc<dyn RowSetListener>)  { RowSet::remove_row_set_listener(&mut self.inner, listener) }
fn url(&self) -> Option<String> { RowSet::url(&self.inner) }
fn set_url(&mut self, url: Option<&str>) -> Result<(), RdbcError> { RowSet::set_url(&mut self.inner, url) }
fn data_source_name(&self) -> Option<String> { RowSet::data_source_name(&self.inner) }
fn set_data_source_name(&mut self, name: Option<&str>) -> Result<(), RdbcError> { RowSet::set_data_source_name(&mut self.inner, name) }
fn username(&self) -> Option<String> { RowSet::username(&self.inner) }
fn set_username(&mut self, name: Option<&str>) -> Result<(), RdbcError> { RowSet::set_username(&mut self.inner, name) }
fn password(&self) -> Option<String> { RowSet::password(&self.inner) }
fn set_password(&mut self, password: Option<&str>) -> Result<(), RdbcError> { RowSet::set_password(&mut self.inner, password) }
fn transaction_isolation(&self) -> TransactionIsolation { RowSet::transaction_isolation(&self.inner) }
fn set_transaction_isolation(&mut self, level: i32) -> Result<(), RdbcError> { RowSet::set_transaction_isolation(&mut self.inner, level) }
fn type_map(&self) -> Arc<Mutex<RdbcTypeMap>> { RowSet::type_map(&self.inner) }
fn set_type_map(&mut self, map: Arc<Mutex<RdbcTypeMap>>) -> Result<(), RdbcError> { RowSet::set_type_map(&mut self.inner, map) }
fn command(&self) -> Option<String> { RowSet::command(&self.inner) }
fn set_command(&mut self, command: Option<&str>) -> Result<(), RdbcError> { RowSet::set_command(&mut self.inner, command) }
fn is_read_only(&self) -> bool { RowSet::is_read_only(&self.inner) }
fn set_read_only(&mut self, value: bool) -> Result<(), RdbcError> { RowSet::set_read_only(&mut self.inner, value) }
fn max_field_size(&self) -> i32 { RowSet::max_field_size(&self.inner) }
fn set_max_field_size(&mut self, max: i32) -> Result<(), RdbcError> { RowSet::set_max_field_size(&mut self.inner, max) }
fn max_rows(&self) -> i32 { RowSet::max_rows(&self.inner) }
fn set_max_rows(&mut self, max: i32) -> Result<(), RdbcError> { RowSet::set_max_rows(&mut self.inner, max) }
fn escape_processing(&self) -> bool { RowSet::escape_processing(&self.inner) }
fn set_escape_processing(&mut self, enable: bool) -> Result<(), RdbcError> { RowSet::set_escape_processing(&mut self.inner, enable) }
fn query_timeout(&self) -> i32 { RowSet::query_timeout(&self.inner) }
fn set_query_timeout(&mut self, seconds: i32) -> Result<(), RdbcError> { RowSet::set_query_timeout(&mut self.inner, seconds) }
fn set_type(&mut self, type_code: i32) -> Result<(), RdbcError> { RowSet::set_type(&mut self.inner, type_code) }
fn set_concurrency(&mut self, concurrency: i32) -> Result<(), RdbcError> { RowSet::set_concurrency(&mut self.inner, concurrency) }
}
#[test]
fn external_row_set_macro_exposes_same_leaf_parent_and_mutable_object() {
 let mut source=ExternalRowSet { inner: SharedRowSet::new() };
 for target in [TypeId::of::<dyn RowSet>(),TypeId::of::<dyn ResultSet>(),TypeId::of::<ExternalRowSet>(),TypeId::of::<dyn Wrapper>()] {
  assert!(source.is_wrapper_for(Some(target)).unwrap());
 }
 let StandardUnwrapped::RowSet(leaf)=source.unwrap(Some(TypeId::of::<dyn RowSet>())).unwrap() else { panic!("RowSet leaf") };
 assert!(std::ptr::addr_eq(leaf,&source as &dyn RowSet));
 let StandardUnwrapped::ResultSet(parent)=source.unwrap(Some(TypeId::of::<dyn ResultSet>())).unwrap() else { panic!("ResultSet parent") };
 assert!(std::ptr::addr_eq(parent,&source as &dyn ResultSet));
 let StandardUnwrappedMut::RowSet(leaf)=source.unwrap_mut(Some(TypeId::of::<ExternalRowSet>())).unwrap() else { panic!("mutable leaf") };
 leaf.set_command(Some("external identity")).unwrap();
 assert_eq!(source.inner.command(),Some("external identity".into()));
 assert!(source.unwrap(None).is_err());
 assert!(source.unwrap_mut(None).is_err());
}

struct ExternalGenericRowSet<T: Send + 'static, const N: usize> { inner: SharedRowSet, marker: std::marker::PhantomData<T> }
impl_standard_wrapper_candidate!(generics [T, const N: usize] for ExternalGenericRowSet<T,N> where [T: Send + 'static] => RowSet);
#[async_trait::async_trait]
impl<T: Send + 'static, const N:usize> ResultSet for ExternalGenericRowSet<T,N> {
 async fn next(&mut self)->Result<bool,RdbcError> { self.inner.next().await }
}
#[async_trait::async_trait]
impl<T:Send+'static,const N:usize> RowSet for ExternalGenericRowSet<T,N> {

fn set_parameter(
        &mut self,
        index: ParameterIndex,
        parameter: PreparedInputParameter,
    ) -> Result<(), RdbcError> { RowSet::set_parameter(&mut self.inner, index, parameter) }
fn set_named_parameter(
        &mut self,
        name: Option<&str>,
        parameter: PreparedInputParameter,
    ) -> Result<(), RdbcError> { RowSet::set_named_parameter(&mut self.inner, name, parameter) }
fn clear_parameters(&mut self) -> Result<(), RdbcError> { RowSet::clear_parameters(&mut self.inner) }
async fn execute(&mut self) -> Result<(), RdbcError> { RowSet::execute(&mut self.inner).await }
fn add_row_set_listener(&mut self, listener: Arc<dyn RowSetListener>)  { RowSet::add_row_set_listener(&mut self.inner, listener) }
fn remove_row_set_listener(&mut self, listener: &Arc<dyn RowSetListener>)  { RowSet::remove_row_set_listener(&mut self.inner, listener) }
fn url(&self) -> Option<String> { RowSet::url(&self.inner) }
fn set_url(&mut self, url: Option<&str>) -> Result<(), RdbcError> { RowSet::set_url(&mut self.inner, url) }
fn data_source_name(&self) -> Option<String> { RowSet::data_source_name(&self.inner) }
fn set_data_source_name(&mut self, name: Option<&str>) -> Result<(), RdbcError> { RowSet::set_data_source_name(&mut self.inner, name) }
fn username(&self) -> Option<String> { RowSet::username(&self.inner) }
fn set_username(&mut self, name: Option<&str>) -> Result<(), RdbcError> { RowSet::set_username(&mut self.inner, name) }
fn password(&self) -> Option<String> { RowSet::password(&self.inner) }
fn set_password(&mut self, password: Option<&str>) -> Result<(), RdbcError> { RowSet::set_password(&mut self.inner, password) }
fn transaction_isolation(&self) -> TransactionIsolation { RowSet::transaction_isolation(&self.inner) }
fn set_transaction_isolation(&mut self, level: i32) -> Result<(), RdbcError> { RowSet::set_transaction_isolation(&mut self.inner, level) }
fn type_map(&self) -> Arc<Mutex<RdbcTypeMap>> { RowSet::type_map(&self.inner) }
fn set_type_map(&mut self, map: Arc<Mutex<RdbcTypeMap>>) -> Result<(), RdbcError> { RowSet::set_type_map(&mut self.inner, map) }
fn command(&self) -> Option<String> { RowSet::command(&self.inner) }
fn set_command(&mut self, command: Option<&str>) -> Result<(), RdbcError> { RowSet::set_command(&mut self.inner, command) }
fn is_read_only(&self) -> bool { RowSet::is_read_only(&self.inner) }
fn set_read_only(&mut self, value: bool) -> Result<(), RdbcError> { RowSet::set_read_only(&mut self.inner, value) }
fn max_field_size(&self) -> i32 { RowSet::max_field_size(&self.inner) }
fn set_max_field_size(&mut self, max: i32) -> Result<(), RdbcError> { RowSet::set_max_field_size(&mut self.inner, max) }
fn max_rows(&self) -> i32 { RowSet::max_rows(&self.inner) }
fn set_max_rows(&mut self, max: i32) -> Result<(), RdbcError> { RowSet::set_max_rows(&mut self.inner, max) }
fn escape_processing(&self) -> bool { RowSet::escape_processing(&self.inner) }
fn set_escape_processing(&mut self, enable: bool) -> Result<(), RdbcError> { RowSet::set_escape_processing(&mut self.inner, enable) }
fn query_timeout(&self) -> i32 { RowSet::query_timeout(&self.inner) }
fn set_query_timeout(&mut self, seconds: i32) -> Result<(), RdbcError> { RowSet::set_query_timeout(&mut self.inner, seconds) }
fn set_type(&mut self, type_code: i32) -> Result<(), RdbcError> { RowSet::set_type(&mut self.inner, type_code) }
fn set_concurrency(&mut self, concurrency: i32) -> Result<(), RdbcError> { RowSet::set_concurrency(&mut self.inner, concurrency) }
}
#[test]
fn external_generic_row_set_macro_retains_where_const_and_identity() {
 let mut source=ExternalGenericRowSet::<String,7> { inner:SharedRowSet::new(),marker:std::marker::PhantomData };
 for target in [TypeId::of::<dyn RowSet>(),TypeId::of::<dyn ResultSet>(),TypeId::of::<ExternalGenericRowSet<String,7>>(),TypeId::of::<dyn Wrapper>()] {
  assert!(source.is_wrapper_for(Some(target)).unwrap());
 }
 let StandardUnwrapped::RowSet(leaf)=source.unwrap(Some(TypeId::of::<dyn RowSet>())).unwrap() else { panic!("generic leaf") };
 assert!(std::ptr::addr_eq(leaf,&source as &dyn RowSet));
 let StandardUnwrapped::ResultSet(parent)=source.unwrap(Some(TypeId::of::<dyn ResultSet>())).unwrap() else { panic!("generic parent") };
 assert!(std::ptr::addr_eq(parent,&source as &dyn ResultSet));
 let StandardUnwrappedMut::RowSet(leaf)=source.unwrap_mut(Some(TypeId::of::<ExternalGenericRowSet<String,7>>())).unwrap() else { panic!("mutable generic leaf") };
 leaf.set_command(Some("generic identity")).unwrap();assert_eq!(source.inner.command(),Some("generic identity".into()));
 let StandardUnwrappedMut::ResultSet(parent)=source.unwrap_mut(Some(TypeId::of::<dyn ResultSet>())).unwrap() else { panic!("mutable parent") };
 assert!(std::ptr::addr_eq(parent,&source as &dyn ResultSet));
 assert!(!source.is_wrapper_for(Some(TypeId::of::<dyn druid_rdbc::statement::PreparedStatement>())).unwrap());
}
