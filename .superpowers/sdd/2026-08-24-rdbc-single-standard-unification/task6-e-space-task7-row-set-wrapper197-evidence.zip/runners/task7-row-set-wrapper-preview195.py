from pathlib import Path
import subprocess,os,json,hashlib,time
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');d=b/'task7-row-set-wrapper-preview195';d.mkdir(exist_ok=False)
original=(b/'task7-row-set-wrapper190/external-wrapper-contract.rs').read_text();methods=original.split('impl RowSet for ExternalRowSet {',1)[1].split('\n}\n#[test]',1)[0]
generic='''
struct ExternalGenericRowSet<T: Send + 'static, const N: usize> { inner: SharedRowSet, marker: std::marker::PhantomData<T> }
druid_rdbc::impl_standard_wrapper!(generics [T, const N: usize] for ExternalGenericRowSet<T,N> where [T: Send + 'static] => RowSet);
#[async_trait::async_trait]
impl<T: Send + 'static, const N:usize> ResultSet for ExternalGenericRowSet<T,N> {
 async fn next(&mut self)->Result<bool,RdbcError> { self.inner.next().await }
}
#[async_trait::async_trait]
impl<T:Send+'static,const N:usize> RowSet for ExternalGenericRowSet<T,N> {
'''+methods+'''
}
#[test]
fn external_generic_row_set_macro_retains_where_const_and_identity() {
 let mut source=ExternalGenericRowSet::<String,7> { inner:SharedRowSet::new(),marker:std::marker::PhantomData };
 for target in [TypeId::of::<dyn RowSet>(),TypeId::of::<dyn ResultSet>(),TypeId::of::<ExternalGenericRowSet<String,7>>(),TypeId::of::<dyn Wrapper>()] {
  assert!(source.is_wrapper_for(Some(target)).unwrap());
 }
 let StandardUnwrapped::RowSet(leaf)=source.unwrap(Some(TypeId::of::<dyn RowSet>())).unwrap() else { panic!("generic leaf") };
 assert!(std::ptr::addr_eq(leaf,&source as &dyn RowSet));
 let StandardUnwrapped::ResultSet(parent)=source.unwrap(Some(TypeId::of::<dyn ResultSet>())).unwrap() else { panic!("generic parent") };
 assert!(std::ptr::addr_eq(parent,&source as &dyn ResultSet));
 let StandardUnwrappedMut::RowSet(leaf)=source.unwrap_mut(Some(TypeId::of::<ExternalGenericRowSet<String,7>>())).unwrap() else { panic!("mutable generic leaf") };
 leaf.set_command(Some("generic identity")).unwrap();assert_eq!(source.inner.command(),Some("generic identity".into()));
 let StandardUnwrappedMut::ResultSet(parent)=source.unwrap_mut(Some(TypeId::of::<dyn ResultSet>())).unwrap() else { panic!("mutable parent") };
 assert!(std::ptr::addr_eq(parent,&source as &dyn ResultSet));
 assert!(!source.is_wrapper_for(Some(TypeId::of::<dyn druid_rdbc::statement::PreparedStatement>())).unwrap());
}
'''
canonical=original+generic;(d/'external-wrapper-contract.rs').write_text(canonical,encoding='utf-8')
patch=(b/'task7-row-set-wrapper193/wrapper-with-row-set.rs').read_text();macro='#[macro_export]\n'+patch[patch.index('macro_rules! impl_standard_wrapper {'):];macro=macro.replace('impl_standard_wrapper','impl_standard_wrapper_candidate')
source=d/'candidate-consumer.rs';source.write_text('pub use druid_rdbc::{extensions,result_set,wrapper};\n'+macro+'\n'+canonical.replace('//!','//',1).replace('druid_rdbc::impl_standard_wrapper!','impl_standard_wrapper_candidate!'),encoding='utf-8')
deps=Path('F:/codex_build_cache/druid_rust/task7_row_set177_target/debug/deps');rlib=list(deps.glob('libdruid_rdbc*.rlib'));proc=list(deps.glob('*async_trait*.dll'));assert len(rlib)==len(proc)==1;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();inputs={str(p):sha(p) for p in [source,rlib[0],proc[0],b/'task7-row-set-wrapper193/wrapper-with-row-set.rs']}
tool=Path('C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin');env=os.environ.copy();env['PATH']=str(tool)+os.pathsep+env['PATH'];env['TMP']=env['TEMP']='F:/codex_tmp/task7_standard_cargo13';exe=d/'candidate-consumer.exe';cmd=[str(tool/'rustc.exe'),'--edition=2024','--test','--crate-name','row_set_macro_candidate',str(source),'-L','dependency='+str(deps),'--extern','druid_rdbc='+str(rlib[0]),'--extern','async_trait='+str(proc[0]),'-o',str(exe)]
p=subprocess.run(cmd,env=env,capture_output=True);(d/'compile.log').write_bytes(p.stdout+p.stderr);s=dict(preview_only=True,production_applied=False,canonical_macro_rebuilt=False,compile_exit_code=p.returncode,command=cmd,frozen_inputs=inputs)
if p.returncode==0:
 p=subprocess.run([str(exe)],env=env,capture_output=True);(d/'test.log').write_bytes(p.stdout+p.stderr);s['test_exit_code']=p.returncode;print(p.stdout.decode(errors='replace'))
else:print((p.stdout+p.stderr).decode(errors='replace')[:4000])
s['changed_inputs']=[n for n,h in inputs.items() if sha(Path(n))!=h];(d/'summary.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in s.items() if k!='frozen_inputs'}))
