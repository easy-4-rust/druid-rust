import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess

b = Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
parent = Path('F:/codex_build_cache/d111')
w = Path('F:/codex_build_cache/d115')
d = b / 'task7-sql-mapping-red115'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
frozen = json.loads((b / 'task7-borrow-clock111/frozen-inputs.json').read_text(encoding='utf-8'))
assert len(frozen) == 1226 and all(sha(parent / rel) == h for rel, h in frozen.items())
w.mkdir(exist_ok=False)
d.mkdir(exist_ok=False)
acquired = json.loads((b / 'task8-java-jdbc42-source-acquisition1.summary.json').read_text(encoding='utf-8'))
records = {v['fqcn']: v for v in acquired['sources']}
mapping = {'SQLData': 3, 'SQLInput': 28, 'SQLOutput': 28}
contracts = []
for name, expected in mapping.items():
    record = records['java.sql.' + name]
    src = Path(record['local_path'])
    assert sha(src) == record['sha256']
    text = src.read_text(encoding='utf-8')
    methods = []
    for match in re.finditer(r'(?m)^\s*((?:default\s+)?(?:<T>\s+)?[\w.<>\[\]]+\s+(\w+)\s*\([^;{}]*\)\s*throws SQLException)\s*([;{])', text):
        signature = ' '.join(match.group(1).split())
        methods.append(dict(signature=signature, method=match.group(2),
                            line=text[:match.start()].count('\n') + 1,
                            default=match.group(3) == '{'))
    assert len(methods) == expected, (name, len(methods))
    assert sum(v['default'] for v in methods) == (0 if name == 'SQLData' else 1)
    shutil.copyfile(src, d / (name + '.java'))
    contracts.append(dict(fqcn=record['fqcn'], source_sha256=sha(src), methods=methods))
(d / 'java-method-contracts.json').write_text(json.dumps(dict(oracle_commit=acquired['oracle_commit'],
    method_count=59, classes=contracts), indent=2) + '\n', encoding='utf-8')
for rel, h in frozen.items():
    target = w / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(parent / rel, target)
    assert sha(target) == h
rel = 'crates/druid-rdbc/tests/standard_sql_mapping_contract_test.rs'
assert not (w / rel).exists()
shutil.copyfile(b / 'task7-sql-mapping-contract115.rs', w / rel)
tool = 'C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin'
env = os.environ.copy()
env.update(RUSTC=tool + '/rustc.exe', RUSTDOC=tool + '/rustdoc.exe',
    RUSTUP_TOOLCHAIN='1.97.1-x86_64-pc-windows-msvc', RUSTUP_AUTO_INSTALL='0',
    PATH=tool + os.pathsep + env['PATH'], CARGO_BUILD_JOBS='1',
    CARGO_TARGET_DIR='F:/codex_build_cache/dr103_target',
    TMP='F:/codex_tmp/task7_standard_cargo13', TEMP='F:/codex_tmp/task7_standard_cargo13')
format_command = [tool + '/rustfmt.exe', '--edition', '2021', str(w / rel)]
with (d / 'format.log').open('xb') as out:
    result = subprocess.run(format_command, env=env, stdout=out, stderr=subprocess.STDOUT)
assert result.returncode == 0
assert all(sha(w / name) == h for name, h in frozen.items())
frozen[rel] = sha(w / rel)
(d / 'frozen-inputs.json').write_text(json.dumps(frozen, indent=2) + '\n', encoding='utf-8')
s = dict(terminal=False, production_applied=False, workspace=str(w), frozen_input_count=len(frozen),
    source_method_count=59, tests=6, pid=os.getpid(), stage='TDD_RED', production_source_changes=[])
def save():
    (d / 'summary.json').write_text(json.dumps(s, indent=2) + '\n', encoding='utf-8')
save()
command = [tool + '/cargo.exe', 'test', '-p', 'druid-rdbc', '--test',
    'standard_sql_mapping_contract_test', '--all-features', '--locked', '--offline', '-j1']
log = d / 'original-red.log'
with log.open('xb') as out:
    result = subprocess.run(command, cwd=w, env=env, stdout=out, stderr=subprocess.STDOUT,
        creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
text = log.read_text(encoding='utf-8')
s.update(terminal=True, exit_code=result.returncode, command=command, log=str(log), sha256=sha(log),
    diagnostics=re.findall(r'error\[(E\d+)\]', text),
    changed_inputs=[name for name, h in frozen.items() if sha(w / name) != h])
s['expected_missing_surface_red'] = result.returncode == 101 and 'E0432' in s['diagnostics'] and all(
    name in text for name in ['BufferedSqlInput', 'BufferedSqlOutput', 'SqlData', 'SqlInput', 'SqlOutput'])
save()
print(json.dumps(s, indent=2), flush=True)
assert not s['changed_inputs']
assert s['expected_missing_surface_red'], 'inspect unexpected compiler result before implementing'
