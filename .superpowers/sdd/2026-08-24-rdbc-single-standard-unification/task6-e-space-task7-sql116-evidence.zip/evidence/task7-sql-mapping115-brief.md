# SQLData / SQLInput / SQLOutput 执行简报

事实源：目标仓库 docs/superpowers/specs/2026-08-24-rdbc-single-standard-trait-tree.md（ADR-RDBC-006），执行现有 P04 Task7/Task8。此简报只记录实现交接，不创建新规格。

当前基线：候选 d111 的完整 1226 输入，父完整 zip109 加 clock114 的单源码 delta；原目标仓库生产源码尚未应用。d111 正在原113验证，禁止修改。

固定来源：OpenJDK 8u 7373384725418fa645fb4508ec05a869bc7fc3e7，来源文件必须与既有 source-acquisition1 收据 SHA 一致。SQLData 三方法、SQLInput 二十八方法、SQLOutput 二十八方法；包括两个 JDBC4.2 default 方法，不得仅补三个空 trait 让入口探针通过。

测试先行：standard_sql_mapping_contract_test.rs 六项合同在独立 d115 编译运行。初始预期 RED 为缺少五个公开对象；编译期 RED 不能冒充六项行为断言已经运行。只有看到实际退出及诊断，才开始生产实现；完整保留原 RED 日志。

Ruling: 标准 SqlData/Input/Output 位于 druid-rdbc::resource；缓冲 reader/writer 具体实现位于 extensions，各对象独立文件。Java SQLData 调用 SQLInput/SQLOutput；Rust 使用标准 trait object，不依赖 Druid 产品类型。所有权敏感操作可异步，需验证 async trait object 的 Send 约束，并对照现有标准签名约定。

Ruling: readObject(Class) 与 writeObject(Object, SQLType) 的标准默认实现必须保留 SQLFeatureNotSupportedException；不能委托普通重载悄悄消费或追加属性。实现若另行支持 typed 转换，必须独立满足 Java 转换合同，不能复用此默认实现测试伪称支持。

Ruling: SQL NULL 对原始类型读为零/false，对引用读为 None，对普通 Object 读为 RdbcObject::Scalar(Value::Null)，wasNull 返回最近一次属性读取状态。每次 reader 消费一个声明顺序属性；耗尽/转换错误必须返回错误，不回退为 NULL。

Ruling: 字符流保留 UTF-16 code units 与原游标，ASCII/Binary Stream 保留原引用与当前位置；不得用 Vec<u8>/String 的急切复制替代。输入和输出的内部属性表示必须能无损承载这些流与标准资源，不能为了简化而修改已接受 RdbcObject 为第二种资源合同。

尚需补充的行为证据（六项初始测试不涵盖全部语义）：

- SQLData.getSQLTypeName 的错误传播；readSQL/writeSQL 的中途 typed cause 原样传播。
- writeObject(SQLData) 非 null 时调用自定义 writeSQL，并正确保留结构类型边界及属性顺序；null 不调用自定义对象。
- 全部资源 Ref/Blob/Clob/NClob/Array/Struct/SQLXML/RowId/URL 的非 null 身份与生命周期，SQLXML 未关闭写入句柄的拒绝行为。
- readObject 的默认/自定义 type map 路径；不能以已物化对象的简单返回冒充 driver custom mapping。
- 真实标量与时间/decimal 精度、数值范围及转换失败；typed target 默认与覆盖实现的独立行为。
- Druid 旧 SqlData/Input/Output 的真实迁移与兼容性判断，最终不能留下独立标准树。

验证顺序：实际 RED → 完整生产实现与扩展合同 → 原六项及新增合同 GREEN → RDBC 完整 all-features → 严格 Clippy/fmt → 原68公开探针 → 最新完整 C1/C2/workspace/API/SemVer/真实数据库与差分。不得改变 oracle、inventory、探针分母或原测试断言以获得通过。

当前无生产实现、无 GREEN、无 Task7/Task8 完成声明，18 顶层任务仍开放。
