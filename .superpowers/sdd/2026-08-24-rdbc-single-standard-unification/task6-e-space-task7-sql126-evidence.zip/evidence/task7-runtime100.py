import hashlib,json,os,re,subprocess
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d91');e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust')
d=b/'task7-runtime100';d.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
f=json.loads((b/'task7-finalize99/frozen-inputs.json').read_text(encoding='utf-8'))
assert len(f)==1221 and all(sha(w/r)==h for r,h in f.items())
(d/'frozen-inputs.json').write_text(json.dumps(f,indent=2)+'\n',encoding='utf-8')
tool='C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin'
env=os.environ.copy();env.update(RUSTC=tool+'/rustc.exe',RUSTDOC=tool+'/rustdoc.exe',RUSTUP_TOOLCHAIN='1.97.1-x86_64-pc-windows-msvc',RUSTUP_AUTO_INSTALL='0',PATH=tool+os.pathsep+env['PATH'],CARGO_TARGET_DIR='F:/codex_build_cache/druid_rust/task7_standard_cargo13_1971',CARGO_BUILD_JOBS='1',TMP='F:/codex_tmp/task7_standard_cargo13',TEMP='F:/codex_tmp/task7_standard_cargo13',DRUID_RDBC_EXTERNAL_TARGET_ROOT='F:/codex_build_cache/dr100_ext',GIT_DIR=str(e/'.git'),GIT_WORK_TREE=str(w),PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1')
s=dict(terminal=False,production_applied=False,workspace=str(w),frozen_input_count=len(f),pid=os.getpid(),commands=[])
save=lambda:(d/'summary.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
save()
common=['--all-features','--locked','--offline','-j1']
commands=[('pure-shared-contract',[tool+'/cargo.exe','test','-p','druid-rdbc','--test','task7_shared_result_set_contract_test']+common),('pure-shared-strict',[tool+'/cargo.exe','clippy','-p','druid-rdbc','--test','task7_shared_result_set_contract_test']+common+['--','-D','warnings']),('c1-complete-runtime',['C:/Espressif/tools/python/python.exe','-X','utf8','scripts/verify_task6_method_parity.py','--repository-root',str(w)])]
for name,cmd in commands:
    assert all(sha(w/r)==h for r,h in f.items())
    log=d/(name+'.log');s['running_command']=name;save()
    with log.open('xb') as out:r=subprocess.run(cmd,cwd=w,env=env,stdout=out,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
    blocks=re.findall(r'^test result: .*?(\d+) passed; (\d+) failed; (\d+) ignored;',log.read_text(encoding='utf-8'),re.M)
    changed=[rel for rel,h in f.items() if sha(w/rel)!=h]
    counts=dict(passed=sum(int(v[0]) for v in blocks),failed=sum(int(v[1]) for v in blocks),ignored=sum(int(v[2]) for v in blocks),blocks=len(blocks))
    s['commands'].append(dict(name=name,command=cmd,exit_code=r.returncode,log=str(log),sha256=sha(log),results=counts,changed_inputs=changed));save();print(json.dumps(s['commands'][-1]),flush=True)
    if r.returncode or changed:break
s.update(terminal=True,exit_code=r.returncode,changed_inputs=[rel for rel,h in f.items() if sha(w/rel)!=h]);s.pop('running_command',None);save()
print(json.dumps(dict(terminal=True,exit_code=r.returncode)),flush=True)
