
#[tokio::test]
async fn output_custom_sql_data_is_one_structured_attribute_with_its_type_name() {
    let mut data = MappedRecord { type_name: "app.record".into(), number: 41, label: None };
    let mut output = BufferedSqlOutput::new();
    output.write_object(Some(&mut data)).await.unwrap();
    output.write_int(99).await.unwrap();
    let mut input = output.into_input();
    let RdbcObject::Struct(value) = input.read_object().await.unwrap() else { panic!("custom SQLData must retain one UDT boundary") };
    assert_eq!(value.sql_type_name().await.unwrap(), "app.record");
    let mut attributes = BufferedSqlInput::new(value.attributes().await.unwrap());
    assert_eq!(attributes.read_int().await.unwrap(), 41);
    assert!(attributes.read_string().await.unwrap().is_none());
    assert!(attributes.was_null().unwrap());
    assert!(attributes.read_object().await.is_err());
    assert_eq!(input.read_int().await.unwrap(), 99);
    assert!(input.read_object().await.is_err());
}

struct FailingMappedData { fail_name: bool }
#[async_trait::async_trait]
impl SqlData for FailingMappedData {
    async fn sql_type_name(&mut self) -> Result<String, RdbcError> {
        if self.fail_name { Err(RdbcError::DriverError("original typename failure".into())) }
        else { Ok("app.failure".into()) }
    }
    async fn read_sql(&mut self, _input: &mut dyn SqlInput, _name: &str) -> Result<(), RdbcError> {
        Err(RdbcError::feature_not_supported("test-read"))
    }
    async fn write_sql(&mut self, output: &mut dyn SqlOutput) -> Result<(), RdbcError> {
        output.write_int(1).await?;
        Err(RdbcError::SqlException(Box::new(druid_rdbc::error::SqlException::new(
            73, Some("22000".into()), Some("original write failure".into())))))
    }
}
#[tokio::test]
async fn failed_custom_mapping_preserves_the_original_error_without_partial_outer_attribute() {
    for fail_name in [false, true] {
        let mut data = FailingMappedData { fail_name };
        let mut output = BufferedSqlOutput::new();
        let expected = if fail_name { RdbcError::DriverError("original typename failure".into()) }
            else { RdbcError::SqlException(Box::new(druid_rdbc::error::SqlException::new(73, Some("22000".into()), Some("original write failure".into())))) };
        assert_eq!(output.write_object(Some(&mut data)).await.unwrap_err(), expected);
        output.write_int(7).await.unwrap();
        let mut input = output.into_input();
        assert_eq!(input.read_int().await.unwrap(), 7);
        assert!(input.read_object().await.is_err());
    }
}

struct StreamMappedData(RdbcInputStream, RdbcReader);
#[async_trait::async_trait]
impl SqlData for StreamMappedData {
    async fn sql_type_name(&mut self) -> Result<String, RdbcError> { Ok("app.streams".into()) }
    async fn read_sql(&mut self, input: &mut dyn SqlInput, _name: &str) -> Result<(), RdbcError> {
        self.0 = input.read_binary_stream().await?.ok_or_else(|| RdbcError::InvalidArgument("null binary".into()))?;
        self.1 = input.read_character_stream().await?.ok_or_else(|| RdbcError::InvalidArgument("null reader".into()))?;
        Ok(())
    }
    async fn write_sql(&mut self, output: &mut dyn SqlOutput) -> Result<(), RdbcError> {
        output.write_binary_stream(Some(self.0.clone())).await?;
        output.write_character_stream(Some(self.1.clone())).await
    }
}
#[tokio::test]
async fn nested_udt_streams_preserve_identity_and_are_not_materialized() {
    let bytes = RdbcInputStream::from_bytes(vec![0,255,128]);
    let chars = RdbcReader::from_utf16(vec![0xD800,0x0061]);
    let mut data = StreamMappedData(bytes.clone(), chars.clone());
    let mut output = BufferedSqlOutput::new();
    output.write_object(Some(&mut data)).await.unwrap();
    let RdbcObject::Struct(value) = output.into_input().read_object().await.unwrap() else { panic!("missing structured attribute") };
    let mut input = BufferedSqlInput::new(value.attributes().await.unwrap());
    let read_bytes = input.read_binary_stream().await.unwrap().unwrap();
    let read_chars = input.read_character_stream().await.unwrap().unwrap();
    assert_eq!(read_bytes, bytes);
    assert_eq!(read_chars, chars);
    assert_eq!(bytes.read_to_end().unwrap(), vec![0,255,128]);
    assert_eq!(chars.read_to_end_utf16().unwrap(), vec![0xD800,0x0061]);
    assert!(read_bytes.read_to_end().unwrap().is_empty());
    assert!(read_chars.read_to_end_utf16().unwrap().is_empty());
}
