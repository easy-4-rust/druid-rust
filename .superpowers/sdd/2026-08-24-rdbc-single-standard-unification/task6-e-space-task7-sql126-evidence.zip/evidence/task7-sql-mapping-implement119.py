import hashlib,json,os,re,subprocess
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d117');d=b/'task7-sql-mapping-implement119'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
previous=json.loads((b/'task7-sql-mapping-red118/summary.json').read_text(encoding='utf-8'));assert previous['terminal'] and previous['expected_missing_surface_red']
parent=json.loads((b/'task7-sql-mapping-red118/frozen-inputs.json').read_text(encoding='utf-8'));assert all(sha(w/r)==h for r,h in parent.items());d.mkdir(exist_ok=False)
changed=[]
def write(rel,source):
    p=w/rel;assert not p.exists();p.write_text(source,encoding='utf-8',newline='');changed.append(rel)
imports='''use crate::error::{RdbcError, SqlException};
use crate::resource::{RdbcArray, RdbcBlob, RdbcClob, RdbcInputStream, RdbcNClob, RdbcReader, RdbcRef, RdbcSqlXml, RdbcStruct};
use crate::types::{RdbcObject, RdbcRowId, RdbcTargetType, RdbcUrl, SqlType, Value};
use bigdecimal::BigDecimal;
use chrono::{NaiveDate, NaiveDateTime, NaiveTime};
'''
readers=[('string','Option<String>'),('boolean','bool'),('byte','i8'),('short','i16'),('int','i32'),('long','i64'),('float','f32'),('double','f64'),('big_decimal','Option<BigDecimal>'),('bytes','Option<Vec<u8>>'),('date','Option<NaiveDate>'),('time','Option<NaiveTime>'),('timestamp','Option<NaiveDateTime>'),('character_stream','Option<RdbcReader>'),('ascii_stream','Option<RdbcInputStream>'),('binary_stream','Option<RdbcInputStream>'),('object','RdbcObject'),('ref','Option<RdbcRef>'),('blob','Option<RdbcBlob>'),('clob','Option<RdbcClob>'),('array','Option<RdbcArray>'),('url','Option<RdbcUrl>'),('n_clob','Option<RdbcNClob>'),('n_string','Option<String>'),('sql_xml','Option<RdbcSqlXml>'),('row_id','Option<RdbcRowId>')]
writers=[(name,ty) for name,ty in readers if name!='object']
writers.insert(16,('object','Option<&mut dyn SqlData>'));writers.insert(20,('struct','Option<RdbcStruct>'))
assert len(readers)==26 and len(writers)==27
java=lambda s: ''.join({'sql':'SQL','xml':'XML','url':'URL','n':'N'}.get(v,v.capitalize()) for v in s.split('_'))
input_source=imports.replace('RdbcStruct','RdbcStruct')+'\n/// 按SQL声明顺序读取UDT属性的独占标准输入合同。对应 Java: java.sql.SQLInput。\n/// 驱动初始化类型映射后交给SQLData；每次reader读取下一属性，wasNull保留最近读取的NULL状态。\n/// 读取数据库、映射或转换失败返回原错误；不支持的方法必须报告SQLFeatureNotSupportedException。\n#[async_trait::async_trait]\npub trait SqlInput: Send {\n'
for name,ty in readers:
    null='SQL NULL返回零或false，并由was_null区分。' if name in {'boolean','byte','short','int','long','float','double'} else 'SQL NULL返回None。'
    if name=='object':null='SQL NULL返回RdbcObject::Scalar(Value::Null)；驱动按默认映射和已注册type map构造自定义SQLData，并调用其readSQL。'
    if name in {'ascii_stream','binary_stream','character_stream'}:null+='保留原流身份及当前位置，不提前物化。'
    input_source+=f'    /// 读取下一{name}属性，无参数，返回属性或数据库/转换错误。{null}对应 Java: SQLInput#read{java(name)}。\n    async fn read_{name}(&mut self) -> Result<{ty}, RdbcError>;\n'
input_source+='''    /// 返回最后读取的属性是否SQL NULL，无参数；驱动访问失败返回错误。对应 Java: SQLInput#wasNull。
    fn was_null(&self) -> Result<bool, RdbcError>;
    /// 按参数target要求转换下一属性，返回对象或NULL；驱动覆盖时必须应用type map和自定义SQLData协议。
    /// 默认不消费属性并报告不支持。对应 Java: SQLInput#readObject(Class)。
    async fn read_object_as(&mut self, _target: &RdbcTargetType) -> Result<RdbcObject, RdbcError> {
        Err(RdbcError::feature_not_supported("SQLInput#readObject(Class)"))
    }
}
'''
# 每个文件仅保留实际使用的依赖；标准trait无需具体SQL异常或Value导入。
input_source=input_source.replace('use crate::error::{RdbcError, SqlException};','use crate::error::RdbcError;').replace(', RdbcStruct','').replace(', SqlType, Value','')
write('crates/druid-rdbc/src/resource/sql_input.rs',input_source)
output_source=imports.replace('use crate::error::{RdbcError, SqlException};','use crate::error::RdbcError;').replace('RdbcTargetType, ','').replace(', Value','')+'use crate::resource::SqlData;\n\n/// 按SQL声明顺序写入UDT属性的独占标准输出合同。对应 Java: java.sql.SQLOutput。\n/// 驱动调用SQLData.writeSQL，后者按字段声明顺序调用writer；NULL不得替换为空字符串或零。\n#[async_trait::async_trait]\npub trait SqlOutput: Send {\n'
for name,ty in writers:
    extra='None写入SQL NULL。' if ty.startswith('Option') else ''
    if name=='object':extra+='非NULL对象调用其writeSQL，按其SQL类型保存一个自定义类型属性边界；错误原样传播。'
    if name=='sql_xml':extra+='SQLXML的Writer/OutputStream/Result尚未关闭或XML处理失败时，驱动必须返回SQL异常。'
    if name in {'character_stream','ascii_stream','binary_stream'}:extra+='保留原流身份及当前位置，不提前读完。'
    output_source+=f'    /// 写入参数value作为下一{name}属性，返回成功或原数据库/转换错误。{extra}对应 Java: SQLOutput#write{java(name)}。\n    async fn write_{name}(&mut self, value: {ty}) -> Result<(), RdbcError>;\n'
output_source+='''    /// 将参数value转换为参数target的SQL类型并写入，返回成功或转换/数据库错误。
    /// NULL写SQL NULL；SQLData须调用writeSQL，资源须按对应SQL类型传递。默认不追加属性并报告不支持。
    /// target须可跨异步任务共享；SqlType本身不增加Sync约束。对应 Java: SQLOutput#writeObject(Object, SQLType)。
    async fn write_object_as(&mut self, _value: Option<RdbcObject>, _target: &(dyn SqlType + Sync)) -> Result<(), RdbcError> {
        Err(RdbcError::feature_not_supported("SQLOutput#writeObject(Object, SQLType)"))
    }
}
'''
write('crates/druid-rdbc/src/resource/sql_output.rs',output_source)
write('crates/druid-rdbc/src/resource/sql_data.rs','''use crate::error::RdbcError;
use crate::resource::{SqlInput, SqlOutput};

/// SQL结构类型或DISTINCT类型到应用对象的自定义映射合同。对应 Java: java.sql.SQLData。
/// 连接类型映射关联限定UDT名与实现；ResultSet.getObject读入，PreparedStatement.setObject写回。
/// 通常由驱动而非应用直接调用。字段按SQL声明顺序读取和写入，DISTINCT类型恰好一个元素。
/// 独占异步调用只要求Send，不强迫应用对象Sync；不把可变应用对象包装为不可变共享值。
#[async_trait::async_trait]
pub trait SqlData: Send {
    /// 返回read_sql接收的完全限定SQL类型名，无参数；数据库访问或不支持时返回原SQL错误。
    /// 对应 Java: SQLData#getSQLTypeName。
    async fn sql_type_name(&mut self) -> Result<String, RdbcError>;
    /// 从参数input按声明顺序逐个读取属性并填入本对象；参数type_name是驱动提供的限定SQL类型名。
    /// 驱动预先初始化input的类型映射；返回成功或原数据库/映射/不支持错误。对应 Java: SQLData#readSQL。
    async fn read_sql(&mut self, input: &mut dyn SqlInput, type_name: &str) -> Result<(), RdbcError>;
    /// 向参数output按声明顺序写入本对象的属性；返回成功或原数据库/序列化/不支持错误。
    /// DISTINCT写一个元素，结构类型写每个属性。对应 Java: SQLData#writeSQL。
    async fn write_sql(&mut self, output: &mut dyn SqlOutput) -> Result<(), RdbcError>;
}
''')
write('crates/druid-rdbc/src/extensions/sql_attribute.rs','''use crate::resource::RdbcInputStream;
use crate::types::{OpaqueObjectValue, RdbcObject, RdbcOpaqueObject};
use std::any::Any;
use std::sync::Arc;

/// SQLInput/SQLOutput内部属性，保留字节流身份而不复制流内容。对应 Java: SQLInput/SQLOutput的属性流。
#[derive(Clone, Debug)]
pub(crate) enum SqlAttribute {
    Object(RdbcObject),
    AsciiStream(RdbcInputStream),
    BinaryStream(RdbcInputStream),
}
impl SqlAttribute {
    /// 从标准对象恢复内部流标签，返回同一原始句柄。
    pub(crate) fn from_object(value: RdbcObject) -> Self {
        if let RdbcObject::Custom(object) = &value {
            if let Some(attribute) = object.downcast_ref::<Self>() { return attribute.clone(); }
        }
        Self::Object(value)
    }
    /// 返回是否为SQL NULL，不消费属性。
    pub(crate) fn is_null(&self) -> bool { matches!(self, Self::Object(value) if value.is_null()) }
    /// 转为标准Object表示，流通过原有opaque平台合同保留引用而不引入第二资源树。
    pub(crate) fn into_object(self) -> RdbcObject {
        match self { Self::Object(value) => value, stream => RdbcObject::Custom(RdbcOpaqueObject::new(Arc::new(stream))) }
    }
}
impl OpaqueObjectValue for SqlAttribute {
    fn class_name(&self) -> &str { match self { Self::Object(_) => "java.lang.Object", Self::AsciiStream(_) | Self::BinaryStream(_) => "java.io.InputStream" } }
    fn as_any(&self) -> &dyn Any { self }
}
''')
buffer_imports=imports.replace('RdbcTargetType, ','').replace('SqlType, ','')
source=buffer_imports+'''use crate::extensions::sql_attribute::SqlAttribute;
use crate::resource::SqlInput;

/// 已由驱动映射的UDT属性缓冲输入；不自行凭类名实例化应用类型。对应 Java: java.sql.SQLInput（Rust缓冲扩展）。
pub struct BufferedSqlInput { values: std::vec::IntoIter<SqlAttribute>, was_null: bool }
impl BufferedSqlInput {
    /// 使用参数values按声明顺序创建输入；保留标准对象与流身份，返回独占reader。
    pub fn new(values: Vec<RdbcObject>) -> Self { Self::from_attributes(values.into_iter().map(SqlAttribute::from_object).collect()) }
    /// 将同一标准输出的内部属性交接给reader，保持所有流标签。
    pub(crate) fn from_attributes(values: Vec<SqlAttribute>) -> Self { Self { values: values.into_iter(), was_null: false } }
    /// 取得并仅消费下一属性；耗尽返回SQL错误，不修改上次NULL状态。
    fn next_attribute(&mut self) -> Result<SqlAttribute, RdbcError> {
        let value=self.values.next().ok_or_else(|| RdbcError::SqlException(Box::new(SqlException::new(0, Some("02000".into()), Some("SQLInput has no remaining attributes".into())))))?;
        self.was_null=value.is_null(); Ok(value)
    }
    /// 返回类型转换错误，保留SQLState而不泄漏属性值。
    fn conversion_error() -> RdbcError { RdbcError::SqlException(Box::new(SqlException::new(0, Some("22005".into()), Some("SQLInput attribute has an incompatible type".into())).with_class_name("java.sql.SQLDataException"))) }
    /// 取得下一标量并保留已有typed标量的数值、时间和decimal精度。
    fn next_scalar(&mut self) -> Result<Value, RdbcError> {
        match self.next_attribute()?.into_object() {
            RdbcObject::Scalar(v)=>Ok(v), RdbcObject::String(v)|RdbcObject::NString(v)=>Ok(Value::String(v)),
            RdbcObject::Boolean(v)=>Ok(Value::Bool(v)), RdbcObject::Byte(v)=>Ok(Value::Int(i64::from(v))),
            RdbcObject::Short(v)=>Ok(Value::Int(i64::from(v))), RdbcObject::Integer(v)=>Ok(Value::Int(i64::from(v))),
            RdbcObject::Long(v)=>Ok(Value::Int(v)), RdbcObject::Float(v)=>Ok(Value::Float(f64::from(v))),
            RdbcObject::Double(v)=>Ok(Value::Float(v)), RdbcObject::Bytes(v)=>Ok(Value::Bytes(v)),
            RdbcObject::BigDecimal(v)=>Ok(Value::Decimal(v)), RdbcObject::Date(v)=>Ok(Value::Date(v)),
            RdbcObject::Time(v)=>Ok(Value::Time(v)), RdbcObject::Timestamp(v)=>Ok(Value::Timestamp(v)),
            _=>Err(Self::conversion_error())
        }
    }
}
#[async_trait::async_trait]
impl SqlInput for BufferedSqlInput {
    fn was_null(&self) -> Result<bool, RdbcError> { Ok(self.was_null) }
'''
scalar={'string':('String','String'),'big_decimal':('BigDecimal','Decimal'),'bytes':('Vec<u8>','Bytes'),'date':('NaiveDate','Date'),'time':('NaiveTime','Time'),'timestamp':('NaiveDateTime','Timestamp'),'n_string':('String','String')}
for name,(ty,variant) in scalar.items():
    source+=f'    async fn read_{name}(&mut self) -> Result<Option<{ty}>, RdbcError> {{ match self.next_scalar()? {{ Value::Null=>Ok(None), Value::{variant}(v)=>Ok(Some(v)), _=>Err(Self::conversion_error()) }} }}\n'
source+='''    async fn read_boolean(&mut self) -> Result<bool,RdbcError> { match self.next_scalar()? { Value::Null=>Ok(false), Value::Bool(v)=>Ok(v), _=>Err(Self::conversion_error()) } }
    async fn read_long(&mut self) -> Result<i64,RdbcError> { match self.next_scalar()? { Value::Null=>Ok(0), Value::Int(v)=>Ok(v), _=>Err(Self::conversion_error()) } }
    async fn read_double(&mut self) -> Result<f64,RdbcError> { match self.next_scalar()? { Value::Null=>Ok(0.0), Value::Float(v)=>Ok(v), Value::Int(v)=>Ok(v as f64), _=>Err(Self::conversion_error()) } }
    async fn read_float(&mut self) -> Result<f32,RdbcError> { Ok(self.read_double().await? as f32) }
'''
for name,ty in [('byte','i8'),('short','i16'),('int','i32')]:source+=f'    async fn read_{name}(&mut self) -> Result<{ty},RdbcError> {{ {ty}::try_from(self.read_long().await?).map_err(|_| Self::conversion_error()) }}\n'
resources={'character_stream':('RdbcReader','CharacterStream'),'ref':('RdbcRef','Ref'),'blob':('RdbcBlob','Blob'),'clob':('RdbcClob','Clob'),'array':('RdbcArray','Array'),'url':('RdbcUrl','Url'),'n_clob':('RdbcNClob','NClob'),'sql_xml':('RdbcSqlXml','SqlXml'),'row_id':('RdbcRowId','RowId')}
for name,(ty,variant) in resources.items():source+=f'    async fn read_{name}(&mut self) -> Result<Option<{ty}>,RdbcError> {{ match self.next_attribute()?.into_object() {{ RdbcObject::Scalar(Value::Null)=>Ok(None), RdbcObject::{variant}(v)=>Ok(Some(v)), _=>Err(Self::conversion_error()) }} }}\n'
for name,variant in [('ascii_stream','AsciiStream'),('binary_stream','BinaryStream')]:source+=f'    async fn read_{name}(&mut self) -> Result<Option<RdbcInputStream>,RdbcError> {{ match self.next_attribute()? {{ SqlAttribute::Object(RdbcObject::Scalar(Value::Null))=>Ok(None), SqlAttribute::{variant}(v)=>Ok(Some(v)), _=>Err(Self::conversion_error()) }} }}\n'
source+='    async fn read_object(&mut self) -> Result<RdbcObject,RdbcError> { Ok(self.next_attribute()?.into_object()) }\n}\n'
source=source.replace(', RdbcStruct','')
write('crates/druid-rdbc/src/extensions/buffered_sql_input.rs',source)
write('crates/druid-rdbc/src/extensions/buffered_sql_struct.rs','''use crate::error::RdbcError;
use crate::resource::{ResourceOperations, Struct};
use crate::types::{RdbcObject, RdbcTypeMap};

/// 已序列化SQLData的单个结构属性，保留UDT名称及原对象身份。对应 Java: java.sql.Struct（SQLData缓冲结果）。
#[derive(Debug)]
pub(crate) struct BufferedSqlStruct { pub(crate) type_name: String, pub(crate) attributes: Vec<RdbcObject> }
#[async_trait::async_trait]
impl Struct for BufferedSqlStruct {
    fn capabilities(&self) -> ResourceOperations { ResourceOperations::READ }
    async fn sql_type_name(&mut self) -> Result<String,RdbcError> { Ok(self.type_name.clone()) }
    async fn attributes(&mut self) -> Result<Vec<RdbcObject>,RdbcError> { Ok(self.attributes.clone()) }
    async fn attributes_with_type_map(&mut self, map: &RdbcTypeMap) -> Result<Vec<RdbcObject>,RdbcError> {
        // 该缓冲层没有应用类构造器；拒绝非空映射，不能把忽略映射伪称TYPE_MAP支持。
        if !map.is_empty() { return Err(RdbcError::feature_not_supported("BufferedSqlStruct#getAttributes(Map)")); }
        Ok(self.attributes.clone())
    }
}
''')
source=buffer_imports.replace('use crate::error::{RdbcError, SqlException};','use crate::error::RdbcError;')+'''use crate::extensions::{BufferedSqlInput, buffered_sql_struct::BufferedSqlStruct, sql_attribute::SqlAttribute};
use crate::resource::{SqlData, SqlOutput};

/// 按声明顺序保存UDT属性的标准输出实现，保留NULL、资源与流引用。对应 Java: java.sql.SQLOutput（Rust缓冲扩展）。
#[derive(Default)]
pub struct BufferedSqlOutput { attributes: Vec<SqlAttribute> }
impl BufferedSqlOutput {
    /// 创建空属性输出，无参数，返回独占writer。
    pub fn new() -> Self { Self::default() }
    /// 将本输出消费为输入，无参数，返回保留属性顺序和流身份的reader。
    pub fn into_input(self) -> BufferedSqlInput { BufferedSqlInput::from_attributes(self.attributes) }
    /// 追加一个原标准对象，不读取或释放其资源。
    fn push(&mut self, value: RdbcObject) { self.attributes.push(SqlAttribute::from_object(value)); }
}
#[async_trait::async_trait]
impl SqlOutput for BufferedSqlOutput {
'''
for name,ty,expr in [('boolean','bool','Value::Bool(value)'),('byte','i8','Value::Int(i64::from(value))'),('short','i16','Value::Int(i64::from(value))'),('int','i32','Value::Int(i64::from(value))'),('long','i64','Value::Int(value)'),('float','f32','Value::Float(f64::from(value))'),('double','f64','Value::Float(value)')]:
    source+=f'    async fn write_{name}(&mut self,value:{ty})->Result<(),RdbcError> {{ self.push(RdbcObject::Scalar({expr})); Ok(()) }}\n'
for name,(ty,variant) in scalar.items():
    expression='RdbcObject::NString' if name=='n_string' else f'|v| RdbcObject::Scalar(Value::{variant}(v))'
    source+=f'    async fn write_{name}(&mut self,value:Option<{ty}>)->Result<(),RdbcError> {{ self.push(value.map_or(RdbcObject::Scalar(Value::Null), {expression})); Ok(()) }}\n'
for name,(ty,variant) in dict(resources,struct=('RdbcStruct','Struct')).items():source+=f'    async fn write_{name}(&mut self,value:Option<{ty}>)->Result<(),RdbcError> {{ self.push(value.map_or(RdbcObject::Scalar(Value::Null), RdbcObject::{variant})); Ok(()) }}\n'
for name,variant in [('ascii_stream','AsciiStream'),('binary_stream','BinaryStream')]:source+=f'    async fn write_{name}(&mut self,value:Option<RdbcInputStream>)->Result<(),RdbcError> {{ self.attributes.push(value.map_or(SqlAttribute::Object(RdbcObject::Scalar(Value::Null)),SqlAttribute::{variant})); Ok(()) }}\n'
source+='''    async fn write_object(&mut self,value:Option<&mut dyn SqlData>)->Result<(),RdbcError> {
        let Some(value)=value else { self.push(RdbcObject::Scalar(Value::Null)); return Ok(()); };
        // 子输出成功后才发布一个结构属性，避免失败泄漏半个UDT到外层。
        let type_name=value.sql_type_name().await?;
        let mut child=Self::new(); value.write_sql(&mut child).await?;
        let attributes=child.attributes.into_iter().map(SqlAttribute::into_object).collect();
        self.push(RdbcObject::Struct(RdbcStruct::from_standard(Box::new(BufferedSqlStruct { type_name, attributes }))));
        Ok(())
    }
}
'''
write('crates/druid-rdbc/src/extensions/buffered_sql_output.rs',source)
for rel,extra in [('crates/druid-rdbc/src/resource/mod.rs','\nmod sql_data;\nmod sql_input;\nmod sql_output;\npub use sql_data::SqlData;\npub use sql_input::SqlInput;\npub use sql_output::SqlOutput;\n'),('crates/druid-rdbc/src/extensions/mod.rs','\nmod sql_attribute;\nmod buffered_sql_input;\nmod buffered_sql_output;\nmod buffered_sql_struct;\npub use buffered_sql_input::BufferedSqlInput;\npub use buffered_sql_output::BufferedSqlOutput;\n')]:
    p=w/rel;(d/(Path(rel).parent.name+'-mod.before.rs')).write_bytes(p.read_bytes());p.write_bytes(p.read_bytes()+extra.encode('utf-8'));changed.append(rel)
tool='C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin';env=os.environ.copy();env.update(RUSTC=tool+'/rustc.exe',RUSTDOC=tool+'/rustdoc.exe',RUSTUP_TOOLCHAIN='1.97.1-x86_64-pc-windows-msvc',RUSTUP_AUTO_INSTALL='0',PATH=tool+os.pathsep+env['PATH'],CARGO_TARGET_DIR='F:/codex_build_cache/dr103_target',CARGO_BUILD_JOBS='1',TMP='F:/codex_tmp/task7_standard_cargo13',TEMP='F:/codex_tmp/task7_standard_cargo13')
with (d/'format.log').open('xb') as out:r=subprocess.run([tool+'/cargo.exe','fmt','--all'],cwd=w,env=env,stdout=out,stderr=subprocess.STDOUT)
assert r.returncode==0
assert [r for r,h in parent.items() if sha(w/r)!=h]==[r for r in parent if r in changed]
f={r:sha(w/r) for r in set(parent)|set(changed)};(d/'frozen-inputs.json').write_text(json.dumps(f,indent=2)+'\n',encoding='utf-8')
s=dict(terminal=False,production_applied=False,workspace=str(w),pid=os.getpid(),frozen_input_count=len(f),changed_production=changed,commands=[]);save=lambda:(d/'summary.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8');save()
common=['--all-features','--locked','--offline','-j1']
for name,args in [('mapping-contract',['test','-p','druid-rdbc','--test','standard_sql_mapping_contract_test']+common),('mapping-strict',['clippy','-p','druid-rdbc','--test','standard_sql_mapping_contract_test']+common+['--','-D','warnings']),('rdbc-complete',['test','-p','druid-rdbc']+common+['--no-fail-fast']),('format-check',['fmt','--all','--','--check'])]:
    cmd=[tool+'/cargo.exe']+args;log=d/(name+'.log')
    with log.open('xb') as out:r=subprocess.run(cmd,cwd=w,env=env,stdout=out,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
    blocks=re.findall(r'^test result: .*?(\d+) passed; (\d+) failed; (\d+) ignored;',log.read_text(encoding='utf-8'),re.M);entry=dict(name=name,command=cmd,exit_code=r.returncode,log=str(log),sha256=sha(log),passed=sum(int(v[0]) for v in blocks),failed=sum(int(v[1]) for v in blocks),changed_inputs=[r for r,h in f.items() if sha(w/r)!=h]);s['commands'].append(entry);save();print(json.dumps(entry),flush=True)
    if r.returncode or entry['changed_inputs']:break
s.update(terminal=True,exit_code=r.returncode);save();print(json.dumps(dict(terminal=True,exit_code=r.returncode)),flush=True)
