import hashlib, json, os, shutil, subprocess
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008'); old=Path('F:/codex_build_cache/d115'); w=Path('F:/codex_build_cache/d117'); d=b/'task7-sql-mapping-red117'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
parent=json.loads((b/'task7-sql-mapping-red115/frozen-inputs.json').read_text(encoding='utf-8'))
assert all(sha(old/r)==h for r,h in parent.items()); w.mkdir(exist_ok=False);d.mkdir(exist_ok=False)
for rel,h in parent.items():
    p=w/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(old/rel,p);assert sha(p)==h
rel='crates/druid-rdbc/tests/standard_sql_mapping_contract_test.rs';p=w/rel;before=p.read_bytes();(d/'before.rs').write_bytes(before);source=before.decode('utf-8')
for a,c in [('async fn sql_type_name(&self)', 'async fn sql_type_name(&mut self)'),('async fn write_sql(&self,', 'async fn write_sql(&mut self,')]:
    assert source.count(a)==1;source=source.replace(a,c)
source+='''
// SQLData 不应强制应用对象 Sync；驱动独占访问足以提供可迁移的 Send future。
struct SendOnlyData(std::cell::Cell<i32>);
#[async_trait::async_trait]
impl SqlData for SendOnlyData {
    async fn sql_type_name(&mut self) -> Result<String, RdbcError> { Ok("app.send_only".into()) }
    async fn read_sql(&mut self, input: &mut dyn SqlInput, _name: &str) -> Result<(), RdbcError> {
        self.0.set(input.read_int().await?); Ok(())
    }
    async fn write_sql(&mut self, output: &mut dyn SqlOutput) -> Result<(), RdbcError> {
        output.write_int(self.0.get()).await
    }
}
#[tokio::test]
async fn custom_sql_data_can_be_send_without_sync_on_a_spawned_task() {
    tokio::spawn(async {
        let mut object=SendOnlyData(std::cell::Cell::new(0));
        let data: &mut dyn SqlData=&mut object;
        let mut input=BufferedSqlInput::new(vec![Value::Int(73).into()]);
        data.read_sql(&mut input,"app.send_only").await.unwrap();
        assert_eq!(data.sql_type_name().await.unwrap(),"app.send_only");
        let mut output=BufferedSqlOutput::new();
        data.write_sql(&mut output).await.unwrap();
        assert_eq!(output.into_input().read_int().await.unwrap(),73);
    }).await.unwrap();
}
'''
p.write_text(source,encoding='utf-8',newline='')
tool='C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin';env=os.environ.copy();env.update(RUSTC=tool+'/rustc.exe',RUSTDOC=tool+'/rustdoc.exe',RUSTUP_TOOLCHAIN='1.97.1-x86_64-pc-windows-msvc',RUSTUP_AUTO_INSTALL='0',PATH=tool+os.pathsep+env['PATH'],CARGO_TARGET_DIR='F:/codex_build_cache/dr103_target',CARGO_BUILD_JOBS='1',TMP='F:/codex_tmp/task7_standard_cargo13',TEMP='F:/codex_tmp/task7_standard_cargo13')
with (d/'format.log').open('xb') as out:r=subprocess.run([tool+'/rustfmt.exe','--edition','2021',str(p)],env=env,stdout=out,stderr=subprocess.STDOUT)
assert r.returncode==0
assert [r for r,h in parent.items() if sha(w/r)!=h]==[rel]
f={r:sha(w/r) for r in parent};(d/'frozen-inputs.json').write_text(json.dumps(f,indent=2)+'\n',encoding='utf-8')
s=dict(terminal=False,production_applied=False,workspace=str(w),pid=os.getpid(),frozen_input_count=len(f),tests=7,changed_from115=[rel],ruling='SQLData exclusive async methods use &mut self and Send, without Sync; only two fixture receiver declarations changed, all six original assertions retained')
save=lambda:(d/'summary.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8');save()
cmd=[tool+'/cargo.exe','test','-p','druid-rdbc','--test','standard_sql_mapping_contract_test','--all-features','--locked','--offline','-j1'];log=d/'original-red.log'
with log.open('xb') as out:r=subprocess.run(cmd,cwd=w,env=env,stdout=out,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
text=log.read_text(encoding='utf-8');s.update(terminal=True,exit_code=r.returncode,command=cmd,log=str(log),sha256=sha(log),changed_inputs=[r for r,h in f.items() if sha(w/r)!=h],expected_missing_surface_red=r.returncode==101 and 'error[E0432]' in text and all(n in text for n in ['SqlData','SqlInput','SqlOutput','BufferedSqlInput','BufferedSqlOutput']));save();print(json.dumps(s,indent=2),flush=True)
assert s['expected_missing_surface_red'] and not s['changed_inputs']
