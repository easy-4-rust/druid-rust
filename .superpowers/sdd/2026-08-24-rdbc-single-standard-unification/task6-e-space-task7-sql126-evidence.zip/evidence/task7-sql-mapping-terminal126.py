import hashlib
import json
import zipfile
from pathlib import Path

b = Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
e = Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust')
w = Path('F:/codex_build_cache/d117')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda name: json.loads((b / name / 'summary.json').read_text(encoding='utf-8'))
green = read('task7-sql-type-retry127')
assert green['terminal'] and green['exit_code'] == 0
assert [(v['name'], v['exit_code'], v['passed'], v['failed']) for v in green['commands']] == [
    ('mapping-contract', 0, 11, 0), ('mapping-strict', 0, 0, 0),
    ('rdbc-complete', 0, 537, 0), ('format-check', 0, 0, 0)]
for v in green['commands']:
    assert not v['changed_inputs'] and sha(Path(v['log'])) == v['sha256']
red = read('task7-sql-type-red123')
assert red['terminal'] and red['expected_descriptor_red'] and red['exit_code'] == 101
assert not red['changed_inputs'] and sha(Path(red['log'])) == red['sha256']
probe = read('task7-sql-type-probes125')
assert probe['terminal'] and probe['cargo_exit_code'] == 0 and not probe['changed_inputs']
assert (probe['compiled_rows'], probe['passed'], probe['failed'], probe['not_rust_target']) == (68, 61, 7, 1)
f = json.loads((b / 'task7-sql-type-retry127/frozen-inputs.json').read_text(encoding='utf-8'))
assert len(f) == 1234 and all(sha(w / rel) == h for rel, h in f.items())
prior = json.loads((b / 'task7-sql-type-red123/frozen-inputs.json').read_text(encoding='utf-8'))
assert sorted(rel for rel, h in prior.items() if f[rel] != h) == [
    'crates/druid-rdbc/src/resource/sql_output.rs',
    'crates/druid-rdbc/tests/standard_sql_mapping_contract_test.rs']
first_fix = read('task7-sql-type-fix124')
assert first_fix['terminal'] and first_fix['exit_code'] == 101
assert first_fix['commands'][0]['passed'] == 11
assert 'clippy::drop_non_drop' in Path(first_fix['commands'][-1]['log']).read_text(encoding='utf-8')
parent = json.loads((b / 'task7-event-retry108/frozen-inputs.json').read_text(encoding='utf-8'))
delta = sorted(rel for rel, h in f.items() if parent.get(rel) != h)
assert len(delta) == 11 and len(set(f) - set(parent)) == 8 and not set(parent) - set(f)
parent_zip = b / 'task7-standard-events-and-regression-terminal109.zip'
assert sha(parent_zip) == '34823d32312df40e36d0b05e2d9cef381d3564ad20b9f1b24c41f33c016da20b'
c1 = read('task7-runtime100')
assert c1['terminal'] and c1['exit_code'] == 1 and not c1['changed_inputs']
assert c1['commands'][-1]['name'] == 'c1-complete-runtime'
assert sha(Path(c1['commands'][-1]['log'])) == c1['commands'][-1]['sha256']
assert 'timed out after 1800 seconds' in Path(c1['commands'][-1]['log']).read_text(encoding='utf-8')
observed = b / 'task7-sql-mapping-terminal126.validation113-observed.json'
observed.write_bytes((b / 'task7-converged-validation113/summary.json').read_bytes())
dirs = ['task7-sql-mapping-red115', 'task7-sql-mapping-red117', 'task7-sql-mapping-red118',
        'task7-sql-mapping-implement119', 'task7-sql-mapping-retry120',
        'task7-sql-mapping-probes121', 'task7-sql-type-red123', 'task7-sql-type-fix124',
        'task7-sql-type-probes125', 'task7-sql-type-retry127', 'task7-runtime100']
files = [p for name in dirs for p in (b / name).rglob('*') if p.is_file()]
files += [b / name for name in ['task7-sql-mapping-red115.py', 'task7-sql-mapping-contract115.rs',
    'task7-sql-mapping115-brief.md', 'task7-sql-mapping-red117.py', 'task7-sql-mapping-red118.py',
    'task7-sql-mapping-extra118.rs', 'task7-sql-mapping-implement119.py', 'task7-sql-mapping-retry120.py',
    'task7-sql-mapping-probes121.py', 'task7-canonical-probes103.py', 'task7-sql-type-descriptor122.rs',
    'task7-sql-type-red123.py', 'task7-sql-type-fix124.py', 'task7-sql-type-probes125.py', 'task7-sql-type-retry127.py',
    'task7-sql-mapping-terminal126.py', 'task7-runtime100.py', 'task7-converged-validation113.py']]
files.append(observed)
manifest = {p.relative_to(b).as_posix(): sha(p) for p in files}
assert len(manifest) == len(files)
archive = b / 'task7-sql-mapping-terminal126.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as z:
    for p in files:
        z.write(p, 'evidence/' + p.relative_to(b).as_posix())
    for rel in delta:
        z.write(w / rel, 'candidate-delta/' + rel)
    z.writestr('manifest.json', json.dumps(manifest, indent=2))
    z.writestr('candidate-manifest.json', json.dumps(f, indent=2))
with zipfile.ZipFile(archive) as z:
    assert all(hashlib.sha256(z.read('evidence/' + rel)).hexdigest() == h for rel, h in manifest.items())
    assert all(hashlib.sha256(z.read('candidate-delta/' + rel)).hexdigest() == f[rel] for rel in delta)
receipt = dict(production_applied=False, archive=str(archive), sha256=sha(archive),
    parent109_sha256=sha(parent_zip), frozen_inputs=len(f), delta=delta,
    terminal127=green, first_fix124=first_fix, red123=red,
    probe125={k: probe[k] for k in ['terminal', 'compiled_rows', 'passed', 'failed', 'not_rust_target', 'artifact_sha256']},
    c1_runtime100=c1, observed_validation113=json.loads(observed.read_text(encoding='utf-8')),
    residuals=['custom SQLData/type map instantiation', 'SQLXML pending writer/validation',
               'seven RowSet canonical entries', 'Druid standard tree migration',
               'full workspace and C1/C2 runtime', 'API/SemVer/MSRV/features/real DB/final review'],
    top_level_open_tasks=18)
summary = b / 'task7-sql-mapping-terminal126.summary.json'
summary.write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
dest = e / '.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'
for source, suffix in [(archive, 'evidence.zip'), (summary, 'summary.json')]:
    target = dest / ('task6-e-space-task7-sql126-' + suffix)
    assert not target.exists()
    target.write_bytes(source.read_bytes())
    assert sha(target) == sha(source)
note = f'''\n\n2026-10-09 SQL映射标准候选与非Sync描述符修复终态：固定Java三标准3+28+28共59方法，独立d117新增七个真实生产对象、两mod导出及原完整合同，SQL NULL、声明顺序、转换错误、嵌套UDT、流身份与失败无部分写入均有实际合同。117/118公开面E0432 RED、119夹具Cell.set(await)编译错误、120仅改局部赋值后的10/0及RDBC536/0保留，不把夹具错误当产品语义RED。新增第十一合同123实际E0277 RED证明typed输出错误要求SQLType Sync；124仅sql_output.rs改对象安全boxed Send Future，Future仅借用self、不持有描述符，原11测试字节不改，实际11/0后严格Clippy因测试drop_non_drop失败。127仅以词法作用域替换显式drop，保留原非Sync Cell、Send Future约束和全部断言，生产源码与124不变；最终正式Cargo合同11/0、指定严格Clippy0、完整RDBC allfeatures537/0、fmt0，1234完整冻结变化0。125从新Cargo JSON唯一rlib重跑全部原68探针实际61PASS7FAIL/另1host未认证，剩七RowSet项；不认证精确kind、全Java行为或SemVer。custom type map实例化、SQLXML pending writer/校验、Druid旧标准树迁移及最终全仓/API/实库仍开放。zip126 SHA {receipt['sha256']}归档原RED/夹具与质量失败/最终GREEN/Java原件/探针与1234清单，相对完整zip109为11路径delta，逐项解压SHA与E镜像核验。更正原100/session70615：实际完整C1 exit1，子C2 Wrapper allfeatures lib命令1800秒超时、replacement NOT_RUN/ERROR；原1221输入不变，历史C1 PASS不得扩大到该候选。113完整候选回归尚未取得终态；正式Rust未apply，Task6 FIX_REQUIRED/Task7八义务/Task8 INCOMPLETE/18顶层OPEN。\n'''
for rel in ['.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md',
            'docs/verification/rdbc-first/status.md',
            'docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md']:
    with (e / rel).open('a', encoding='utf-8', newline='') as out:
        out.write(note)
print(json.dumps(dict(sha256=receipt['sha256'], evidence_files=len(files), delta_paths=len(delta),
    mapping_passed=11, rdbc_passed=537, probe_passed=61, probe_failed=7, top_level_open_tasks=18), indent=2), flush=True)
