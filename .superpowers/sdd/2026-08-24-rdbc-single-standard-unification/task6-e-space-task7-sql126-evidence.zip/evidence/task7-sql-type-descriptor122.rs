
struct SendOnlySqlType(std::cell::Cell<i32>);
impl druid_rdbc::types::SqlType for SendOnlySqlType {
    fn name(&self) -> &'static str { "VENDOR_INTEGER" }
    fn vendor(&self) -> &'static str { "example" }
    fn vendor_type_number(&self) -> i32 { self.0.get() }
}
#[tokio::test]
async fn default_typed_output_does_not_add_sync_to_the_standard_sql_type_contract() {
    fn require_send<T: std::future::Future + Send>(future: T) -> T { future }
    let descriptor = SendOnlySqlType(std::cell::Cell::new(73));
    let mut output = BufferedSqlOutput::new();
    let future = require_send(output.write_object_as(None, &descriptor));
    drop(descriptor);
    let error = future.await.unwrap_err();
    assert!(matches!(error, RdbcError::SqlException(ref e) if e.class_name() == "java.sql.SQLFeatureNotSupportedException"));
    assert!(output.into_input().read_object().await.is_err());
}
