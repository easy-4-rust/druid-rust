import hashlib,json,os,re,subprocess
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d117');d=b/'task7-sql-type-fix124'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
previous=json.loads((b/'task7-sql-type-red123/summary.json').read_text(encoding='utf-8'));assert previous['terminal'] and previous['expected_descriptor_red']
f=json.loads((b/'task7-sql-type-red123/frozen-inputs.json').read_text(encoding='utf-8'));assert all(sha(w/r)==h for r,h in f.items());d.mkdir(exist_ok=False)
rel='crates/druid-rdbc/src/resource/sql_output.rs';p=w/rel;raw=p.read_bytes();(d/'before.rs').write_bytes(raw);source=raw.decode('utf-8')
source=source.replace('use crate::resource::SqlData;','use crate::resource::SqlData;\nuse std::future::Future;\nuse std::pin::Pin;')
needle='target须可跨异步任务共享；SqlType本身不增加Sync约束。';assert source.count(needle)==1
source=source.replace(needle,'返回Future仅借用self；覆盖实现应在调用时读取所需描述符，不将非Sync引用移入Send Future。')
start=source.index('    async fn write_object_as(');end=source.index('\n    }\n}',start)+len('\n    }')
source=source[:start]+'''    fn write_object_as<'a>(
        &'a mut self,
        _value: Option<RdbcObject>,
        _target: &dyn SqlType,
    ) -> Pin<Box<dyn Future<Output = Result<(), RdbcError>> + Send + 'a>> {
        // Java默认方法同步报告不支持；返回Future不保存也不要求描述符Sync。
        Box::pin(async { Err(RdbcError::feature_not_supported("SQLOutput#writeObject(Object, SQLType)")) })
    }'''+source[end:]
p.write_text(source,encoding='utf-8',newline='')
tool='C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin';env=os.environ.copy();env.update(RUSTC=tool+'/rustc.exe',RUSTDOC=tool+'/rustdoc.exe',RUSTUP_TOOLCHAIN='1.97.1-x86_64-pc-windows-msvc',RUSTUP_AUTO_INSTALL='0',PATH=tool+os.pathsep+env['PATH'],CARGO_TARGET_DIR='F:/codex_build_cache/dr103_target',CARGO_BUILD_JOBS='1',TMP='F:/codex_tmp/task7_standard_cargo13',TEMP='F:/codex_tmp/task7_standard_cargo13')
with (d/'format.log').open('xb') as out:r=subprocess.run([tool+'/rustfmt.exe','--edition','2021',str(p)],env=env,stdout=out,stderr=subprocess.STDOUT)
assert r.returncode==0 and [r for r,h in f.items() if sha(w/r)!=h]==[rel]
f[rel]=sha(p);(d/'frozen-inputs.json').write_text(json.dumps(f,indent=2)+'\n',encoding='utf-8')
s=dict(terminal=False,production_applied=False,workspace=str(w),pid=os.getpid(),frozen_input_count=len(f),changed_source=rel,original_tests_unchanged=True,ruling='Default typed output accepts the original SqlType contract without Sync; its Send future borrows only self, so descriptors may be released after negotiation',commands=[]);save=lambda:(d/'summary.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8');save()
common=['--all-features','--locked','--offline','-j1']
for name,args in [('mapping-contract',['test','-p','druid-rdbc','--test','standard_sql_mapping_contract_test']+common),('mapping-strict',['clippy','-p','druid-rdbc','--test','standard_sql_mapping_contract_test']+common+['--','-D','warnings']),('rdbc-complete',['test','-p','druid-rdbc']+common+['--no-fail-fast']),('format-check',['fmt','--all','--','--check'])]:
    cmd=[tool+'/cargo.exe']+args;log=d/(name+'.log')
    with log.open('xb') as out:r=subprocess.run(cmd,cwd=w,env=env,stdout=out,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
    blocks=re.findall(r'^test result: .*?(\d+) passed; (\d+) failed; (\d+) ignored;',log.read_text(encoding='utf-8'),re.M);entry=dict(name=name,command=cmd,exit_code=r.returncode,log=str(log),sha256=sha(log),passed=sum(int(v[0]) for v in blocks),failed=sum(int(v[1]) for v in blocks),changed_inputs=[r for r,h in f.items() if sha(w/r)!=h]);s['commands'].append(entry);save();print(json.dumps(entry),flush=True)
    if r.returncode or entry['changed_inputs']:break
s.update(terminal=True,exit_code=r.returncode);save();print(json.dumps(dict(terminal=True,exit_code=r.returncode)),flush=True)
