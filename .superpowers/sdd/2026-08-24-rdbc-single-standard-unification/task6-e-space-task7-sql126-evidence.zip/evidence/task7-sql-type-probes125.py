import json
from pathlib import Path

b = Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
previous = json.loads((b / 'task7-sql-type-retry127/summary.json').read_text(encoding='utf-8'))
assert previous['terminal'] and previous['exit_code'] == 0 and len(previous['commands']) == 4
assert all(c['exit_code'] == 0 and not c['changed_inputs'] for c in previous['commands'])
source = (b / 'task7-canonical-probes103.py').read_text(encoding='utf-8')
for old, new in [
    ("w=Path('F:/codex_build_cache/d91')", "w=Path('F:/codex_build_cache/d117')"),
    ("d=b/'task7-canonical-probes103'", "d=b/'task7-sql-type-probes125'"),
    ('task7-finalize99/frozen-inputs.json', 'task7-sql-type-retry127/frozen-inputs.json'),
    ('len(f)==1221', 'len(f)==1234'),
]:
    assert source.count(old) == 1
    source = source.replace(old, new)
exec(compile(source, str(b / 'task7-sql-type-probes125.py'), 'exec'))
