import hashlib,json,os,re,subprocess
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d117');d=b/'task7-sql-type-red123'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
previous=json.loads((b/'task7-sql-mapping-probes121/summary.json').read_text(encoding='utf-8'));assert previous['terminal'] and not previous['changed_inputs']
f=json.loads((b/'task7-sql-mapping-retry120/frozen-inputs.json').read_text(encoding='utf-8'));assert len(f)==1234 and all(sha(w/r)==h for r,h in f.items());d.mkdir(exist_ok=False)
rel='crates/druid-rdbc/tests/standard_sql_mapping_contract_test.rs';p=w/rel;(d/'before.rs').write_bytes(p.read_bytes());p.write_bytes(p.read_bytes()+(b/'task7-sql-type-descriptor122.rs').read_bytes())
tool='C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin';env=os.environ.copy();env.update(RUSTC=tool+'/rustc.exe',RUSTDOC=tool+'/rustdoc.exe',RUSTUP_TOOLCHAIN='1.97.1-x86_64-pc-windows-msvc',RUSTUP_AUTO_INSTALL='0',PATH=tool+os.pathsep+env['PATH'],CARGO_TARGET_DIR='F:/codex_build_cache/dr103_target',CARGO_BUILD_JOBS='1',TMP='F:/codex_tmp/task7_standard_cargo13',TEMP='F:/codex_tmp/task7_standard_cargo13')
with (d/'format.log').open('xb') as out:r=subprocess.run([tool+'/rustfmt.exe','--edition','2021',str(p)],env=env,stdout=out,stderr=subprocess.STDOUT)
assert r.returncode==0 and [r for r,h in f.items() if sha(w/r)!=h]==[rel]
f[rel]=sha(p);(d/'frozen-inputs.json').write_text(json.dumps(f,indent=2)+'\n',encoding='utf-8')
s=dict(terminal=False,production_applied=False,workspace=str(w),pid=os.getpid(),frozen_input_count=len(f),tests=11);save=lambda:(d/'summary.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8');save()
cmd=[tool+'/cargo.exe','test','-p','druid-rdbc','--test','standard_sql_mapping_contract_test','--all-features','--locked','--offline','-j1'];log=d/'descriptor-red.log'
with log.open('xb') as out:r=subprocess.run(cmd,cwd=w,env=env,stdout=out,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
text=log.read_text(encoding='utf-8');s.update(terminal=True,exit_code=r.returncode,command=cmd,log=str(log),sha256=sha(log),diagnostics=re.findall(r'error\[(E\d+)\]',text),changed_inputs=[r for r,h in f.items() if sha(w/r)!=h],expected_descriptor_red=r.returncode==101 and 'error[E0277]' in text and 'Cell<i32>' in text and 'Sync' in text);save();print(json.dumps(s,indent=2),flush=True);assert s['expected_descriptor_red'] and not s['changed_inputs']
