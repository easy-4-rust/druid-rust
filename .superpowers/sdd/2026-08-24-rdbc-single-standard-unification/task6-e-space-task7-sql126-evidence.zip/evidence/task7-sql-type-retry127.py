import hashlib,json,os,subprocess
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
w=Path('F:/codex_build_cache/d117');d=b/'task7-sql-type-retry127'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
previous=json.loads((b/'task7-sql-type-fix124/summary.json').read_text(encoding='utf-8'))
assert previous['terminal'] and previous['exit_code']==101
assert [(c['name'],c['exit_code']) for c in previous['commands']]==[('mapping-contract',0),('mapping-strict',101)]
assert 'clippy::drop_non_drop' in Path(previous['commands'][-1]['log']).read_text(encoding='utf-8')
f=json.loads((b/'task7-sql-type-fix124/frozen-inputs.json').read_text(encoding='utf-8'))
assert all(sha(w/r)==h for r,h in f.items());d.mkdir(exist_ok=False)
rel='crates/druid-rdbc/tests/standard_sql_mapping_contract_test.rs';p=w/rel
raw=p.read_bytes();(d/'before.rs').write_bytes(raw);source=raw.decode('utf-8')
old='''    let descriptor = SendOnlySqlType(std::cell::Cell::new(73));
    let mut output = BufferedSqlOutput::new();
    let future = require_send(output.write_object_as(None, &descriptor));
    drop(descriptor);'''
new='''    let mut output = BufferedSqlOutput::new();
    let future = {
        let descriptor = SendOnlySqlType(std::cell::Cell::new(73));
        require_send(output.write_object_as(None, &descriptor))
    };'''
assert source.count(old)==1;source=source.replace(old,new)
assert source.replace(new,old).encode('utf-8')==raw
p.write_text(source,encoding='utf-8',newline='')
tool='C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin'
env=os.environ.copy();env.update(RUSTUP_TOOLCHAIN='1.97.1-x86_64-pc-windows-msvc',RUSTUP_AUTO_INSTALL='0')
with (d/'format.log').open('xb') as out:r=subprocess.run([tool+'/rustfmt.exe','--edition','2021',str(p)],env=env,stdout=out,stderr=subprocess.STDOUT)
assert r.returncode==0 and [r for r,h in f.items() if sha(w/r)!=h]==[rel]
f[rel]=sha(p)
source=(b/'task7-sql-type-fix124.py').read_text(encoding='utf-8')
tail=source[source.index("tool='C:/Users/"):]
start=tail.index("with (d/'format.log')");end=tail.index("s=dict(terminal=False",start)
tail=tail[:start]+"(d/'frozen-inputs.json').write_text(json.dumps(f,indent=2)+'\\n',encoding='utf-8')\n"+tail[end:]
tail=tail.replace('original_tests_unchanged=True','original_assertions_unchanged=True, production_unchanged_from124=True')
tail=tail.replace('Default typed output accepts the original SqlType contract without Sync; its Send future borrows only self, so descriptors may be released after negotiation','Use lexical descriptor scope instead of explicit drop; retain the original non-Sync Cell, Send future requirement and all assertions')
exec(compile('import re\n'+tail,str(b/'task7-sql-type-retry127.py'),'exec'))
