from pathlib import Path
import hashlib,json,os,subprocess,sys,time
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d177');d=b/'task7-sqlx-forward-red224';d.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();base=json.loads((b/'task8-api-variant-green219/frozen-inputs.json').read_text());assert len(base)==1273
assert all(sha(w/r)==h for r,h in base.items())
new='crates/druid-wrapper/tests/task7_sqlx_forward_direction_contract_test.rs';f=base|{new:sha(w/new)}
(d/'frozen-inputs.json').write_text(json.dumps(f,indent=2)+'\n',encoding='utf-8')
s=dict(terminal=False,production_applied=False,pid=os.getpid(),workspace=str(w),frozen_input_count=len(f),source_delta=[new],running_command='real-sqlite-forward-direction-red')
(d/'summary.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
rt=Path('C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin');env=os.environ.copy();env.update(RUSTC=str(rt/'rustc.exe'),RUSTDOC=str(rt/'rustdoc.exe'),RUSTUP_TOOLCHAIN='1.97.1',RUSTUP_AUTO_INSTALL='0',CARGO_NET_OFFLINE='true',CARGO_TARGET_DIR='F:/codex_build_cache/druid_rust/task7_row_set177_target',DRUID_RDBC_EXTERNAL_TARGET_ROOT='F:/codex_build_cache/druid_rust/task7_row_set177_external',TMP='F:/codex_tmp/task7_standard_cargo13',TEMP='F:/codex_tmp/task7_standard_cargo13');env['PATH']=str(rt)+os.pathsep+env['PATH']
cmd=[str(rt/'cargo.exe'),'test','-p','druid-wrapper','--test','task7_sqlx_forward_direction_contract_test','--locked','--offline','-j1'];log=d/'red.log';started=time.monotonic()
with log.open('wb') as out:r=subprocess.run(cmd,cwd=w,env=env,stdout=out,stderr=subprocess.STDOUT)
s.update(terminal=True,command=cmd,exit_code=r.returncode,elapsed_seconds=time.monotonic()-started,log=str(log),log_sha256=sha(log),changed_inputs=[p for p,h in f.items() if sha(w/p)!=h]);(d/'summary.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8');print(json.dumps(s))
