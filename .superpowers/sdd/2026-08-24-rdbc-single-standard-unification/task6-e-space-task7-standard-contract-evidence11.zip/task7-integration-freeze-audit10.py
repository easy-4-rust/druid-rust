import hashlib
import json
from pathlib import Path
from datetime import datetime, timezone

b = Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
d = b / 'task7-external-resource-consumer-candidate1'
w = d / 'workspace'
p = d / 'integrated6-frozen-inputs9.json'
frozen = json.loads(p.read_text(encoding='utf-8'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
changed = [name for name, digest in frozen.items()
           if not (w / name).is_file() or sha(w / name) != digest]
new_rust = sorted(p.relative_to(w).as_posix() for p in (w / 'crates').rglob('*.rs')
                  if p.relative_to(w).as_posix() not in frozen)
s = dict(observed=datetime.now(timezone.utc).isoformat(), original_session=60792,
         frozen_input_count=len(frozen), frozen_manifest_sha256=sha(p),
         changed_inputs=changed, added_crate_rust_sources=new_rust,
         pipeline=json.loads((d / 'integrated6.summary.json').read_text(encoding='utf-8')),
         ruling='This audit proves input integrity only; process liveness comes from the original exec handle, and no build or runtime result is inferred.')
assert not changed and not new_rust, (changed, new_rust)
out = b / 'task7-integration-freeze-audit10.summary.json'
assert not out.exists()
out.write_text(json.dumps(s, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k:v for k,v in s.items() if k != 'pipeline'}), flush=True)
