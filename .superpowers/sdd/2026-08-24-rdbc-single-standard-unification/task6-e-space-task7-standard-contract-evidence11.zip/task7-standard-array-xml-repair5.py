import hashlib
import json
from pathlib import Path
import shutil
import subprocess

b = Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
old = b / 'task7-standard-array-xml-candidate1'
d = b / 'task7-standard-array-xml-candidate2'
d.mkdir(exist_ok=False)
shutil.copytree(old / 'crates', d / 'crates')
s = json.loads((old / 'summary.json').read_text(encoding='utf-8'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
p = d / 'crates/druid-rdbc/tests/resource_standard_support/sql_xml_contract.rs'
t = p.read_text(encoding='utf-8')
assert t.count('use std::time::Duration;\n') == 1
p.write_text(t.replace('use std::time::Duration;\n', ''), encoding='utf-8', newline='\n')
s.update(prior_compile_failure=str(old / 'compile.log'), commands=[], terminal=False,
         ruling='Remove only the unused import left by independent XML extraction. Preserve every extracted contract and all prior 13 tests; do not change the running integrated workspace.')
tests = d / 'crates/druid-rdbc/tests'
s['sources'] = {p.relative_to(tests).as_posix(): sha(p) for p in tests.rglob('*.rs')}
cmd = json.loads((old / 'summary.json').read_text(encoding='utf-8'))['commands'][0]['command']
cmd[cmd.index('--test') + 3] = str(tests / 'resource_standard_contract_test.rs')
exe = d / 'standard-contract5.exe'
cmd[cmd.index('-o') + 1] = str(exe)
assert not any(x.startswith('druid=') or x.startswith('druid_wrapper=') for x in cmd)
def save():
    (d / 'summary.json').write_text(json.dumps(s, indent=2) + '\n', encoding='utf-8')
def run(name, command):
    log = d / (name + '.log')
    with log.open('xb') as out:
        r = subprocess.run(command, stdout=out, stderr=subprocess.STDOUT,
                           creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
    s['commands'].append(dict(name=name, command=command, exit_code=r.returncode,
                              log=str(log), sha256=sha(log)))
    save()
    print(name, r.returncode, flush=True)
    assert r.returncode == 0
save()
run('compile', cmd)
run('runtime', [str(exe), '--test-threads=1'])
expected = 13 + s['array_tests_preserved'] + s['xml_tests_preserved']
assert f'{expected} passed; 0 failed;' in (d / 'runtime.log').read_text(encoding='utf-8')
assert s['sources'] == {p.relative_to(tests).as_posix(): sha(p) for p in tests.rglob('*.rs')}
s.update(terminal=True, runtime_tests=expected, source_unchanged=True)
save()
