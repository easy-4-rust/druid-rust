import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess

b = Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
original = b / 'task7-pooled-xml-value-consumer3.rs'
t = original.read_text(encoding='utf-8')
d = b / 'task7-standard-array-xml-candidate1'
d.mkdir(exist_ok=False)
tests = d / 'crates/druid-rdbc/tests'
shutil.copytree(b / 'task7-planned-contract-tests-candidate1/crates/druid-rdbc/tests', tests)
support = tests / 'resource_standard_support'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
fatal = t[t.index('fn fatal_error()'):t.index('\nmod payload_fixture')]
nonfatal_start = t.index('fn array_nonfatal_error()')
nonfatal = t[nonfatal_start:t.index('\n}', nonfatal_start) + 2]
array_start = t.index('use druid_rdbc::resource::Array;')
array_fixture = t[array_start:t.index('fn array_probe(control:', array_start)]
map_start = t.index('fn array_map()')
array_fixture += t[map_start:t.index('\n', map_start)] + '\n'
array_start = t.index('fn value_array_probe(')
array_end = t.index('use druid_rdbc::resource::{BlobPattern, RdbcBlob, ResourceHandleFactory};', array_start)
array_tests = t[array_start:array_end]
pooled_start = array_tests.index('#[tokio::test]\nasync fn task7_array_value_pooled_free_cancel_and_parent_close_share_driver_release')
pooled_end = array_tests.index('/// 在驱动入口计数', pooled_start)
excluded_array = array_tests[pooled_start:pooled_end]
array_tests = array_tests[:pooled_start] + array_tests[pooled_end:]
array_header = '''use druid_rdbc::error::{RdbcError, SqlException};
use druid_rdbc::resource::ResourceOperations;
use std::sync::{Arc, Mutex, atomic::{AtomicBool, AtomicUsize, Ordering}};
'''
array = array_header + fatal + '\n' + nonfatal + '\n' + array_fixture + array_tests
assert 'druid::' not in array and 'Control' not in array
(support / 'array_contract.rs').write_text(array, encoding='utf-8', newline='\n')
release_start = t.index('#[derive(Clone, Debug)]\npub(super) struct ReleaseProbe')
release_end = t.index('pub(super) fn controlled(', release_start)
release = ('mod payload_fixture {\nuse std::sync::{Arc, atomic::AtomicUsize};\n'
           'use tokio::sync::Notify;\n' + t[release_start:release_end] + '}\n')
xml_start = t.index('#[derive(Debug)]\nstruct XmlProbe')
xml_fixture = t[xml_start:t.index('async fn xml_read(', xml_start)]
xml_start = t.index('mod xml_value_contract {')
xml_end = t.index('#[tokio::test]\nasync fn pooled_xml_cleanup_queued_behind_another_resource_reports_xml', xml_start)
xml_tests = t[xml_start:xml_end]
pooled_start = xml_tests.index('#[tokio::test]\nasync fn actual_pooled_value_cancellation_parent_cleanup_and_fatal_error')
pooled_end = xml_tests.index('#[cfg(task7_require_xml_value_sync)]', pooled_start)
excluded_xml = xml_tests[pooled_start:pooled_end]
xml_tests = xml_tests[:pooled_start] + xml_tests[pooled_end:]
xml_header = '''use druid_rdbc::error::{RdbcError, SqlException};
use druid_rdbc::resource::{SqlXml, RdbcXmlRepresentationType, RdbcXmlSource, RdbcXmlResult,
    RdbcInputStream, RdbcOutputStream, RdbcReader, RdbcWriter, ResourceOperations};
use druid_rdbc::types::RdbcString;
use std::sync::{Arc, Mutex, atomic::{AtomicBool, AtomicUsize, Ordering}};
use std::time::Duration;
'''
xml = xml_header + fatal + '\n' + release + xml_fixture + xml_tests
assert 'druid::' not in xml and 'Control' not in xml
(support / 'sql_xml_contract.rs').write_text(xml, encoding='utf-8', newline='\n')
root = tests / 'resource_standard_contract_test.rs'
root.write_text(root.read_text(encoding='utf-8')
    .replace('//! 现有原合同保持完整；Array与SQLXML完整矩阵仍须补齐，不能据此关闭Task7。',
             '//! 独立保留六类资源及Struct的能力、访问与生命周期合同；正式Cargo验收另行记录。')
    + '#[path = "resource_standard_support/array_contract.rs"]\nmod array_contract;\n'
    + '#[path = "resource_standard_support/sql_xml_contract.rs"]\nmod sql_xml_contract;\n', encoding='utf-8')
before = b / 'task7-planned-contract-tests-candidate1'
for p in (before / 'crates/druid-rdbc/tests/resource_standard_support').glob('*.rs'):
    assert (support / p.name).read_bytes() == p.read_bytes()
old_receipt = json.loads((before / 'standard-contract3.summary.json').read_text())
cmd = old_receipt['commands'][0]['command'].copy()
cmd[cmd.index('--test') + 3] = str(root)
exe = d / 'standard-contract4.exe'
cmd[cmd.index('-o') + 1] = str(exe)
s = dict(terminal=False, production_applied=False, cargo_certified=False, commands=[],
         original_source_sha256=sha(original),
         array_tests_preserved=len(re.findall(r'#\[tokio::test\]', array_tests)),
         xml_tests_preserved=len(re.findall(r'#\[tokio::test\]', xml_tests)),
         pooled_tests_retained_in_owner_target=[
             hashlib.sha256(excluded_array.encode()).hexdigest(),
             hashlib.sha256(excluded_xml.encode()).hexdigest()],
         ruling='Extract only independent standard contracts; keep the two Druid owner scenarios in the unchanged 104-test owner target. Existing 13 independent tests remain byte-identical.',
         sources={p.relative_to(tests).as_posix(): sha(p) for p in tests.rglob('*.rs')})
def save():
    (d / 'summary.json').write_text(json.dumps(s, indent=2) + '\n', encoding='utf-8')
def run(name, command):
    log = d / (name + '.log')
    with log.open('xb') as out:
        r = subprocess.run(command, stdout=out, stderr=subprocess.STDOUT,
                           creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
    s['commands'].append(dict(name=name, command=command, exit_code=r.returncode,
                              log=str(log), sha256=sha(log)))
    save()
    print(name, r.returncode, flush=True)
    assert r.returncode == 0
save()
run('compile', cmd)
run('runtime', [str(exe), '--test-threads=1'])
expected = 13 + s['array_tests_preserved'] + s['xml_tests_preserved']
assert f'{expected} passed; 0 failed;' in (d / 'runtime.log').read_text(encoding='utf-8')
s.update(terminal=True, runtime_tests=expected)
save()
