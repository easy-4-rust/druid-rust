import hashlib
import json
from pathlib import Path
import subprocess

b = Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
d = b / 'task7-standard-array-xml-candidate2'
old = json.loads((b / 'task7-standard-array-xml-candidate1/summary.json').read_text(encoding='utf-8'))
cmd = old['commands'][0]['command'].copy()
root = d / 'crates/druid-rdbc/tests/resource_standard_contract_test.rs'
cmd[cmd.index('--test') + 3] = str(root)
cmd[cmd.index('-o') + 1] = str(d / 'negative-control6.exe')
s = dict(terminal=False, controls=[], production_applied=False, cargo_certified=False)
for cfg, marker in [('task7_require_xml_value_sync', 'E0277'),
                    ('task7_require_old_xml_access', 'E0432')]:
    log = d / (cfg + '6.log')
    command = cmd + ['--cfg', cfg]
    with log.open('xb') as out:
        r = subprocess.run(command, stdout=out, stderr=subprocess.STDOUT,
                           creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
    t = log.read_text(encoding='utf-8')
    assert r.returncode != 0 and marker in t, (cfg, r.returncode, t)
    s['controls'].append(dict(cfg=cfg, command=command, exit_code=r.returncode,
        required_diagnostic=marker, log_sha256=hashlib.sha256(log.read_bytes()).hexdigest()))
    (d / 'negative-controls6.summary.json').write_text(json.dumps(s, indent=2) + '\n', encoding='utf-8')
    print(cfg, r.returncode, marker, flush=True)
s.update(terminal=True)
(d / 'negative-controls6.summary.json').write_text(json.dumps(s, indent=2) + '\n', encoding='utf-8')
