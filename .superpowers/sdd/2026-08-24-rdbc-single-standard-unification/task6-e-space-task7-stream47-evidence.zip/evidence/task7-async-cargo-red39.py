import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess

b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
d=b/'task7-async-cargo-red39'
d.mkdir(exist_ok=False)
w=b/'task7-standard-cargo-candidate1/workspace'
owner=json.loads((b/'task7-owner-clippy-repair32/summary.json').read_text(encoding='utf-8'))
assert owner['terminal'] and owner['exit_code']==0
prior=json.loads((b/'task7-async-contract-retry36/summary.json').read_text(encoding='utf-8'))
assert prior['terminal'] and not prior['semantic_red']
assert 'LNK1181' in Path(prior['commands'][0]['log']).read_text(encoding='utf-8')
p=w/'crates/druid-wrapper/tests/async_result_set_test.rs'
assert not p.exists()
shutil.copyfile(b/'task7-async-contract-retry36/async_result_set_test.rs',p)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
tool='C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin'
env=os.environ.copy()
env.update(RUSTC=tool+'/rustc.exe',RUSTDOC=tool+'/rustdoc.exe',RUSTUP_TOOLCHAIN='1.97.1-x86_64-pc-windows-msvc',RUSTUP_AUTO_INSTALL='0',
    PATH=tool+os.pathsep+env['PATH'],CARGO_TARGET_DIR='F:/codex_build_cache/druid_rust/task7_standard_cargo13_1971',
    CARGO_BUILD_JOBS='1',RUST_TEST_THREADS='1',TMP='F:/codex_tmp/task7_standard_cargo13',TEMP='F:/codex_tmp/task7_standard_cargo13')
cmd=[tool+'/cargo.exe','test','-p','druid-wrapper','--test','async_result_set_test','--locked','--offline','-j1','--','--test-threads=1']
s=dict(terminal=False,production_applied=False,source_sha256=sha(p),command=cmd,
    prior_failure='Direct rustc36 native link LNK1181 missing windows.0.52.0.lib; not semantic RED. Formal default-feature Cargo manages native search paths on idle baseline candidate.')
def save():
    (d/'summary.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
save()
log=d/'cargo-red39.log'
with log.open('xb') as output:
    result=subprocess.run(cmd,cwd=w,env=env,stdout=output,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
text=log.read_text(encoding='utf-8')
results=re.findall(r'^test result: .*?(\d+) passed; (\d+) failed; (\d+) ignored;',text,re.M)
semantic=bool(results) and result.returncode!=0 and 'bounded query must not materialize every row' in text and 'late driver error belongs to next' in text
s.update(terminal=True,exit_code=result.returncode,semantic_red=semantic,results=results,source_unchanged=sha(p)==s['source_sha256'],log=str(log),log_sha256=sha(log))
save()
print(json.dumps({k:s[k] for k in ['terminal','exit_code','semantic_red','results']}),flush=True)
assert semantic
