use druid_rdbc::connection::Connection;
use druid_rdbc::result_set::{ColumnIndex, ResultSetExt};
use druid_rdbc::statement::{GeneratedKeys, ParameterIndex, PreparedParameter, ResultSetType, StatementOptions};
use druid_rdbc::types::Value;
use druid_wrapper::sqlx::SqlxConnectionAdapter;
use std::time::Duration;

const ROWS: &str = "WITH RECURSIVE n(x) AS (SELECT 1 UNION ALL SELECT x+1 FROM n WHERE x<200) SELECT x AS value FROM n";
const LATE_ERROR: &str = "WITH RECURSIVE n(x) AS (SELECT 1 UNION ALL SELECT x+1 FROM n WHERE x<200) SELECT CASE WHEN x=200 THEN abs(-9223372036854775808) ELSE x END AS value FROM n";

#[tokio::test]
async fn forward_query_with_bounded_fetch_reports_unknown_total_and_real_rows() {
    let mut connection = SqlxConnectionAdapter::connect("sqlite::memory:").await.unwrap();
    let mut statement = connection.create_statement(StatementOptions::default()).await.unwrap();
    statement.set_fetch_size(1).unwrap();
    let mut cursor = statement.execute_query(ROWS).await.unwrap();
    assert_eq!(cursor.known_row_count(), None, "bounded query must not materialize every row");
    assert_eq!(cursor.result_set_type().unwrap(), ResultSetType::ForwardOnly);
    assert_eq!(cursor.meta_data().unwrap().column_count(), 1);
    assert_eq!(cursor.find_column("value").unwrap(), ColumnIndex::new(1).unwrap());
    for expected in 1..=200 {
        assert!(cursor.next().await.unwrap());
        assert_eq!(cursor.int(ColumnIndex::new(1).unwrap()).unwrap(), expected);
    }
    assert!(!cursor.next().await.unwrap());
    assert!(!cursor.next().await.unwrap());
    cursor.close().await.unwrap();
    connection.close().await.unwrap();
}

#[tokio::test]
async fn database_error_in_later_row_does_not_prevent_first_row_consumption() {
    let mut connection = SqlxConnectionAdapter::connect("sqlite::memory:").await.unwrap();
    let mut statement = connection.create_statement(StatementOptions::default()).await.unwrap();
    statement.set_fetch_size(1).unwrap();
    let mut cursor = statement.execute_query(LATE_ERROR).await.expect("late driver error belongs to next, not eager query setup");
    for expected in 1..200 {
        assert!(cursor.next().await.unwrap());
        assert_eq!(cursor.int(ColumnIndex::new(1).unwrap()).unwrap(), expected);
    }
    assert!(cursor.next().await.is_err());
    cursor.close().await.unwrap();
    tokio::time::timeout(Duration::from_secs(5), connection.exec("CREATE TABLE after_error(id INTEGER)", vec![])).await.unwrap().unwrap();
    connection.close().await.unwrap();
}

#[tokio::test]
async fn explicit_cursor_close_releases_same_connection_before_exhaustion() {
    let mut connection = SqlxConnectionAdapter::connect("sqlite::memory:").await.unwrap();
    let mut statement = connection.create_statement(StatementOptions::default()).await.unwrap();
    statement.set_fetch_size(1).unwrap();
    let mut cursor = statement.execute_query(ROWS).await.unwrap();
    assert!(cursor.next().await.unwrap());
    cursor.close().await.unwrap();
    cursor.close().await.unwrap();
    assert!(cursor.next().await.is_err());
    tokio::time::timeout(Duration::from_secs(5), connection.exec("CREATE TABLE after_close(id INTEGER)", vec![])).await.unwrap().unwrap();
    connection.close().await.unwrap();
}

#[tokio::test]
async fn dropped_cursor_releases_actor_and_parent_close_finishes_with_live_cursor() {
    let mut connection = SqlxConnectionAdapter::connect("sqlite::memory:").await.unwrap();
    let mut statement = connection.create_statement(StatementOptions::default()).await.unwrap();
    statement.set_fetch_size(1).unwrap();
    let mut cursor = statement.execute_query(ROWS).await.unwrap();
    assert!(cursor.next().await.unwrap());
    drop(cursor);
    tokio::time::timeout(Duration::from_secs(5), connection.exec("CREATE TABLE after_drop(id INTEGER)", vec![])).await.unwrap().unwrap();
    let mut cursor = statement.execute_query(ROWS).await.unwrap();
    tokio::time::timeout(Duration::from_secs(5), connection.close()).await.unwrap().unwrap();
    assert!(cursor.next().await.is_err());
    cursor.close().await.unwrap();
}

#[tokio::test]
async fn prepared_bounded_query_preserves_parameters_and_generic_execute_stays_buffered() {
    let mut connection = SqlxConnectionAdapter::connect("sqlite::memory:").await.unwrap();
    let mut prepared = connection.prepare_statement("SELECT ? AS value", StatementOptions::default()).await.unwrap();
    prepared.set_fetch_size(1).unwrap();
    prepared.set_parameter(PreparedParameter { index: ParameterIndex::new(1).unwrap(), value: Value::Int(42) }).unwrap();
    let mut cursor = prepared.execute_prepared_query().await.unwrap();
    assert_eq!(cursor.known_row_count(), None);
    assert!(cursor.next().await.unwrap());
    assert_eq!(cursor.int(ColumnIndex::new(1).unwrap()).unwrap(), 42);
    cursor.close().await.unwrap();
    let mut statement = connection.create_statement(StatementOptions::default()).await.unwrap();
    statement.set_fetch_size(1).unwrap();
    let results = statement.execute(ROWS, GeneratedKeys::None).await.unwrap();
    match &results[0] {
        druid_rdbc::statement::ExecutionResult::ResultSet(rows) => assert_eq!(rows.known_row_count(), Some(200)),
        druid_rdbc::statement::ExecutionResult::UpdateCount(_) => panic!("query must remain a result set"),
    }
    connection.close().await.unwrap();
}
