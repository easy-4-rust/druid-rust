import hashlib
import json
from pathlib import Path
import subprocess

b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
d=b/'task7-stream-extension-red43'
d.mkdir(exist_ok=False)
old=json.loads((b/'task7-async-contract-red34/summary.json').read_text(encoding='utf-8'))['commands'][0]['command']
source=d/'stream_adapter_missing.rs'
source.write_text('''use druid_rdbc::result_set::{ColumnIndex, ResultSet, ResultSetExt};
pub fn stream(cursor: Box<dyn ResultSet>) {
    let _stream = cursor.into_stream(|rows| rows.int(ColumnIndex::new(1)?));
}
''',encoding='utf-8',newline='\n')
cmd=[old[0],'--edition=2021','--crate-type=lib','--emit=metadata',str(source),'-o',str(d/'probe.rmeta')]
for i,value in enumerate(old):
    if value=='--extern' and old[i+1].startswith('druid_rdbc='):
        cmd.extend([value,old[i+1]])
    if value=='-L':cmd.extend([value,old[i+1]])
log=d/'compile.log'
with log.open('xb') as output:
    r=subprocess.run(cmd,stdout=output,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
text=log.read_text(encoding='utf-8')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
s=dict(terminal=True,exit_code=r.returncode,semantic_red=r.returncode!=0 and 'E0599' in text and 'into_stream' in text,command=cmd,source_sha256=sha(source),log_sha256=sha(log),production_applied=False)
(d/'summary.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
print(json.dumps(s),flush=True)
assert s['semantic_red']
