use druid_rdbc::result_set::{ColumnIndex, ResultSet, ResultSetExt};
pub fn stream(cursor: Box<dyn ResultSet>) {
    let _stream = cursor.into_stream(|rows| rows.int(ColumnIndex::new(1)?));
}
