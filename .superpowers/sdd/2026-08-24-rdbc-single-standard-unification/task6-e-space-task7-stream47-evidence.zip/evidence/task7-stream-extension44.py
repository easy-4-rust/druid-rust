import hashlib
import json
from pathlib import Path
import shutil
import subprocess

b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
w=b/'task7-async-stream-candidate35/workspace'
d=b/'task7-stream-extension44'
d.mkdir(exist_ok=False)
prior=json.loads((b/'task7-stream-cargo41/summary.json').read_text(encoding='utf-8'))
assert prior['terminal'] and prior['exit_code']==0 and not prior['changed_inputs']
red=json.loads((b/'task7-stream-extension-red43/summary.json').read_text(encoding='utf-8'))
assert red['semantic_red']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before={}
def change(rel, fn):
    p=w/rel
    before[rel]=sha(p) if p.exists() else None
    if p.exists():
        dest=d/'before'/rel
        dest.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(p,dest)
        text=p.read_text(encoding='utf-8')
    else:text=''
    with p.open('w',encoding='utf-8',newline='\n') as f:f.write(fn(text))

method=r'''    /// 将唯一拥有的标准游标转换为按需 Stream，每次轮询至多推进一行。
    /// 参数 map 在当前行上生成拥有所有权的输出；返回 Send Stream，不要求游标 Sync。
    /// EOF、读取或映射失败会等待 close；错误优先保留原读取/映射错误。
    /// 提前丢弃 Stream 会丢弃其拥有的游标，具体驱动负责在 Drop 中监管异步释放。
    /// 对应 Java: java.sql.ResultSet#next/close 的 Rust 异步消费扩展。
    fn into_stream<T, F>(self: Box<Self>, mut map: F) -> std::pin::Pin<Box<dyn futures::Stream<Item = Result<T, RdbcError>> + Send>>
    where
        T: Send + 'static,
        F: FnMut(&Self) -> Result<T, RdbcError> + Send + 'static,
    {
        Box::pin(futures::stream::try_unfold((self, map), |(mut cursor, mut map)| async move {
            match cursor.next().await {
                Ok(true) => match map(cursor.as_ref()) {
                    Ok(value) => Ok(Some((value, (cursor, map)))),
                    Err(error) => {
                        let _ = cursor.close().await;
                        Err(error)
                    }
                },
                Ok(false) => {
                    cursor.close().await?;
                    Ok(None)
                }
                Err(error) => {
                    let _ = cursor.close().await;
                    Err(error)
                }
            }
        }))
    }

'''
# map is mutated inside unfolding state, not before it is moved there.
method=method.replace('self: Box<Self>, mut map: F','self: Box<Self>, map: F')
change('crates/druid-rdbc/src/result_set/result_set_ext.rs',lambda s:s.replace('pub trait ResultSetExt: ResultSet {\n','pub trait ResultSetExt: ResultSet {\n'+method,1))
change('crates/druid-rdbc/Cargo.toml',lambda s:s.replace('async-trait.workspace = true\n','async-trait.workspace = true\nfutures.workspace = true\n',1))
def lock_update(s):
    start=s.index('name = "druid-rdbc"\n')
    end=s.index('[[package]]',start)
    block=s[start:end]
    assert ' "futures",' not in block and ' "chrono",\n' in block
    block=block.replace(' "chrono",\n',' "chrono",\n "futures",\n',1)
    return s[:start]+block+s[end:]
change('Cargo.lock',lock_update)
change('crates/druid-wrapper/tests/async_result_set_test.rs',lambda s:s+(b/'task7-stream-extra-contract42.rs').read_text(encoding='utf-8')+r'''

#[tokio::test]
async fn owning_stream_maps_rows_and_early_drop_releases_same_physical_connection() {
    use futures::StreamExt;
    let mut connection = SqlxConnectionAdapter::connect("sqlite::memory:").await.unwrap();
    let mut statement = connection.create_statement(StatementOptions::default()).await.unwrap();
    statement.set_fetch_size(1).unwrap();
    let cursor = statement.execute_query(ROWS).await.unwrap();
    let mut stream = cursor.into_stream(|row| row.int(ColumnIndex::new(1)?));
    assert_eq!(stream.next().await.unwrap().unwrap(), 1);
    assert_eq!(stream.next().await.unwrap().unwrap(), 2);
    drop(stream);
    tokio::time::timeout(Duration::from_secs(5), connection.exec("CREATE TABLE after_stream_drop(id INTEGER)", vec![])).await.unwrap().unwrap();
    connection.close().await.unwrap();
}
''')
change('crates/druid-rdbc/tests/result_set_stream_test.rs',lambda _:r'''use druid_rdbc::error::RdbcError;
use druid_rdbc::result_set::{ColumnIndex, ResultSet, ResultSetExt};
use druid_rdbc::types::Value;
use futures::StreamExt;
use std::cell::Cell;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::Arc;

/// 记录真实标准游标调用的 Send 非 Sync 外部实现，用于检验扩展所有权与关闭顺序。
/// 对应 Java: java.sql.ResultSet 的外部驱动实现合同。
struct StreamContractCursor {
    next_calls: Arc<AtomicUsize>,
    closes: Arc<AtomicUsize>,
    drops: Arc<AtomicUsize>,
    index: Cell<usize>,
    fail_read: bool,
    fail_close: bool,
}

druid_rdbc::impl_standard_wrapper!(StreamContractCursor => ResultSet);

impl Drop for StreamContractCursor {
    fn drop(&mut self) { self.drops.fetch_add(1, Ordering::SeqCst); }
}

#[async_trait::async_trait]
impl ResultSet for StreamContractCursor {
    async fn next(&mut self) -> Result<bool, RdbcError> {
        self.next_calls.fetch_add(1, Ordering::SeqCst);
        if self.fail_read { return Err(RdbcError::InvalidArgument("read-primary".to_owned())); }
        self.index.set(self.index.get()+1);
        Ok(self.index.get() <= 2)
    }
    fn value(&self, _: ColumnIndex) -> Result<Value, RdbcError> { Ok(Value::Int(self.index.get() as i64)) }
    async fn close(&mut self) -> Result<(), RdbcError> {
        self.closes.fetch_add(1, Ordering::SeqCst);
        if self.fail_close { Err(RdbcError::InvalidArgument("close-secondary".to_owned())) } else { Ok(()) }
    }
}

fn cursor(fail_read: bool, fail_close: bool) -> (Box<dyn ResultSet>, Arc<AtomicUsize>, Arc<AtomicUsize>, Arc<AtomicUsize>) {
    let next = Arc::new(AtomicUsize::new(0));
    let closes = Arc::new(AtomicUsize::new(0));
    let drops = Arc::new(AtomicUsize::new(0));
    let cursor = StreamContractCursor { next_calls: Arc::clone(&next), closes: Arc::clone(&closes), drops: Arc::clone(&drops), index: Cell::new(0), fail_read, fail_close };
    (Box::new(cursor), next, closes, drops)
}

#[tokio::test]
async fn standard_trait_object_stream_is_lazy_send_and_drops_owned_cursor() {
    let (cursor, next, closes, drops) = cursor(false, false);
    let mut stream = cursor.into_stream(|row| row.int(ColumnIndex::new(1)?));
    fn assert_send<T: Send>(_: &T) {}
    assert_send(&stream);
    assert_eq!(next.load(Ordering::SeqCst), 0);
    assert_eq!(stream.next().await.unwrap().unwrap(), 1);
    assert_eq!(next.load(Ordering::SeqCst), 1);
    drop(stream);
    assert_eq!(drops.load(Ordering::SeqCst), 1);
    assert_eq!(closes.load(Ordering::SeqCst), 0, "generic Drop cannot await driver close");
}

#[tokio::test]
async fn stream_eof_closes_exactly_once_and_never_repolls_cursor() {
    let (cursor, next, closes, drops) = cursor(false, false);
    let mut stream = cursor.into_stream(|row| row.int(ColumnIndex::new(1)?));
    assert_eq!(stream.next().await.unwrap().unwrap(), 1);
    assert_eq!(stream.next().await.unwrap().unwrap(), 2);
    assert!(stream.next().await.is_none());
    assert!(stream.next().await.is_none());
    assert_eq!(next.load(Ordering::SeqCst), 3);
    assert_eq!(closes.load(Ordering::SeqCst), 1);
    assert_eq!(drops.load(Ordering::SeqCst), 1);
}

#[tokio::test]
async fn stream_read_error_is_preserved_over_cleanup_error() {
    let (cursor, next, closes, _) = cursor(true, true);
    let mut stream = cursor.into_stream(|row| row.int(ColumnIndex::new(1)?));
    let error = stream.next().await.unwrap().unwrap_err();
    assert!(error.to_string().contains("read-primary"));
    assert_eq!(next.load(Ordering::SeqCst), 1);
    assert_eq!(closes.load(Ordering::SeqCst), 1);
    assert!(stream.next().await.is_none());
}

#[tokio::test]
async fn stream_map_error_is_preserved_over_cleanup_error() {
    let (cursor, next, closes, _) = cursor(false, true);
    let mut stream = cursor.into_stream(|_| Err::<i32,_>(RdbcError::InvalidArgument("map-primary".to_owned())));
    assert!(stream.next().await.unwrap().unwrap_err().to_string().contains("map-primary"));
    assert_eq!(next.load(Ordering::SeqCst), 1);
    assert_eq!(closes.load(Ordering::SeqCst), 1);
    assert!(stream.next().await.is_none());
}

#[tokio::test]
async fn stream_eof_reports_cleanup_error_when_no_primary_error_exists() {
    let (cursor, _, closes, _) = cursor(false, true);
    let mut stream = cursor.into_stream(|row| row.int(ColumnIndex::new(1)?));
    stream.next().await.unwrap().unwrap();
    stream.next().await.unwrap().unwrap();
    assert!(stream.next().await.unwrap().unwrap_err().to_string().contains("close-secondary"));
    assert_eq!(closes.load(Ordering::SeqCst), 1);
    assert!(stream.next().await.is_none());
}
''')
paths=list(before)+list(json.loads((b/'task7-stream-implementation40/summary.json').read_text(encoding='utf-8'))['after'])
cmd=['C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin/rustfmt.exe','--edition','2021']+[str(w/r) for r in paths if r.endswith('.rs')]
r=subprocess.run(cmd,cwd=w,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(d/'rustfmt.log').write_bytes(r.stdout)
assert r.returncode==0
(d/'summary.json').write_text(json.dumps(dict(production_applied=False,before=before,after={r:sha(w/r) for r in paths}),indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(changed=len(paths),production_applied=False)),flush=True)
