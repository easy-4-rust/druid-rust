import hashlib
import json
from pathlib import Path
import shutil

b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
w=b/'task7-async-stream-candidate35/workspace'
d=b/'task7-stream-implementation40'
d.mkdir(exist_ok=False)
red=json.loads((b/'task7-async-cargo-red39/summary.json').read_text(encoding='utf-8'))
assert red['terminal'] and red['semantic_red']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before={}
def edit(rel, transform):
    p=w/rel
    if p.exists():
        before[rel]=sha(p)
        dest=d/'before'/rel
        dest.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(p,dest)
        text=p.read_text(encoding='utf-8')
    else:
        before[rel]=None
        text=''
    result=transform(text)
    with p.open('w',encoding='utf-8',newline='\n') as f:f.write(result)

request=r'''use druid_rdbc::error::RdbcError;
use druid_rdbc::metadata::ColumnDescriptor;
use druid_rdbc::types::Row;
use futures::{Stream, TryStreamExt};
use tokio::sync::{mpsc, oneshot};

/// 一次标准 next 请求；同一游标最多保存一个未消费响应。
/// 对应 Java: java.sql.ResultSet#next 的异步驱动适配。
pub(super) struct SqlxCursorRequest {
    pub(super) reply: oneshot::Sender<Result<Option<Row>, RdbcError>>,
}

impl SqlxCursorRequest {
    /// 在持有同一物理连接的任务内按需推进；无请求时绝不轮询 SQLx stream。
    /// 参数为列描述、启动响应、容量为一的请求通道及驱动流；返回结束或驱动错误。
    pub(super) async fn serve<S>(
        columns: Vec<ColumnDescriptor>,
        startup: &mut Option<oneshot::Sender<Result<Vec<ColumnDescriptor>, RdbcError>>>,
        requests: &mut mpsc::Receiver<Self>,
        rows: S,
    ) -> Result<(), RdbcError>
    where
        S: Stream<Item = Result<Row, RdbcError>> + Send,
    {
        if startup.take().is_none_or(|sender| sender.send(Ok(columns)).is_err()) {
            return Ok(());
        }
        futures::pin_mut!(rows);
        while let Some(request) = requests.recv().await {
            let result = rows.try_next().await;
            let terminal = !matches!(result, Ok(Some(_)));
            if request.reply.send(result).is_err() || terminal {
                break;
            }
        }
        Ok(())
    }
}
'''
edit('crates/druid-wrapper/src/sqlx/sqlx_cursor_request.rs',lambda _:request)

cursor=r'''use super::sqlx_connection_actor::SqlxConnectionActor;
use super::sqlx_cursor_request::SqlxCursorRequest;
use druid_rdbc::error::{RdbcError, SqlWarning};
use druid_rdbc::metadata::{ResultSetMetaData, ResultSetMetaDataSnapshot};
use druid_rdbc::result_set::{ColumnIndex, ResultSet};
use druid_rdbc::statement::{FetchDirection, ResultSetConcurrency, ResultSetHoldability, ResultSetType, StatementOptions};
use druid_rdbc::types::{Row, Value};
use std::cell::Cell;
use std::sync::Arc;
use tokio::sync::{mpsc, oneshot, watch};
use tokio::task::JoinHandle;

/// 独占标准 SQLx 异步前向游标；当前行及一个待接收响应占用有界空间。
/// 对应 Java: java.sql.ResultSet。物理连接始终由同一 actor 的任务持有。
pub(crate) struct SqlxAsyncResultSet {
    actor: Arc<SqlxConnectionActor>,
    metadata: Option<Arc<ResultSetMetaDataSnapshot>>,
    requests: Option<mpsc::Sender<SqlxCursorRequest>>,
    pending: Option<oneshot::Receiver<Result<Option<Row>, RdbcError>>>,
    shutdown: watch::Sender<bool>,
    worker: Option<JoinHandle<()>>,
    current: Option<Row>,
    was_null: Cell<bool>,
    row_number: i32,
    finished: bool,
    closed: bool,
    fetch_size: i32,
    direction: FetchDirection,
    options: StatementOptions,
}

impl SqlxAsyncResultSet {
    /// 创建受监管游标；参数为同一连接 actor、SQL、绑定值和标准选项。
    /// 返回仅完成元数据准备的结果集；取消创建 future 会触发 Drop 清理。
    pub(crate) async fn open(
        actor: Arc<SqlxConnectionActor>,
        sql: String,
        values: Vec<Value>,
        options: StatementOptions,
        fetch_size: i32,
    ) -> Result<Box<dyn ResultSet>, RdbcError> {
        let (requests, receiver) = mpsc::channel(1);
        let (startup, ready) = oneshot::channel();
        let (shutdown, stop) = watch::channel(false);
        let worker = actor.spawn_cursor(sql, values, receiver, startup, stop);
        // 在第一个 await 之前建立拥有 worker 的守卫，避免创建被取消后泄漏连接锁。
        let mut cursor = Self {
            actor, metadata: None, requests: Some(requests), pending: None,
            shutdown, worker: Some(worker), current: None, was_null: Cell::new(false),
            row_number: 0, finished: false, closed: false, fetch_size,
            direction: FetchDirection::Forward, options,
        };
        let columns = ready.await.map_err(|_| RdbcError::ConnectionDiscarded)??;
        cursor.metadata = Some(Arc::new(ResultSetMetaDataSnapshot::new(columns)));
        Ok(Box::new(cursor))
    }

    fn ensure_open(&self) -> Result<(), RdbcError> {
        if self.closed || self.actor.is_closed() {
            Err(RdbcError::ConnectionDiscarded)
        } else {
            Ok(())
        }
    }
}

impl Drop for SqlxAsyncResultSet {
    fn drop(&mut self) {
        self.shutdown.send_replace(true);
        self.requests.take();
    }
}

druid_rdbc::impl_standard_wrapper!(SqlxAsyncResultSet => ResultSet);

#[async_trait::async_trait]
impl ResultSet for SqlxAsyncResultSet {
    async fn next(&mut self) -> Result<bool, RdbcError> {
        self.ensure_open()?;
        if self.finished { return Ok(false); }
        if self.pending.is_none() {
            let (reply, pending) = oneshot::channel();
            self.requests.as_ref().ok_or(RdbcError::ConnectionDiscarded)?
                .try_send(SqlxCursorRequest { reply })
                .map_err(|_| RdbcError::ConnectionDiscarded)?;
            // 请求接纳与保存响应之间没有 await；取消 next 不会遗失尚未读到的行。
            self.pending = Some(pending);
        }
        let result = self.pending.as_mut().ok_or(RdbcError::ConnectionDiscarded)?
            .await.map_err(|_| RdbcError::ConnectionDiscarded);
        self.pending.take();
        self.was_null.set(false);
        self.current = None;
        match result.and_then(std::convert::identity) {
            Ok(Some(row)) => {
                self.row_number = self.row_number.checked_add(1).ok_or_else(||
                    RdbcError::InvalidArgument("row exceeds JDBC i32".to_owned()))?;
                self.current = Some(row);
                self.actor.task4_trace_result_next();
                Ok(true)
            }
            Ok(None) => { self.finished = true; Ok(false) }
            Err(error) => { self.finished = true; Err(error) }
        }
    }

    fn value(&self, column: ColumnIndex) -> Result<Value, RdbcError> {
        self.ensure_open()?;
        let row = self.current.as_ref().ok_or_else(||
            RdbcError::InvalidArgument("result set is not on a row".to_owned()))?;
        let value = row.get(column.get() - 1).cloned().ok_or_else(||
            RdbcError::InvalidArgument(format!("column {} is out of range", column.get())))?;
        self.was_null.set(matches!(value, Value::Null));
        Ok(value)
    }

    fn row(&self) -> Result<i32, RdbcError> {
        self.ensure_open()?;
        Ok(if self.current.is_some() { self.row_number } else { 0 })
    }

    fn find_column(&self, label: &str) -> Result<ColumnIndex, RdbcError> {
        self.ensure_open()?;
        self.metadata.as_ref().ok_or(RdbcError::ConnectionDiscarded)?
            .columns().iter().position(|column| column.label().eq_ignore_ascii_case(label))
            .map(|index| ColumnIndex::new(index + 1)).transpose()?
            .ok_or_else(|| RdbcError::InvalidArgument(format!("unknown column: {label}")))
    }

    fn meta_data(&self) -> Result<Arc<dyn ResultSetMetaData>, RdbcError> {
        self.ensure_open()?;
        self.actor.task4_trace_result_set_metadata();
        let metadata = self.metadata.as_ref().ok_or(RdbcError::ConnectionDiscarded)?;
        Ok(Arc::clone(metadata) as Arc<dyn ResultSetMetaData>)
    }

    fn was_null(&self) -> Result<bool, RdbcError> { self.ensure_open()?; Ok(self.was_null.get()) }
    fn result_set_type(&self) -> Result<ResultSetType, RdbcError> { self.ensure_open()?; Ok(ResultSetType::ForwardOnly) }
    fn concurrency(&self) -> Result<ResultSetConcurrency, RdbcError> { self.ensure_open()?; Ok(self.options.concurrency()) }
    fn holdability(&self) -> Result<ResultSetHoldability, RdbcError> { self.ensure_open()?; Ok(self.options.holdability()) }
    fn fetch_size(&self) -> Result<i32, RdbcError> { self.ensure_open()?; Ok(self.fetch_size) }
    fn set_fetch_size(&mut self, size: i32) -> Result<(), RdbcError> {
        self.ensure_open()?;
        if size < 0 { return Err(RdbcError::InvalidArgument("fetch size must not be negative".to_owned())); }
        self.fetch_size = size;
        Ok(())
    }
    fn fetch_direction(&self) -> Result<FetchDirection, RdbcError> { self.ensure_open()?; Ok(self.direction) }
    fn set_fetch_direction(&mut self, direction: FetchDirection) -> Result<(), RdbcError> {
        self.ensure_open()?;
        if !matches!(direction, FetchDirection::Forward | FetchDirection::Unknown) {
            return Err(RdbcError::feature_not_supported("sqlx_async_fetch_direction"));
        }
        self.direction = direction;
        Ok(())
    }
    fn warnings(&self) -> Result<Option<SqlWarning>, RdbcError> { self.ensure_open()?; Ok(None) }
    fn clear_warnings(&mut self) -> Result<(), RdbcError> { self.ensure_open() }

    async fn close(&mut self) -> Result<(), RdbcError> {
        self.closed = true;
        self.current = None;
        self.pending.take();
        self.shutdown.send_replace(true);
        self.requests.take();
        if let Some(worker) = self.worker.as_mut() {
            // 通过可变引用等待；close 被取消后，后继 close 仍可等待原清理任务。
            worker.await.map_err(|error| RdbcError::InvalidArgument(format!("SQLx cursor worker failed: {error}")))?;
        }
        self.worker.take();
        Ok(())
    }

    fn is_closed(&self) -> Result<bool, RdbcError> { Ok(self.closed || self.actor.is_closed()) }
}
'''
edit('crates/druid-wrapper/src/sqlx/sqlx_async_result_set.rs',lambda _:cursor)
edit('crates/druid-wrapper/src/sqlx/mod.rs',lambda s:s+'\nmod sqlx_async_result_set;\nmod sqlx_cursor_request;\n')

def actor(s):
    s=s.replace('use tokio::sync::Mutex;', 'use tokio::sync::{mpsc, oneshot, watch, Mutex};\nuse super::sqlx_cursor_request::SqlxCursorRequest;\nuse super::sqlx_async_result_set::SqlxAsyncResultSet;\nuse druid_rdbc::statement::StatementOptions;')
    s=s.replace('    closed: AtomicBool,','    closed: AtomicBool,\n    cursor_shutdown: watch::Sender<bool>,',1)
    s=s.replace('            closed: AtomicBool::new(false),','            closed: AtomicBool::new(false),\n            cursor_shutdown: watch::channel(false).0,',1)
    s=s.replace('if self.closed.load(Ordering::Acquire) {','if self.is_closed() {',1)
    mark='    pub(crate) fn result_set_core('
    new=r'''    /// 通过同一 actor 的物理连接创建按需游标；返回元数据准备后的标准结果集。
    pub(crate) async fn execute_async_query(
        self: &Arc<Self>, sql: &str, values: Vec<Value>, options: StatementOptions, fetch_size: i32,
    ) -> Result<Box<dyn ResultSet>, RdbcError> {
        self.ensure_open_core()?;
        SqlxAsyncResultSet::open(Arc::clone(self), sql.to_owned(), values, options, fetch_size).await
    }

    /// 启动受父连接及游标关闭信号监管的唯一 raw cursor 任务。
    pub(super) fn spawn_cursor(
        self: &Arc<Self>, sql: String, values: Vec<Value>,
        mut requests: mpsc::Receiver<SqlxCursorRequest>,
        startup: oneshot::Sender<Result<Vec<ColumnDescriptor>, RdbcError>>,
        mut stop: watch::Receiver<bool>,
    ) -> tokio::task::JoinHandle<()> {
        let actor = Arc::clone(self);
        let mut parent_stop = self.cursor_shutdown.subscribe();
        tokio::spawn(async move {
            let mut startup = Some(startup);
            if *stop.borrow() || *parent_stop.borrow() {
                return;
            }
            let outcome = {
                let work = async {
                    let mut connection = actor.connection.lock().await;
                    actor.ensure_open_core()?;
                    connection.serve_cursor_core(&sql, values, &mut startup, &mut requests).await
                };
                tokio::select! {
                    biased;
                    _ = stop.changed() => Err(RdbcError::ConnectionDiscarded),
                    _ = parent_stop.changed() => Err(RdbcError::ConnectionDiscarded),
                    result = work => result,
                }
            };
            if let (Err(error), Some(sender)) = (outcome, startup) {
                let _ = sender.send(Err(error));
            }
        })
    }

'''
    assert mark in s
    s=s.replace(mark,new+mark,1)
    close='''        let mut connection = self.connection.lock().await;
        if self.closed.load(Ordering::Acquire) {
            return Ok(());
        }
        connection.close_connection_core().await?;'''
    assert close in s
    s=s.replace(close,'''        // 先通知持有连接锁的游标退出，再等待锁；避免父关闭与空闲游标互等。
        self.cursor_shutdown.send_replace(true);
'''+close,1)
    s=s.replace('''    pub(crate) fn is_closed(&self) -> bool {
        self.closed.load(Ordering::Acquire)
''','''    pub(crate) fn is_closed(&self) -> bool {
        self.closed.load(Ordering::Acquire) || *self.cursor_shutdown.borrow()
''')
    return s
edit('crates/druid-wrapper/src/sqlx/sqlx_connection_actor.rs',actor)

def adapter(s):
    # Reuse each backend's exact prepare, column and value mapping. Replace only fetch_all with demand service.
    start=s.index('    pub(super) async fn fetch_rows_with_labels(')
    end=s.index('    pub(super) async fn standard_parameter_count_core(',start)
    old=s[start:end]
    new=old.replace('fetch_rows_with_labels','serve_cursor_core',1)
    new=new.replace('''        params: Vec<Value>,
    ) -> Result<(Vec<Row>, Vec<ColumnDescriptor>), RdbcError> {''','''        params: Vec<Value>,
        startup: &mut Option<tokio::sync::oneshot::Sender<Result<Vec<ColumnDescriptor>, RdbcError>>>,
        requests: &mut tokio::sync::mpsc::Receiver<super::sqlx_cursor_request::SqlxCursorRequest>,
    ) -> Result<(), RdbcError> {''',1)
    for kind in ['any','mysql','postgresql','sqlite']:
        bind='?' if kind=='any' else ''
        a=f'''                let rows = Self::bind_{kind}_prepared_values(&statement, params){bind}
                    .fetch_all(connection)
                    .await
                    .map_err(Self::driver_error)?;
                let rows = rows
                    .into_iter()
                    .map(Self::decode_{kind}_row)
                    .collect::<Result<Vec<_>, _>>()?;
                Ok((rows, columns))'''
        z=f'''                let rows = Self::bind_{kind}_prepared_values(&statement, params){bind}
                    .fetch(connection);
                let rows = futures::StreamExt::map(rows, |row| {{
                    row.map_err(Self::driver_error).and_then(Self::decode_{kind}_row)
                }});
                super::sqlx_cursor_request::SqlxCursorRequest::serve(columns, startup, requests, rows).await'''
        assert a in new,kind
        new=new.replace(a,z,1)
    return s[:end]+'''    /// 在原物理连接上执行按需读取；驱动自有缓冲与 wrapper 请求容量分别受各自预算约束。
'''+new+s[end:]
edit('crates/druid-wrapper/src/sqlx/sqlx_connection_adapter.rs',adapter)

def prepared(s):
    s=s.replace('    ExecutionResult, FetchDirection, GeneratedKeys, PreparedParameter, StatementOptions,','    ExecutionResult, FetchDirection, GeneratedKeys, PreparedParameter, ResultSetType, StatementOptions,')
    marker='    /// 执行准备查询并更新本次生成键；无插入行时清除上次键。'
    helper=r'''    /// 正 fetch hint 的前向查询使用按需游标；其他调用保留原缓冲行为。
    async fn execute_query_values(
        &self, actor: &Arc<SqlxConnectionActor>, sql: &str, values: Vec<Value>, allow_stream: bool,
    ) -> Result<Box<dyn druid_rdbc::result_set::ResultSet>, RdbcError> {
        let fetch_size = self.fetch_size.load(Ordering::Acquire);
        if allow_stream && fetch_size > 0 && self.options.result_set_type() == ResultSetType::ForwardOnly {
            self.bounded(actor.execute_async_query(sql, values, self.options, fetch_size)).await
        } else {
            self.bounded(actor.execute_query(sql, values)).await
        }
    }

'''
    assert marker in s
    s=s.replace(marker,helper+marker,1)
    s=s.replace('''        values: Vec<Value>,
    ) -> Result<Box<dyn druid_rdbc::result_set::ResultSet>, RdbcError> {
        let (rows, key)''','''        values: Vec<Value>,
        allow_stream: bool,
    ) -> Result<Box<dyn druid_rdbc::result_set::ResultSet>, RdbcError> {
        let (rows, key)''',1)
    s=s.replace('self.bounded(actor.execute_query(&self.sql, values)).await?,','self.execute_query_values(actor, &self.sql, values, allow_stream).await?,',1)
    s=s.replace('self.bounded(actor.execute_query(sql, Vec::new())).await\n','self.execute_query_values(&actor, sql, Vec::new(), true).await\n',1)
    s=s.replace('self.bounded(actor.execute_query(sql, values)).await\n    }\n}', 'self.execute_query_values(&actor, sql, values, true).await\n    }\n}',1)
    s=s.replace('self.execute_prepared_query_values(&actor, values).await?;', 'self.execute_prepared_query_values(&actor, values, true).await?;',1)
    s=s.replace('self.execute_prepared_query_values(&actor, values).await?,', 'self.execute_prepared_query_values(&actor, values, false).await?,',1)
    return s
edit('crates/druid-wrapper/src/sqlx/sqlx_prepared_statement.rs',prepared)
(d/'summary.json').write_text(json.dumps(dict(production_applied=False,red=red,before=before,after={r:sha(w/r) for r in before}),indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(changed=len(before),production_applied=False)))
