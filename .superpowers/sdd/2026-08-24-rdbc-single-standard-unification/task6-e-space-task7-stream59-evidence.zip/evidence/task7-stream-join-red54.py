import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess

b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
w=b/'task7-async-stream-candidate35/workspace'
d=b/'task7-stream-join-red54'
d.mkdir(exist_ok=False)
prior=json.loads((b/'task7-stream-cargo51/summary.json').read_text(encoding='utf-8'))
assert prior['terminal'] and prior['exit_code']==101 and not prior['changed_inputs']
assert 'semicolon_if_nothing_returned' in (b/'task7-stream-cargo51/wrapper-clippy.log').read_text(encoding='utf-8')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before={}
for rel in ['crates/druid-wrapper/tests/async_result_set_test.rs','crates/druid-wrapper/src/sqlx/sqlx_async_result_set.rs','crates/druid-wrapper/src/sqlx/sqlx_async_result_set_test.rs']:
    p=w/rel
    before[rel]=sha(p) if p.exists() else None
    if p.exists():
        dest=d/'before'/rel
        dest.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(p,dest)
        text=p.read_text(encoding='utf-8')
    else:text=''
    if rel.endswith('async_result_set_test.rs') and '/tests/' in rel:
        old='assert_eq!(rows.known_row_count(), Some(200))\n'
        assert text.count(old)==1
        text=text.replace(old,'assert_eq!(rows.known_row_count(), Some(200));\n')
    elif rel.endswith('sqlx_async_result_set.rs'):
        text+='\n#[cfg(test)]\n#[path = "sqlx_async_result_set_test.rs"]\nmod tests;\n'
    else:
        text=(b/'task7-stream-worker-join-contract53.rs').read_text(encoding='utf-8')
    p.write_text(text,encoding='utf-8',newline='\n')
tool='C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin'
r=subprocess.run([tool+'/rustfmt.exe','--edition','2021']+[str(w/r) for r in before],stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(d/'rustfmt.log').write_bytes(r.stdout)
assert r.returncode==0
frozen={p.relative_to(w).as_posix():sha(p) for p in w.rglob('*') if p.is_file() and (p.suffix in ['.rs','.toml','.json','.inc'] or p.name=='Cargo.lock')}
(d/'frozen-inputs.json').write_text(json.dumps(frozen,indent=2)+'\n',encoding='utf-8')
env=os.environ.copy()
env.update(RUSTC=tool+'/rustc.exe',RUSTDOC=tool+'/rustdoc.exe',RUSTUP_TOOLCHAIN='1.97.1-x86_64-pc-windows-msvc',RUSTUP_AUTO_INSTALL='0',PATH=tool+os.pathsep+env['PATH'],CARGO_TARGET_DIR='F:/codex_build_cache/druid_rust/task7_standard_cargo13_1971',CARGO_BUILD_JOBS='1',TMP='F:/codex_tmp/task7_standard_cargo13',TEMP='F:/codex_tmp/task7_standard_cargo13')
s=dict(terminal=False,production_applied=False,before=before,commands=[])
def save():(d/'summary.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
save()
for name,args in [('wrapper-clippy-retry',['clippy','-p','druid-wrapper','--test','async_result_set_test','--locked','--offline','-j1','--','-D','warnings']),('join-red',['test','-p','druid-wrapper','--lib','failed_cursor_worker_is_joined_once','--locked','--offline','-j1','--','--test-threads=1'])]:
    cmd=[tool+'/cargo.exe']+args
    log=d/(name+'.log')
    with log.open('xb') as output:r=subprocess.run(cmd,cwd=w,env=env,stdout=output,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
    text=log.read_text(encoding='utf-8')
    s['commands'].append(dict(name=name,command=cmd,exit_code=r.returncode,log=str(log),sha256=sha(log),results=re.findall(r'^test result: .*?(\d+) passed; (\d+) failed; (\d+) ignored;',text,re.M)))
    save()
    print(json.dumps(dict(name=name,exit_code=r.returncode,results=s['commands'][-1]['results'])),flush=True)
    if name=='wrapper-clippy-retry' and r.returncode:break
s.update(terminal=True,exit_code=r.returncode,semantic_red=name=='join-red' and r.returncode!=0 and 'a completed JoinHandle must not be polled a second time' in text and bool(s['commands'][-1]['results']),changed_inputs=[r for r,h in frozen.items() if sha(w/r)!=h])
save()
print(json.dumps({k:s[k] for k in ['terminal','exit_code','semantic_red','changed_inputs']}),flush=True)
