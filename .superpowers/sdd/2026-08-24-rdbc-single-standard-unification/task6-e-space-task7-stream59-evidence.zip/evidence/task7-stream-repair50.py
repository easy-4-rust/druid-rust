import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess

b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
w=b/'task7-async-stream-candidate35/workspace'
d=b/'task7-stream-repair50'
d.mkdir(exist_ok=False)
old=json.loads((b/'task7-stream-cargo45/summary.json').read_text(encoding='utf-8'))
assert old['terminal'] and old['exit_code']==101 and not old['changed_inputs']
log=(b/'task7-stream-cargo45/wrapper-stream.log').read_text(encoding='utf-8')
assert 'CloseCursorsAtCommit' in log and 'E0599' in log
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
changes={}
for rel in ['crates/druid-wrapper/tests/async_result_set_test.rs','crates/druid-wrapper/src/sqlx/mod.rs','crates/druid-wrapper/src/sqlx/sqlx_cursor_request_test.rs']:
    p=w/rel
    before=sha(p) if p.exists() else None
    if p.exists():
        target=d/'before'/rel
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(p,target)
    if rel.endswith('async_result_set_test.rs'):
        text=p.read_text(encoding='utf-8')
        names=re.findall(r'async fn (\w+)\(',text)
        assert len(names)==10
        assert text.count('CloseCursorsAtCommit')==1
        text=text.replace('CloseCursorsAtCommit','CloseAtCommit')
        text+='\n'+(b/'task7-stream-extra-contract49.rs').read_text(encoding='utf-8')
        assert re.findall(r'async fn (\w+)\(',text)[:10]==names
    elif rel.endswith('mod.rs'):
        text=p.read_text(encoding='utf-8')+'\n#[cfg(test)]\nmod sqlx_cursor_request_test;\n'
    else:
        text=(b/'task7-sqlx-cursor-demand-test48.rs').read_text(encoding='utf-8')
        text=text.replace('requests.try_send(SqlxCursorRequest { reply }).unwrap();','assert!(requests.try_send(SqlxCursorRequest { reply }).is_ok());')
    p.write_text(text,encoding='utf-8',newline='\n')
    changes[rel]=dict(before_sha256=before)
cmd=['C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin/rustfmt.exe','--edition','2021']+[str(w/r) for r in changes]
result=subprocess.run(cmd,cwd=w,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(d/'rustfmt.log').write_bytes(result.stdout)
assert result.returncode==0
for rel in changes:changes[rel]['after_sha256']=sha(w/rel)
(d/'summary.json').write_text(json.dumps(dict(production_applied=False,fixture_error='Enum name should be actual CloseAtCommit; original compile failure retained, not semantic RED.',changes=changes),indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(changes=len(changes),wrapper_contracts=13,demand_contracts=1)),flush=True)
