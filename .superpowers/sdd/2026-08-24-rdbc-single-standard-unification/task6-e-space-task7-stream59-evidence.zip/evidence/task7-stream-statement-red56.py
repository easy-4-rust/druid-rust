import json
from pathlib import Path
import runpy
import shutil
import subprocess

b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
old=json.loads((b/'task7-stream-join-red54/summary.json').read_text(encoding='utf-8'))
assert old['terminal'] and old['semantic_red'] and not old['changed_inputs']
w=b/'task7-async-stream-candidate35/workspace'
p=w/'crates/druid-wrapper/tests/async_result_set_test.rs'
shutil.copyfile(p,b/'task7-stream-statement-red56-before.rs')
with p.open('a',encoding='utf-8',newline='\n') as f:f.write((b/'task7-stream-statement-close-contract55.rs').read_text(encoding='utf-8'))
result=subprocess.run(['C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin/rustfmt.exe','--edition','2021',str(p)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
assert result.returncode==0,result.stdout
runner=(b/'task7-stream-cargo41.py').read_text(encoding='utf-8').replace("d=b/'task7-stream-cargo41'","d=b/'task7-stream-statement-red56'").replace("log=d/'cargo41.log'","log=d/'cargo56.log'")
path=b/'task7-stream-statement-red56-runner.py'
path.write_text(runner,encoding='utf-8',newline='\n')
runpy.run_path(str(path),run_name='__main__')
