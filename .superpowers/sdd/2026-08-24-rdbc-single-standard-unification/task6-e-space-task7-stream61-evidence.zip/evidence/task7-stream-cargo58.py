import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
w=b/'task7-async-stream-candidate35/workspace'
d=b/'task7-stream-cargo58'
d.mkdir(exist_ok=False)
tool='C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin'
env=os.environ.copy()
env.update(RUSTC=tool+'/rustc.exe',RUSTDOC=tool+'/rustdoc.exe',RUSTUP_TOOLCHAIN='1.97.1-x86_64-pc-windows-msvc',RUSTUP_AUTO_INSTALL='0',PATH=tool+os.pathsep+env['PATH'],CARGO_TARGET_DIR='F:/codex_build_cache/druid_rust/task7_standard_cargo13_1971',CARGO_BUILD_JOBS='1',TMP='F:/codex_tmp/task7_standard_cargo13',TEMP='F:/codex_tmp/task7_standard_cargo13')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths=[p for p in w.rglob('*') if p.is_file() and (p.suffix in ['.rs','.toml','.json','.inc'] or p.name=='Cargo.lock')]
frozen={p.relative_to(w).as_posix():sha(p) for p in paths}
(d/'frozen-inputs.json').write_text(json.dumps(frozen,indent=2)+'\n',encoding='utf-8')
s=dict(terminal=False,production_applied=False,commands=[])
def save(): (d/'summary.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
save()
for name, action, package, target in [
    ('demand-bound','test','druid-wrapper',None),
    ('wrapper-stream','test','druid-wrapper','async_result_set_test'),
    ('rdbc-clippy','clippy','druid-rdbc','result_set_stream_test'),
    ('wrapper-clippy','clippy','druid-wrapper','async_result_set_test'),
]:
    cmd=[tool+'/cargo.exe',action,'-p',package]+(['--test',target] if target else ['--lib'])+['--locked','--offline','-j1','--']
    cmd+=['--test-threads=1'] if action=='test' else ['-D','warnings']
    log=d/(name+'.log')
    with log.open('xb') as output:
        r=subprocess.run(cmd,cwd=w,env=env,stdout=output,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
    text=log.read_text(encoding='utf-8')
    s['commands'].append(dict(name=name,command=cmd,exit_code=r.returncode,log=str(log),sha256=sha(log),results=re.findall(r'^test result: .*?(\d+) passed; (\d+) failed; (\d+) ignored;',text,re.M)))
    save()
    print(json.dumps(dict(name=name,exit_code=r.returncode,results=s['commands'][-1]['results'])),flush=True)
    if r.returncode:break
s.update(terminal=True,exit_code=r.returncode,changed_inputs=[r for r,h in frozen.items() if sha(w/r)!=h])
save()
print(json.dumps(dict(terminal=True,exit_code=s['exit_code'],changed_inputs=s['changed_inputs'])),flush=True)
