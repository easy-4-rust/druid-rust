import hashlib
import json
from pathlib import Path
import shutil
import subprocess

b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
w=b/'task7-async-stream-candidate35/workspace'
d=b/'task7-stream-lifecycle-repair57'
old=json.loads((b/'task7-stream-statement-red56/summary.json').read_text(encoding='utf-8'))
assert old['terminal'] and old['exit_code']==101 and not old['changed_inputs']
log=(b/'task7-stream-statement-red56/cargo56.log').read_text(encoding='utf-8')
assert 'statement close must invalidate its live result set' in log and 'dropping the statement must invalidate its owned stream' in log
d.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
changes={}
def edit(rel,fn):
    p=w/rel
    target=d/'before'/rel
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(p,target)
    text=p.read_text(encoding='utf-8')
    p.write_text(fn(text),encoding='utf-8',newline='\n')
    changes[rel]=dict(before_sha256=sha(target),after_sha256=sha(p))

def cursor(s):
    s=s.replace('    shutdown: watch::Sender<bool>,','    shutdown: watch::Sender<bool>,\n    statement_stop: watch::Receiver<bool>,',1)
    s=s.replace('''        fetch_size: i32,
    ) -> Result<Box<dyn ResultSet>, RdbcError> {''','''        fetch_size: i32,
        statement_stop: watch::Receiver<bool>,
    ) -> Result<Box<dyn ResultSet>, RdbcError> {''',1)
    s=s.replace('actor.spawn_cursor(sql, values, receiver, startup, stop);','actor.spawn_cursor(sql, values, receiver, startup, stop, statement_stop.clone());',1)
    s=s.replace('            shutdown,\n','            shutdown,\n            statement_stop,\n',1)
    s=s.replace('''        if self.closed || self.actor.is_closed() {''','''        if self.closed || self.actor.is_closed() || *self.statement_stop.borrow() || self.statement_stop.has_changed().is_err() {''',1)
    a='''        if let Some(worker) = self.worker.as_mut() {
            // 通过可变引用等待；close 被取消后，后继 close 仍可等待原清理任务。
            worker.await.map_err(|error| {
                RdbcError::InvalidArgument(format!("SQLx cursor worker failed: {error}"))
            })?;
        }
        self.worker.take();
        Ok(())'''
    z='''        let outcome = if let Some(worker) = self.worker.as_mut() {
            // 可变引用等待保留取消安全；完成后无论成功或失败都必须移走句柄。
            worker.await.map_err(|error| {
                RdbcError::InvalidArgument(format!("SQLx cursor worker failed: {error}"))
            })
        } else {
            Ok(())
        };
        self.worker.take();
        outcome'''
    assert a in s
    s=s.replace(a,z,1)
    s=s.replace('Ok(self.closed || self.actor.is_closed())','Ok(self.ensure_open().is_err())',1)
    return s
edit('crates/druid-wrapper/src/sqlx/sqlx_async_result_set.rs',cursor)

def actor(s):
    a='''        fetch_size: i32,
    ) -> Result<Box<dyn ResultSet>, RdbcError> {'''
    assert a in s
    s=s.replace(a,'''        fetch_size: i32,
        statement_stop: watch::Receiver<bool>,
    ) -> Result<Box<dyn ResultSet>, RdbcError> {''',1)
    # rustfmt expanded open call; add the last parameter at that exact site.
    a='''            options,
            fetch_size,
        )'''
    assert a in s
    s=s.replace(a,'''            options,
            fetch_size,
            statement_stop,
        )''',1)
    s=s.replace('''        mut stop: watch::Receiver<bool>,
    ) -> tokio::task::JoinHandle<()> {''','''        mut stop: watch::Receiver<bool>,
        mut statement_stop: watch::Receiver<bool>,
    ) -> tokio::task::JoinHandle<()> {''',1)
    s=s.replace('''            if *stop.borrow() || *parent_stop.borrow() {''','''            if *stop.borrow() || *parent_stop.borrow() || *statement_stop.borrow() || statement_stop.has_changed().is_err() {''',1)
    s=s.replace('''                    _ = parent_stop.changed() => Err(RdbcError::ConnectionDiscarded),''','''                    _ = parent_stop.changed() => Err(RdbcError::ConnectionDiscarded),
                    _ = statement_stop.changed() => Err(RdbcError::ConnectionDiscarded),''',1)
    return s
edit('crates/druid-wrapper/src/sqlx/sqlx_connection_actor.rs',actor)

def statement(s):
    s=s.replace('    closed: AtomicBool,','    closed: AtomicBool,\n    cursor_shutdown: tokio::sync::watch::Sender<bool>,',1)
    s=s.replace('            closed: AtomicBool::new(false),','            closed: AtomicBool::new(false),\n            cursor_shutdown: tokio::sync::watch::channel(false).0,',1)
    a='self.bounded(actor.execute_async_query(sql, values, self.options, fetch_size))'
    assert a in s
    s=s.replace(a,'self.bounded(actor.execute_async_query(sql, values, self.options, fetch_size, self.cursor_shutdown.subscribe()))',1)
    s=s.replace('''    async fn close(&mut self) -> Result<(), RdbcError> {
        self.closed.store(true, Ordering::Release);''','''    async fn close(&mut self) -> Result<(), RdbcError> {
        // 子游标持有同一物理连接；语句关闭或 Sender Drop 都会终止其任务。
        self.cursor_shutdown.send_replace(true);
        self.closed.store(true, Ordering::Release);''',1)
    return s
edit('crates/druid-wrapper/src/sqlx/sqlx_prepared_statement.rs',statement)

def test(s):
    s=s.replace('    let worker = tokio::spawn(', '    let (_statement_shutdown, statement_stop) = watch::channel(false);\n    let worker = tokio::spawn(',1)
    assert '        shutdown,\n' in s
    return s.replace('        shutdown,\n','        shutdown,\n        statement_stop,\n',1)
edit('crates/druid-wrapper/src/sqlx/sqlx_async_result_set_test.rs',test)
r=subprocess.run(['C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin/rustfmt.exe','--edition','2021']+[str(w/r) for r in changes],stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(d/'rustfmt.log').write_bytes(r.stdout)
assert r.returncode==0
for rel in changes:changes[rel]['after_sha256']=sha(w/rel)
(d/'summary.json').write_text(json.dumps(dict(production_applied=False,changes=changes),indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(changes=len(changes),production_applied=False)),flush=True)
