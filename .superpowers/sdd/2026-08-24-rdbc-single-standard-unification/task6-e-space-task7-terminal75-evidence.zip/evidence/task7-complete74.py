import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
w=Path('F:/codex_build_cache/d72')
d=b/'task7-complete74'
d.mkdir(exist_ok=False)
tool='C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin'
env=os.environ.copy()
env.update(RUSTC=tool+'/rustc.exe',RUSTDOC=tool+'/rustdoc.exe',RUSTUP_TOOLCHAIN='1.97.1-x86_64-pc-windows-msvc',RUSTUP_AUTO_INSTALL='0',PATH=tool+os.pathsep+env['PATH'],CARGO_TARGET_DIR='F:/codex_build_cache/druid_rust/task6_lifetime_clean_1971_20261008',CARGO_BUILD_JOBS='1',TMP='F:/codex_tmp/task7_standard_cargo13',TEMP='F:/codex_tmp/task7_standard_cargo13',DRUID_RDBC_EXTERNAL_TARGET_ROOT='F:/codex_build_cache/dr74_ext')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
frozen=json.loads((b/'task7-format73/frozen-inputs.json').read_text(encoding='utf-8'))
assert all(sha(w/rel)==h for rel,h in frozen.items())
(d/'frozen-inputs.json').write_text(json.dumps(frozen,indent=2)+'\n',encoding='utf-8')
s=dict(terminal=False,production_applied=False,workspace=str(w),frozen_input_count=len(frozen),commands=[])
def save(): (d/'summary.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
save()
for name,args in [
    ('rdbc-complete',['test','-p','druid-rdbc','--all-features','--locked','--offline','--no-fail-fast','-j1']),
    ('wrapper-complete',['test','-p','druid-wrapper','--all-features','--locked','--offline','--no-fail-fast','-j1']),
    ('druid-complete',['test','-p','druid','--all-features','--locked','--offline','--no-fail-fast','-j1']),
    ('owner-and-pooled-clippy',['clippy','-p','druid','--test','resource_owner_cancellation_test','--test','task7_pooled_async_result_set_test','--all-features','--locked','--offline','-j1','--','-D','warnings']),
    ('format',['fmt','--all','--','--check']),
]:
    cmd=[tool+'/cargo.exe']+args
    log=d/(name+'.log')
    with log.open('xb') as output:
        r=subprocess.run(cmd,cwd=w,env=env,stdout=output,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
    blocks=re.findall(r'^test result: .*?(\d+) passed; (\d+) failed; (\d+) ignored;',log.read_text(encoding='utf-8'),re.M)
    counts=dict(passed=sum(int(v[0]) for v in blocks),failed=sum(int(v[1]) for v in blocks),ignored=sum(int(v[2]) for v in blocks),blocks=len(blocks))
    changes=[rel for rel,h in frozen.items() if sha(w/rel)!=h]
    s['commands'].append(dict(name=name,command=cmd,exit_code=r.returncode,log=str(log),sha256=sha(log),results=counts,changed_inputs=changes))
    save()
    print(json.dumps(dict(name=name,exit_code=r.returncode,results=counts)),flush=True)
    if r.returncode or changes:break
s.update(terminal=True,exit_code=r.returncode,changed_inputs=[rel for rel,h in frozen.items() if sha(w/rel)!=h])
save()
print(json.dumps({k:s[k] for k in ['terminal','exit_code','changed_inputs']}),flush=True)
