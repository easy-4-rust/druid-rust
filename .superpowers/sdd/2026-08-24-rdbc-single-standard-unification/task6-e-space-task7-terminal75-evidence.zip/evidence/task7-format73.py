import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import zipfile

b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
w=Path('F:/codex_build_cache/d72')
d=b/'task7-format73'
d.mkdir(exist_ok=False)
sha=lambda data:hashlib.sha256(data).hexdigest()
before=json.loads((b/'task7-short-workspace72/frozen-inputs.json').read_text(encoding='utf-8'))
assert all(sha((w/rel).read_bytes())==h for rel,h in before.items())
archive=d/'before.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for rel in before:
        z.write(w/rel,rel)
with zipfile.ZipFile(archive) as z:
    assert all(sha(z.read(rel))==h for rel,h in before.items())
tool='C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin'
env=os.environ.copy()
env.update(RUSTC=tool+'/rustc.exe',RUSTDOC=tool+'/rustdoc.exe',RUSTUP_TOOLCHAIN='1.97.1-x86_64-pc-windows-msvc',RUSTUP_AUTO_INSTALL='0',PATH=tool+os.pathsep+env['PATH'])
commands=[]
for name,args in [('format',['fmt','--all']),('check',['fmt','--all','--','--check'])]:
    cmd=[tool+'/cargo.exe']+args
    log=d/(name+'.log')
    with log.open('xb') as output:
        r=subprocess.run(cmd,cwd=w,env=env,stdout=output,stderr=subprocess.STDOUT)
    commands.append(dict(command=cmd,exit_code=r.returncode,log=str(log),sha256=sha(log.read_bytes())))
    assert r.returncode==0
after={rel:sha((w/rel).read_bytes()) for rel in before}
changed=[rel for rel,h in before.items() if after[rel]!=h]
assert all(rel.endswith('.rs') for rel in changed)
with zipfile.ZipFile(archive) as z:
    for rel in changed:
        old=z.read(rel).decode('utf-8')
        new=(w/rel).read_text(encoding='utf-8')
        identities=lambda value: sorted(re.findall(r'\b(?:async\s+)?fn\s+([A-Za-z_][A-Za-z_0-9]*)\s*\(',value))
        assert identities(old)==identities(new),rel
(d/'frozen-inputs.json').write_text(json.dumps(after,indent=2)+'\n',encoding='utf-8')
s=dict(terminal=True,production_applied=False,workspace=str(w),commands=commands,changed_paths=changed,before_archive_sha256=sha(archive.read_bytes()),all_function_identities_preserved=True,input_count=len(after),other_candidates_unmodified=True)
(d/'summary.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
print(json.dumps(s,indent=2))
