import hashlib
import json
import os
from pathlib import Path
import subprocess

b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
w=b/'task7-external-resource-consumer-candidate1/workspace'
destination=Path('F:/codex_build_cache/d72')
assert not destination.exists()
prior=json.loads((b/'task7-pooled-green69/summary.json').read_text(encoding='utf-8'))
assert prior['terminal'] and prior['exit_code']==0 and not prior['changed_inputs']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs={}
for root,dirs,files in os.walk(w):
    dirs[:]=[name for name in dirs if name not in ['target','.git','.codegraph']]
    for name in files:
        source=Path(root)/name
        rel=source.relative_to(w)
        target=destination/rel
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(source.read_bytes())
        assert sha(source)==sha(target)
        inputs[rel.as_posix()]=sha(source)
d=b/'task7-short-workspace72'
d.mkdir(exist_ok=False)
(d/'frozen-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf-8')
tool='C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin'
env=os.environ.copy()
env.update(RUSTC=tool+'/rustc.exe',RUSTDOC=tool+'/rustdoc.exe',RUSTUP_TOOLCHAIN='1.97.1-x86_64-pc-windows-msvc',RUSTUP_AUTO_INSTALL='0',PATH=tool+os.pathsep+env['PATH'])
cmd=[tool+'/cargo.exe','fmt','--all','--','--check']
log=d/'workspace-format.log'
with log.open('xb') as output:
    r=subprocess.run(cmd,cwd=destination,env=env,stdout=output,stderr=subprocess.STDOUT)
s=dict(terminal=True,production_applied=False,source=str(w),workspace=str(destination),exact_copied_files=len(inputs),command=cmd,exit_code=r.returncode,log=str(log),sha256=sha(log),changed_source_inputs=[rel for rel,h in inputs.items() if sha(w/rel)!=h],changed_copy_inputs=[rel for rel,h in inputs.items() if sha(destination/rel)!=h])
(d/'summary.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
print(json.dumps(s),flush=True)
print(log.read_text(encoding='utf-8')[:10000])
