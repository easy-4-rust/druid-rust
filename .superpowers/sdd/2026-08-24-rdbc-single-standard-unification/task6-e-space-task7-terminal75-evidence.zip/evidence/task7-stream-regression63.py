import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
w=b/'task7-async-stream-candidate35/workspace'
prior=json.loads((b/'task7-stream-cargo58/summary.json').read_text(encoding='utf-8'))
assert prior['terminal'] and prior['exit_code']==0 and not prior['changed_inputs']
d=b/'task7-stream-regression63'
d.mkdir(exist_ok=False)
tool='C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin'
env=os.environ.copy()
env['DRUID_RDBC_EXTERNAL_TARGET_ROOT']='F:/codex_build_cache/druid_rust/t7_rdbc63'
env.update(RUSTC=tool+'/rustc.exe',RUSTDOC=tool+'/rustdoc.exe',RUSTUP_TOOLCHAIN='1.97.1-x86_64-pc-windows-msvc',RUSTUP_AUTO_INSTALL='0',PATH=tool+os.pathsep+env['PATH'],CARGO_TARGET_DIR='F:/codex_build_cache/druid_rust/task7_standard_cargo13_1971',CARGO_BUILD_JOBS='1',TMP='F:/codex_tmp/task7_standard_cargo13',TEMP='F:/codex_tmp/task7_standard_cargo13')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
frozen={p.relative_to(w).as_posix():sha(p) for p in w.rglob('*') if p.is_file() and 'target' not in p.relative_to(w).parts and (p.suffix in ['.rs','.toml','.json','.inc'] or p.name=='Cargo.lock')}
(d/'frozen-inputs.json').write_text(json.dumps(frozen,indent=2)+'\n',encoding='utf-8')
s=dict(terminal=False,production_applied=False,commands=[])
def save(): (d/'summary.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
save()
tests=['generated_keys_prepare_test','task6_prepared_statement_canonical_matrix_test','standard_adapter_conformance_test','task6_sqlite_wrapper_semantics_test_parity']
regress=['test','-p','druid-wrapper']
for target in tests:regress+=['--test',target]
for name,args in [
    ('rdbc-complete',['test','-p','druid-rdbc','--all-features','--locked','--offline','--no-fail-fast','-j1']),
    ('wrapper-base-regression',regress+['--locked','--offline','--no-fail-fast','-j1']),
    ('wrapper-all-targets-clippy',['clippy','-p','druid-wrapper','--all-targets','--locked','--offline','-j1','--','-D','warnings']),
    ('workspace-format',['fmt','--all','--','--check']),
]:
    cmd=[tool+'/cargo.exe']+args
    log=d/(name+'.log')
    with log.open('xb') as output:
        r=subprocess.run(cmd,cwd=w,env=env,stdout=output,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
    text=log.read_text(encoding='utf-8')
    blocks=re.findall(r'^test result: .*?(\d+) passed; (\d+) failed; (\d+) ignored;',text,re.M)
    counts=dict(passed=sum(int(v[0]) for v in blocks),failed=sum(int(v[1]) for v in blocks),ignored=sum(int(v[2]) for v in blocks),blocks=len(blocks))
    s['commands'].append(dict(name=name,command=cmd,exit_code=r.returncode,log=str(log),sha256=sha(log),results=counts))
    save()
    print(json.dumps(dict(name=name,exit_code=r.returncode,results=counts)),flush=True)
    if r.returncode:break
s.update(terminal=True,exit_code=r.returncode,changed_inputs=[rel for rel,h in frozen.items() if sha(w/rel)!=h])
save()
print(json.dumps({k:s[k] for k in ['terminal','exit_code','changed_inputs']}),flush=True)
