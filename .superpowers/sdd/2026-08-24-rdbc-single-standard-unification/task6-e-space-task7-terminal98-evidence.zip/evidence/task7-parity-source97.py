import hashlib,json,os,subprocess
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust');w=Path('F:/codex_build_cache/d91')
d=b/'task7-parity-source97';d.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads((b/'task7-parity-source91/frozen-inputs.json').read_text(encoding='utf-8'))
diff=[rel for rel,h in old.items() if sha(w/rel)!=h]
assert set(diff)=={'docs/verification/rdbc-first/task6-method-migration.tsv','scripts/render_task6_method_default_evidence.py'}
f={rel:sha(w/rel) for rel in old}
(d/'frozen-inputs.json').write_text(json.dumps(f,indent=2)+'\n',encoding='utf-8')
env=os.environ.copy();env.update(GIT_DIR=str(e/'.git'),GIT_WORK_TREE=str(w),PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1')
cmd=['C:/Espressif/tools/python/python.exe','-X','utf8','scripts/verify_task6_method_parity.py','--repository-root',str(w),'--no-execute']
s=dict(terminal=False,production_applied=False,command=cmd,frozen_input_count=len(f),changed_from91=diff)
save=lambda:(d/'summary.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
save();log=d/'c1-source.log'
with log.open('xb') as out:r=subprocess.run(cmd,cwd=w,env=env,stdout=out,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
s.update(terminal=True,exit_code=r.returncode,log=str(log),sha256=sha(log),changed_inputs=[rel for rel,h in f.items() if sha(w/rel)!=h]);save();print(json.dumps(s,indent=2))
