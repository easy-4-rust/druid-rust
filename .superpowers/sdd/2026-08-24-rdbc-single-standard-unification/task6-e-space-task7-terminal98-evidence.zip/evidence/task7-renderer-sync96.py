import hashlib,json,os,subprocess
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d91')
d=b/'task7-renderer-sync96';d.mkdir(exist_ok=False)
prior=json.loads((b/'task7-parity-source94/summary.json').read_text(encoding='utf-8'))
assert prior['terminal'] and prior['exit_code']==1 and not prior['changed_inputs']
assert 'generated method behavior matrix drift' in Path(prior['log']).read_text(encoding='utf-8')
p=w/'scripts/render_task6_method_default_evidence.py';before=p.read_bytes()
needle=b'use druid_rdbc::types::{';addition=b'use druid_rdbc::resource::{Blob, Clob, NClob};\n'
assert before.count(needle)==1 and addition not in before
after=before.replace(needle,addition+needle)
assert after==(b/'task7-render-method-evidence17.py').read_bytes()
(d/'renderer-before.py').write_bytes(before);p.write_bytes(after);(d/'renderer-after.py').write_bytes(after)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
tool='C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin'
env=os.environ.copy();env.update(PATH=tool+os.pathsep+env['PATH'],RUSTUP_TOOLCHAIN='1.97.1-x86_64-pc-windows-msvc',RUSTUP_AUTO_INSTALL='0',PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1')
generated={p.relative_to(w).as_posix():sha(p) for p in (w/'crates/druid-rdbc/tests/task6_method_behavior_generated').glob('*.rs')}
cmd=['C:/Espressif/tools/python/python.exe','-X','utf8',str(p),'--repository-root',str(w),'--check'];log=d/'renderer-check.log'
with log.open('xb') as out:r=subprocess.run(cmd,cwd=w,env=env,stdout=out,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
changes=[rel for rel,h in generated.items() if sha(w/rel)!=h]
s=dict(terminal=True,production_applied=False,command=cmd,exit_code=r.returncode,log=str(log),sha256=sha(log),changed_generated_files=changes,before_sha256=hashlib.sha256(before).hexdigest(),after_sha256=sha(p),ruling='Synchronize exactly the three resource trait imports already present in the Cargo-verified generated common fixture. Renderer equals preserved candidate17 byte-for-byte. --check only, no generated Rust/test body/assertion/selector modifications.')
(d/'summary.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8');print(json.dumps(s,indent=2))
assert r.returncode==0 and not changes
runner=(b/'task7-parity-source94.py').read_text(encoding='utf-8')
runner=runner.replace("d=b/'task7-parity-source94'","d=b/'task7-parity-source97'")
runner=runner.replace("assert diff==['docs/verification/rdbc-first/task6-method-migration.tsv']","assert set(diff)=={'docs/verification/rdbc-first/task6-method-migration.tsv','scripts/render_task6_method_default_evidence.py'}")
(b/'task7-parity-source97.py').write_text(runner,encoding='utf-8')
