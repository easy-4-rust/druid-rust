import hashlib,json,zipfile
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d161');e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust');d=b/'task7-type-map-failure161'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
s=json.loads((d/'summary.json').read_text(encoding='utf-8'));assert s['terminal'] and s['exit_code']==0 and len(s['commands'])==4
assert [c['passed'] for c in s['commands']]==[4,0,5,0]
assert all(c['exit_code']==0 and not c['changed_inputs'] and sha(Path(c['log']))==c['sha256'] for c in s['commands'])
f=json.loads((d/'frozen-inputs.json').read_text(encoding='utf-8'));parent=json.loads((d/'parent-inputs.json').read_text(encoding='utf-8'));assert len(f)==1245 and len(parent)==1244
assert all(sha(w/r)==h for r,h in f.items()) and all(f[r]==h for r,h in parent.items())
delta={r:h for r,h in f.items() if parent.get(r)!=h};assert list(delta)==['crates/druid-rdbc/tests/standard_sql_type_map_failure_test.rs']
oracle=json.loads((w/'docs/verification/rdbc-first/jdbc42-oracle.json').read_text(encoding='utf-8'))
java=[]
for package in oracle['packages'].values():
 for record in package['objects']:
  if record['fqcn'] in {'java.sql.SQLInput','java.sql.SQLData'}:
   p=b/'task8-java-jdbc42-source'/record['source_path'];assert sha(p)==record['source_sha256'];java.append(p)
assert len(java)==2
(d/'setup-first-failure.json').write_text(json.dumps(dict(command=['C:/Espressif/tools/python/python.exe','-X','utf8',str(b/'task7-type-map-failure161.py')],exit_code=1,cargo_executed=False,error='FileNotFoundError: parent-inputs.json; original clone session20419 was still running; same clone completed before retry',not_product_red=True),indent=2)+'\n',encoding='utf-8')
files={str(p.relative_to(b)).replace('\\','/'):p for p in d.rglob('*') if p.is_file()}
for r in delta:files['candidate-delta/'+r]=w/r
for p in java:files['java-source/'+p.name]=p
files['task7-type-map-failure161.py']=b/'task7-type-map-failure161.py';files['task7-type-map-failure-terminal162.py']=b/'task7-type-map-failure-terminal162.py'
manifest={n:sha(p) for n,p in files.items()};z=b/'task7-type-map-failure-terminal162.zip';assert not z.exists()
with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED) as out:
 for n,p in files.items():out.write(p,n)
 out.writestr('archive-manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(z) as inp:assert all(hashlib.sha256(inp.read(n)).hexdigest()==h for n,h in manifest.items())
parentzip=b/'task8-final-cli-terminal160.zip';assert sha(parentzip)=='ab5670b5fab1f8e6f5180bb9049d698193a366a322be13a05b030e27363bb9e9'
r=dict(scope='LOCAL_TYPE_MAP_FAILURE_AND_CANCELLATION_EVIDENCE',production_applied=False,production_changed=False,archive=str(z),archive_sha256=sha(z),parent_archive=str(parentzip),parent_sha256=sha(parentzip),frozen_input_count=1245,delta=delta,verified_commands=s['commands'],new_contracts_passed=4,original_contracts_passed=5,task7_complete=False,top_level_open=18)
p=b/'task7-type-map-failure-terminal162.summary.json';p.write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8');dest=e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'
for original,name in [(z,'task6-e-space-task7-type-map-failure162-evidence.zip'),(p,'task6-e-space-task7-type-map-failure162-summary.json')]:
 t=dest/name;assert not t.exists();t.write_bytes(original.read_bytes());assert sha(t)==sha(original)
note=f'''\n\n2026-10-09 SQLData映射失败与取消合同终态：独立d161从159逐项复制1244冻结输入，仅增一个真实合同文件，所有生产/原测试/工具源码字节不变，合计1245。固定Java SQLInput/SQLData原件SHA匹配既有69oracle；新增四合同通过标准SQLOutput生成真实Struct、同一显式type map/应用factory进入readSQL。实际单层/嵌套readSQL错误完整保留vendor/SQLState/null消息/运行类/cause与next链，未发布实例各drop一次；先真实poll进入readSQL及Pending再取消，单层/嵌套实例各drop一次，后续99属性仍可读取。四合同首次实际4/0，既有实现正确，无产品RED或生产修复声明；严格Clippy0、原五项映射5/0、fmt0，1245冻结变化0。最初runner在复制未完成时缺parent-inputs文件，Cargo未执行，保存设置失败事实；原clone完成后同一runner正常执行，不算产品RED。zip162 SHA {sha(z)}为160父链的一路径测试delta，含实际命令/日志/来源原件和完整SHA清单，全部解压及E镜像一致。Ruling: 取消合同只证明未发布映射实例的Rust所有权清理，不扩张为外部数据库事务回滚或任意驱动资源释放认证。此局部readSQL错误/取消缺口已取得证据；provider type-map接入、DISTINCT实库、六RowSet入口、完整API/SemVer/MSRV/compiler/全仓仍未闭合。正式Rust未apply，Task6 FIX_REQUIRED/Task7八义务/Task8 INCOMPLETE/18顶层OPEN。\n'''
for rel in ['.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md','docs/verification/rdbc-first/status.md','docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md']:
 p=e/rel;raw=p.read_bytes();assert b'zip162 SHA' not in raw;p.write_bytes(raw+note.encode('utf-8'))
print(json.dumps(dict(archive=str(z),sha256=sha(z),new_contracts=4,original_contracts=5,production_changed=False,mirrored=True)),flush=True)
