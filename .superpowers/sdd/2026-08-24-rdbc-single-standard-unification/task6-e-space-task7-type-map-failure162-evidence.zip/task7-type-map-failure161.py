import hashlib,json,os,re,subprocess,time
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d161');d=b/'task7-type-map-failure161'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
f=json.loads((d/'parent-inputs.json').read_text(encoding='utf-8'))
assert len(f)==1244 and all(sha(w/r)==h for r,h in f.items())
tool='C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin'
env=os.environ.copy();env.update(RUSTUP_TOOLCHAIN='1.97.1',RUSTUP_AUTO_INSTALL='0',RUSTC=tool+'/rustc.exe',RUSTDOC=tool+'/rustdoc.exe',CARGO_TARGET_DIR='F:/codex_build_cache/druid_rust/task7_type_map146_target',TMP='F:/codex_tmp/task7_standard_cargo13',TEMP='F:/codex_tmp/task7_standard_cargo13');env['PATH']=tool+os.pathsep+env['PATH']
new=['crates/druid-rdbc/tests/standard_sql_type_map_failure_test.rs']
format_files=new
p=subprocess.run([tool+'/rustfmt.exe','--edition','2021','--config','skip_children=true',*[str(w/r) for r in format_files]],cwd=w,env=env,capture_output=True);(d/'format-setup.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0
for r in list(f)+new:f[r]=sha(w/r)
(d/'frozen-inputs.json').write_text(json.dumps(f,indent=2)+'\n',encoding='utf-8')
s=dict(terminal=False,production_applied=False,workspace=str(w),pid=os.getpid(),frozen_input_count=len(f),commands=[],original_five_contracts_preserved=True,production_changed=False,ruling='Instance-scoped constructors adapt reflection; canonical Custom identity protects a Send-only SQLData behind its object mutex; nested input inherits explicit mapping')
summary=d/'summary.json'
def save():summary.write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
commands=[('mapping-green',['test','-p','druid-rdbc','--test','standard_sql_type_map_failure_test','--all-features','--locked','--offline','-j1']),('mapping-strict',['clippy','-p','druid-rdbc','--test','standard_sql_type_map_failure_test','--all-features','--locked','--offline','-j1','--','-D','warnings']),('original-type-map-five',['test','-p','druid-rdbc','--test','standard_sql_type_map_contract_test','--all-features','--locked','--offline','-j1']),('fmt',['fmt','--all','--','--check'])]
for name,args in commands:
    s['running_command']=name;save();log=d/(name+'.log');command=[tool+'/cargo.exe']+args;start=time.time()
    with log.open('wb') as output:
        p=subprocess.Popen(command,cwd=w,env=env,stdout=output,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS);s['cargo_pid']=p.pid;save();code=p.wait()
    text=log.read_text(encoding='utf-8',errors='replace');counts=re.findall(r'test result: \w+\. (\d+) passed; (\d+) failed;',text);changed=[r for r,h in f.items() if sha(w/r)!=h]
    record=dict(name=name,command=command,exit_code=code,elapsed_seconds=time.time()-start,log=str(log),sha256=sha(log),passed=sum(int(a) for a,_ in counts),failed=sum(int(a) for _,a in counts),changed_inputs=changed);s['commands'].append(record);save();print(json.dumps(record),flush=True)
    if code or changed:s.update(terminal=True,exit_code=code or 97);save();raise SystemExit(code or 97)
s.update(terminal=True,exit_code=0);s.pop('running_command',None);save();print(json.dumps(s),flush=True)
