import hashlib,json,zipfile,subprocess
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust');d=b/'task7-type-map146';w=Path('F:/codex_build_cache/d146')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
s=json.loads((d/'summary.json').read_text(encoding='utf-8'))
f=json.loads((d/'frozen-inputs.json').read_text(encoding='utf-8'))
r='crates/druid-rdbc/tests/standard_sql_type_map_contract_test.rs'
assert len(f)==1236 and sha(w/r)==f[r]
original=(w/r).read_text(encoding='utf-8');corrected=(b/'task7-type-map146.rs').read_text(encoding='utf-8')
assert original.replace('use druid_rdbc::error::{RdbcError, SqlException};','use druid_rdbc::error::{RdbcError, RdbcErrorKind, SqlException};').replace('assert!(matches!(input.read_object().await, Err(RdbcError::FeatureNotSupported { .. })));','assert_eq!(input.read_object().await.unwrap_err().kind(), RdbcErrorKind::SqlFeatureNotSupported);').replace('        self.number.set(input.read_int().await?);','        let number = input.read_int().await?;\n        self.number.set(number);')==corrected
acquisition=json.loads((b/'task8-java-jdbc42-source-acquisition1.summary.json').read_text(encoding='utf-8'))
java=next(x for x in acquisition['sources'] if x['fqcn']=='java.sql.SQLInput')
assert sha(d/'SQLInput.java')==java['sha256'] and acquisition['oracle_commit']=='7373384725418fa645fb4508ec05a869bc7fc3e7'
observation=subprocess.check_output(['powershell','-NoProfile','-Command',f'Get-CimInstance Win32_Process | Where-Object {{ $_.ProcessId -eq {s["pid"]} -or $_.ParentProcessId -eq {s["pid"]} }} | Select-Object ProcessId,ParentProcessId,Name | ConvertTo-Json -Compress'],text=True,encoding='utf-8')
assert s.get('terminal') or 'python.exe' in observation
files={'frozen-inputs.json':d/'frozen-inputs.json','start-summary.json':d/'summary.json','brief.txt':d/'brief.txt','fixed-Java-SQLInput.java':d/'SQLInput.java','original-frozen-test.rs':w/r,'corrected-draft-not-applied.rs':b/'task7-type-map146.rs','runner146.py':b/'task7-type-map146.py','collector147.py':b/'task7-type-map-start147.py'}
manifest={n:sha(p) for n,p in files.items()};z=b/'task7-type-map-start147.zip';assert not z.exists()
with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED) as out:
    for n,p in files.items():out.write(p,n)
    out.writestr('archive-manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(z) as inp:assert all(hashlib.sha256(inp.read(n)).hexdigest()==h for n,h in manifest.items())
result=dict(scope='START_AND_FIXTURE_PREFLIGHT_ONLY',production_applied=False,terminal=s.get('terminal',False),archive=str(z),archive_sha256=sha(z),frozen_input_count=1236,original_test_sha256=f[r],corrected_draft_sha256=sha(b/'task7-type-map146.rs'),fixture_error='Initial frozen test uses nonexistent RdbcError::FeatureNotSupported; corrected draft uses actual RdbcErrorKind::SqlFeatureNotSupported. Do not certify initial compile failure as clean product RED.',java_source_sha256=java['sha256'],oracle_commit=acquisition['oracle_commit'],original_process_observation=observation,top_level_open=18)
p=b/'task7-type-map-start147.summary.json';p.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
dest=e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'
for source,name in [(z,'task6-e-space-task7-type-map147-evidence.zip'),(p,'task6-e-space-task7-type-map147-summary.json')]:
    target=dest/name;assert not target.exists();target.write_bytes(source.read_bytes());assert sha(target)==sha(source)
note=f'''\n\n2026-10-09 custom type map合同启动：固定OpenJDK {acquisition['oracle_commit']} SQLInput#readObject原件SHA逐项匹配已取得oracle。独立d146复制137冻结1235输入后增加五项真实合同，构造Cell非Sync应用SQLData、原限定UDT名/新实例、SQL NULL/无匹配Struct身份、不存在构造器拒绝、原构造错误及递归映射，合计1236冻结；未写生产实现。Ruling: 保留现有描述符RdbcTypeMap与canonical对象，通过实例级Rust构造器registry适配Java反射；同一SqlData只以mutex独占访问，不能用类名或JSON替代。原146/session31290已实际Cargo101终态、冻结变化0；诊断同时包含缺失标准映射入口与两处夹具错误，不能计纯产品RED。预检发现原夹具引用不存在的RdbcError::FeatureNotSupported及Cell借用跨await；修正版草稿仅改为现有kind分类并先await局部值再set，尚未应用运行中输入，原终态保留，须先排除夹具错误，不能记纯产品RED。zip147 SHA {sha(z)}保存原冻结测试/修正草稿/简报/Java原件/冻结清单及启动进程证据，全部解压与E镜像SHA核验；不是PASS。137池化/Drop实际9/0，后继Druid lib仍待终态；113/129完整回归保留原进程。正式Rust未apply，Task6 FIX_REQUIRED/Task7八义务/Task8 INCOMPLETE/18顶层OPEN。\n'''
for rel in ['.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md','docs/verification/rdbc-first/status.md','docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md']:
    target=e/rel;raw=target.read_bytes();assert b'zip147 SHA' not in raw;target.write_bytes(raw+note.encode('utf-8'))
print(json.dumps(result),flush=True)
