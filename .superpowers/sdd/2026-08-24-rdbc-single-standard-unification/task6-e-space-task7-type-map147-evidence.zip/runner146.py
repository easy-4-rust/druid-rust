import hashlib,json,os,subprocess,time
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
source=Path('F:/codex_build_cache/d117');w=Path('F:/codex_build_cache/d146');d=b/'task7-type-map146'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
f=json.loads((b/'task7-xml-owner-fix137/frozen-inputs.json').read_text(encoding='utf-8'))
assert len(f)==1235 and all(sha(source/r)==h for r,h in f.items())
assert not w.exists() and not d.exists();w.mkdir();d.mkdir()
for r,h in f.items():
    target=w/r;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((source/r).read_bytes());assert sha(target)==h
assert all(sha(source/r)==h for r,h in f.items())
r='crates/druid-rdbc/tests/standard_sql_type_map_contract_test.rs'
(w/r).write_bytes((b/'task7-type-map146.rs').read_bytes());f[r]=sha(w/r)
(d/'frozen-inputs.json').write_text(json.dumps(f,indent=2)+'\n',encoding='utf-8')
java=b/'task8-java-jdbc42-source/jdk/src/share/classes/java/sql/SQLInput.java'
(d/'SQLInput.java').write_bytes(java.read_bytes())
brief='''P04 Task7/Task8 custom type map implementation brief
Authority: fixed OpenJDK7373384725418fa645fb4508ec05a869bc7fc3e7 java.sql.SQLInput#readObject; existing SQLData/Input/Output standard contract.
Requirement: matching SQL UDT -> application class construction -> SQLData.read_sql, with inherited nested type map, fresh instances, ordered attributes, SQL NULL/default mapping and original error identity.
Ruling: preserve descriptor-only RdbcTypeMap and canonical RdbcObject. Add instance-scoped Rust constructor registry as reflection adaptation, no process-global second driver registry. BufferedSqlInput receives registry and map explicitly; no implicit import or driver dependency. Store Send-only SQLData behind same per-object async mutex and existing Custom opaque handle; shared clones retain identity. Expose qualified SQL type name and write-back through that same object, never serialize the application instance into a string.
No silent Struct fallback for a matched but unregistered class; report unsupported. An unmapped Struct retains reference identity. Each read consumes exactly one original attribute; constructor/read_sql errors publish no partial object.
Initial five real contracts cover construction of Cell-bearing non-Sync SQLData, null/default identity, missing constructor, original constructor error and nested map inheritance. Additional read_sql error/cancellation gates and final full API/real provider integration remain required; this brief is not final compliance proof.
Candidate d146 is a byte-identical independent copy of137 frozen1235 before adding one test; do not edit d117/d111/d129 active sources. No business Rust applied to E.
'''
(d/'brief.txt').write_text(brief,encoding='utf-8')
tool='C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin'
env=os.environ.copy();env.update(RUSTUP_TOOLCHAIN='1.97.1',RUSTUP_AUTO_INSTALL='0',RUSTC=tool+'/rustc.exe',RUSTDOC=tool+'/rustdoc.exe',CARGO_TARGET_DIR='F:/codex_build_cache/druid_rust/task7_type_map146_target',TMP='F:/codex_tmp/task7_standard_cargo13',TEMP='F:/codex_tmp/task7_standard_cargo13');env['PATH']=tool+os.pathsep+env['PATH']
command=[tool+'/cargo.exe','test','-p','druid-rdbc','--test','standard_sql_type_map_contract_test','--all-features','--locked','--offline','-j1']
s=dict(terminal=False,production_applied=False,workspace=str(w),pid=os.getpid(),frozen_input_count=len(f),source_copy_verified=True,java_source_sha256=sha(java),command=command)
summary=d/'summary.json';summary.write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
start=time.time();log=d/'red.log'
with log.open('wb') as output:
    p=subprocess.Popen(command,cwd=w,env=env,stdout=output,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
    s['cargo_pid']=p.pid;summary.write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8');code=p.wait()
text=log.read_text(encoding='utf-8',errors='replace');changed=[r for r,h in f.items() if sha(w/r)!=h]
s.update(terminal=True,exit_code=code,elapsed_seconds=time.time()-start,log=str(log),log_sha256=sha(log),changed_inputs=changed,expected_public_surface_red=code==101 and 'unresolved imports' in text and 'SqlDataRegistry' in text and 'SqlDataObject' in text and not changed)
summary.write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8');print(json.dumps(s),flush=True)
assert s['expected_public_surface_red']
