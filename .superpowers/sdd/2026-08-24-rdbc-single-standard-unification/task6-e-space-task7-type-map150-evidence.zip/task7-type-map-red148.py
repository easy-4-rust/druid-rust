import hashlib,json,os,subprocess,time
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d146');d=b/'task7-type-map-red148';d.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
prior=json.loads((b/'task7-type-map146/summary.json').read_text(encoding='utf-8'));assert prior['terminal'] and prior['exit_code']==101 and not prior['changed_inputs']
f=json.loads((b/'task7-type-map146/frozen-inputs.json').read_text(encoding='utf-8'));assert len(f)==1236 and all(sha(w/r)==h for r,h in f.items())
rel='crates/druid-rdbc/tests/standard_sql_type_map_contract_test.rs';p=w/rel
(d/'original-fixture.rs').write_bytes(p.read_bytes());(d/'original-red.log').write_bytes(Path(prior['log']).read_bytes());(d/'original-summary.json').write_bytes((b/'task7-type-map146/summary.json').read_bytes())
p.write_bytes((b/'task7-type-map146.rs').read_bytes());f[rel]=sha(p)
(d/'frozen-inputs.json').write_text(json.dumps(f,indent=2)+'\n',encoding='utf-8')
tool='C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin'
env=os.environ.copy();env.update(RUSTUP_TOOLCHAIN='1.97.1',RUSTUP_AUTO_INSTALL='0',RUSTC=tool+'/rustc.exe',RUSTDOC=tool+'/rustdoc.exe',CARGO_TARGET_DIR='F:/codex_build_cache/druid_rust/task7_type_map146_target',TMP='F:/codex_tmp/task7_standard_cargo13',TEMP='F:/codex_tmp/task7_standard_cargo13');env['PATH']=tool+os.pathsep+env['PATH']
command=prior['command'];s=dict(terminal=False,production_applied=False,workspace=str(w),pid=os.getpid(),frozen_input_count=len(f),command=command,fixture_only_recovery=True)
summary=d/'summary.json';summary.write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
start=time.time();log=d/'red.log'
with log.open('wb') as output:
    process=subprocess.Popen(command,cwd=w,env=env,stdout=output,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS);s['cargo_pid']=process.pid;summary.write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8');code=process.wait()
text=log.read_text(encoding='utf-8',errors='replace');changed=[r for r,h in f.items() if sha(w/r)!=h]
clean=code==101 and 'unresolved imports' in text and 'SqlDataRegistry' in text and 'SqlDataObject' in text and 'with_type_map' in text and 'future cannot be sent' not in text and 'no variant named' not in text and not changed
s.update(terminal=True,exit_code=code,elapsed_seconds=time.time()-start,log=str(log),log_sha256=sha(log),changed_inputs=changed,expected_clean_public_surface_red=clean)
summary.write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8');print(json.dumps(s),flush=True);assert clean
