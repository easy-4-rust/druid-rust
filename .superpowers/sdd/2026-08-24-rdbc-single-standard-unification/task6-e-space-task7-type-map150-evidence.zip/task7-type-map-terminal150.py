import hashlib,json,zipfile
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d146');e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
s=json.loads((b/'task7-type-map-fix149/summary.json').read_text(encoding='utf-8'));red=json.loads((b/'task7-type-map-red148/summary.json').read_text(encoding='utf-8'))
assert s['terminal'] and s['exit_code']==0 and len(s['commands'])==4 and red['expected_clean_public_surface_red']
assert all(c['exit_code']==0 and not c['changed_inputs'] and sha(Path(c['log']))==c['sha256'] for c in s['commands'])
counts={c['name']:(c['passed'],c['failed']) for c in s['commands']};assert counts['mapping-green']==(5,0)
f=json.loads((b/'task7-type-map-fix149/frozen-inputs.json').read_text(encoding='utf-8'));parent=json.loads((b/'task7-xml-owner-fix137/frozen-inputs.json').read_text(encoding='utf-8'))
assert len(f)==1238 and all(sha(w/r)==h for r,h in f.items())
delta={r:h for r,h in f.items() if parent.get(r)!=h}
assert set(delta)=={'crates/druid-rdbc/src/extensions/buffered_sql_input.rs','crates/druid-rdbc/src/extensions/mod.rs','crates/druid-rdbc/src/extensions/sql_data_object.rs','crates/druid-rdbc/src/extensions/sql_data_registry.rs','crates/druid-rdbc/tests/standard_sql_type_map_contract_test.rs'}
parent_zip=b/'task7-xml-owner-terminal141.zip'
assert sha(parent_zip)=='f93536322fb7c1508f9b509115341ee67f71ff795a21ef7b2cebd02475938528'
files={}
for folder in ['task7-type-map146','task7-type-map-red148','task7-type-map-fix149']:
    for p in (b/folder).rglob('*'):
        if p.is_file():files[str(p.relative_to(b)).replace('\\','/')]=p
for name in ['task7-type-map146.py','task7-type-map146.rs','task7-type-map-red148.py','task7-type-map-fix149.py','task7-type-map-terminal150.py','task7-type-map-start147.summary.json']:
    files[name]=b/name
for r in delta:files['candidate-delta/'+r]=w/r
manifest={n:sha(p) for n,p in files.items()};z=b/'task7-type-map-terminal150.zip';assert not z.exists()
with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED) as out:
    for n,p in files.items():out.write(p,n)
    out.writestr('archive-manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(z) as inp:assert all(hashlib.sha256(inp.read(n)).hexdigest()==h for n,h in manifest.items())
result=dict(terminal=True,production_applied=False,archive=str(z),archive_sha256=sha(z),frozen_input_count=len(f),delta=delta,commands=s['commands'],parent_archive=str(parent_zip),parent_sha256=sha(parent_zip),clean_red_sha256=red['log_sha256'],original_five_contracts_preserved=True,full_java_or_driver_certification=False,top_level_open=18)
local=b/'task7-type-map-terminal150.summary.json';local.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');dest=e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'
for source,name in [(z,'task6-e-space-task7-type-map150-evidence.zip'),(local,'task6-e-space-task7-type-map150-summary.json')]:
    target=dest/name;assert not target.exists();target.write_bytes(source.read_bytes());assert sha(source)==sha(target)
note=f'''\n\n2026-10-09 custom type map候选局部终态：原146编译101同时包含缺失入口与两处夹具错误，不计纯产品RED；148只将不存在异常枚举改为原kind分类、Cell.set(await)改先await局部值，保留Cell非Sync及全部五合同，实际干净E0432/E0599标准入口RED，1236冻结变化0。149新增实例级SqlDataRegistry和SqlDataObject两个一对象一文件生产类型，BufferedSqlInput显式安装原type map/工厂，匹配限定UDT后构造真实Send-only SQLData、按原声明顺序readSQL，嵌套继承同一目录；映射失败不发布半成品，原错误传播，NULL及无匹配原Struct身份保留。现有RdbcTypeMap/RdbcObject与driver registry不改。官方定向rustfmt保留五原合同，最终映射5/0、指定严格Clippy0、完整RDBC allfeatures {counts['rdbc-complete'][0]}/0、fmt0，1238完整冻结变化0。zip150 SHA {sha(z)}保存原混合失败、干净RED、最终GREEN、固定Java原件/简报、完整清单及相对141终态父链的五路径delta，全部解压与E镜像核验。Ruling: 用显式构造器适配Java反射，用对象级mutex保留可变应用实例及Custom身份；不要求SQLData Sync、不通过类名/JSON冒充对象。readSQL错误/取消、各provider type-map接入、DISTINCT实库、RowSet及最终API/SemVer/MSRV/compiler/全仓仍需完成；不宣称完整JDBC语义或驱动认证。正式Rust未apply，Task6 FIX_REQUIRED/Task7八义务/Task8 INCOMPLETE/18顶层OPEN。\n'''
for rel in ['.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md','docs/verification/rdbc-first/status.md','docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md']:
    p=e/rel;raw=p.read_bytes();assert b'zip150 SHA' not in raw;p.write_bytes(raw+note.encode('utf-8'))
print(json.dumps(dict(archive=str(z),sha256=sha(z),counts=counts,mirrored=True)),flush=True)
