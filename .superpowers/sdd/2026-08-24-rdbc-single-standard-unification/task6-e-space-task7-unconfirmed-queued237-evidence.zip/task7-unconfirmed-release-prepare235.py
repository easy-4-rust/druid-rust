from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');s=(b/'task7-unconfirmed-release-contract234.rs').read_text(encoding='utf-8');s=s.replace('fn queued_read_rechecks_cancellation_before_entering_driver()', 'fn reads_are_rejected_during_release_and_after_cancellation()');old='''        assert!(
            futures::future::poll_fn(|cx| Poll::Ready(read.as_mut().poll(cx)))
                .await
                .is_pending()
        );
        drop(release);
        assert!(read.await.is_err());''';new='''        let result = futures::future::poll_fn(|cx| Poll::Ready(read.as_mut().poll(cx))).await;
        assert!(matches!(result, Poll::Ready(Err(_))));
        drop(read);
        drop(release);
        assert!(blob.length().await.is_err());''';assert s.count(old)==1;s=s.replace(old,new);p=b/'task7-unconfirmed-release-contract235.rs';assert not p.exists();p.write_text(s,encoding='utf-8',newline='\n');r=(b/'task7-unconfirmed-release-red234.py').read_text(encoding='utf-8');p=b/'task7-unconfirmed-release-red235.py';assert not p.exists();p.write_text(r.replace('234','235'),encoding='utf-8',newline='\n')
