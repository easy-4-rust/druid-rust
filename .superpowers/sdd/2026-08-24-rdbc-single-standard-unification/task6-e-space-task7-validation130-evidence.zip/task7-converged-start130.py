import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

b = Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
e = Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust')
w = Path('F:/codex_build_cache/d129')
d = b / 'task7-converged-validation129'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
s = json.loads((d / 'summary.json').read_text(encoding='utf-8'))
assert not s['terminal'] and s['running_command'] == 'wrapper-prewarm-exact'
pid = int(s['pid'])
command = f"Get-CimInstance Win32_Process | Where-Object {{$_.ProcessId -eq {pid} -or $_.ParentProcessId -eq {pid}}} | Select-Object ProcessId,ParentProcessId,Name | ConvertTo-Json"
r = subprocess.run(['powershell.exe', '-NoProfile', '-NonInteractive', '-Command', command], capture_output=True)
assert r.returncode == 0
observed = json.loads(r.stdout.decode('utf-8-sig'))
if isinstance(observed, dict):
    observed = [observed]
assert any(p['ProcessId'] == pid and p['Name'] == 'python.exe' for p in observed)
assert any(p['ParentProcessId'] == pid and p['Name'] == 'cargo.exe' for p in observed)
f = json.loads((d / 'frozen-inputs.json').read_text(encoding='utf-8'))
parent = json.loads((b / 'task7-sql-type-retry127/frozen-inputs.json').read_text(encoding='utf-8'))
assert len(f) == 1234 and f == parent and all(sha(w / rel) == h for rel, h in f.items())
assert sha(b / 'task7-sql-mapping-terminal126.zip') == 'b9988c511d3f06ed8dfc6f6f8eaab14520ca118c7814bc6fa9cc0ac2e0da63d5'
receipt = dict(terminal=False, production_applied=False, scope='Observation only, not runtime PASS',
    session_id=70876, pid=pid, processes=observed, workspace=str(w), frozen_inputs=len(f),
    source_copy_matches127=True, source_parent126_sha256=sha(b / 'task7-sql-mapping-terminal126.zip'),
    commands_planned=['exact original Wrapper allfeatures lib prewarm', 'complete workspace allfeatures no-fail-fast',
                      'strict workspace alltargets Clippy', 'workspace docs', 'fmt check', 'complete C1 including C2'],
    original_c1_timeout_preserved=True, top_level_open_tasks=18)
summary = b / 'task7-converged-start130.summary.json'
summary.write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
observed_path = b / 'task7-converged-start130.observed.json'
observed_path.write_text(json.dumps(s, indent=2) + '\n', encoding='utf-8')
files = [b / 'task7-converged-validation129.py', b / 'task7-converged-start130.py', summary,
         observed_path, d / 'frozen-inputs.json']
manifest = {p.relative_to(b).as_posix(): sha(p) for p in files}
archive = b / 'task7-converged-start130.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as z:
    for p in files:
        z.write(p, p.relative_to(b).as_posix())
    z.writestr('manifest.json', json.dumps(manifest, indent=2))
with zipfile.ZipFile(archive) as z:
    assert all(hashlib.sha256(z.read(rel)).hexdigest() == h for rel, h in manifest.items())
dest = e / '.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'
for source, suffix in [(archive, 'evidence.zip'), (summary, 'summary.json')]:
    target = dest / ('task6-e-space-task7-validation130-' + suffix)
    assert not target.exists()
    target.write_bytes(source.read_bytes())
    assert sha(target) == sha(source)
note = f'''\n\n2026-10-09 当前SQL候选完整验证接续：129独立短目录逐项复制127最终1234完整输入，所有SHA一致；原session70876/Python{pid}及直属Cargo实际存活。先执行与原C2完全相同Wrapper allfeatures lib/show-output命令完成原生预构建，再执行完整workspace/allfeatures/no-fail-fast、严格alltargets Clippy、文档、fmt与正式完整C1含C2；原验证器超时/分母/测试断言不改，单项失败继续收集门禁、输入漂移停止。当前实际编译libduckdb-sys，尚无运行终态或PASS；100原1800秒超时保留。zip130 SHA {sha(archive)}保存runner、1234清单及真实进程观察，逐项解压与E镜像SHA一致；最终源码可由完整109与126 delta重建。原113同样保持原作业。正式Rust未apply，Task6 FIX_REQUIRED/Task7八义务/Task8 INCOMPLETE/18顶层OPEN。\n'''
for rel in ['.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md',
            'docs/verification/rdbc-first/status.md',
            'docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md']:
    with (e / rel).open('a', encoding='utf-8', newline='') as out:
        out.write(note)
print(json.dumps(dict(archive_sha256=sha(archive), session_id=70876, pid=pid,
                     frozen_inputs=len(f), terminal=False, top_level_open_tasks=18), indent=2), flush=True)
