import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess

b = Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
origin = Path('F:/codex_build_cache/d117')
w = Path('F:/codex_build_cache/d129')
e = Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust')
d = b / 'task7-converged-validation129'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
previous = json.loads((b / 'task7-sql-type-retry127/summary.json').read_text(encoding='utf-8'))
assert previous['terminal'] and previous['exit_code'] == 0 and len(previous['commands']) == 4
assert all(c['exit_code'] == 0 and not c['changed_inputs'] for c in previous['commands'])
frozen = json.loads((b / 'task7-sql-type-retry127/frozen-inputs.json').read_text(encoding='utf-8'))
assert len(frozen) == 1234 and all(sha(origin / rel) == h for rel, h in frozen.items())
assert not w.exists() and not d.exists()
d.mkdir()
w.mkdir()
for rel, h in frozen.items():
    assert '..' not in Path(rel).parts and not Path(rel).is_absolute()
    target = w / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(origin / rel, target)
    assert sha(target) == h
assert all(sha(origin / rel) == h and sha(w / rel) == h for rel, h in frozen.items())
(d / 'frozen-inputs.json').write_text(json.dumps(frozen, indent=2) + '\n', encoding='utf-8')
source = (b / 'task7-converged-validation113.py').read_text(encoding='utf-8')
tail = source[source.index("tool = 'C:/Users/"):]
old = "CARGO_TARGET_DIR='F:/codex_build_cache/druid_rust/task6_lifetime_clean_1971_20261008'"
assert tail.count(old) == 1
tail = tail.replace(old, "CARGO_TARGET_DIR='F:/codex_build_cache/druid_rust/task7_standard_cargo13_1971'")
assert tail.count('F:/codex_build_cache/dr113_ext') == 1
tail = tail.replace('F:/codex_build_cache/dr113_ext', 'F:/codex_build_cache/dr129_ext')
old = 'commands = [\n'
assert tail.count(old) == 1
tail = tail.replace(old, "commands = [\n    ('wrapper-prewarm-exact', [tool + '/cargo.exe', 'test', '--offline', '--locked', '-p', 'druid-wrapper', '--all-features', '--lib', '--', '--show-output']),\n")
tail = tail.replace('frozen_input_count=len(frozen), pid=os.getpid(), commands=[])',
    'frozen_input_count=len(frozen), pid=os.getpid(), source_copy_verified=True, original_c1_timeout_preserved=True, commands=[])')
exec(compile(tail, str(b / 'task7-converged-validation129.py'), 'exec'))
