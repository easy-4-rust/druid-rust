//! 独立RDBC资源合同；对应 Java: java.sql.Blob、Clob、NClob、Ref和Struct。
//! 现有原合同保持完整；Array与SQLXML完整矩阵仍须补齐，不能据此关闭Task7。
#[path = "resource_standard_support/blob_contract.rs"]
mod blob_contract;
#[path = "resource_standard_support/clob_contract.rs"]
mod clob_contract;
#[path = "resource_standard_support/context_contract.rs"]
mod context_contract;
#[path = "resource_standard_support/ref_contract.rs"]
mod ref_contract;
