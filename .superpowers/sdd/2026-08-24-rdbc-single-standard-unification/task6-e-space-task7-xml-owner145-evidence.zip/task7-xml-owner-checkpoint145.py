import hashlib,json,subprocess,zipfile
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d117');e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
s=json.loads((b/'task7-xml-owner-fix137/summary.json').read_text(encoding='utf-8'))
assert not s['terminal'] and s['running_command']=='pooled-stream'
assert [(c['name'],c['exit_code']) for c in s['commands']]==[('binding-green',0),('owner-complete',0),('owner-strict',0)]
assert [(c['passed'],c['failed']) for c in s['commands'][:2]]==[(7,0),(112,0)]
assert all(not c['changed_inputs'] and sha(Path(c['log']))==c['sha256'] for c in s['commands'])
pid=int(s['pid']);cmd=f"$p=Get-CimInstance Win32_Process -Filter 'ProcessId={pid}'; $c=Get-CimInstance Win32_Process -Filter 'ParentProcessId={pid}'; [pscustomobject]@{{parent=$p.Name; pid=$p.ProcessId; children=@($c | Select-Object ProcessId,Name)}} | ConvertTo-Json -Depth 4 -Compress"
process=json.loads(subprocess.check_output(['powershell.exe','-NoProfile','-Command',cmd],encoding='utf-8'))
assert process['parent']=='python.exe' and process['pid']==pid and any(c['Name']=='cargo.exe' for c in process['children'])
f=json.loads((b/'task7-xml-owner-fix137/frozen-inputs.json').read_text(encoding='utf-8'));p=json.loads((b/'task7-sql-xml-quality134/frozen-inputs.json').read_text(encoding='utf-8'))
assert len(f)==1235 and all(sha(w/r)==h for r,h in f.items());delta={r:h for r,h in f.items() if p.get(r)!=h};assert len(delta)==2
files={}
for name in ['task7-xml-owner-red135','task7-xml-owner-red140','task7-xml-owner-setup138','task7-xml-owner-fix137']:
    for item in (b/name).rglob('*'):
        if item.is_file():files[str(item.relative_to(b)).replace('\\','/')]=item.read_bytes()
for name in ['task7-xml-owner135.rs','task7-xml-owner-close139.rs','task7-xml-owner-red135.py','task7-xml-owner-red140.py','task7-xml-owner-setup138.py','task7-xml-owner-fix137.py','task7-xml-owner-terminal141.py','task7-xml-owner-checkpoint145.py','task7-java-xml-source-binding144.summary.json']:
    files[name]=(b/name).read_bytes()
for rel in delta:files['candidate-delta/'+rel]=(w/rel).read_bytes()
manifest={n:hashlib.sha256(raw).hexdigest() for n,raw in files.items()};z=b/'task7-xml-owner-checkpoint145.zip';assert not z.exists()
with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED) as out:
    for name,raw in files.items():out.writestr(name,raw)
    out.writestr('archive-manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(z) as source:assert all(hashlib.sha256(source.read(n)).hexdigest()==h for n,h in manifest.items())
assert all(sha(w/r)==h for r,h in f.items())
result=dict(terminal=False,production_applied=False,archive=str(z),archive_sha256=sha(z),archive_files=len(files),frozen_input_count=len(f),parent_archive='task7-sql-xml-terminal136.zip',parent_sha256='132b853e0c74b9b83bda9cde8df7c3bc63ca45a4e9b09abc6c9720cc0748bb01',delta=delta,completed_commands=s['commands'],verified_live_process=process,running_command=s['running_command'],partial_log_scope='pooled-stream is an in-progress snapshot, not a completed test result',top_level_open=18)
summary=b/'task7-xml-owner-checkpoint145.summary.json';summary.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
dest=e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'
for original,name in [(z,'task6-e-space-task7-xml-owner145-evidence.zip'),(summary,'task6-e-space-task7-xml-owner145-summary.json')]:
    target=dest/name;assert not target.exists();target.write_bytes(original.read_bytes());assert sha(target)==sha(original)
note=f'''\n\n2026-10-09 Druid SQLXML绑定委托阶段证据：135原六合同实际0/6行为RED，140新增父级关闭等待验证后取消交接，原七合同实际0/7 RED，均1235冻结无变化。137仅一生产代理方法增加等待payload锁前后生命周期检查、无admit的同一驱动委托及释放锁后原错误分类；七原断言不改。已完成binding7/0、完整owner112/0（原105保留）及三个指定目标严格Clippy0；原session79819控制Python{pid}与直属Cargo现场确认存活，正在pooled-stream编译，后继Druid lib与fmt未取得终态。135启动脚本第一次设置错误Cargo未执行，138保存现场并按134快照恢复后修正，未计产品RED。zip145 SHA {sha(z)}为136父链的两路径delta，保存全部真实RED与三个已完成GREEN、冻结清单及部分运行日志，逐项解压SHA及E镜像一致；部分日志不是通过证据。141终态归档脚本已准备，须137全部六命令实际exit0才可运行。正式Rust未apply；原113/129完整回归继续各自冻结快照，工具补齐确认仍待回复，Task6 FIX_REQUIRED/Task7八义务/Task8 INCOMPLETE/18顶层OPEN。\n'''
for rel in ['.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md','docs/verification/rdbc-first/status.md','docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md']:
    target=e/rel;raw=target.read_bytes();assert b'zip145 SHA' not in raw;target.write_bytes(raw+note.encode('utf-8'))
print(json.dumps(dict(archive=str(z),sha256=sha(z),source_changes=list(delta),verified_live_process=process)),flush=True)
