
#[tokio::test]
async fn task7_xml_binding_cancelled_validation_unblocks_parent_cleanup_exactly_once() {
    let control = Arc::new(Control::default());
    let mut connection = pooled(control.clone()).await;
    let mut xml = connection.create_sql_xml().await.unwrap();
    let probe = control.xml.lock().unwrap()[0].clone();
    probe.read_block.store(true, Ordering::SeqCst);
    let mut validation = xml.validate_for_binding();
    let pending = std::future::poll_fn(|cx| {
        std::task::Poll::Ready(std::future::Future::poll(validation.as_mut(), cx).is_pending())
    }).await;
    assert!(pending, "driver validation must be in flight");
    let mut closing = Box::pin(connection.close());
    let close_pending = std::future::poll_fn(|cx| {
        std::task::Poll::Ready(std::future::Future::poll(closing.as_mut(), cx).is_pending())
    }).await;
    assert!(close_pending, "parent cleanup must await the in-flight payload");
    assert_eq!(probe.release.calls.load(Ordering::SeqCst), 0);
    // 取消验证交还独占payload锁，父级监管任务继续释放，不能依赖验证调用者存活。
    drop(validation);
    tokio::time::timeout(Duration::from_secs(2), closing)
        .await.expect("cancelled validation must unblock parent cleanup").unwrap();
    assert_eq!(probe.validations.load(Ordering::SeqCst), 1);
    assert_eq!(probe.release.calls.load(Ordering::SeqCst), 1);
    assert_eq!(probe.reads.load(Ordering::SeqCst), 0);
    assert_eq!(probe.writes.load(Ordering::SeqCst), 0);
    assert_eq!(xml.validate_for_binding().await.unwrap_err().class_name(), "java.sql.SQLException");
    xml.free().await.unwrap();
    connection.close().await.unwrap();
    assert_eq!(probe.release.calls.load(Ordering::SeqCst), 1);
    assert_eq!(control.returns.lock().unwrap().len(), 1);
    assert!(control.returns.lock().unwrap()[0].is_reusable());
}
