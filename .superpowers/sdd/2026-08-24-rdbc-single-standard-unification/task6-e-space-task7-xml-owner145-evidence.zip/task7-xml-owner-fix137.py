import hashlib,json,os,re,subprocess
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d117');d=b/'task7-xml-owner-fix137'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
previous=json.loads((b/'task7-xml-owner-red140/summary.json').read_text(encoding='utf-8'))
assert previous['terminal'] and previous['expected_behavior_red']
f=json.loads((b/'task7-xml-owner-red140/frozen-inputs.json').read_text(encoding='utf-8'))
assert len(f)==1235 and all(sha(w/r)==h for r,h in f.items());d.mkdir(exist_ok=False)
rel='crates/druid/src/core/druid_sql_xml.rs';p=w/rel;raw=p.read_bytes();(d/'before.rs').write_bytes(raw);s=raw.decode('utf-8')
old='impl SqlXml for DruidSqlXml {\n'
new='''impl SqlXml for DruidSqlXml {
    async fn validate_for_binding(&mut self) -> Result<(), RdbcError> {
        let operation = "SQLXML#validate_for_binding";
        self.require(ResourceOperations::empty(), operation)?;
        let result = {
            let mut payload = self.state.payload.lock().await;
            // 等待期间owner或free可能关闭资源；验证不调用admit、不消耗读写机会。
            self.require(ResourceOperations::empty(), operation)?;
            payload.driver.validate_for_binding().await
        };
        // 释放payload锁后沿用所属连接的异常分类，保留驱动原错误和恰好一次处置。
        self.state.context.classify_operation_result(result)
    }
'''
assert s.count(old)==1;p.write_text(s.replace(old,new),encoding='utf-8',newline='');changes={rel:sha(p)}
source=(b/'task7-sql-xml-fix133.py').read_text(encoding='utf-8');tail=source[source.index("tool='C:/Users/"):]
start=tail.index('\ncommands=[')+1;end=tail.index('\nfor name,args in commands:',start)
commands='''commands=[
('binding-green',['test','-p','druid','--test','resource_owner_cancellation_test','task7_xml_binding_','--locked','--offline','-j1']),
('owner-complete',['test','-p','druid','--test','resource_owner_cancellation_test','--locked','--offline','-j1']),
('owner-strict',['clippy','-p','druid','--test','resource_owner_cancellation_test','--test','task7_pooled_async_result_set_test','--test','task7_pooled_stream_drop_test','--locked','--offline','-j1','--','-D','warnings']),
('pooled-stream',['test','-p','druid','--test','task7_pooled_async_result_set_test','--test','task7_pooled_stream_drop_test','--locked','--offline','-j1']),
('druid-lib',['test','-p','druid','--lib','--all-features','--locked','--offline','-j1']),
('format-check',['fmt','--all','--','--check'])]
'''
tail=tail[:start]+commands+tail[end:]
tail=tail.replace('Only wires the pre-existing validation helper into the new standard method; original eight tests and assertions unchanged','Original seven binding RED contracts and all prior 105 owner assertions unchanged; only one production proxy delegates standard validation')
tail=tail.replace('Binding validation belongs to the same canonical SqlXml driver; default refuses unknown readiness, preserving XML framework ownership, raw errors and read/write consumption gates','Druid SQLXML validates parent and registration before and after acquiring the same payload lock, delegates without admit, releases lock before classifying the original driver result')
exec(compile(tail,str(b/'task7-xml-owner-fix137.py'),'exec'))
