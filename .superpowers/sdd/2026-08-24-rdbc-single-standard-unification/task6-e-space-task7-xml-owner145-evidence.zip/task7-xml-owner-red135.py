import hashlib,json,os,re,subprocess
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d117');d=b/'task7-xml-owner-red135'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
previous=json.loads((b/'task7-sql-xml-quality134/summary.json').read_text(encoding='utf-8'))
assert previous['terminal'] and previous['exit_code']==0 and len(previous['commands'])==5
assert all(c['exit_code']==0 and not c['changed_inputs'] for c in previous['commands'])
f=json.loads((b/'task7-sql-xml-quality134/frozen-inputs.json').read_text(encoding='utf-8'))
assert len(f)==1235 and all(sha(w/r)==h for r,h in f.items());d.mkdir(exist_ok=False)
rel='crates/druid/tests/resource_owner_cancellation_test.rs';p=w/rel;raw=p.read_bytes();(d/'before.rs').write_bytes(raw);s=raw.decode('utf-8')
replacements=[('struct XmlProbe {\n    release: payload_fixture::ReleaseProbe,','struct XmlProbe {\n    validations: AtomicUsize,\n    release: payload_fixture::ReleaseProbe,'),('impl XmlProbe {\n    fn new(block: bool) -> Self {\n        Self {','impl XmlProbe {\n    fn new(block: bool) -> Self {\n        Self {\n            validations: AtomicUsize::new(0),')]
hook='''    async fn validate_for_binding(&mut self) -> Result<(), RdbcError> {
        self.open()?;
        self.not_sync.set(self.not_sync.get() + 1);
        self.probe.validations.fetch_add(1, Ordering::SeqCst);
        if self.probe.read_block.load(Ordering::SeqCst) {
            self.probe.read_finish.notified().await;
        }
        if self.probe.release.read_failure.load(Ordering::SeqCst) {
            Err(fatal_error())
        } else if self.probe.read_nonfatal.load(Ordering::SeqCst) {
            Err(RdbcError::SqlException(Box::new(SqlException::new(
                88, Some("22000".into()), Some("invalid XML".into()),
            ))))
        } else {
            Ok(())
        }
    }
'''
replacements.append(('impl SqlXml for XmlDriver {\n','impl SqlXml for XmlDriver {\n'+hook))
for old,new in replacements:
    assert s.count(old)==1;s=s.replace(old,new)
reverse=s
for old,new in reversed(replacements):reverse=reverse.replace(new,old)
assert reverse.encode('utf-8')==raw
draft=(b/'task7-xml-owner135.rs').read_text(encoding='utf-8');assert draft.count('#[tokio::test]')==6
p.write_text(s+draft,encoding='utf-8',newline='');changes={rel:sha(p)}
source=(b/'task7-sql-xml-fix133.py').read_text(encoding='utf-8');tail=source[source.index("tool='C:/Users/"):]
start=tail.index('\ncommands=[')+1;end=tail.index('\nfor name,args in commands:',start)
tail=tail[:start]+"commands=[('owner-binding-red',['test','-p','druid','--test','resource_owner_cancellation_test','task7_xml_binding_','--locked','--offline','-j1'])]"+tail[end:]
tail=tail.replace('Only wires the pre-existing validation helper into the new standard method; original eight tests and assertions unchanged','Add six owner binding contracts plus driver fixture validation; original 105 owner contracts and all production sources unchanged')
tail=tail.replace('s.update(terminal=True,exit_code=r.returncode);','s.update(terminal=True,exit_code=r.returncode,expected_behavior_red=(r.returncode==101 and entry["passed"]==0 and entry["failed"]==6 and not entry["changed_inputs"]));')
exec(compile(tail,str(b/'task7-xml-owner-red135.py'),'exec'))
