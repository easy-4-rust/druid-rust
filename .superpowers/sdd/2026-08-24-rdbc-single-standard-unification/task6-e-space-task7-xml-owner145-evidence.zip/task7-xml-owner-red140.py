import hashlib,json,os,re,subprocess
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d117');d=b/'task7-xml-owner-red140'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
previous=json.loads((b/'task7-xml-owner-red135/summary.json').read_text(encoding='utf-8'))
assert previous['terminal'] and previous['expected_behavior_red'] and previous['commands'][0]['failed']==6
f=json.loads((b/'task7-xml-owner-red135/frozen-inputs.json').read_text(encoding='utf-8'))
assert len(f)==1235 and all(sha(w/r)==h for r,h in f.items());d.mkdir(exist_ok=False)
rel='crates/druid/tests/resource_owner_cancellation_test.rs';p=w/rel;raw=p.read_bytes();(d/'before.rs').write_bytes(raw)
draft=(b/'task7-xml-owner-close139.rs').read_bytes();assert draft.count(b'#[tokio::test]')==1;p.write_bytes(raw+draft);changes={rel:sha(p)}
source=(b/'task7-sql-xml-fix133.py').read_text(encoding='utf-8');tail=source[source.index("tool='C:/Users/"):]
start=tail.index('\ncommands=[')+1;end=tail.index('\nfor name,args in commands:',start)
tail=tail[:start]+"commands=[('owner-binding-red',['test','-p','druid','--test','resource_owner_cancellation_test','task7_xml_binding_','--locked','--offline','-j1'])]"+tail[end:]
tail=tail.replace('Only wires the pre-existing validation helper into the new standard method; original eight tests and assertions unchanged','Preserve original 105 owner and six initial binding assertions; add parent cleanup waiting on cancelled validation; production unchanged')
tail=tail.replace('s.update(terminal=True,exit_code=r.returncode);','s.update(terminal=True,exit_code=r.returncode,expected_behavior_red=(r.returncode==101 and entry["passed"]==0 and entry["failed"]==7 and not entry["changed_inputs"]));')
compile(tail,str(b/'task7-xml-owner-red140.py'),'exec')
exec(compile(tail,str(b/'task7-xml-owner-red140.py'),'exec'))
