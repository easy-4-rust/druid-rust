import hashlib,json
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d117');old=b/'task7-xml-owner-red135';d=b/'task7-xml-owner-setup138'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
f=json.loads((b/'task7-sql-xml-quality134/frozen-inputs.json').read_text(encoding='utf-8'))
rel='crates/druid/tests/resource_owner_cancellation_test.rs';p=w/rel
assert not (old/'summary.json').exists() and sha(old/'before.rs')==f[rel]
assert [r for r,h in f.items() if sha(w/r)!=h]==[rel]
assert p.read_bytes().endswith((b/'task7-xml-owner135.rs').read_bytes())
(old/'partial-test.rs').write_bytes(p.read_bytes())
(old/'runner135.failed.py').write_bytes((b/'task7-xml-owner-red135.py').read_bytes())
(old/'error.json').write_text(json.dumps(dict(terminal=True,cargo_executed=False,error='SyntaxError: opening s=dict was truncated by selecting commands=[] inside summary instead of the standalone command list',production_changed=False),indent=2)+'\n',encoding='utf-8')
assert old.resolve().parent==b.resolve() and d.resolve().parent==b.resolve() and not d.exists()
old.rename(d)
p.write_bytes((d/'before.rs').read_bytes());assert all(sha(w/r)==h for r,h in f.items())
for name in ['task7-xml-owner-red135.py','task7-xml-owner-fix137.py']:
    target=b/name;s=target.read_text(encoding='utf-8');needle="start=tail.index('commands=[');";assert s.count(needle)==1
    target.write_text(s.replace(needle,"start=tail.index('\\ncommands=[')+1;"),encoding='utf-8',newline='')
print(json.dumps(dict(recovered=True,source_restored_to134=True,preserved_failure=str(d))),flush=True)
