import hashlib,json,zipfile
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d117');e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
red=json.loads((b/'task7-xml-owner-red140/summary.json').read_text(encoding='utf-8'))
s=json.loads((b/'task7-xml-owner-fix137/summary.json').read_text(encoding='utf-8'))
assert red['terminal'] and red['expected_behavior_red'] and red['commands'][0]['failed']==7
assert s['terminal'] and s['exit_code']==0 and len(s['commands'])==6
assert all(c['exit_code']==0 and not c['changed_inputs'] and sha(Path(c['log']))==c['sha256'] for c in s['commands'])
counts={c['name']:(c['passed'],c['failed']) for c in s['commands']}
assert counts['binding-green']==(7,0) and counts['owner-complete']==(112,0)
f=json.loads((b/'task7-xml-owner-fix137/frozen-inputs.json').read_text(encoding='utf-8'));parent=json.loads((b/'task7-sql-xml-quality134/frozen-inputs.json').read_text(encoding='utf-8'))
assert len(f)==1235 and set(parent)==set(f) and all(sha(w/r)==h for r,h in f.items())
delta={r:h for r,h in f.items() if parent[r]!=h};assert set(delta)=={'crates/druid/src/core/druid_sql_xml.rs','crates/druid/tests/resource_owner_cancellation_test.rs'}
assert sha(b/'task7-sql-xml-terminal136.zip')=='132b853e0c74b9b83bda9cde8df7c3bc63ca45a4e9b09abc6c9720cc0748bb01'
files={}
for n in ['task7-xml-owner-setup138','task7-xml-owner-red135','task7-xml-owner-red140','task7-xml-owner-fix137']:
    for p in (b/n).rglob('*'):
        if p.is_file():files[str(p.relative_to(b)).replace('\\','/')]=p
for n in ['task7-xml-owner135.rs','task7-xml-owner-close139.rs','task7-xml-owner-red135.py','task7-xml-owner-setup138.py','task7-xml-owner-red140.py','task7-xml-owner-fix137.py','task7-xml-owner-terminal141.py','task7-java-xml-source-binding144.summary.json']:
    files[n]=b/n
for r in delta:files['candidate-delta/'+r]=w/r
z=b/'task7-xml-owner-terminal141.zip';assert not z.exists();manifest={n:sha(p) for n,p in files.items()}
with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED) as out:
    for n,p in files.items():out.write(p,n)
    out.writestr('archive-manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(z) as source:assert all(hashlib.sha256(source.read(n)).hexdigest()==h for n,h in manifest.items())
result=dict(terminal=True,production_applied=False,archive=str(z),archive_sha256=sha(z),archive_files=len(files),parent_archive='task7-sql-xml-terminal136.zip',parent_sha256='132b853e0c74b9b83bda9cde8df7c3bc63ca45a4e9b09abc6c9720cc0748bb01',frozen_input_count=len(f),delta=delta,commands=s['commands'],original_105_owner_contracts_preserved=True,original_7_binding_assertions_preserved=True,top_level_open=18)
local=b/'task7-xml-owner-terminal141.summary.json';local.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
dest=e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'
for original,name in [(z,'task6-e-space-task7-xml-owner141-evidence.zip'),(local,'task6-e-space-task7-xml-owner141-summary.json')]:
    target=dest/name;assert not target.exists();target.write_bytes(original.read_bytes());assert sha(target)==sha(original)
note=f'''\n\n2026-10-09 Druid SQLXML绑定委托局部终态：135首次runner选中summary内部commands=[]造成SyntaxError，Cargo未执行；138保存原runner/部分夹具并按134冻结恢复，修正独立命令列表定位后再执行，未计产品RED。135原六合同实际0/6行为RED，新增139父关闭等待验证后取消清理交接，140原七合同实际0/7 RED。137仅druid_sql_xml.rs覆盖唯一SqlXml验证，等待payload锁前后检查父级/登记，委托同一driver且不调用admit，释放锁后保留原结果分类；七原断言不改。最终binding7/0、完整owner112/0（保留原105）、池化/Drop {counts['pooled-stream'][0]}/0、Druid lib {counts['druid-lib'][0]}/0，指定三目标严格Clippy0、fmt0；1235完整输入变化0。zip141 SHA {sha(z)}含原设置失败、实际RED/GREEN、两路径delta及69份Java来源SHA重检证明，全部解压与E镜像逐项核验，可由136父链重建。Ruling: 绑定验证属于同一标准资源操作，不消耗读写机会、不绕过父级、不隐式关闭调用者资源；取消交还锁后由原监管队列完成清理。未知驱动默认拒绝仍需实库/provider验证，custom type map、RowSet与最终API/SemVer/MSRV/compiler/全仓仍开放，正式Rust未apply，Task6 FIX_REQUIRED/Task7八义务/Task8 INCOMPLETE/18顶层OPEN。\n'''
for rel in ['.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md','docs/verification/rdbc-first/status.md','docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md']:
    p=e/rel;raw=p.read_bytes();assert b'zip141 SHA' not in raw;p.write_bytes(raw+note.encode('utf-8'))
print(json.dumps(dict(archive=str(z),sha256=sha(z),counts=counts,mirrored=True)),flush=True)
