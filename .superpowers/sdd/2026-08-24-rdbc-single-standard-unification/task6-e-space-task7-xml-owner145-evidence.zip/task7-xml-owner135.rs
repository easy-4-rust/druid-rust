
#[tokio::test]
async fn task7_xml_binding_ready_delegates_without_consuming_read_or_write() {
    let control = Arc::new(Control::default());
    let mut connection = pooled(control.clone()).await;
    let mut xml = connection.create_sql_xml().await.unwrap();
    let probe = control.xml.lock().unwrap()[0].clone();
    xml.validate_for_binding().await.unwrap();
    xml.validate_for_binding().await.unwrap();
    assert_eq!(probe.validations.load(Ordering::SeqCst), 2);
    assert_eq!(probe.reads.load(Ordering::SeqCst), 0);
    assert_eq!(probe.writes.load(Ordering::SeqCst), 0);
    let text = RdbcString::from("<bound>😀</bound>");
    xml.set_string(&text).await.unwrap();
    assert_eq!(xml.string().await.unwrap(), text);
    assert_eq!(probe.reads.load(Ordering::SeqCst), 1);
    assert_eq!(probe.writes.load(Ordering::SeqCst), 1);
    connection.close().await.unwrap();
    assert_eq!(probe.release.calls.load(Ordering::SeqCst), 1);
    assert!(control.returns.lock().unwrap()[0].is_reusable());
}

#[tokio::test]
async fn task7_xml_binding_nonfatal_error_preserves_raw_error_and_read_write_gates() {
    let control = Arc::new(Control::default());
    let mut connection = pooled(control.clone()).await;
    connection.set_exception_sorter(Arc::new(CountingSorter(control.clone())));
    let mut xml = connection.create_sql_xml().await.unwrap();
    let probe = control.xml.lock().unwrap()[0].clone();
    probe.read_nonfatal.store(true, Ordering::SeqCst);
    let error = xml.validate_for_binding().await.unwrap_err();
    let expected = SqlException::new(88, Some("22000".into()), Some("invalid XML".into()));
    assert_eq!(error.sql_exception().unwrap(), &expected);
    assert!(!connection.is_closed().unwrap());
    assert_eq!(control.sorter_calls.load(Ordering::SeqCst), 1);
    assert_eq!(control.discards.load(Ordering::SeqCst), 0);
    assert_eq!(probe.reads.load(Ordering::SeqCst), 0);
    assert_eq!(probe.writes.load(Ordering::SeqCst), 0);
    probe.read_nonfatal.store(false, Ordering::SeqCst);
    xml.validate_for_binding().await.unwrap();
    let text = RdbcString::from("<recovered/>");
    xml.set_string(&text).await.unwrap();
    assert_eq!(xml.string().await.unwrap(), text);
    assert_eq!(probe.validations.load(Ordering::SeqCst), 2);
    connection.close().await.unwrap();
    assert!(control.returns.lock().unwrap()[0].is_reusable());
    assert_eq!(probe.release.calls.load(Ordering::SeqCst), 1);
}

#[tokio::test]
async fn task7_xml_binding_fatal_error_discards_and_notifies_exactly_once() {
    let control = Arc::new(Control::default());
    let mut connection = pooled(control.clone()).await;
    connection.set_exception_sorter(Arc::new(CountingSorter(control.clone())));
    let mut xml = connection.create_sql_xml().await.unwrap();
    let probe = control.xml.lock().unwrap()[0].clone();
    probe.release.read_failure.store(true, Ordering::SeqCst);
    let error = xml.validate_for_binding().await.unwrap_err();
    assert_eq!(error.sql_exception().unwrap(), fatal_error().sql_exception().unwrap());
    assert!(connection.is_closed().unwrap());
    assert_eq!(control.sorter_calls.load(Ordering::SeqCst), 1);
    assert_eq!(control.discards.load(Ordering::SeqCst), 1);
    assert!(matches!(xml.validate_for_binding().await.unwrap_err(), RdbcError::ConnectionDiscarded));
    assert_eq!(probe.validations.load(Ordering::SeqCst), 1);
    assert_eq!(control.sorter_calls.load(Ordering::SeqCst), 1);
    xml.free().await.unwrap();
    connection.close().await.unwrap();
    assert_eq!(probe.release.calls.load(Ordering::SeqCst), 1);
    assert!(!control.returns.lock().unwrap()[0].is_reusable());
}

#[tokio::test]
async fn task7_xml_binding_parent_closed_rejects_before_touching_driver() {
    let control = Arc::new(Control::default());
    let mut connection = pooled(control.clone()).await;
    let mut xml = connection.create_sql_xml().await.unwrap();
    let probe = control.xml.lock().unwrap()[0].clone();
    connection.close().await.unwrap();
    assert_eq!(xml.validate_for_binding().await.unwrap_err().class_name(), "java.sql.SQLException");
    assert_eq!(probe.validations.load(Ordering::SeqCst), 0);
    assert_eq!(probe.release.calls.load(Ordering::SeqCst), 1);
}

#[tokio::test]
async fn task7_xml_binding_freed_rejects_before_touching_driver() {
    let control = Arc::new(Control::default());
    let mut connection = pooled(control.clone()).await;
    let mut xml = connection.create_sql_xml().await.unwrap();
    let probe = control.xml.lock().unwrap()[0].clone();
    xml.free().await.unwrap();
    assert_eq!(xml.validate_for_binding().await.unwrap_err().class_name(), "java.sql.SQLException");
    assert_eq!(probe.validations.load(Ordering::SeqCst), 0);
    xml.free().await.unwrap();
    connection.close().await.unwrap();
    assert_eq!(probe.release.calls.load(Ordering::SeqCst), 1);
}

#[tokio::test]
async fn task7_xml_binding_cancelled_validation_releases_lock_without_consuming_gates() {
    let control = Arc::new(Control::default());
    let mut connection = pooled(control.clone()).await;
    let mut xml = connection.create_sql_xml().await.unwrap();
    let probe = control.xml.lock().unwrap()[0].clone();
    probe.read_block.store(true, Ordering::SeqCst);
    let mut future = xml.validate_for_binding();
    // 单次轮询必须进入真实阻塞驱动；默认不支持会立即失败，不等待通知或放宽超时。
    let pending = std::future::poll_fn(|cx| {
        std::task::Poll::Ready(std::future::Future::poll(future.as_mut(), cx).is_pending())
    }).await;
    assert!(pending, "validation must enter the same driver and remain pending");
    drop(future);
    assert_eq!(probe.validations.load(Ordering::SeqCst), 1);
    assert_eq!(probe.reads.load(Ordering::SeqCst), 0);
    assert_eq!(probe.writes.load(Ordering::SeqCst), 0);
    assert_eq!(probe.release.calls.load(Ordering::SeqCst), 0);
    probe.read_block.store(false, Ordering::SeqCst);
    xml.validate_for_binding().await.unwrap();
    assert_eq!(probe.validations.load(Ordering::SeqCst), 2);
    let text = RdbcString::from("<after-cancel/>");
    xml.set_string(&text).await.unwrap();
    assert_eq!(xml.string().await.unwrap(), text);
    connection.close().await.unwrap();
    assert_eq!(probe.release.calls.load(Ordering::SeqCst), 1);
    assert!(control.returns.lock().unwrap()[0].is_reusable());
}
