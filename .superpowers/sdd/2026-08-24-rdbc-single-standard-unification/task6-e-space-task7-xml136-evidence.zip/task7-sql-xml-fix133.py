import hashlib,json,os,re,subprocess
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d117');d=b/'task7-sql-xml-fix133'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
previous=json.loads((b/'task7-sql-xml-red132/summary.json').read_text(encoding='utf-8'))
assert previous['terminal'] and previous['expected_behavior_red'] and not previous['changed_inputs']
f=json.loads((b/'task7-sql-xml-red132/frozen-inputs.json').read_text(encoding='utf-8'))
assert len(f)==1235 and all(sha(w/r)==h for r,h in f.items());d.mkdir(exist_ok=False)
changes={}
def edit(rel,old,new):
    p=w/rel;raw=p.read_bytes();s=raw.decode('utf-8');assert s.count(old)==1
    backup=d/'before'/rel;backup.parent.mkdir(parents=True,exist_ok=True);backup.write_bytes(raw)
    p.write_text(s.replace(old,new),encoding='utf-8',newline='');changes[rel]=sha(p)
edit('crates/druid-rdbc/src/resource/sql_xml.rs','''    /// 对应 Java: SQLXML#free()；释放后其他JDBC方法拒绝，重复释放无副作用。''','''    /// 验证本XML能否绑定到SQL输出，无参数；返回成功或原数据库/XML异常。
    /// 对应 Java: SQLOutput#writeSQLXML 的前置状态合同（Rust平台扩展）。
    /// 驱动必须确认所有Writer、OutputStream和框架Result已完成关闭，并传播XML处理错误。
    /// 本操作不得消费读写机会、读取XML内容或隐式关闭调用者资源；未知状态默认明确拒绝。
    async fn validate_for_binding(&mut self) -> Result<(), RdbcError> {
        Err(RdbcError::feature_not_supported("SQLXML#validate_for_binding"))
    }
    /// 对应 Java: SQLXML#free()；释放后其他JDBC方法拒绝，重复释放无副作用。''')
edit('crates/druid-rdbc/src/resource/rdbc_sql_xml.rs','''    /// 幂等释放，无参数；失败或取消不误报成功，后续free重试确认。对应 Java: SQLXML#free。''','''    /// 验证当前XML的绑定状态，无参数；返回成功或原生命周期、状态或XML处理异常。
    /// 对应 Java: SQLOutput#writeSQLXML；只串行委托唯一标准驱动，不消耗读写机会或提前读取XML。
    pub async fn validate_for_binding(&self) -> Result<(), RdbcError> {
        // 绑定验证与free使用同一独占锁，并在等待前后检查释放状态。
        self.value
            .lock(ResourceOperations::empty(), "SQLXML#validate_for_binding")
            .await?
            .driver
            .validate_for_binding()
            .await
    }
    /// 幂等释放，无参数；失败或取消不误报成功，后续free重试确认。对应 Java: SQLXML#free。''')
edit('crates/druid-rdbc/src/extensions/buffered_sql_output.rs','''    async fn write_sql_xml(&mut self, value: Option<RdbcSqlXml>) -> Result<(), RdbcError> {
        self.push(value.map_or(RdbcObject::Scalar(Value::Null), RdbcObject::SqlXml));''','''    async fn write_sql_xml(&mut self, value: Option<RdbcSqlXml>) -> Result<(), RdbcError> {
        // 驱动确认写入端已关闭且XML可用后才发布属性；错误或取消不留下部分输出。
        if let Some(value) = &value {
            value.validate_for_binding().await?;
        }
        self.push(value.map_or(RdbcObject::Scalar(Value::Null), RdbcObject::SqlXml));''')
edit('crates/druid-rdbc/tests/standard_sql_xml_binding_contract_test.rs','''impl SqlXml for ReadyXml {
''','''impl SqlXml for ReadyXml {
    async fn validate_for_binding(&mut self) -> Result<(), RdbcError> {
        self.validate_binding().await
    }
''')
tool='C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin';env=os.environ.copy()
env.update(RUSTC=tool+'/rustc.exe',RUSTDOC=tool+'/rustdoc.exe',RUSTUP_TOOLCHAIN='1.97.1-x86_64-pc-windows-msvc',RUSTUP_AUTO_INSTALL='0',PATH=tool+os.pathsep+env['PATH'],CARGO_TARGET_DIR='F:/codex_build_cache/dr103_target',CARGO_BUILD_JOBS='1',TMP='F:/codex_tmp/task7_standard_cargo13',TEMP='F:/codex_tmp/task7_standard_cargo13')
with (d/'format.log').open('xb') as out:r=subprocess.run([tool+'/rustfmt.exe','--edition','2021']+[str(w/r) for r in changes],env=env,stdout=out,stderr=subprocess.STDOUT)
assert r.returncode==0 and sorted(r for r,h in f.items() if sha(w/r)!=h)==sorted(changes)
for rel in changes:f[rel]=sha(w/rel)
(d/'frozen-inputs.json').write_text(json.dumps(f,indent=2)+'\n',encoding='utf-8')
s=dict(terminal=False,production_applied=False,workspace=str(w),pid=os.getpid(),frozen_input_count=len(f),changed_sources=list(changes),fixture_change='Only wires the pre-existing validation helper into the new standard method; original eight tests and assertions unchanged',ruling='Binding validation belongs to the same canonical SqlXml driver; default refuses unknown readiness, preserving XML framework ownership, raw errors and read/write consumption gates',commands=[])
save=lambda:(d/'summary.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8');save()
common=['--all-features','--locked','--offline','-j1']
commands=[('binding-contract',['test','-p','druid-rdbc','--test','standard_sql_xml_binding_contract_test']+common),('binding-strict',['clippy','-p','druid-rdbc','--test','standard_sql_xml_binding_contract_test']+common+['--','-D','warnings']),('original-mapping',['test','-p','druid-rdbc','--test','standard_sql_mapping_contract_test']+common),('rdbc-complete',['test','-p','druid-rdbc']+common+['--no-fail-fast']),('format-check',['fmt','--all','--','--check'])]
for name,args in commands:
    cmd=[tool+'/cargo.exe']+args;log=d/(name+'.log');s['running_command']=name;save()
    with log.open('xb') as out:r=subprocess.run(cmd,cwd=w,env=env,stdout=out,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
    blocks=re.findall(r'^test result: .*?(\d+) passed; (\d+) failed; (\d+) ignored;',log.read_text(encoding='utf-8'),re.M)
    entry=dict(name=name,command=cmd,exit_code=r.returncode,log=str(log),sha256=sha(log),passed=sum(int(v[0]) for v in blocks),failed=sum(int(v[1]) for v in blocks),changed_inputs=[r for r,h in f.items() if sha(w/r)!=h]);s['commands'].append(entry);save();print(json.dumps(entry),flush=True)
    if r.returncode or entry['changed_inputs']:break
s.update(terminal=True,exit_code=r.returncode);s.pop('running_command',None);save();print(json.dumps(dict(terminal=True,exit_code=r.returncode)),flush=True)
