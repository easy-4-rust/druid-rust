import hashlib,json,os,re,subprocess
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d117');d=b/'task7-sql-xml-quality134'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
previous=json.loads((b/'task7-sql-xml-fix133/summary.json').read_text(encoding='utf-8'))
assert previous['terminal'] and previous['exit_code']==101
assert [(c['name'],c['exit_code']) for c in previous['commands']]==[('binding-contract',0),('binding-strict',101)]
f=json.loads((b/'task7-sql-xml-fix133/frozen-inputs.json').read_text(encoding='utf-8'))
assert len(f)==1235 and all(sha(w/r)==h for r,h in f.items());d.mkdir(exist_ok=False)
rel='crates/druid-rdbc/tests/standard_sql_xml_binding_contract_test.rs';p=w/rel;raw=p.read_bytes();(d/'before.rs').write_bytes(raw)
s=raw.decode('utf-8')
replacements=[('async fn validate_binding(&mut self)', 'fn validate_binding(&mut self)'),('self.validate_binding().await','self.validate_binding()'),('RdbcReader::from_string("<ready/>".to_owned())','RdbcReader::from_string("<ready/>")')]
for old,new in replacements:
    assert s.count(old)==1;s=s.replace(old,new)
reverse=s
for old,new in reversed(replacements):reverse=reverse.replace(new,old)
assert reverse.encode('utf-8')==raw
p.write_text(s,encoding='utf-8',newline='');f[rel]=sha(p);changes={rel:f[rel]}
source=(b/'task7-sql-xml-fix133.py').read_text(encoding='utf-8');tail=source[source.index("tool='C:/Users/"):]
tail=tail.replace("sorted(changes)","sorted(changes)")
tail=tail.replace("assert r.returncode==0 and sorted(r for r,h in f.items() if sha(w/r)!=h)==sorted(changes)","assert r.returncode==0")
tail=tail.replace('Only wires the pre-existing validation helper into the new standard method; original eight tests and assertions unchanged','Remove two fixture-only Clippy diagnostics; all eight tests and assertions and production sources unchanged from133')
exec(compile(tail,str(b/'task7-sql-xml-quality134.py'),'exec'))
