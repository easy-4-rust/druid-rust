import hashlib,json,os,re,subprocess
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
w=Path('F:/codex_build_cache/d117');d=b/'task7-sql-xml-red132'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
previous=json.loads((b/'task7-sql-type-probes125/summary.json').read_text(encoding='utf-8'))
assert previous['terminal'] and not previous['changed_inputs']
f=json.loads((b/'task7-sql-type-retry127/frozen-inputs.json').read_text(encoding='utf-8'))
assert len(f)==1234 and all(sha(w/r)==h for r,h in f.items());d.mkdir(exist_ok=False)
rel='crates/druid-rdbc/tests/standard_sql_xml_binding_contract_test.rs';p=w/rel
assert not p.exists();p.write_bytes((b/'task7-sql-xml-binding131.rs').read_bytes())
tool='C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin'
env=os.environ.copy();env.update(RUSTC=tool+'/rustc.exe',RUSTDOC=tool+'/rustdoc.exe',RUSTUP_TOOLCHAIN='1.97.1-x86_64-pc-windows-msvc',RUSTUP_AUTO_INSTALL='0',PATH=tool+os.pathsep+env['PATH'],CARGO_TARGET_DIR='F:/codex_build_cache/dr103_target',CARGO_BUILD_JOBS='1',TMP='F:/codex_tmp/task7_standard_cargo13',TEMP='F:/codex_tmp/task7_standard_cargo13')
with (d/'format.log').open('xb') as out:r=subprocess.run([tool+'/rustfmt.exe','--edition','2021',str(p)],env=env,stdout=out,stderr=subprocess.STDOUT)
assert r.returncode==0 and all(sha(w/r)==h for r,h in f.items())
f[rel]=sha(p);(d/'frozen-inputs.json').write_text(json.dumps(f,indent=2)+'\n',encoding='utf-8')
s=dict(terminal=False,production_applied=False,workspace=str(w),pid=os.getpid(),frozen_input_count=len(f),tests=8)
save=lambda:(d/'summary.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8');save()
cmd=[tool+'/cargo.exe','test','-p','druid-rdbc','--test','standard_sql_xml_binding_contract_test','--all-features','--locked','--offline','-j1'];log=d/'binding-red.log'
with log.open('xb') as out:r=subprocess.run(cmd,cwd=w,env=env,stdout=out,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
raw=log.read_text(encoding='utf-8');blocks=re.findall(r'^test result: .*?(\d+) passed; (\d+) failed;',raw,re.M)
s.update(terminal=True,exit_code=r.returncode,command=cmd,log=str(log),sha256=sha(log),diagnostics=re.findall(r'error\[(E\d+)\]',raw),passed=sum(int(v[0]) for v in blocks),failed=sum(int(v[1]) for v in blocks),changed_inputs=[r for r,h in f.items() if sha(w/r)!=h])
s['expected_behavior_red']=s['exit_code']==101 and s['passed']==1 and s['failed']==7 and not s['diagnostics']
save();print(json.dumps(s,indent=2),flush=True)
