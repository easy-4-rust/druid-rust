import hashlib,json,zipfile
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d117');e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
s=json.loads((b/'task7-sql-xml-quality134/summary.json').read_text(encoding='utf-8'))
assert s['terminal'] and s['exit_code']==0 and len(s['commands'])==5
assert all(c['exit_code']==0 and not c['changed_inputs'] and sha(Path(c['log']))==c['sha256'] for c in s['commands'])
f=json.loads((b/'task7-sql-xml-quality134/frozen-inputs.json').read_text(encoding='utf-8'))
parent=json.loads((b/'task7-sql-type-retry127/frozen-inputs.json').read_text(encoding='utf-8'))
assert len(f)==1235 and len(parent)==1234 and all(sha(w/r)==h for r,h in f.items())
delta={r:h for r,h in f.items() if parent.get(r)!=h}
assert len(delta)==4 and not (set(parent)-set(f))
files={}
for n in ['task7-sql-xml-red132','task7-sql-xml-fix133','task7-sql-xml-quality134']:
    for p in (b/n).rglob('*'):
        if p.is_file():files[str(p.relative_to(b)).replace('\\','/')]=p
for n in ['task7-sql-xml-binding131.rs','task7-sql-xml-red132.py','task7-sql-xml-fix133.py','task7-sql-xml-quality134.py','task7-sql-xml-terminal136.py']:
    files[n]=b/n
for r in delta:files['candidate-delta/'+r]=w/r
j=b/'task8-java-jdbc42-source/jdk/src/share/classes/java/sql/SQLOutput.java';assert j.is_file();files['java-oracle/SQLOutput.java']=j
z=b/'task7-sql-xml-terminal136.zip';assert not z.exists()
manifest={n:sha(p) for n,p in files.items()}
with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED) as out:
    for n,p in files.items():out.write(p,n)
    out.writestr('archive-manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(z) as source:
    assert all(hashlib.sha256(source.read(n)).hexdigest()==h for n,h in manifest.items())
result=dict(terminal=True,production_applied=False,archive_sha256=sha(z),archive_files=len(files),parent_archive='task7-sql-mapping-terminal126.zip',parent_archive_sha256='b9988c511d3f06ed8dfc6f6f8eaab14520ca118c7814bc6fa9cc0ac2e0da63d5',parent_full_archive='task7-standard-events-and-regression-terminal109.zip',parent_full_archive_sha256='34823d32312df40e36d0b05e2d9cef381d3564ad20b9f1b24c41f33c016da20b',frozen_input_count=len(f),delta=delta,java_output_sha256=sha(j),commands=s['commands'],remaining=['Druid SQLXML proxy binding delegation and owner contracts','custom type map instantiation','final full workspace C1/C2 API compiler SemVer MSRV features and real databases'],top_level_open=18)
local=b/'task7-sql-xml-terminal136.summary.json';local.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
dest=e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'
for original,name in [(z,'task6-e-space-task7-xml136-evidence.zip'),(local,'task6-e-space-task7-xml136-summary.json')]:
    target=dest/name;assert not target.exists();target.write_bytes(original.read_bytes());assert sha(target)==sha(original)
counts={c['name']:(c['passed'],c['failed']) for c in s['commands']}
note=f'''\n\n2026-10-09 SQLXML绑定验证候选局部终态：原132实际1PASS7FAIL行为RED保留；133在唯一标准SqlXml增加驱动验证、同一RdbcSqlXml独占锁串行委托，BufferedSqlOutput验证成功后才发布属性，默认未知绑定状态明确Unsupported，不提前读取、不消费读写机会、不隐式关闭调用者流。原133行为8/0后严格Clippy因夹具多余to_owned/无await helper失败；134仅修两夹具诊断，原八测试及断言和三生产源码不变。134最终绑定{counts['binding-contract'][0]}/0、指定严格Clippy0、原SQL映射{counts['original-mapping'][0]}/0、完整RDBC allfeatures {counts['rdbc-complete'][0]}/0、fmt0；1235完整冻结输入变化0。zip136 SHA {sha(z)}含原RED/质量失败/最终GREEN、固定Java SQLOutput原件及相对126的四路径delta，全部解压SHA及E镜像一致。Ruling: XML框架写状态由同一驱动验证，不通过读取XML猜测，不增加第二资源端口；代价是未知驱动必须实现验证后才允许绑定。Druid代理当前尚未覆盖该验证方法，后续须先执行owner RED再委托并验证fatal/nonfatal/关闭/free/取消。custom type map及最终全仓/API/实库未闭合，正式Rust未apply，Task6 FIX_REQUIRED/Task7八义务/Task8 INCOMPLETE/18顶层OPEN。\n'''
for rel in ['.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md','docs/verification/rdbc-first/status.md','docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md']:
    p=e/rel;raw=p.read_bytes();assert 'zip136 SHA'.encode() not in raw;p.write_bytes(raw+note.encode('utf-8'))
print(json.dumps(dict(archive=str(z),sha256=sha(z),rdbc=counts['rdbc-complete'],evidence_files=len(files),mirrored=True)),flush=True)
