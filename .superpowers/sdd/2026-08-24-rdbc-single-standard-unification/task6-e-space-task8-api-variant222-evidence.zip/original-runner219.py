from pathlib import Path
import hashlib,json,re,subprocess,sys,zipfile,shutil
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
w=Path('F:/codex_build_cache/d177');e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust')
d=b/'task8-api-variant-green219';d.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
base=json.loads((b/'task7-row-set-implementation210/frozen-inputs.json').read_text())
expected={'scripts/verify_jdbc42_final_runtime.py','scripts/test_api_enum_variant_contract.py'}
f={r:sha(w/r) for r in base};f['scripts/test_api_enum_variant_contract.py']=sha(w/'scripts/test_api_enum_variant_contract.py')
delta={r:h for r,h in f.items() if base.get(r)!=h}
assert set(delta)==expected and len(f)==1273
(d/'frozen-inputs.json').write_text(json.dumps(f,indent=2)+'\n',encoding='utf-8')
s={'terminal':False,'production_applied':False,'workspace':str(w),'frozen_input_count':len(f),'commands':[],'source_delta':delta}
for name,count in [('test_api_enum_variant_contract.py',7),('test_jdbc42_final_cli.py',23),('test_verify_jdbc42_semantic_inventory.py',35),('test_verify_jdbc42_public_entries.py',10)]:
 cmd=[sys.executable,'-X','utf8','-m','unittest','discover','-s','scripts','-p',name,'-v'];log=d/(name+'.log')
 with log.open('wb') as out:r=subprocess.run(cmd,cwd=w,stdout=out,stderr=subprocess.STDOUT)
 text=log.read_text(encoding='utf-8');assert r.returncode==0 and re.search(r'Ran '+str(count)+r' tests',text) and text.rstrip().endswith('OK')
 assert all(sha(w/p)==h for p,h in f.items())
 s['commands'].append(dict(command=cmd,exit_code=r.returncode,passed=count,log=str(log),sha256=sha(log)))
 print(name,count,flush=True)
cmd=[sys.executable,'-X','utf8','scripts/verify_jdbc42_semantic_inventory.py','--repository-root',str(w),'--require-final-evidence']
log=d/'actual-final-cli.log'
with log.open('wb') as out:r=subprocess.run(cmd,cwd=w,stdout=out,stderr=subprocess.STDOUT)
s['actual_cli']={'command':cmd,'exit_code':r.returncode,'log':str(log),'sha256':sha(log)}
assert r.returncode==1 and 'PLANNED_TARGET' in log.read_text(encoding='utf-8')
assert all(sha(w/p)==h for p,h in f.items())
s.update(terminal=True,tests_passed=75,task8_complete=False,inputs_unchanged=True)
(d/'summary.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
parent=b/'task7-row-set-public-probes216.zip';assert sha(parent)=='8ae7046eb73948ff9f93bea700e356bc091e563b25ef2d6ed3fcf93f2242d4c4'
files={'green/'+p.name:p for p in d.iterdir() if p.is_file()}
files.update({'red/'+p.name:p for p in (b/'task8-api-variant-red218').iterdir() if p.is_file()})
files['runner.py']=Path(__file__)
for p in delta:files['source-delta/'+p]=w/p
manifest={n:sha(p) for n,p in files.items()}
z=b/'task8-api-variant-terminal219.zip';assert not z.exists()
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as out:
 for n,p in files.items():out.write(p,n)
 out.writestr('manifest.json',json.dumps(manifest,indent=2))
 out.writestr('scope.json',json.dumps(dict(scope='API_UNIT_ENUM_VARIANT_PARSER_ONLY',parent_sha256=sha(parent),production_applied=False,task8_complete=False,historical_api_is_format_fixture_only=True,source_delta=delta),indent=2))
with zipfile.ZipFile(z) as out:assert all(hashlib.sha256(out.read(n)).hexdigest()==h for n,h in manifest.items())
s['archive_sha256']=sha(z);s['verified_entries']=len(manifest)
summary=b/'task8-api-variant-terminal219.summary.json';summary.write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
mirror=e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'
for src,name in [(z,'task6-e-space-task8-api-variant219-evidence.zip'),(summary,'task6-e-space-task8-api-variant219-summary.json')]:
 target=mirror/name;assert not target.exists();shutil.copyfile(src,target);assert sha(target)==sha(src)
note='\n\n2026-10-09 最终API单元枚举成员识别219：218原7合同5PASS/2ERROR，缺少实际cargo-public-api格式的枚举成员识别，原生产源SHA未变。候选仅修正验证器并增加原7合同，成员需完整路径及直接父枚举声明，不从父枚举推断缺失成员，不接受关联常量、字段或DTO冒充；原enum/struct/module/trait检查保持严格。新7、原CLI23、原语义35、原公共入口10，共75自测实际PASS；前文35/23套件名称次序在此按实际结果明确。当前实际最终CLI仍exit1/row2 PLANNED_TARGET，下游未执行，不晋升清单状态。1273冻结输入终态变化0，相对210仅两个Python路径delta；Rust/原测试/库存清单未改，d215仍保留原1272快照。zip219 SHA '+sha(z)+'，父216，全部条目/E镜像SHA核验。历史API只作为格式夹具，未执行新cargo-public-api或认证真实API/SemVer。正式Rust与CLI未apply；Task6 FIX_REQUIRED/Task7八义务/Task8 INCOMPLETE/18顶层OPEN。\n'
for p in ['.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md','docs/verification/rdbc-first/status.md','docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md']:
 with (e/p).open('ab') as out:out.write(note.encode('utf-8'))
print(json.dumps(dict(archive_sha256=sha(z),tests_passed=75,actual_cli_exit=r.returncode,verified_entries=len(manifest))))
