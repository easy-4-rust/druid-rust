from pathlib import Path
import hashlib,json,re,subprocess,sys,zipfile,shutil
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d177');e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust');d=b/'task8-api-variant-green219';o=b/'task8-api-variant-terminal222';o.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
f=json.loads((d/'frozen-inputs.json').read_text());base=json.loads((b/'task7-row-set-implementation210/frozen-inputs.json').read_text());assert len(f)==1273 and all(sha(w/r)==h for r,h in f.items());delta={r:h for r,h in f.items() if base.get(r)!=h};assert set(delta)=={'scripts/verify_jdbc42_final_runtime.py','scripts/test_api_enum_variant_contract.py'}
commands=[]
for name,count in [('test_api_enum_variant_contract.py',7),('test_jdbc42_final_cli.py',23),('test_verify_jdbc42_semantic_inventory.py',35),('test_verify_jdbc42_public_entries.py',10)]:
 log=d/(name+'.log');t=log.read_text(encoding='utf-8');assert re.search(r'Ran '+str(count)+r' tests',t) and t.rstrip().endswith('OK');commands.append(dict(name=name,passed=count,log=str(log),sha256=sha(log)))
cmd=[sys.executable,'-X','utf8','scripts/verify_jdbc42_semantic_inventory.py','--require-final-evidence'];log=o/'actual-final-cli.log'
with log.open('wb') as out:r=subprocess.run(cmd,cwd=w,stdout=out,stderr=subprocess.STDOUT)
assert r.returncode==1 and 'PLANNED_TARGET' in log.read_text(encoding='utf-8')
assert all(sha(w/p)==h for p,h in f.items())
s=dict(terminal=True,production_applied=False,tests_passed=75,task8_complete=False,source_delta=delta,inputs_unchanged=True,frozen_input_count=len(f),commands=commands,actual_cli=dict(command=cmd,exit_code=r.returncode,log=str(log),sha256=sha(log)),prior_runner_error='219 --repository-root unsupported exit2; original logs retained; not product failure')
(o/'summary.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
parent=b/'task7-row-set-public-probes216.zip';assert sha(parent)=='8ae7046eb73948ff9f93bea700e356bc091e563b25ef2d6ed3fcf93f2242d4c4'
files={}
for folder,prefix in [(d,'green'),(o,'terminal'),(b/'task8-api-variant-red218','red')]:
 for p in folder.iterdir():
  if p.is_file():files[prefix+'/'+p.name]=p
files['original-runner219.py']=b/'task8-api-variant-green219.py';files['runner222.py']=Path(__file__)
for p in delta:files['source-delta/'+p]=w/p
manifest={n:sha(p) for n,p in files.items()};z=b/'task8-api-variant-terminal222.zip';assert not z.exists()
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as out:
 for n,p in files.items():out.write(p,n)
 out.writestr('manifest.json',json.dumps(manifest,indent=2));out.writestr('scope.json',json.dumps(dict(scope='API_UNIT_ENUM_VARIANT_PARSER_ONLY',parent_sha256=sha(parent),production_applied=False,task8_complete=False,historical_api_is_format_fixture_only=True,source_delta=delta),indent=2))
with zipfile.ZipFile(z) as out:assert all(hashlib.sha256(out.read(n)).hexdigest()==h for n,h in manifest.items())
s.update(archive_sha256=sha(z),verified_entries=len(manifest));summary=b/'task8-api-variant-terminal222.summary.json';summary.write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
mirror=e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'
for src,name in [(z,'task6-e-space-task8-api-variant222-evidence.zip'),(summary,'task6-e-space-task8-api-variant222-summary.json')]:
 target=mirror/name;assert not target.exists();shutil.copyfile(src,target);assert sha(target)==sha(src)
note='\n\n2026-10-09 最终API单元枚举成员识别222：218原7合同5PASS/2ERROR，缺少实际cargo-public-api格式的单元枚举成员识别。候选仅修验证器并增加原7合同，必须完整成员路径及直接父枚举声明，不推断缺失成员，不接受常量/字段/DTO冒充；原enum/struct/module/trait检查保持严格。219新7、原CLI23、原语义35、原公共入口10共75自测实际PASS，套件名称与数量以本记录为准。219实际CLI使用不支持的--repository-root而exit2，原失败脚本与日志保留；222在原cwd用真实支持参数重新执行，exit1/row2 PLANNED_TARGET，下游未执行，不晋升清单状态。1273冻结输入终态变化0，相对210仅两个Python路径delta，Rust/原测试/库存清单未改，d215仍保留1272原快照。zip222 SHA '+sha(z)+'，父216，全部条目/E镜像SHA核验。历史API只作为格式夹具，未执行新cargo-public-api或认证真实API/SemVer。正式Rust与CLI未apply；Task6 FIX_REQUIRED/Task7八义务/Task8 INCOMPLETE/18顶层OPEN。\n'
for p in ['.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md','docs/verification/rdbc-first/status.md','docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md']:
 with (e/p).open('ab') as out:out.write(note.encode('utf-8'))
print(json.dumps(dict(archive_sha256=sha(z),tests_passed=75,actual_cli_exit=r.returncode,verified_entries=len(manifest))))
