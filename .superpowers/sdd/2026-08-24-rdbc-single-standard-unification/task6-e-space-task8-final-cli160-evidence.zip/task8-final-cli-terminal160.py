import hashlib,json,re,zipfile
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d157');e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust');d=b/'task8-final-cli-verification159'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
s=json.loads((d/'summary.json').read_text(encoding='utf-8'));assert s['terminal'] and s['verification_exit_code']==0 and s['final_gate_exit_code']==1 and not s['final_gate_pass']
f=json.loads((d/'frozen-inputs.json').read_text(encoding='utf-8'));parent=json.loads((b/'task7-row-set-metadata-fix153/frozen-inputs.json').read_text(encoding='utf-8'))
assert len(f)==1244 and all(sha(w/r)==h for r,h in f.items())
assert all(not c['changed_inputs'] and c['exit_code']==c['expected_exit_code'] and sha(Path(c['log']))==c['sha256'] for c in s['commands'])
assert 'Ran 35 tests' in Path(s['commands'][0]['log']).read_text(encoding='utf-8')
assert 'Ran 23 tests' in Path(s['commands'][1]['log']).read_text(encoding='utf-8')
delta={r:h for r,h in f.items() if parent.get(r)!=h};assert set(delta)=={'scripts/verify_jdbc42_semantic_inventory.py','scripts/verify_jdbc42_final_runtime.py','scripts/test_jdbc42_final_cli.py'}
parentzip=b/'task7-row-set-metadata-terminal156.zip';assert sha(parentzip)=='09a675fe891c8dbd87688e452d49bed66e393d11fca1ac9c8b410fd6dac0b181'
files={}
for folder in ['task8-final-cli157','task8-final-cli-verification158','task8-final-cli-verification159']:
 for p in (b/folder).rglob('*'):
  if p.is_file():files[str(p.relative_to(b)).replace('\\','/')]=p
for r in delta:files['candidate-delta/'+r]=w/r
for name in ['task8-final-cli-verification158.py','task8-final-cli-verification159.py','task8-final-cli-terminal160.py']:files[name]=b/name
manifest={n:sha(p) for n,p in files.items()};z=b/'task8-final-cli-terminal160.zip';assert not z.exists()
with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED) as out:
 for n,p in files.items():out.write(p,n)
 out.writestr('archive-manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(z) as inp:assert all(hashlib.sha256(inp.read(n)).hexdigest()==h for n,h in manifest.items())
result=dict(scope='FINAL_CLI_COMPONENT_TERMINAL_NOT_TASK8_CERTIFICATION',production_applied=False,archive=str(z),archive_sha256=sha(z),parent_archive=str(parentzip),parent_sha256=sha(parentzip),frozen_input_count=1244,delta=delta,original_tests_passed=35,new_contracts_passed=23,actual_final_gate_exit_code=1,final_gate_pass=False,task8_complete=False,top_level_open=18,verification=s)
p=b/'task8-final-cli-terminal160.summary.json';p.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
dest=e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'
for original,name in [(z,'task6-e-space-task8-final-cli160-evidence.zip'),(p,'task6-e-space-task8-final-cli160-summary.json')]:
 target=dest/name;assert not target.exists();target.write_bytes(original.read_bytes());assert sha(target)==sha(original)
note=f'''\n\n2026-10-09 最终语义CLI候选终态：独立d157逐项复制153冻结1242输入，新增最终入口合同和运行证据组件，仅修改原semantic verifier，共1244输入。原CLI --require-final-evidence真实exit2/unknown argument及调用unexpected keyword RED保留；新增CLI接通已存在最终来源重建与状态策略，禁止跳过adapter/logical evidence，保留显式Task3 canonical要求。运行组件要求当前cargo-public-api形态（非原68import探针替代）、final purity、原完整no-Physical含C1/C2、Wrapper compiler/runtime及Druid零Task6/7 pending；工具缺失/编译失败/未闭合资源不能返回成功，原执行器超时和分母不变，未安装工具。新增协议/API输入冻结缺失实际RED后补完整来源冻结；来源加载期oracle替换实际23项中1FAIL RED后将oracle快照提前到load之前，原错误未隐藏。159最终原35自测与新23合同实际全通过，1244冻结变化0；新合同中的合成API文本/组件mock只证明解析和委托/失败关闭，不冒充真实compiler/runtime认证。实际CLI当前输入仍exit1：row2 PLANNED_TARGET，未运行下游门禁，最终验收仍未通过。zip160 SHA {sha(z)}保存原RED/中间已验证源码/159日志与三路径delta，全部解压及E镜像SHA核验，可由156父链恢复。Ruling: 最终semantic gate拒绝计划态与来源漂移，再要求新鲜编译和原运行证据；API/SemVer/实库/性能及全仓仍按Task8/P07独立验收，不把CLI测试通过算产品完成。正式Rust与新CLI均未apply到E；Task6 FIX_REQUIRED/Task7八义务/Task8 INCOMPLETE/18顶层OPEN。\n'''
for rel in ['.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md','docs/verification/rdbc-first/status.md','docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md']:
 p=e/rel;raw=p.read_bytes();assert b'zip160 SHA' not in raw;p.write_bytes(raw+note.encode('utf-8'))
print(json.dumps(dict(archive=str(z),sha256=sha(z),frozen_input_count=1244,original_tests=35,new_tests=23,actual_final_gate_exit_code=1,mirrored=True)),flush=True)
