import hashlib,json,subprocess,sys,time
from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d157');d=b/'task8-final-cli-verification159';d.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
parent=json.loads((b/'task8-final-cli157/parent-inputs.json').read_text(encoding='utf-8'))
f={r:sha(w/r) for r in parent}
for r in ['scripts/test_jdbc42_final_cli.py','scripts/verify_jdbc42_final_runtime.py']:f[r]=sha(w/r)
assert len(f)==1244
assert [r for r,h in parent.items() if f[r]!=h]==['scripts/verify_jdbc42_semantic_inventory.py']
(d/'frozen-inputs.json').write_text(json.dumps(f,indent=2)+'\n',encoding='utf-8')
summary=dict(terminal=False,production_applied=False,workspace=str(w),frozen_input_count=len(f),commands=[],scope='FINAL_CLI_COMPONENT_VERIFICATION_NOT_TASK8_OR_RELEASE_CERTIFICATION')
save=lambda:(d/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
save()
commands=[('original-and-final-cli-tests',[sys.executable,'-X','utf8','-m','unittest','discover','-s','scripts','-p','test*jdbc42*inventory.py','-v'],0),('final-cli-contract-tests',[sys.executable,'-X','utf8','-m','unittest','discover','-s','scripts','-p','test_jdbc42_final_cli.py','-v'],0),('live-final-gate',[sys.executable,'-X','utf8','scripts/verify_jdbc42_semantic_inventory.py','--require-final-evidence'],1)]
for name,cmd,expected in commands:
 log=d/(name+'.log');start=time.monotonic()
 with log.open('wb') as out:result=subprocess.run(cmd,cwd=w,stdout=out,stderr=subprocess.STDOUT)
 changes=[r for r,h in f.items() if sha(w/r)!=h]
 item=dict(name=name,command=cmd,exit_code=result.returncode,expected_exit_code=expected,elapsed_seconds=time.monotonic()-start,log=str(log),sha256=sha(log),changed_inputs=changes)
 summary['commands'].append(item);save()
 assert result.returncode==expected and not changes
 if name=='live-final-gate':
  text=log.read_text(encoding='utf-8');assert 'planned/unresolved target_state: PLANNED_TARGET' in text and 'JAVA_SQL=' not in text
summary.update(terminal=True,verification_exit_code=0,final_gate_exit_code=1,final_gate_pass=False,task8_complete=False,top_level_open=18)
save();print(json.dumps(summary,indent=2),flush=True)
