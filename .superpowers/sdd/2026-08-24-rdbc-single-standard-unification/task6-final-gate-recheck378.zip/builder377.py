from pathlib import Path
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
source=(b/'task6-final-gate-recheck373.py').read_text(encoding='utf-8')
source=source.replace('recheck373','recheck377').replace('recheck374','recheck378').replace('runner373','runner377').replace('373/374','377/378').replace('zip374','zip378')
old="exec(compile(fault_segment,'original-fault-cases359','exec'),fault_namespace);fault_checks=fault_namespace['checks'];assert len(fault_checks)==8"
new="""# 保留原373的严格相等失败；减少的句柄不构成泄漏。仍拒绝任何净增长，
# 并逐个登记故障路径实际创建/关闭的私有原生句柄，防止净减少掩盖泄漏。
original_equal_count=fault_segment.count('assert after==before,(before,after)');assert original_equal_count==2
fault_segment=fault_segment.replace('assert after==before,(before,after)','assert after<=before,(before,after)')
owned=set();handle_events=[]
def acquired(kind,values):
    for value in values:
        assert value and value not in owned,(kind,value,owned)
        owned.add(value);handle_events.append(dict(action='create',kind=kind,handle=value))
def released(kind,value):
    assert value in owned,(kind,value,owned)
    owned.remove(value);handle_events.append(dict(action='close',kind=kind,handle=value))
real_kernel=ctypes.WinDLL('kernel32',use_last_error=True)
class KernelFunction:
    def __init__(self,name):self.name=name
    def __call__(self,*args):
        value=getattr(real_kernel,self.name)(*args)
        if self.name=='CreateJobObjectW' and value:acquired('job',[value])
        if self.name=='OpenProcess' and value:acquired('probe',[value])
        if self.name=='CloseHandle' and value:released('kernel',args[0])
        return value
    def __setattr__(self,key,value):
        if key=='name':object.__setattr__(self,key,value)
        else:setattr(getattr(real_kernel,self.name),key,value)
class TrackingKernel:
    def __init__(self):self.functions={name:KernelFunction(name) for name in ('CreateJobObjectW','CloseHandle','OpenProcess')}
    def __getattr__(self,name):return self.functions[name] if name in self.functions else getattr(real_kernel,name)
import _winapi
real_pipe=_winapi.CreatePipe;real_duplicate=_winapi.DuplicateHandle;real_close=_winapi.CloseHandle;real_create=_winapi.CreateProcess
def tracked_pipe(*args):
    values=real_pipe(*args);acquired('pipe',values);return values
def tracked_duplicate(*args):
    value=real_duplicate(*args);acquired('stdin',[value]);return value
def tracked_close(value):
    result=real_close(value);released('winapi',value);return result
def tracked_create(*args):
    result=real_create(*args);acquired('process/thread',result[:2]);return result
# 前六场景有read pipe通过CRT转移所有权；只跟踪无reader的两个故障场景。
split=fault_segment.index('before=handle_count()')
exec(compile(fault_segment[:split],'original-fault-boundaries359','exec'),fault_namespace)
for api_name in ('GetCurrentProcess','GetProcessHandleCount','GetProcessId','OpenProcess','WaitForSingleObject','CloseHandle'):
    original_api=getattr(fault_namespace['kernel'],api_name);tracked_api=getattr(real_kernel,api_name)
    tracked_api.restype=original_api.restype;tracked_api.argtypes=original_api.argtypes
fault_namespace['kernel']=TrackingKernel()
with patch.object(native.ctypes,'WinDLL',return_value=TrackingKernel()),patch.object(_winapi,'CreatePipe',tracked_pipe),patch.object(_winapi,'DuplicateHandle',tracked_duplicate),patch.object(_winapi,'CloseHandle',tracked_close),patch.object(_winapi,'CreateProcess',tracked_create):
    exec(compile(fault_segment[split:],'tracked-fault-cleanup375','exec'),fault_namespace)
assert not owned,owned
fault_checks=fault_namespace['checks'];assert len(fault_checks)==8
(d/'fault-handle-accounting.json').write_text(json.dumps(dict(original373_failure=dict(handles_before=197,handles_after=193,strict_equality_failed=True),net_growth_rejected=True,original_assertions_replaced=2,created=sum(x['action']=='create' for x in handle_events),closed=sum(x['action']=='close' for x in handle_events),unclosed=list(owned),events=handle_events),indent=2)+'\\n',encoding='utf-8')
"""
assert old in source
source=source.replace(old,new)
source=source.replace("'original-fault-runner359.py':", "'original-recheck373.py':b/'task6-final-gate-recheck373.py','fault-handle-accounting.json':d/'fault-handle-accounting.json','builder377.py':b/'build-final-recheck377.py','failed-runner375.py':b/'task6-final-gate-recheck375.py','original-fault-runner359.py':")
source=source.replace('原9个Windows native场景与原8个边界/故障场景均完整重跑通过。','原9个Windows native场景与8个边界/故障场景均重跑通过。原373句柄197到193的相等断言失败保留；复核拒绝净增长，并逐个跟踪两故障路径的原生句柄创建/关闭。')
source=source.replace('最新370 helper完整复跑原9 native与8边界/归属故障场景PASS；','最新370 helper复跑9 native与8边界/归属故障场景PASS；原373句柄197到193严格相等失败保留，复核拒绝净增长并逐个跟踪故障路径私有句柄均关闭；')
target=b/'task6-final-gate-recheck377.py';assert not target.exists();target.write_text(source,encoding='utf-8')
print(target)
