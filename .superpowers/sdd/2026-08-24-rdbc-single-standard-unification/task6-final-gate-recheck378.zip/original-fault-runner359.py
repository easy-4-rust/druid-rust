from pathlib import Path
from unittest.mock import patch
import ctypes,hashlib,importlib.util,json,os,shutil,sys,time,zipfile
sys.dont_write_bytecode=True
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d177');e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust');d=b/'task6-windows-runner-fault359';d.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
frozen_path=b/'task7-final-candidate-workspace319/frozen-inputs.json';frozen=json.loads(frozen_path.read_text());assert len(frozen)==1277 and all(sha(w/p)==h for p,h in frozen.items())
helper=b/'windows_bounded_process356.py';spec=importlib.util.spec_from_file_location('windows_bounded_fault359',helper);native=importlib.util.module_from_spec(spec);spec.loader.exec_module(native)
kernel=ctypes.WinDLL('kernel32',use_last_error=True)
kernel.OpenProcess.argtypes=[ctypes.c_ulong,ctypes.c_int,ctypes.c_ulong];kernel.OpenProcess.restype=ctypes.c_void_p
kernel.CloseHandle.argtypes=[ctypes.c_void_p];kernel.CloseHandle.restype=ctypes.c_int
kernel.WaitForSingleObject.argtypes=[ctypes.c_void_p,ctypes.c_ulong];kernel.WaitForSingleObject.restype=ctypes.c_ulong
kernel.GetProcessId.argtypes=[ctypes.c_void_p];kernel.GetProcessId.restype=ctypes.c_ulong
kernel.GetCurrentProcess.restype=ctypes.c_void_p
kernel.GetProcessHandleCount.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_ulong)];kernel.GetProcessHandleCount.restype=ctypes.c_int
def running(pid):
    handle=kernel.OpenProcess(0x101000,False,pid)
    if not handle:
        error=ctypes.get_last_error()
        if error in (87,1168):return False
        raise ctypes.WinError(error)
    try:
        status=kernel.WaitForSingleObject(handle,0)
        assert status in (0,258),status
        return status==258
    finally:assert kernel.CloseHandle(handle)
def handle_count():
    value=ctypes.c_ulong();assert kernel.GetProcessHandleCount(kernel.GetCurrentProcess(),ctypes.byref(value));return value.value
checks=[]
def execute(name,source,timeout=5,limit=4096,expected=None,expected_code=0,env=None,args=(),cwd=None):
    started=time.monotonic()
    try:
        code,out,err=native.run_windows_bounded_process([sys.executable,'-X','utf8','-c',source,*args],cwd=cwd or d,timeout_seconds=timeout,output_limit=limit,env=env)
        assert expected is None and code==expected_code,(name,code,out,err)
        result=dict(name=name,status='PASS',exit_code=code,stdout=out,stderr=err)
    except RuntimeError as error:
        assert expected and expected in str(error),(name,str(error))
        result=dict(name=name,status='EXPECTED_REJECTION',error=str(error))
    result['elapsed_seconds']=time.monotonic()-started;checks.append(result)
execute('exact-total-output-boundary',"import os;os.write(1,b'a'*512);os.write(2,b'b'*512)",limit=1024)
assert len(checks[-1]['stdout'])+len(checks[-1]['stderr'])==1024
execute('one-byte-over-total-boundary',"import os;os.write(1,b'a'*512);os.write(2,b'b'*513)",limit=1024,expected='output limit')
execute('closed-pipes-do-not-disable-deadline',"import os,time;os.close(1);os.close(2);time.sleep(30)",timeout=.1,expected='timed out')
execute('exit-code259-is-terminal',"import sys;sys.exit(259)",expected_code=259)
task_env=os.environ.copy();task_env['DRUID_TEST_ONLY_NATIVE_JOB_VALUE']='test-value'
execute('explicit-environment-preserved',"import os;print(os.environ['DRUID_TEST_ONLY_NATIVE_JOB_VALUE'])",env=task_env);assert checks[-1]['stdout']=='test-value\r\n'
spaced=d/'directory with spaces';spaced.mkdir()
execute('unicode-literal-arguments-and-cwd',"import sys,os,json;print(json.dumps([sys.argv[1:],os.path.basename(os.getcwd())],ensure_ascii=False))",args=('含 空格','literal-$()-`-quote"'),cwd=spaced)
assert json.loads(checks[-1]['stdout'])==[['含 空格','literal-$()-`-quote"'],'directory with spaces']
before=handle_count()
for index in range(3):
    try:native.run_windows_bounded_process([str(d/'missing-executable.exe')],cwd=d,timeout_seconds=5,output_limit=1024)
    except FileNotFoundError:pass
    else:raise AssertionError('missing executable accepted')
after=handle_count();assert after==before,(before,after)
checks.append(dict(name='failed-create-process-handles-reclaimed',status='PASS',attempts=3,handles_before=before,handles_after=after))
# 在真实挂起子进程处注入归属失败：恢复线程之前必须拒绝，禁止执行用户代码。
own_pid=[]
class DenyAssignment:
    def __call__(self,job,process):
        pid=kernel.GetProcessId(process);assert pid;own_pid.append(pid);ctypes.set_last_error(5);return 0
denied=DenyAssignment()
class KernelProxy:
    def __getattr__(self,name):return denied if name=='AssignProcessToJobObject' else getattr(kernel,name)
marker=d/'must-not-execute.txt';before=handle_count()
with patch.object(native.ctypes,'WinDLL',return_value=KernelProxy()):
    try:native.run_windows_bounded_process([sys.executable,'-c',"open('must-not-execute.txt','w').write('executed')"],cwd=d,timeout_seconds=5,output_limit=1024)
    except PermissionError:pass
    else:raise AssertionError('assignment failure was ignored')
assert len(own_pid)==1 and not running(own_pid[0]) and not marker.exists()
after=handle_count();assert after==before,(before,after)
checks.append(dict(name='job-assignment-fails-before-user-code',status='PASS',owned_suspended_pid=own_pid[0],terminated=True,user_marker_absent=True,handles_before=before,handles_after=after))
assert all(sha(w/p)==h for p,h in frozen.items())
summary=dict(scope='WINDOWS_BOUNDED_EXECUTOR_FAULT_AND_BOUNDARY_VALIDATION',production_applied=False,checks=checks,frozen_inputs_changed=0,cargo_started=False,original_timeout_unchanged=True,original_suite_still_not_passed=True,readonly_process_probe='OpenProcess(SYNCHRONIZE|QUERY_LIMITED_INFORMATION)+WaitForSingleObject',python3_resolved_path=shutil.which('python3'))
(d/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(d/'report.md').write_text('# Windows执行器边界与归属失败验证\n\n总输出恰好上限成功、多1字节拒绝；关闭两管道后仍执行0.1秒deadline；退出码259识别为终态；环境、Unicode和包含引号/反引号的字面参数原样传递。三次创建失败句柄计数不增。真实挂起子进程处注入AssignProcessToJobObject失败，确认用户代码未执行、该新建进程已终止、句柄计数不增。\n\n原测试python3解析到WindowsApps别名，os.kill(pid,0)不适用于Windows只读存活查询。此验证使用同步/查询句柄及WaitForSingleObject，不调用TerminateProcess探测存活。原suite未通过，不以这些补充场景替代其验收。候选输入1277不变，无Cargo，补丁未apply。\n\nPython官方依据：https://docs.python.org/3/library/os.html#os.kill\n',encoding='utf-8')
files={'runner359.py':Path(__file__),'windows_bounded_process.py':helper,'summary.json':d/'summary.json','report.md':d/'report.md','frozen319.json':frozen_path};entries={name:sha(path) for name,path in files.items()};z=b/'task6-windows-runner-fault360.zip';assert not z.exists()
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as archive:
    for name,path in files.items():archive.write(path,name)
    archive.writestr('manifest.json',json.dumps(entries,indent=2))
with zipfile.ZipFile(z) as archive:assert all(hashlib.sha256(archive.read(name)).hexdigest()==h for name,h in entries.items())
receipt=b/'task6-windows-runner-fault360.summary.json';receipt.write_text(json.dumps(dict(sha256=sha(z),verified_entries=len(entries),checks=len(checks),production_applied=False),indent=2)+'\n',encoding='utf-8')
for item in (z,receipt):
    target=e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'/item.name;assert not target.exists();shutil.copyfile(item,target);assert sha(item)==sha(target)
note='2026-10-09 Windows执行器边界/故障359/360：8场景实际通过；恰好输出cap与+1拒绝、关闭管道仍保留0.1s超时、259退出码、环境/Unicode字面参数、3次创建失败句柄计数不增；真实挂起子进程归属失败注入证明未执行用户代码且私有进程/句柄已清理。存活探测只用同步/查询句柄；原测试python3为WindowsApps别名，原suite仍不PASS。无Cargo、未apply，1277冻结变化0，zip360 SHA '+sha(z)+'全部条目/E镜像核验。18顶层OPEN。'
for relative in ('.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md','docs/verification/rdbc-first/status.md','docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md'):
    with (e/relative).open('ab') as out:out.write(('\n\n'+note+'\n').encode('utf-8'))
print(json.dumps(dict(checks=len(checks),zip_sha256=sha(z),handle_checks=[check for check in checks if 'handles_before' in check]),ensure_ascii=False))
