from pathlib import Path
from unittest.mock import patch
import ctypes,difflib,hashlib,importlib.util,io,json,os,shutil,sys,time,types,unittest,zipfile
sys.dont_write_bytecode=True
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d177');e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust');d=b/'task6-final-gate-recheck377';d.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
frozen_path=b/'task7-final-candidate-workspace319/frozen-inputs.json';frozen=json.loads(frozen_path.read_text());assert len(frozen)==1277 and all(sha(w/p)==h for p,h in frozen.items())
sys.path.insert(0,str(w/'scripts'));spec=importlib.util.spec_from_file_location('windows_bounded_process',b/'windows_bounded_process370.py');native=importlib.util.module_from_spec(spec);sys.modules[spec.name]=native;spec.loader.exec_module(native)
verifier_source=(b/'task6-unit-coverage-fixture371/verify_wrapper_standard_impls.py').read_text(encoding='utf-8');verifier=types.ModuleType('verify_wrapper_standard_impls');verifier.__file__=str(w/'scripts/verify_wrapper_standard_impls.py');sys.modules[verifier.__name__]=verifier;exec(compile(verifier_source,verifier.__file__,'exec'),verifier.__dict__)
import regenerate_task6_coverage_manifest as generator
test_path=w/'scripts/test_regenerate_task6_coverage_manifest.py';test_source=test_path.read_text(encoding='utf-8');tests=types.ModuleType('original_regenerator_tests373');tests.__file__=str(test_path);sys.modules[tests.__name__]=tests;exec(compile(test_source,str(test_path),'exec'),tests.__dict__)
output=io.StringIO();result=unittest.TextTestRunner(stream=output,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(tests));(d/'original-regenerator-tests.log').write_text(output.getvalue(),encoding='utf-8')
assert result.wasSuccessful(),output.getvalue()
# 复用原9项native测试和原8项边界/故障测试的全部函数体与断言，不重复旧suite。
original_native=(b/'task6-windows-runner-validation357.py').read_text(encoding='utf-8');begin=original_native.index("kernel=ctypes.WinDLL(");end=original_native.index('# 将修复作为未应用的独立Windows分支',begin);native_segment=original_native[begin:end]
native_dir=d/'native';native_dir.mkdir()
namespace=dict(Path=Path,patch=patch,ctypes=ctypes,hashlib=hashlib,io=io,json=json,os=os,shutil=shutil,sys=sys,time=time,types=types,unittest=unittest,zipfile=zipfile,native=native,d=native_dir)
exec(compile(native_segment,'original-native-cases357','exec'),namespace);native_checks=namespace['checks'];assert len(native_checks)==9
original_fault=(b/'task6-windows-runner-fault359.py').read_text(encoding='utf-8');begin=original_fault.index("kernel=ctypes.WinDLL(");end=original_fault.index('\nassert all(sha(w/p)==h for p,h in frozen.items())',begin);fault_segment=original_fault[begin:end]
fault_dir=d/'fault';fault_dir.mkdir();fault_namespace=dict(namespace);fault_namespace['d']=fault_dir
# 保留原373的严格相等失败；减少的句柄不构成泄漏。仍拒绝任何净增长，
# 并逐个登记故障路径实际创建/关闭的私有原生句柄，防止净减少掩盖泄漏。
original_equal_count=fault_segment.count('assert after==before,(before,after)');assert original_equal_count==2
fault_segment=fault_segment.replace('assert after==before,(before,after)','assert after<=before,(before,after)')
owned=set();handle_events=[]
def acquired(kind,values):
    for value in values:
        assert value and value not in owned,(kind,value,owned)
        owned.add(value);handle_events.append(dict(action='create',kind=kind,handle=value))
def released(kind,value):
    assert value in owned,(kind,value,owned)
    owned.remove(value);handle_events.append(dict(action='close',kind=kind,handle=value))
real_kernel=ctypes.WinDLL('kernel32',use_last_error=True)
class KernelFunction:
    def __init__(self,name):self.name=name
    def __call__(self,*args):
        value=getattr(real_kernel,self.name)(*args)
        if self.name=='CreateJobObjectW' and value:acquired('job',[value])
        if self.name=='OpenProcess' and value:acquired('probe',[value])
        if self.name=='CloseHandle' and value:released('kernel',args[0])
        return value
    def __setattr__(self,key,value):
        if key=='name':object.__setattr__(self,key,value)
        else:setattr(getattr(real_kernel,self.name),key,value)
class TrackingKernel:
    def __init__(self):self.functions={name:KernelFunction(name) for name in ('CreateJobObjectW','CloseHandle','OpenProcess')}
    def __getattr__(self,name):return self.functions[name] if name in self.functions else getattr(real_kernel,name)
import _winapi
real_pipe=_winapi.CreatePipe;real_duplicate=_winapi.DuplicateHandle;real_close=_winapi.CloseHandle;real_create=_winapi.CreateProcess
def tracked_pipe(*args):
    values=real_pipe(*args);acquired('pipe',values);return values
def tracked_duplicate(*args):
    value=real_duplicate(*args);acquired('stdin',[value]);return value
def tracked_close(value):
    result=real_close(value);released('winapi',value);return result
def tracked_create(*args):
    result=real_create(*args);acquired('process/thread',result[:2]);return result
# 前六场景有read pipe通过CRT转移所有权；只跟踪无reader的两个故障场景。
split=fault_segment.index('before=handle_count()')
exec(compile(fault_segment[:split],'original-fault-boundaries359','exec'),fault_namespace)
for api_name in ('GetCurrentProcess','GetProcessHandleCount','GetProcessId','OpenProcess','WaitForSingleObject','CloseHandle'):
    original_api=getattr(fault_namespace['kernel'],api_name);tracked_api=getattr(real_kernel,api_name)
    tracked_api.restype=original_api.restype;tracked_api.argtypes=original_api.argtypes
fault_namespace['kernel']=TrackingKernel()
with patch.object(native.ctypes,'WinDLL',return_value=TrackingKernel()),patch.object(_winapi,'CreatePipe',tracked_pipe),patch.object(_winapi,'DuplicateHandle',tracked_duplicate),patch.object(_winapi,'CloseHandle',tracked_close),patch.object(_winapi,'CreateProcess',tracked_create):
    exec(compile(fault_segment[split:],'tracked-fault-cleanup375','exec'),fault_namespace)
assert not owned,owned
fault_checks=fault_namespace['checks'];assert len(fault_checks)==8
(d/'fault-handle-accounting.json').write_text(json.dumps(dict(original373_failure=dict(handles_before=197,handles_after=193,strict_equality_failed=True),net_growth_rejected=True,original_assertions_replaced=2,created=sum(x['action']=='create' for x in handle_events),closed=sum(x['action']=='close' for x in handle_events),unclosed=list(owned),events=handle_events),indent=2)+'\n',encoding='utf-8')

actor_path=w/'crates/druid-wrapper/src/sqlx/sqlx_connection_actor.rs';actor_draft=(b/'task6-sqlx-trace-draft352/sqlx_connection_actor.rs').read_text(encoding='utf-8');read=Path.read_text
def overlay(path,*args,**kwargs):return actor_draft if path==actor_path else read(path,*args,**kwargs)
with patch.object(Path,'read_text',overlay):generator.validate_canonical_source_requirements(w,generator.canonical_requirements(w))
manifest_path=w/verifier.DEFAULT_COVERAGE_MANIFEST
try:verifier.load_coverage_manifest(w)
except verifier.VerificationError as error:production_gate=dict(status='REJECT',error=str(error))
else:raise AssertionError('stale production manifest unexpectedly accepted')
assert all(sha(w/p)==h for p,h in frozen.items())
summary=dict(scope='UNAPPLIED_GATE_FINAL_NATIVE_AND_ORIGINAL_REGENERATOR_RECHECK',production_applied=False,regenerator_tests=result.testsRun,regenerator_failures=0,regenerator_errors=0,regenerator_skipped=len(result.skipped),native_checks=native_checks,fault_checks=fault_checks,canonical_source_preflight='PASS_STATIC_ONLY',canonical_source_requirements=105,production_manifest_gate=production_gate,production_manifest_sha256=sha(manifest_path),compiler_coverage_certified=False,cargo_started=False,frozen_inputs_changed=0,parent372_sha256=sha(b/'task6-unit-coverage-fixture372.zip'))
(d/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');(d/'report.md').write_text('# 更新后门禁最终补充验证\n\n当前草稿完成原生成器全部'+str(result.testsRun)+'测试；原9个Windows native场景与8个边界/故障场景均重跑通过。原373句柄197到193的相等断言失败保留；复核拒绝净增长，并逐个跟踪两故障路径的原生句柄创建/关闭。105条canonical源码预检通过。父372完整校验器44项中43通过、1POSIX跳过。\n\n生产manifest仍被原加载拒绝，未人工改hash/编译器身份，无真实LLVM覆盖声明。全部补丁未apply、运行中1277冻结输入不变。\n',encoding='utf-8')
files={'runner377.py':Path(__file__),'original-native-runner357.py':b/'task6-windows-runner-validation357.py','original-recheck373.py':b/'task6-final-gate-recheck373.py','fault-handle-accounting.json':d/'fault-handle-accounting.json','builder377.py':b/'build-final-recheck377.py','failed-runner375.py':b/'task6-final-gate-recheck375.py','original-fault-runner359.py':b/'task6-windows-runner-fault359.py','windows_bounded_process.py':b/'windows_bounded_process370.py','draft-verifier.py':b/'task6-unit-coverage-fixture371/verify_wrapper_standard_impls.py','draft-tests.py':b/'task6-unit-coverage-fixture371/test_verify_wrapper_standard_impls.py','original-regenerator.py':w/'scripts/regenerate_task6_coverage_manifest.py','original-regenerator-tests.py':test_path,'original-regenerator-tests.log':d/'original-regenerator-tests.log','summary.json':d/'summary.json','report.md':d/'report.md','frozen319.json':frozen_path};entries={name:sha(path) for name,path in files.items()};z=b/'task6-final-gate-recheck378.zip';assert not z.exists()
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as archive:
    for name,path in files.items():archive.write(path,name)
    archive.writestr('manifest.json',json.dumps(entries,indent=2))
with zipfile.ZipFile(z) as archive:assert all(hashlib.sha256(archive.read(name)).hexdigest()==h for name,h in entries.items())
receipt=b/'task6-final-gate-recheck378.summary.json';receipt.write_text(json.dumps(dict(sha256=sha(z),verified_entries=len(entries),regenerator_tests=result.testsRun,native_checks=9,fault_checks=8,production_applied=False),indent=2)+'\n',encoding='utf-8')
for item in (z,receipt):
    target=e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'/item.name;assert not target.exists();shutil.copyfile(item,target);assert sha(item)==sha(target)
note='2026-10-09 当前门禁草稿最终补证377/378：原覆盖生成器全部'+str(result.testsRun)+'测试PASS；最新370 helper复跑9 native与8边界/归属故障场景PASS；原373句柄197到193严格相等失败保留，复核拒绝净增长并逐个跟踪故障路径私有句柄均关闭；原105源码义务预检PASS_STATIC_ONLY。父372原42+新2测试43PASS/0FAIL/0ERROR/1POSIX-SKIP。原生产manifest仍拒绝过期hash，无新LLVM/产品runtime认证、无Cargo、未apply，1277冻结变化0，zip378 SHA '+sha(z)+'全部条目/E镜像核验。18顶层OPEN。'
for relative in ('.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md','docs/verification/rdbc-first/status.md','docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md'):
    with (e/relative).open('ab') as out:out.write(('\n\n'+note+'\n').encode('utf-8'))
print(json.dumps(dict(regenerator_tests=result.testsRun,native_checks=len(native_checks),fault_checks=len(fault_checks),zip_sha256=sha(z)),ensure_ascii=False))
