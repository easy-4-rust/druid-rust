from pathlib import Path
import ast,hashlib,json,shutil,zipfile
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
w=Path('F:/codex_build_cache/d177');e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust')
d=b/'task6-gate-review-ready379';d.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
frozen_path=b/'task7-final-candidate-workspace319/frozen-inputs.json'
frozen=json.loads(frozen_path.read_text());assert len(frozen)==1277
assert all(sha(w/p)==h for p,h in frozen.items())
desired={
 'scripts/verify_wrapper_standard_impls.py':b/'task6-unit-coverage-fixture371/verify_wrapper_standard_impls.py',
 'scripts/test_verify_wrapper_standard_impls.py':b/'task6-unit-coverage-fixture371/test_verify_wrapper_standard_impls.py',
 'scripts/windows_bounded_process.py':b/'windows_bounded_process370.py',
 'crates/druid-wrapper/src/sqlx/sqlx_connection_actor.rs':b/'task6-sqlx-trace-draft352/sqlx_connection_actor.rs'}
rows=[]
for relative,path in desired.items():
 if relative.endswith('.py'):ast.parse(path.read_text(encoding='utf-8'),filename=relative)
 rows.append(dict(path=relative,candidate_preimage_sha256=sha(w/relative) if (w/relative).exists() else None,formal_preimage_sha256=sha(e/relative) if (e/relative).exists() else None,desired_sha256=sha(path)))
patch_path=b/'task6-unit-coverage-fixture371/complete-gate-review.patch'
summary=dict(scope='FOUR_FILE_GATE_DRAFT_REVIEW_READY_NOT_APPLIED',production_applied=False,
 candidate_dry_run=dict(command=['git','apply','--check','--unsafe-paths',str(patch_path)],cwd=str(w),exit_code=0,evidence='actual exec_command tool result chunk553e1e',patch_sha256=sha(patch_path)),
 files=rows,python_syntax='PASS',frozen_input_count=1277,frozen_inputs_changed=0,
 full_suite=dict(tests=44,passed=43,failed=0,errors=0,posix_skipped=1,parent372_sha256=sha(b/'task6-unit-coverage-fixture372.zip')),
 native_recheck=dict(regenerator=7,native=9,fault=8,owned_handles_created=27,owned_handles_closed=27,unclosed=0,parent378_sha256=sha(b/'task6-final-gate-recheck378.zip')),
 compiler_coverage_certified=False,formal_integration_certified=False,
 previous_failures=[dict(runner=373,condition='original handle-count equality assertion',observed_before=197,observed_after=193),dict(runner=375,condition='tracking test proxy missing GetCurrentProcess ctypes prototype; handle_count assertion failed before fault execution',fixed_by='377 copies existing ctypes signatures; production helper unchanged')])
(d/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(d/'report.md').write_text('# 四文件校验门禁补丁可审阅状态\n\n真实git apply --check在F候选成功；三个Python草稿AST解析通过，四个文件的F/E preimage与desired SHA逐项绑定。此补丁只针对冻结候选，不宣称可直接覆盖E的未提交修改。\n\n原373严格相等检查因句柄197→193失败保留；原375测试跟踪代理缺少GetCurrentProcess的ctypes签名而失败，377只修测试代理，生产helper未改。377实测两个故障路径27个原生句柄全部关闭；拒绝句柄净增长。原生成器7、native9、边界故障8通过，原完整校验器43通过/1POSIX跳过。\n\n105源码预检为静态通过，生产LLVM清单继续拒绝过期hash。没有改清单、提升身份或apply。运行中1277输入不变，完整全仓319继续原session，18顶层任务仍开放。\n',encoding='utf-8')
files={'runner379.py':Path(__file__),'summary.json':d/'summary.json','report.md':d/'report.md','complete-gate-review.patch':patch_path,'frozen319.json':frozen_path,'failed-runner373.py':b/'task6-final-gate-recheck373.py','failed-runner375.py':b/'task6-final-gate-recheck375.py'}
files.update({relative:path for relative,path in desired.items()})
entries={name:sha(path) for name,path in files.items()};z=b/'task6-gate-review-ready380.zip';assert not z.exists()
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as archive:
 for name,path in files.items():archive.write(path,name)
 archive.writestr('manifest.json',json.dumps(entries,indent=2))
with zipfile.ZipFile(z) as archive:assert all(hashlib.sha256(archive.read(name)).hexdigest()==h for name,h in entries.items())
receipt=b/'task6-gate-review-ready380.summary.json';receipt.write_text(json.dumps(dict(sha256=sha(z),verified_entries=len(entries),production_applied=False,candidate_dry_run_exit=0),indent=2)+'\n',encoding='utf-8')
assert all(sha(w/p)==h for p,h in frozen.items())
for item in (z,receipt):
 target=e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'/item.name;assert not target.exists();shutil.copyfile(item,target);assert sha(item)==sha(target)
note='2026-10-09 四文件门禁补丁审阅379/380：真实F候选git apply --check exit0，三个Python AST PASS；逐项绑定F/E preimage与desired SHA，正式E集成尚未认证。373句柄197→193相等失败及375测试代理ctypes签名失败保留，377故障路径27创建/27关闭/0遗留。原生成器7/native9/故障8及完整suite43PASS/1POSIX-SKIP证据绑定；生产105LLVM清单仍拒绝过期hash、未apply，1277冻结变化0。zip380 SHA '+sha(z)+'全部条目/E镜像核验。原319继续，18顶层OPEN。'
for relative in ('.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md','docs/verification/rdbc-first/status.md','docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md'):
 with (e/relative).open('ab') as out:out.write(('\n\n'+note+'\n').encode('utf-8'))
print(json.dumps(dict(zip_sha256=sha(z),files=len(rows),candidate_dry_run_exit=0,frozen_inputs_changed=0)))
