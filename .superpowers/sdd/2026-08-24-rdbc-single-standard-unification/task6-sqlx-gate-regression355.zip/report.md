# SQLx门禁完整原测试与新增回归

全部原测试均保留并执行，迁移旧结果集fixture到Buffered和Async，fixture调用选择限制在原指定函数范围。新增真实源码负例检查actor、有界请求与关闭，以及两路径trace精确次数。

结果：44 tests / 0 failures / 4 errors / 1 skipped。完整错误保留在summary与日志；未以局部成功代替整套通过。补丁未apply，无Cargo或LLVM覆盖认证。
