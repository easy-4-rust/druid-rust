from pathlib import Path
from unittest.mock import patch
import difflib, hashlib, io, json, shutil, sys, types, unittest, zipfile
sys.dont_write_bytecode=True
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d177');e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust');d=b/'task6-sqlx-gate-regression354';d.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
frozen_path=b/'task7-final-candidate-workspace319/frozen-inputs.json';frozen=json.loads(frozen_path.read_text());assert len(frozen)==1277 and all(sha(w/p)==h for p,h in frozen.items())
sys.path.insert(0,str(w/'scripts'))
verifier_path=w/'scripts/verify_wrapper_standard_impls.py';test_path=w/'scripts/test_verify_wrapper_standard_impls.py'
verifier_source=(b/'task6-sqlx-trace-draft352/verify_wrapper_standard_impls.py').read_text(encoding='utf-8')
actor_path=w/'crates/druid-wrapper/src/sqlx/sqlx_connection_actor.rs';actor_bytes=(b/'task6-sqlx-trace-draft352/sqlx_connection_actor.rs').read_bytes()
draft=types.ModuleType('verify_wrapper_standard_impls');draft.__file__=str(verifier_path);sys.modules[draft.__name__]=draft;exec(compile(verifier_source,str(verifier_path),'exec'),draft.__dict__)
test_source=(b/'task6-sqlx-trace-draft352/test_verify_wrapper_standard_impls.py').read_text(encoding='utf-8')
assert test_source.count('sqlx_streaming_result_set.rs')==2
test_source=test_source.replace('sqlx_streaming_result_set.rs','sqlx_buffered_result_set.rs')
needle='''            "sqlx_buffered_result_set.rs",
            "sqlx_database_meta_data.rs",
'''
assert test_source.count(needle)==1
test_source=test_source.replace(needle,'''            "sqlx_buffered_result_set.rs",
            "sqlx_async_result_set.rs",
            "sqlx_database_meta_data.rs",
''')
extra='''
    def test_current_sqlx_async_ownership_rejects_lost_lease_and_unbounded_pull(self) -> None:
        """真实当前源码负例：异步游标必须保留actor、容量1及受监管关闭。"""
        repository = Path(__file__).resolve().parents[1]
        source_root = repository / "crates/druid-wrapper/src/sqlx"
        target_root = self.root / "crates/druid-wrapper/src/sqlx"
        target_root.mkdir(parents=True)
        for name in (
            "sqlx_connection_actor.rs", "sqlx_prepared_statement.rs",
            "sqlx_buffered_result_set.rs", "sqlx_async_result_set.rs",
            "sqlx_database_meta_data.rs",
        ):
            (target_root / name).write_bytes((source_root / name).read_bytes())
        verify_sqlx_ownership(self.root)
        path = target_root / "sqlx_async_result_set.rs"
        source = path.read_text(encoding="utf-8")
        mutations = (
            ("actor: Arc<SqlxConnectionActor>", "actor: usize"),
            ("mpsc::channel(1)", "mpsc::channel(100)"),
            ("actor.spawn_cursor", "actor.retired_spawn_cursor"),
            (".try_send(SqlxCursorRequest", ".retired_send(SqlxCursorRequest"),
            ("worker.await", "worker.retired_wait"),
            ("self.shutdown.send_replace(true)", "self.shutdown.retired_send(true)"),
            ("current: Option<Row>", "current: Vec<Row>"),
        )
        for old, new in mutations:
            with self.subTest(mutation=old):
                self.assertIn(old, source)
                path.write_text(source.replace(old, new), encoding="utf-8")
                with self.assertRaises(VerificationError):
                    verify_sqlx_ownership(self.root)
        path.write_text(source, encoding="utf-8")

    def test_sqlx_buffered_and_async_trace_calls_each_remain_exact(self) -> None:
        """缓冲与异步两个真实分支的next/metadata调用各恰好一次。"""
        repository_source = Path(__file__).resolve().parents[1] / "crates/druid-wrapper/src"
        target = self.root / "crates/druid-wrapper/src"
        shutil.copytree(repository_source, target, dirs_exist_ok=True)
        verify_trace_record_callsites(self.root)
        for name in ("sqlx_buffered_result_set.rs", "sqlx_async_result_set.rs"):
            path = target / "sqlx" / name
            source = path.read_text(encoding="utf-8")
            for method in ("task4_trace_result_next", "task4_trace_result_set_metadata"):
                call = "." + method + "("
                self.assertEqual(source.count(call), 1)
                mutations = (
                    source.replace(call, ".retired_" + method + "("),
                    source + "\\nfn invalid_duplicate(actor: &SqlxConnectionActor) { actor." + method + "(); }\\n",
                )
                for index, changed in enumerate(mutations):
                    with self.subTest(file=name, method=method, mutation=index):
                        path.write_text(changed, encoding="utf-8")
                        with self.assertRaisesRegex(VerificationError, "callsite multiset drift"):
                            verify_trace_record_callsites(self.root)
                path.write_text(source, encoding="utf-8")

'''
marker='    @staticmethod\n    def marker('
assert test_source.count(marker)==1;test_source=test_source.replace(marker,extra+marker)
(d/'test_verify_wrapper_standard_impls.py').write_text(test_source,encoding='utf-8',newline='\n')
shutil.copyfile(b/'task6-sqlx-trace-draft352/verify_wrapper_standard_impls.py',d/'verify_wrapper_standard_impls.py');shutil.copyfile(b/'task6-sqlx-trace-draft352/sqlx_connection_actor.rs',d/'sqlx_connection_actor.rs')
test_module=types.ModuleType('task6_sqlx_full_tests354');test_module.__file__=str(test_path);sys.modules[test_module.__name__]=test_module;exec(compile(test_source,str(test_path),'exec'),test_module.__dict__)
read_bytes=Path.read_bytes
def actor_overlay(path):return actor_bytes if path==actor_path else read_bytes(path)
suite=unittest.defaultTestLoader.loadTestsFromModule(test_module);output=io.StringIO()
with patch.object(Path,'read_bytes',actor_overlay):result=unittest.TextTestRunner(stream=output,verbosity=2).run(suite)
(d/'full-original-plus-regression.log').write_text(output.getvalue(),encoding='utf-8')
assert all(sha(w/p)==h for p,h in frozen.items())
summary=dict(scope='UNAPPLIED_SQLX_GATE_FULL_ORIGINAL_SUITE_PLUS_NEW_REGRESSIONS',production_applied=False,tests_run=result.testsRun,failures=[dict(test=str(test),trace=trace) for test,trace in result.failures],errors=[dict(test=str(test),trace=trace) for test,trace in result.errors],skipped=[dict(test=str(test),reason=reason) for test,reason in result.skipped],suite_passed=result.wasSuccessful(),new_tests=2,original_tests_removed=0,cargo_started=False,compiler_coverage_certified=False,frozen_inputs_changed=0)
(d/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
diff=''
for relative,new_source in [('scripts/test_verify_wrapper_standard_impls.py',test_source),('scripts/verify_wrapper_standard_impls.py',verifier_source),('crates/druid-wrapper/src/sqlx/sqlx_connection_actor.rs',actor_bytes.decode('utf-8'))]:
    original=(w/relative).read_text(encoding='utf-8');diff+=''.join(difflib.unified_diff(original.splitlines(True),new_source.splitlines(True),fromfile='a/'+relative,tofile='b/'+relative))
(d/'complete-review.patch').write_text(diff,encoding='utf-8',newline='\n')
(d/'report.md').write_text('# SQLx门禁完整原测试与新增回归\n\n全部原测试均保留并执行，迁移旧结果集fixture到Buffered和Async，fixture调用选择限制在原指定函数范围。新增真实源码负例检查actor、有界请求与关闭，以及两路径trace精确次数。\n\n结果：'+str(result.testsRun)+' tests / '+str(len(result.failures))+' failures / '+str(len(result.errors))+' errors / '+str(len(result.skipped))+' skipped。完整错误保留在summary与日志；未以局部成功代替整套通过。补丁未apply，无Cargo或LLVM覆盖认证。\n',encoding='utf-8')
files={p.name:p for p in d.iterdir() if p.is_file()};files.update({'runner354.py':Path(__file__),'original-tests.py':test_path,'original-verifier.py':verifier_path,'original-actor.rs':actor_path,'frozen319.json':frozen_path});entries={name:sha(path) for name,path in files.items()};z=b/'task6-sqlx-gate-regression355.zip';assert not z.exists()
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as archive:
    for name,path in files.items():archive.write(path,name)
    archive.writestr('manifest.json',json.dumps(entries,indent=2))
with zipfile.ZipFile(z) as archive:assert all(hashlib.sha256(archive.read(name)).hexdigest()==h for name,h in entries.items())
receipt=b/'task6-sqlx-gate-regression355.summary.json';receipt.write_text(json.dumps(dict(sha256=sha(z),verified_entries=len(entries),tests_run=result.testsRun,failures=len(result.failures),errors=len(result.errors),skipped=len(result.skipped),production_applied=False),indent=2)+'\n',encoding='utf-8')
for item in (z,receipt):
    target=e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'/item.name;assert not target.exists();shutil.copyfile(item,target);assert sha(item)==sha(target)
note='2026-10-09 SQLx校验器完整原suite草稿354/355：全部原测试保留，结果 '+str(result.testsRun)+' tests/'+str(len(result.failures))+'FAIL/'+str(len(result.errors))+'ERROR/'+str(len(result.skipped))+'SKIP；新增两个方法承载异步所有权7负例和双结果集trace8负例。旧fixture路径迁移与精确函数选择补丁完整可审阅；错误/环境问题保留，不替换为局部PASS。无Cargo/LLVM认证、未apply，1277冻结变化0，zip355 SHA '+sha(z)+'全部条目/E镜像核验。18顶层OPEN。'
for relative in ('.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md','docs/verification/rdbc-first/status.md','docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md'):
    with (e/relative).open('ab') as out:out.write(('\n\n'+note+'\n').encode('utf-8'))
print(json.dumps(dict(tests_run=result.testsRun,failures=len(result.failures),errors=len(result.errors),skipped=len(result.skipped),zip_sha256=sha(z),error_tests=[str(test) for test,_ in result.errors],failure_tests=[str(test) for test,_ in result.failures]),ensure_ascii=False))
