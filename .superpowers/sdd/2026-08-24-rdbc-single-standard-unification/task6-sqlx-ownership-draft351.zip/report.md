# SQLx 所有权与结果集迁移校验草稿

原导入检查失败；仅拆分导入后原检查暴露已退休文件引用。草稿将缓冲结果集检查绑定到真实 Buffered 类型，并额外检查 Async actor、容量1、pull 请求、worker 和关闭路径，保留原更新链与元数据要求。所有结果仅为源码门禁和受控负例，不是编译、覆盖率或运行时证明。

完整105条源码预检：{"status": "FAIL", "error": "runtime trace record callsite multiset drift: missing={('crates/druid-wrapper/src/sqlx/sqlx_streaming_result_set.rs', 'task4_trace_result_next'): 1, ('crates/druid-wrapper/src/sqlx/sqlx_streaming_result_set.rs', 'task4_trace_result_set_metadata'): 1}, extra={('crates/druid-wrapper/src/sqlx/sqlx_async_result_set.rs', 'task4_trace_result_set_metadata'): 1, ('crates/druid-wrapper/src/sqlx/sqlx_async_result_set.rs', 'task4_trace_result_next'): 1, ('crates/druid-wrapper/src/sqlx/sqlx_buffered_result_set.rs', 'task4_trace_result_set_metadata'): 1, ('crates/druid-wrapper/src/sqlx/sqlx_buffered_result_set.rs', 'task4_trace_result_next'): 1}", "requirements": 105}

运行中1277个冻结输入保持不变；补丁未应用。
