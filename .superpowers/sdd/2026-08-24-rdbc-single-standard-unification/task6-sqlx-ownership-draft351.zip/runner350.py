from pathlib import Path
from unittest.mock import patch
import difflib, hashlib, json, shutil, sys, types, zipfile
sys.dont_write_bytecode = True
b = Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
w = Path('F:/codex_build_cache/d177')
e = Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust')
d = b / 'task6-sqlx-ownership-draft350'
d.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
frozen_path = b / 'task7-final-candidate-workspace319/frozen-inputs.json'
frozen = json.loads(frozen_path.read_text())
assert len(frozen) == 1277 and all(sha(w / p) == h for p, h in frozen.items())
sys.path.insert(0, str(w / 'scripts'))
import verify_wrapper_standard_impls as original
import regenerate_task6_coverage_manifest as generator
actor_path = w / 'crates/druid-wrapper/src/sqlx/sqlx_connection_actor.rs'
actor_original = actor_path.read_text(encoding='utf-8')
old_import = 'use tokio::sync::{mpsc, oneshot, watch, Mutex};'
new_import = 'use tokio::sync::{mpsc, oneshot, watch};\nuse tokio::sync::Mutex;'
assert actor_original.count(old_import) == 1
actor_draft = actor_original.replace(old_import, new_import)
assert actor_draft.replace(new_import, old_import) == actor_original
verifier_path = w / 'scripts/verify_wrapper_standard_impls.py'
verifier_original = verifier_path.read_text(encoding='utf-8')
start = verifier_original.index('def verify_sqlx_ownership(')
end = verifier_original.index('\ndef verify_family_executor_call_chains(', start)
old_function = verifier_original[start:end]
assert old_function.count('sqlx_streaming_result_set.rs') == 1
new_function = old_function.replace('sqlx_streaming_result_set.rs', 'sqlx_buffered_result_set.rs')
new_function += '''
    async_source = code_tokens(
        (root / "crates/druid-wrapper/src/sqlx/sqlx_async_result_set.rs").read_text(
            encoding="utf-8"
        )
    )
    required_async = (
        "struct SqlxAsyncResultSet",
        "actor : Arc < SqlxConnectionActor >",
        "metadata : Option < Arc < ResultSetMetaDataSnapshot > >",
        "mpsc :: channel ( 1 )",
        "actor . spawn_cursor",
        "async fn next",
        ". try_send ( SqlxCursorRequest",
        "async fn close",
        "worker . await",
        "self . shutdown . send_replace ( true )",
    )
    missing_async = [marker for marker in required_async if marker not in async_source]
    if missing_async:
        fail(f"SQLx async ResultSet ownership/bounded pull evidence is incomplete: {missing_async}")
    if "Vec < Row >" in async_source:
        fail("SQLx async ResultSet retains an eager row vector")
    if "connection : Mutex < SqlxConnectionAdapter >" not in actor_source:
        fail("SQLx actor does not own the raw adapter under its Tokio mutex")

'''
verifier_draft = verifier_original[:start] + new_function + verifier_original[end:]
draft = types.ModuleType('task6_ownership_draft350')
draft.__file__ = str(verifier_path)
sys.modules[draft.__name__] = draft
exec(compile(verifier_draft, str(verifier_path), 'exec'), draft.__dict__)
original_read = Path.read_text
checks = []
def run_check(name, module, overrides, expected):
    def read(path, *args, **kwargs):
        return overrides[path] if path in overrides else original_read(path, *args, **kwargs)
    try:
        with patch.object(Path, 'read_text', read):
            module.verify_sqlx_ownership(w)
        result = {'name': name, 'outcome': 'PASS'}
    except (original.VerificationError, draft.VerificationError, OSError) as error:
        result = {'name': name, 'outcome': 'REJECT', 'error': str(error)}
    assert result['outcome'] == expected, result
    checks.append(result)
run_check('original-current-import-red', original, {}, 'REJECT')
run_check('original-explicit-import-retired-file-red', original, {actor_path: actor_draft}, 'REJECT')
run_check('draft-current-real-source-green', draft, {actor_path: actor_draft}, 'PASS')
async_path = w / 'crates/druid-wrapper/src/sqlx/sqlx_async_result_set.rs'
async_original = async_path.read_text(encoding='utf-8')
negative_changes = [
    ('async-actor-removed', 'actor: Arc<SqlxConnectionActor>', 'actor: usize'),
    ('async-capacity-expanded', 'mpsc::channel(1)', 'mpsc::channel(100)'),
    ('async-worker-bypassed', 'actor.spawn_cursor', 'actor.retired_spawn_cursor'),
    ('async-pull-bypassed', '.try_send(SqlxCursorRequest', '.retired_send(SqlxCursorRequest'),
    ('async-close-not-awaited', 'worker.await', 'worker.retired_wait'),
    ('async-shutdown-removed', 'self.shutdown.send_replace(true)', 'self.shutdown.retired_send(true)'),
    ('async-eager-vector-added', 'current: Option<Row>', 'current: Vec<Row>'),
]
for name, old, new in negative_changes:
    assert old in async_original, name
    mutated = async_original.replace(old, new)
    run_check(name, draft, {actor_path: actor_draft, async_path: mutated}, 'REJECT')
buffered_path = w / 'crates/druid-wrapper/src/sqlx/sqlx_buffered_result_set.rs'
buffered_original = buffered_path.read_text(encoding='utf-8')
run_check('buffered-actor-removed', draft, {actor_path: actor_draft, buffered_path: buffered_original.replace('Arc<SqlxConnectionActor>', 'usize')}, 'REJECT')
run_check('raw-adapter-mutex-removed', draft, {actor_path: actor_draft.replace('connection: Mutex<SqlxConnectionAdapter>', 'connection: SqlxConnectionAdapter')}, 'REJECT')
run_check('actor-update-entry-retired', draft, {actor_path: actor_draft.replace('async fn execute_update_result', 'async fn retired_execute_update_result')}, 'REJECT')
def read_overlay(path, *args, **kwargs):
    return actor_draft if path == actor_path else original_read(path, *args, **kwargs)
try:
    with patch.object(Path, 'read_text', read_overlay), patch.object(generator, 'verifier', draft):
        generator.validate_canonical_source_requirements(w, generator.canonical_requirements(w))
    canonical = {'status': 'PASS_STATIC_ONLY', 'requirements': 105}
except (draft.VerificationError, OSError) as error:
    canonical = {'status': 'FAIL', 'error': str(error), 'requirements': 105}
for name, source in [('sqlx_connection_actor.rs', actor_draft), ('verify_wrapper_standard_impls.py', verifier_draft)]:
    (d / name).write_text(source, encoding='utf-8', newline='\n')
diff = ''.join(difflib.unified_diff(actor_original.splitlines(True), actor_draft.splitlines(True), fromfile='a/crates/druid-wrapper/src/sqlx/sqlx_connection_actor.rs', tofile='b/crates/druid-wrapper/src/sqlx/sqlx_connection_actor.rs'))
diff += ''.join(difflib.unified_diff(verifier_original.splitlines(True), verifier_draft.splitlines(True), fromfile='a/scripts/verify_wrapper_standard_impls.py', tofile='b/scripts/verify_wrapper_standard_impls.py'))
(d / 'ownership.patch').write_text(diff, encoding='utf-8', newline='\n')
assert all(sha(w / p) == h for p, h in frozen.items())
summary = dict(scope='UNAPPLIED_SQLX_OWNERSHIP_AND_BUFFERED_ASYNC_GATE_DRAFT', production_applied=False, frozen_inputs_changed=0, source_import_only_change=True, verifier_preserves_original_ownership_update_metadata_checks=True, added_async_bounded_ownership_guards=True, checks=checks, canonical_source_preflight=canonical, compiler_coverage_certified=False, cargo_started=False)
(d / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
(d / 'report.md').write_text('# SQLx 所有权与结果集迁移校验草稿\n\n原导入检查失败；仅拆分导入后原检查暴露已退休文件引用。草稿将缓冲结果集检查绑定到真实 Buffered 类型，并额外检查 Async actor、容量1、pull 请求、worker 和关闭路径，保留原更新链与元数据要求。所有结果仅为源码门禁和受控负例，不是编译、覆盖率或运行时证明。\n\n完整105条源码预检：'+json.dumps(canonical, ensure_ascii=False)+'\n\n运行中1277个冻结输入保持不变；补丁未应用。\n', encoding='utf-8')
files = {p.name:p for p in d.iterdir() if p.is_file()}
files.update({'runner350.py':Path(__file__), 'original-verifier.py':verifier_path, 'original-actor.rs':actor_path, 'original-async.rs':async_path, 'original-buffered.rs':buffered_path, 'frozen319.json':frozen_path})
entries = {name:sha(path) for name,path in files.items()}
z = b / 'task6-sqlx-ownership-draft351.zip'
assert not z.exists()
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as archive:
    for name,path in files.items(): archive.write(path,name)
    archive.writestr('manifest.json',json.dumps(entries,indent=2))
with zipfile.ZipFile(z) as archive:
    assert all(hashlib.sha256(archive.read(name)).hexdigest()==h for name,h in entries.items())
receipt = b / 'task6-sqlx-ownership-draft351.summary.json'
receipt.write_text(json.dumps(dict(sha256=sha(z),verified_entries=len(entries),checks=len(checks),canonical_source_preflight=canonical,production_applied=False),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for source in (z,receipt):
    target=e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'/source.name
    assert not target.exists()
    shutil.copyfile(source,target)
    assert sha(source)==sha(target)
note='2026-10-09 SQLx所有权校验草稿350/351：原源码组合导入RED，显式Mutex导入后暴露原校验器引用已退休Streaming文件；未应用草稿将原缓冲检查迁移到Buffered并额外拒绝Async丢失actor/扩大容量/绕过pull或worker/不等待关闭/保留Vec<Row>。'+str(len(checks))+'项原RED/草稿GREEN及负例均符合预期；完整105源码预检 '+json.dumps(canonical,ensure_ascii=False)+'。无Cargo/编译器或runtime coverage认证，1277冻结变化0，zip351 SHA '+sha(z)+'全部条目/E镜像核验。Task6及18顶层仍OPEN。'
for relative in ('.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md','docs/verification/rdbc-first/status.md','docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md'):
    with (e/relative).open('ab') as output: output.write(('\n\n'+note+'\n').encode('utf-8'))
print(json.dumps(dict(checks=checks,canonical_source_preflight=canonical,zip_sha256=sha(z)),ensure_ascii=False))
