# 当前 SQLx 所有权与精确 trace 草稿

原105条源码义务预检在草稿上通过。旧单缓冲结果集路径迁移到真实 Buffered；Async 的两个额外调用点分别要求恰好一次，不放宽原精确测试的缓冲路径来源。8个移除/重复负例全部拒绝。4个原测试3通过/1 fixture错误；用原校验器独立复现同一HTTP fixture误取set_input_parameter调用。仅把fixture选择限制到原规定函数范围后4/0，错误函数来源负例保留。合成 trace 仅检查来源解析，不构成 runtime 或 compiler coverage。原清单105项过期仍待新LLVM profile再生成。

候选源码与校验器均未应用；运行中1277冻结输入变化0。
