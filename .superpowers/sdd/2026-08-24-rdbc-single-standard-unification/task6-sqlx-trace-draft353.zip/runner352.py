from pathlib import Path
from unittest.mock import patch
import difflib, hashlib, io, json, shutil, sys, types, unittest, zipfile
sys.dont_write_bytecode=True
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d177');e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust');d=b/'task6-sqlx-trace-draft352';d.mkdir(exist_ok=True);assert not (d/'summary.json').exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
frozen_path=b/'task7-final-candidate-workspace319/frozen-inputs.json';frozen=json.loads(frozen_path.read_text());assert len(frozen)==1277 and all(sha(w/p)==h for p,h in frozen.items())
sys.path.insert(0,str(w/'scripts'))
import regenerate_task6_coverage_manifest as generator
verifier_path=w/'scripts/verify_wrapper_standard_impls.py';base_path=b/'task6-sqlx-ownership-draft350/verify_wrapper_standard_impls.py';source=base_path.read_text(encoding='utf-8')
old='crates/druid-wrapper/src/sqlx/sqlx_streaming_result_set.rs';buffered='crates/druid-wrapper/src/sqlx/sqlx_buffered_result_set.rs';async_relative='crates/druid-wrapper/src/sqlx/sqlx_async_result_set.rs'
assert source.count(old)==4
source=source.replace(old,buffered)
marker='TRACE_BRANCH_CALLSITE_COUNTS = {'
assert source.count(marker)==1
extra='''TRACE_RECORD_CALLSITE_COUNTS.update({
    ("crates/druid-wrapper/src/sqlx/sqlx_async_result_set.rs", "task4_trace_result_next"): 1,
    ("crates/druid-wrapper/src/sqlx/sqlx_async_result_set.rs", "task4_trace_result_set_metadata"): 1,
})
'''
source=source.replace(marker,extra+marker)
draft=types.ModuleType('task6_sqlx_trace_draft352');draft.__file__=str(verifier_path);sys.modules[draft.__name__]=draft;exec(compile(source,str(verifier_path),'exec'),draft.__dict__)
actor_path=w/'crates/druid-wrapper/src/sqlx/sqlx_connection_actor.rs';actor_source=(b/'task6-sqlx-ownership-draft350/sqlx_connection_actor.rs').read_text(encoding='utf-8');read=Path.read_text
def overlay(path,*args,**kwargs):return actor_source if path==actor_path else read(path,*args,**kwargs)
with patch.object(Path,'read_text',overlay),patch.object(generator,'verifier',draft):
    generator.validate_canonical_source_requirements(w,generator.canonical_requirements(w))
checks=[dict(name='full105-canonical-source-preflight',outcome='PASS_STATIC_ONLY')]
for relative in (buffered,async_relative):
    path=w/relative;original=path.read_text(encoding='utf-8')
    for method in ('task4_trace_result_next','task4_trace_result_set_metadata'):
        assert original.count('.'+method+'(')==1
        for kind in ('removed','duplicated'):
            changed=original.replace('.'+method+'(','.retired_'+method+'(') if kind=='removed' else original+'\nfn invalid_duplicate(actor: &SqlxConnectionActor) { actor.'+method+'(); }\n'
            def mutation(target,*args,**kwargs):return changed if target==path else overlay(target,*args,**kwargs)
            try:
                with patch.object(Path,'read_text',mutation):draft.verify_trace_record_callsites(w)
            except draft.VerificationError as error:
                assert 'multiset drift' in str(error)
                checks.append(dict(name=relative+':'+method+':'+kind,outcome='REJECT',error=str(error)))
            else:raise AssertionError('trace mutation accepted')
# 执行原测试，保持其函数体不变；只将模块导入绑定到未应用草稿。
old_module=sys.modules['verify_wrapper_standard_impls'];sys.modules['verify_wrapper_standard_impls']=draft
test_path=w/'scripts/test_verify_wrapper_standard_impls.py';test_module=types.ModuleType('ownership_original_tests352');test_module.__file__=str(test_path);sys.modules[test_module.__name__]=test_module
exec(compile(test_path.read_text(encoding='utf-8'),str(test_path),'exec'),test_module.__dict__)
sys.modules['verify_wrapper_standard_impls']=old_module
names=('test_rejects_missing_sqlx_actor','test_rejects_comment_only_actor_ownership_markers','test_runtime_marker_parser_is_diagnostic_not_the_coverage_anchor','test_caller_line_must_remain_inside_the_exact_production_function_region')
suite=unittest.TestSuite(test_module.WrapperStandardVerifierTest(name) for name in names);output=io.StringIO();result=unittest.TextTestRunner(stream=output,verbosity=2).run(suite)
(d/'original-tests.log').write_text(output.getvalue(),encoding='utf-8')
assert result.testsRun==4 and len(result.errors)==1 and not result.failures
assert 'outside its production function region' in result.errors[0][1]
# 原HTTP fixture取同文件第一个调用，已落入set_input_parameter而非set_parameter；
# 使用原校验器复现，随后只修fixture选择，仍保留错误函数来源负例。
baseline=types.ModuleType('trace_original_baseline352');baseline.__file__=str(test_path);sys.modules[baseline.__name__]=baseline
exec(compile(test_path.read_text(encoding='utf-8'),str(test_path),'exec'),baseline.__dict__)
baseline_output=io.StringIO();baseline_result=unittest.TextTestRunner(stream=baseline_output,verbosity=2).run(unittest.TestSuite([baseline.WrapperStandardVerifierTest(names[-1])]))
(d/'original-baseline-fixture-red.log').write_text(baseline_output.getvalue(),encoding='utf-8')
assert len(baseline_result.errors)==1 and 'outside its production function region' in baseline_result.errors[0][1]
test_original=test_path.read_text(encoding='utf-8')
old_selection='''                if f".{method}(" in line
'''
assert test_original.count(old_selection)==1
new_selection='''                if f".{method}(" in line
                and any(
                    start <= index <= end
                    for start, end in verifier.function_line_ranges(
                        destination.read_text(encoding="utf-8"),
                        verifier.TRACE_CALLSITE_FUNCTIONS[family][event["stage"]],
                    )
                )
'''
test_draft=test_original.replace(old_selection,new_selection)
sys.modules['verify_wrapper_standard_impls']=draft
repaired=types.ModuleType('trace_fixture_repaired352');repaired.__file__=str(test_path);sys.modules[repaired.__name__]=repaired;exec(compile(test_draft,str(test_path),'exec'),repaired.__dict__)
sys.modules['verify_wrapper_standard_impls']=old_module
repaired_output=io.StringIO();repaired_result=unittest.TextTestRunner(stream=repaired_output,verbosity=2).run(unittest.TestSuite(repaired.WrapperStandardVerifierTest(name) for name in names));assert repaired_result.wasSuccessful(),repaired_output.getvalue()
(d/'repaired-tests.log').write_text(repaired_output.getvalue(),encoding='utf-8');(d/'test_verify_wrapper_standard_impls.py').write_text(test_draft,encoding='utf-8',newline='\n')
# 原精确 SQLX runtime trace 仍只允许默认缓冲路径，不以任意新路径替代。
payload=json.loads(test_module.WrapperStandardVerifierTest.marker(family='SQLX',evidence_id='task4.sqlx.runtime-trace-v1').split('\t',1)[1])
for event in payload['events']:
    relative=draft.TRACE_CALLSITE_RULES['SQLX'][event['stage']];method=draft.TRACE_STAGE_METHODS[event['stage']]
    lines=(w/relative).read_text(encoding='utf-8').splitlines();ranges=draft.function_line_ranges('\n'.join(lines),draft.TRACE_CALLSITE_FUNCTIONS['SQLX'][event['stage']])
    selected=[i for i,line in enumerate(lines,1) if '.'+method+'(' in line and any(start<=i<=end for start,end in ranges)]
    assert selected,(event['stage'],relative)
    event['caller_file']=relative;event['caller_line']=selected[0]
marker_prefix='DRUID_TASK4_RUNTIME_TRACE\t'
draft.validate_runtime_trace_output(marker_prefix+json.dumps(payload),'task4.sqlx.runtime-trace-v1','SQLX',draft.TRACE_VERSION,'nonce-a',w)
checks.append(dict(name='source-derived-synthetic-buffered-trace-exact-region',outcome='PASS_DIAGNOSTIC_ONLY'))
for wrong in (old,async_relative):
    forged=json.loads(json.dumps(payload));next(event for event in forged['events'] if event['stage']=='ResultNext')['caller_file']=wrong
    try:draft.validate_runtime_trace_output(marker_prefix+json.dumps(forged),'task4.sqlx.runtime-trace-v1','SQLX',draft.TRACE_VERSION,'nonce-a',w)
    except draft.VerificationError as error:checks.append(dict(name='reject-synthetic-wrong-path:'+wrong,outcome='REJECT',error=str(error)))
    else:raise AssertionError('wrong runtime provenance accepted')
assert all(sha(w/p)==h for p,h in frozen.items())
(d/'verify_wrapper_standard_impls.py').write_text(source,encoding='utf-8',newline='\n');shutil.copyfile(b/'task6-sqlx-ownership-draft350/sqlx_connection_actor.rs',d/'sqlx_connection_actor.rs')
original_source=verifier_path.read_text(encoding='utf-8');diff=''.join(difflib.unified_diff(original_source.splitlines(True),source.splitlines(True),fromfile='a/scripts/verify_wrapper_standard_impls.py',tofile='b/scripts/verify_wrapper_standard_impls.py'))
actor_original=actor_path.read_text(encoding='utf-8');diff+=''.join(difflib.unified_diff(actor_original.splitlines(True),actor_source.splitlines(True),fromfile='a/crates/druid-wrapper/src/sqlx/sqlx_connection_actor.rs',tofile='b/crates/druid-wrapper/src/sqlx/sqlx_connection_actor.rs'))
(d/'ownership-and-trace.patch').write_text(diff,encoding='utf-8',newline='\n')
test_diff=''.join(difflib.unified_diff(test_original.splitlines(True),test_draft.splitlines(True),fromfile='a/scripts/test_verify_wrapper_standard_impls.py',tofile='b/scripts/test_verify_wrapper_standard_impls.py'));(d/'fixture-region.patch').write_text(test_diff,encoding='utf-8',newline='\n')
summary=dict(scope='UNAPPLIED_CURRENT_SQLX_BUFFERED_ASYNC_OWNERSHIP_AND_EXACT_TRACE_DRAFT',production_applied=False,frozen_inputs_changed=0,canonical_requirements=105,canonical_source_preflight='PASS_STATIC_ONLY',checks=checks,original_tests_run=len(names),original_tests_passed=3,original_tests_errors=1,original_baseline_same_fixture_error=True,repaired_fixture_tests_run=4,repaired_fixture_tests_errors=0,compiler_coverage_certified=False,runtime_trace_certified=False,cargo_started=False,preserves_exact_buffered_runtime_provenance=True)
(d/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(d/'report.md').write_text('# 当前 SQLx 所有权与精确 trace 草稿\n\n原105条源码义务预检在草稿上通过。旧单缓冲结果集路径迁移到真实 Buffered；Async 的两个额外调用点分别要求恰好一次，不放宽原精确测试的缓冲路径来源。8个移除/重复负例全部拒绝。4个原测试3通过/1 fixture错误；用原校验器独立复现同一HTTP fixture误取set_input_parameter调用。仅把fixture选择限制到原规定函数范围后4/0，错误函数来源负例保留。合成 trace 仅检查来源解析，不构成 runtime 或 compiler coverage。原清单105项过期仍待新LLVM profile再生成。\n\n候选源码与校验器均未应用；运行中1277冻结输入变化0。\n',encoding='utf-8')
files={p.name:p for p in d.iterdir() if p.is_file()};files.update({'runner352.py':Path(__file__),'original-verifier.py':verifier_path,'original-tests.py':test_path,'original-actor.rs':actor_path,'original-buffered.rs':w/buffered,'original-async.rs':w/async_relative,'frozen319.json':frozen_path})
entries={name:sha(path) for name,path in files.items()};z=b/'task6-sqlx-trace-draft353.zip';assert not z.exists()
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as archive:
    for name,path in files.items():archive.write(path,name)
    archive.writestr('manifest.json',json.dumps(entries,indent=2))
with zipfile.ZipFile(z) as archive:assert all(hashlib.sha256(archive.read(name)).hexdigest()==h for name,h in entries.items())
receipt=b/'task6-sqlx-trace-draft353.summary.json';receipt.write_text(json.dumps(dict(sha256=sha(z),verified_entries=len(entries),canonical_source_preflight=summary['canonical_source_preflight'],checks=len(checks),original_tests_run=len(names),production_applied=False),indent=2)+'\n',encoding='utf-8')
for item in (z,receipt):
    target=e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'/item.name;assert not target.exists();shutil.copyfile(item,target);assert sha(item)==sha(target)
note='2026-10-09 SQLx所有权/trace草稿352/353：保留原15x7义务和所有actor/update/metadata检查，Buffered绑定真实缓冲路径，额外登记Async两个各恰好一次调用点；完整105源码预检PASS_STATIC_ONLY，8个缺失/重复调用负例拒绝。原4测试3PASS/1HTTP fixture错误，用原校验器复现；仅限制fixture调用选择到规定函数范围后4/0，错误函数负例保留。原精确runtime来源仍只允许Buffered并拒绝退休/Async替代。合成来源数据不作为runtime，未修改过期hash/compiler身份、无Cargo，1277冻结变化0，草稿未apply。zip353 SHA '+sha(z)+'全部条目/E镜像核验；105新鲜LLVM覆盖及319终态仍待完成，18顶层OPEN。'
for relative in ('.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md','docs/verification/rdbc-first/status.md','docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md'):
    with (e/relative).open('ab') as out:out.write(('\n\n'+note+'\n').encode('utf-8'))
print(json.dumps(dict(canonical_source_preflight=summary['canonical_source_preflight'],checks=len(checks),original_tests_run=len(names),zip_sha256=sha(z)),ensure_ascii=False))
