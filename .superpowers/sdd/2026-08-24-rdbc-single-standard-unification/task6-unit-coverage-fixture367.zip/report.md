# 单元覆盖清单fixture隔离

三个清单负例改用临时fixture，7x15分母、实际source函数和所有错误断言保留。compiler名称显式标为UNIT_TEST_ONLY_NO_LLVM，不做生产证据。完整原42测试及新增2测试均执行：44 tests/0 failures/1 errors/1 skipped。完整错误保留。

生产manifest SHA未变，原生产加载仍拒绝过期hash；105 LLVM义务未通过。原Windows0.1s预算与后代断言保留，全部运行中1277输入不变，补丁未apply。
