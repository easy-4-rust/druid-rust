from pathlib import Path
from unittest.mock import patch
import difflib,hashlib,importlib.util,io,json,shutil,sys,types,unittest,zipfile
sys.dont_write_bytecode=True
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d177');e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust');d=b/'task6-unit-coverage-fixture366';d.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
frozen_path=b/'task7-final-candidate-workspace319/frozen-inputs.json';frozen=json.loads(frozen_path.read_text());assert len(frozen)==1277 and all(sha(w/p)==h for p,h in frozen.items())
sys.path.insert(0,str(w/'scripts'));native_spec=importlib.util.spec_from_file_location('windows_bounded_process',b/'windows_bounded_process363.py');native=importlib.util.module_from_spec(native_spec);sys.modules[native_spec.name]=native;native_spec.loader.exec_module(native)
verifier_path=w/'scripts/verify_wrapper_standard_impls.py';verifier_source=(b/'task6-windows-runner-validation364/verify_wrapper_standard_impls.py').read_text(encoding='utf-8');verifier=types.ModuleType('verify_wrapper_standard_impls');verifier.__file__=str(verifier_path);sys.modules[verifier.__name__]=verifier;exec(compile(verifier_source,str(verifier_path),'exec'),verifier.__dict__)
test_path=w/'scripts/test_verify_wrapper_standard_impls.py';test_source=(b/'task6-windows-fixture-draft361/test_verify_wrapper_standard_impls.py').read_text(encoding='utf-8')
helper='''
    def unit_coverage_manifest_root(self) -> Path:
        """构建临时单元fixture；人工compiler标识不作为生产LLVM覆盖证据。"""
        repository = Path(__file__).resolve().parents[1]
        fixture_root = self.root / "unit_only_coverage_manifest"
        document = json.loads((repository / verifier.DEFAULT_COVERAGE_MANIFEST).read_bytes())
        self.assertEqual(len(document["families"]), 7)
        for family in document["families"]:
            self.assertEqual(len(family["requirements"]), 15)
            for requirement in family["requirements"]:
                relative = Path(requirement["source_path"])
                destination = fixture_root / relative
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes((repository / relative).read_bytes())
                requirement["source_sha256"] = hashlib.sha256(destination.read_bytes()).hexdigest()
                requirement["compiler_function_name"] = (
                    "UNIT_TEST_ONLY_NO_LLVM_" + family["family"] + "_" + requirement["requirement_id"]
                )
        manifest = fixture_root / verifier.DEFAULT_COVERAGE_MANIFEST
        manifest.parent.mkdir(parents=True, exist_ok=True)
        manifest.write_text(json.dumps(document, ensure_ascii=False, indent=2) + "\\n", encoding="utf-8", newline="\\n")
        return fixture_root

'''
marker='    def test_wrong_source_hash_or_compiler_function_identity_is_rejected(self) -> None:';assert test_source.count(marker)==1;test_source=test_source.replace(marker,helper+marker)
names=('test_wrong_source_hash_or_compiler_function_identity_is_rejected','test_wrong_family_factory_manifest_mapping_is_rejected','test_duplicate_or_reordered_coverage_manifest_mapping_is_rejected')
for name in names:
    start=test_source.index('    def '+name+'(');end=test_source.find('\n    def ',start+1)
    assert end>start
    body=test_source[start:end];old='repository = Path(__file__).resolve().parents[1]';assert body.count(old)==1
    body=body.replace(old,'repository = self.unit_coverage_manifest_root()');test_source=test_source[:start]+body+test_source[end:]
test_module=types.ModuleType('unit_coverage_fixture_tests366');test_module.__file__=str(test_path);sys.modules[test_module.__name__]=test_module;exec(compile(test_source,str(test_path),'exec'),test_module.__dict__)
actor_path=w/'crates/druid-wrapper/src/sqlx/sqlx_connection_actor.rs';actor_bytes=(b/'task6-sqlx-trace-draft352/sqlx_connection_actor.rs').read_bytes();read=Path.read_bytes
def overlay(path):return actor_bytes if path==actor_path else read(path)
manifest_path=w/verifier.DEFAULT_COVERAGE_MANIFEST;manifest_hash=sha(manifest_path)
output=io.StringIO()
with patch.object(Path,'read_bytes',overlay):result=unittest.TextTestRunner(stream=output,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(test_module))
(d/'full-suite.log').write_text(output.getvalue(),encoding='utf-8')
assert sha(manifest_path)==manifest_hash and all(sha(w/p)==h for p,h in frozen.items())
try:verifier.load_coverage_manifest(w)
except verifier.VerificationError as error:production_manifest_status=dict(status='REJECT',error=str(error))
else:raise AssertionError('production stale manifest unexpectedly accepted')
summary=dict(scope='UNAPPLIED_UNIT_MANIFEST_FIXTURE_DECOUPLING_FULL_SUITE',production_applied=False,tests_run=result.testsRun,failures=[dict(test=str(test),trace=trace) for test,trace in result.failures],errors=[dict(test=str(test),trace=trace) for test,trace in result.errors],skipped=[dict(test=str(test),reason=reason) for test,reason in result.skipped],suite_passed=result.wasSuccessful(),unit_fixture_only=True,unit_compiler_prefix='UNIT_TEST_ONLY_NO_LLVM_',production_manifest_sha256=manifest_hash,production_manifest_unchanged=True,production_manifest_gate=production_manifest_status,compiler_coverage_certified=False,cargo_started=False,frozen_inputs_changed=0,original_tests_removed=0)
(d/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');(d/'test_verify_wrapper_standard_impls.py').write_text(test_source,encoding='utf-8',newline='\n');(d/'verify_wrapper_standard_impls.py').write_text(verifier_source,encoding='utf-8',newline='\n');shutil.copyfile(b/'windows_bounded_process363.py',d/'windows_bounded_process.py')
diff=''
for relative,new_source in [('scripts/test_verify_wrapper_standard_impls.py',test_source),('scripts/verify_wrapper_standard_impls.py',verifier_source),('crates/druid-wrapper/src/sqlx/sqlx_connection_actor.rs',actor_bytes.decode('utf-8'))]:
    original=(w/relative).read_text(encoding='utf-8');diff+=''.join(difflib.unified_diff(original.splitlines(True),new_source.splitlines(True),fromfile='a/'+relative,tofile='b/'+relative))
diff+=''.join(difflib.unified_diff([], (b/'windows_bounded_process363.py').read_text(encoding='utf-8').splitlines(True),fromfile='/dev/null',tofile='b/scripts/windows_bounded_process.py'));(d/'complete-gate-review.patch').write_text(diff,encoding='utf-8',newline='\n')
(d/'report.md').write_text('# 单元覆盖清单fixture隔离\n\n三个清单负例改用临时fixture，7x15分母、实际source函数和所有错误断言保留。compiler名称显式标为UNIT_TEST_ONLY_NO_LLVM，不做生产证据。完整原42测试及新增2测试均执行：'+str(result.testsRun)+' tests/'+str(len(result.failures))+' failures/'+str(len(result.errors))+' errors/'+str(len(result.skipped))+' skipped。完整错误保留。\n\n生产manifest SHA未变，原生产加载仍拒绝过期hash；105 LLVM义务未通过。原Windows0.1s预算与后代断言保留，全部运行中1277输入不变，补丁未apply。\n',encoding='utf-8')
files={p.name:p for p in d.iterdir() if p.is_file()};files.update({'runner366.py':Path(__file__),'original-tests.py':test_path,'original-verifier.py':verifier_path,'original-production-manifest.json':manifest_path,'frozen319.json':frozen_path});entries={name:sha(path) for name,path in files.items()};z=b/'task6-unit-coverage-fixture367.zip';assert not z.exists()
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as archive:
    for name,path in files.items():archive.write(path,name)
    archive.writestr('manifest.json',json.dumps(entries,indent=2))
with zipfile.ZipFile(z) as archive:assert all(hashlib.sha256(archive.read(name)).hexdigest()==h for name,h in entries.items())
receipt=b/'task6-unit-coverage-fixture367.summary.json';receipt.write_text(json.dumps(dict(sha256=sha(z),verified_entries=len(entries),tests_run=result.testsRun,failures=len(result.failures),errors=len(result.errors),skipped=len(result.skipped),production_applied=False),indent=2)+'\n',encoding='utf-8')
for item in (z,receipt):
    target=e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'/item.name;assert not target.exists();shutil.copyfile(item,target);assert sha(item)==sha(target)
note='2026-10-09 清单单元fixture草稿366/367：三个负例使用临时7x15清单和UNIT_TEST_ONLY_NO_LLVM标识，错hash/家族/重复顺序断言保留；全部原42+新2测试结果 '+str(result.testsRun)+' tests/'+str(len(result.failures))+'FAIL/'+str(len(result.errors))+'ERROR/'+str(len(result.skipped))+'SKIP。生产清单SHA不变且原加载仍拒绝过期hash，105覆盖未认证；Windows原0.1s/2s/输出/后代断言未缩减。无Cargo、未apply，1277冻结变化0，zip367 SHA '+sha(z)+'全部条目/E镜像核验。18顶层OPEN。'
for relative in ('.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md','docs/verification/rdbc-first/status.md','docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md'):
    with (e/relative).open('ab') as out:out.write(('\n\n'+note+'\n').encode('utf-8'))
print(json.dumps(dict(tests_run=result.testsRun,failures=len(result.failures),errors=len(result.errors),skipped=len(result.skipped),error_tests=[str(test) for test,_ in result.errors],zip_sha256=sha(z)),ensure_ascii=False))
