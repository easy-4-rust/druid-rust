# Windows测试解释器与只读探测草稿

以sys.executable替代WindowsApps python3别名，仅用Windows同步/查询句柄检查子进程存活。保留原0.1秒deadline、2秒elapsed断言、输出上限和后代退出断言。实际结果：False；全部错误/失败原样保存，未增加超时或删除断言。运行中1277输入不变，补丁未apply。
