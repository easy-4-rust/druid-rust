from pathlib import Path
from unittest.mock import patch
import difflib,hashlib,importlib.util,io,json,shutil,sys,types,unittest,zipfile
sys.dont_write_bytecode=True
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d177');e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust');d=b/'task6-windows-fixture-draft361';d.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
frozen_path=b/'task7-final-candidate-workspace319/frozen-inputs.json';frozen=json.loads(frozen_path.read_text());assert len(frozen)==1277 and all(sha(w/p)==h for p,h in frozen.items())
sys.path.insert(0,str(w/'scripts'));spec=importlib.util.spec_from_file_location('windows_bounded_process',b/'windows_bounded_process356.py');native=importlib.util.module_from_spec(spec);sys.modules[spec.name]=native;spec.loader.exec_module(native)
verifier_path=w/'scripts/verify_wrapper_standard_impls.py';verifier_source=(b/'task6-windows-runner-validation357/verify_wrapper_standard_impls.py').read_text(encoding='utf-8');verifier=types.ModuleType('verify_wrapper_standard_impls');verifier.__file__=str(verifier_path);sys.modules[verifier.__name__]=verifier;exec(compile(verifier_source,str(verifier_path),'exec'),verifier.__dict__)
test_path=w/'scripts/test_verify_wrapper_standard_impls.py';test_original=test_path.read_text(encoding='utf-8');test_source=(b/'task6-sqlx-gate-regression354/test_verify_wrapper_standard_impls.py').read_text(encoding='utf-8')
start=test_source.index('    def test_runner_is_offline_locked_bounded_and_kills_hanging_process_group(');end=test_source.index('    @unittest.skipUnless(os.name == "posix"',start);body=test_source[start:end]
old_child='''            "child=subprocess.Popen(['python3','-c','import time; time.sleep(10)']); "'''
new_child='''            f"child=subprocess.Popen([{sys.executable!r},'-c','import time; time.sleep(10)']); "'''
assert body.count(old_child)==1 and body.count('["python3", "-c"')==2
body=body.replace(old_child,new_child).replace('["python3", "-c"','[sys.executable, "-c"')
old_probe='''            try:
                os.kill(child_pid, 0)
            except ProcessLookupError:
                child_alive = False
                break
'''
new_probe='''            if not process_is_running(child_pid):
                child_alive = False
                break
'''
assert body.count(old_probe)==1;body=body.replace(old_probe,new_probe)
assert 'timeout_seconds=0.1' in body and 'output_limit=4096' in body and 'output_limit=1024' in body and 'self.assertLess(time.monotonic() - started, 2.0)' in body
test_source=test_source[:start]+body+test_source[end:];test_source=test_source.replace('import subprocess\n','import subprocess\nimport sys\n') if 'import subprocess\n' in test_source else test_source.replace('import signal\n','import signal\nimport sys\n')
helper='''
def process_is_running(pid: int) -> bool:
    """仅查询进程状态；Windows不能使用会终止进程的os.kill(pid,0)。"""
    if os.name != "nt":
        try:
            os.kill(pid, 0)
            return True
        except ProcessLookupError:
            return False
    import ctypes
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.OpenProcess.argtypes = [ctypes.c_ulong, ctypes.c_int, ctypes.c_ulong]
    kernel.OpenProcess.restype = ctypes.c_void_p
    kernel.WaitForSingleObject.argtypes = [ctypes.c_void_p, ctypes.c_ulong]
    kernel.WaitForSingleObject.restype = ctypes.c_ulong
    kernel.CloseHandle.argtypes = [ctypes.c_void_p]
    kernel.CloseHandle.restype = ctypes.c_int
    handle = kernel.OpenProcess(0x101000, False, pid)
    if not handle:
        error = ctypes.get_last_error()
        if error in (87, 1168):
            return False
        raise ctypes.WinError(error)
    try:
        status = kernel.WaitForSingleObject(handle, 0)
        if status not in (0, 258):
            raise ctypes.WinError(ctypes.get_last_error())
        return status == 258
    finally:
        if not kernel.CloseHandle(handle):
            raise ctypes.WinError(ctypes.get_last_error())

'''
marker='class WrapperStandardVerifierTest(unittest.TestCase):';assert test_source.count(marker)==1;test_source=test_source.replace(marker,helper+marker)
test_module=types.ModuleType('windows_fixture_tests361');test_module.__file__=str(test_path);sys.modules[test_module.__name__]=test_module;exec(compile(test_source,str(test_path),'exec'),test_module.__dict__)
output=io.StringIO();result=unittest.TextTestRunner(stream=output,verbosity=2).run(unittest.TestSuite([test_module.WrapperStandardVerifierTest('test_runner_is_offline_locked_bounded_and_kills_hanging_process_group')]))
(d/'original-timeout-fixture.log').write_text(output.getvalue(),encoding='utf-8')
assert all(sha(w/p)==h for p,h in frozen.items())
summary=dict(scope='UNAPPLIED_WINDOWS_TEST_EXECUTABLE_AND_READONLY_PROCESS_PROBE',production_applied=False,original_timeout_seconds=.1,original_elapsed_assertion_seconds=2.0,original_output_limits=[4096,1024],original_descendant_assertion_retained=True,tests_run=result.testsRun,passed=result.wasSuccessful(),errors=[trace for _,trace in result.errors],failures=[trace for _,trace in result.failures],frozen_inputs_changed=0,cargo_started=False)
(d/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');(d/'test_verify_wrapper_standard_impls.py').write_text(test_source,encoding='utf-8',newline='\n');(d/'verify_wrapper_standard_impls.py').write_text(verifier_source,encoding='utf-8',newline='\n');shutil.copyfile(b/'windows_bounded_process356.py',d/'windows_bounded_process.py')
diff=''.join(difflib.unified_diff(test_original.splitlines(True),test_source.splitlines(True),fromfile='a/scripts/test_verify_wrapper_standard_impls.py',tofile='b/scripts/test_verify_wrapper_standard_impls.py'));(d/'test-fixture.patch').write_text(diff,encoding='utf-8',newline='\n')
(d/'report.md').write_text('# Windows测试解释器与只读探测草稿\n\n以sys.executable替代WindowsApps python3别名，仅用Windows同步/查询句柄检查子进程存活。保留原0.1秒deadline、2秒elapsed断言、输出上限和后代退出断言。实际结果：'+str(result.wasSuccessful())+'；全部错误/失败原样保存，未增加超时或删除断言。运行中1277输入不变，补丁未apply。\n',encoding='utf-8')
files={p.name:p for p in d.iterdir() if p.is_file()};files.update({'runner361.py':Path(__file__),'original-tests.py':test_path,'frozen319.json':frozen_path});entries={name:sha(path) for name,path in files.items()};z=b/'task6-windows-fixture-draft362.zip';assert not z.exists()
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as archive:
    for name,path in files.items():archive.write(path,name)
    archive.writestr('manifest.json',json.dumps(entries,indent=2))
with zipfile.ZipFile(z) as archive:assert all(hashlib.sha256(archive.read(name)).hexdigest()==h for name,h in entries.items())
receipt=b/'task6-windows-fixture-draft362.summary.json';receipt.write_text(json.dumps(dict(sha256=sha(z),verified_entries=len(entries),test_passed=result.wasSuccessful(),production_applied=False),indent=2)+'\n',encoding='utf-8')
for item in (z,receipt):
    target=e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'/item.name;assert not target.exists();shutil.copyfile(item,target);assert sha(item)==sha(target)
note='2026-10-09 Windows测试fixture草稿361/362：仅改解释器到sys.executable和只读OpenProcess/WaitForSingleObject存活探测，保留原0.1s超时/2s elapsed/4096及1024输出cap/后代退出断言；原测试实际PASS='+str(result.wasSuccessful())+'，全部错误/失败保留。未增加超时或删除断言、无Cargo、未apply，1277冻结变化0，zip362 SHA '+sha(z)+'全部条目/E镜像核验。18顶层OPEN。'
for relative in ('.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md','docs/verification/rdbc-first/status.md','docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md'):
    with (e/relative).open('ab') as out:out.write(('\n\n'+note+'\n').encode('utf-8'))
print(json.dumps(dict(passed=result.wasSuccessful(),errors=summary['errors'],failures=summary['failures'],zip_sha256=sha(z)),ensure_ascii=False))
