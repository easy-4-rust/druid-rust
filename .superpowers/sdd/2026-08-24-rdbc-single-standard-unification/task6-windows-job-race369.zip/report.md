# 原0.1秒测试私有Job成员诊断

仅在本次native helper即将清理自己Job的调用点执行QueryInformationJobObject；保持原实际Term调用，不增加超时、不重启全仓、不遍历或结束外部进程。原测试结果与Job成员记录见summary。查询只是本次进程所有权诊断，不作为数据库或完整suite验收。
