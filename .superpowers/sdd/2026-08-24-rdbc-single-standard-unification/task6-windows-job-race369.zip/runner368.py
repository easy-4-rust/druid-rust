from pathlib import Path
from unittest.mock import patch
import ctypes,hashlib,importlib.util,io,json,sys,time,types,unittest,zipfile,shutil
sys.dont_write_bytecode=True
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d177');e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust');d=b/'task6-windows-job-race368';d.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
frozen_path=b/'task7-final-candidate-workspace319/frozen-inputs.json';frozen=json.loads(frozen_path.read_text());assert len(frozen)==1277 and all(sha(w/p)==h for p,h in frozen.items())
sys.path.insert(0,str(w/'scripts'));spec=importlib.util.spec_from_file_location('windows_bounded_process',b/'windows_bounded_process363.py');native=importlib.util.module_from_spec(spec);sys.modules[spec.name]=native;spec.loader.exec_module(native)
kernel=ctypes.WinDLL('kernel32',use_last_error=True);kernel.QueryInformationJobObject.argtypes=[ctypes.c_void_p,ctypes.c_int,ctypes.c_void_p,ctypes.c_ulong,ctypes.c_void_p];kernel.QueryInformationJobObject.restype=ctypes.c_int;kernel.GetProcessId.argtypes=[ctypes.c_void_p];kernel.GetProcessId.restype=ctypes.c_ulong
class JobPids(ctypes.Structure):
    _fields_=[('assigned',ctypes.c_ulong),('listed',ctypes.c_ulong),('pids',ctypes.c_size_t*64)]
records=[];roots={};started=time.monotonic()
assign=kernel.AssignProcessToJobObject;assign.argtypes=[ctypes.c_void_p,ctypes.c_void_p];assign.restype=ctypes.c_int
terminate=kernel.TerminateJobObject;terminate.argtypes=[ctypes.c_void_p,ctypes.c_uint];terminate.restype=ctypes.c_int
class Assign:
    def __call__(self,job,process):
        pid=kernel.GetProcessId(process);assert pid;roots[int(job)]=pid;return assign(job,process)
class Terminate:
    def __call__(self,job,code):
        query=JobPids();success=kernel.QueryInformationJobObject(job,3,ctypes.byref(query),ctypes.sizeof(query),None)
        assert success and query.listed<=64,(success,ctypes.get_last_error(),query.listed)
        pids=[int(query.pids[i]) for i in range(query.listed)];root=roots.get(int(job))
        records.append(dict(elapsed_seconds=time.monotonic()-started,root_pid=root,pids=pids,descendants=[pid for pid in pids if pid!=root],assigned=int(query.assigned)))
        return terminate(job,code)
proxy_assign=Assign();proxy_terminate=Terminate()
class KernelProxy:
    def __getattr__(self,name):return proxy_assign if name=='AssignProcessToJobObject' else proxy_terminate if name=='TerminateJobObject' else getattr(kernel,name)
verifier_source=(b/'task6-unit-coverage-fixture366/verify_wrapper_standard_impls.py').read_text(encoding='utf-8');verifier=types.ModuleType('verify_wrapper_standard_impls');verifier.__file__=str(w/'scripts/verify_wrapper_standard_impls.py');sys.modules[verifier.__name__]=verifier;exec(compile(verifier_source,verifier.__file__,'exec'),verifier.__dict__)
test_path=w/'scripts/test_verify_wrapper_standard_impls.py';test_source=(b/'task6-unit-coverage-fixture366/test_verify_wrapper_standard_impls.py').read_text(encoding='utf-8');tests=types.ModuleType('windows_job_race_tests368');tests.__file__=str(test_path);sys.modules[tests.__name__]=tests;exec(compile(test_source,str(test_path),'exec'),tests.__dict__)
output=io.StringIO()
with patch.object(native.ctypes,'WinDLL',return_value=KernelProxy()):result=unittest.TextTestRunner(stream=output,verbosity=2).run(unittest.TestSuite([tests.WrapperStandardVerifierTest('test_runner_is_offline_locked_bounded_and_kills_hanging_process_group')]))
(d/'original-deadline-test.log').write_text(output.getvalue(),encoding='utf-8')
assert records and all(sha(w/p)==h for p,h in frozen.items())
summary=dict(scope='READONLY_PRIVATE_JOB_MEMBERSHIP_AT_ORIGINAL_TIMEOUT',production_applied=False,original_timeout_seconds=.1,original_test_passed=result.wasSuccessful(),errors=[trace for _,trace in result.errors],failures=[trace for _,trace in result.failures],private_job_records=records,descendants_observed_before_cleanup=any(record['descendants'] for record in records),frozen_inputs_changed=0,cargo_started=False)
(d/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');(d/'report.md').write_text('# 原0.1秒测试私有Job成员诊断\n\n仅在本次native helper即将清理自己Job的调用点执行QueryInformationJobObject；保持原实际Term调用，不增加超时、不重启全仓、不遍历或结束外部进程。原测试结果与Job成员记录见summary。查询只是本次进程所有权诊断，不作为数据库或完整suite验收。\n',encoding='utf-8')
files={'runner368.py':Path(__file__),'native-helper.py':b/'windows_bounded_process363.py','draft-tests.py':b/'task6-unit-coverage-fixture366/test_verify_wrapper_standard_impls.py','summary.json':d/'summary.json','report.md':d/'report.md','original-deadline-test.log':d/'original-deadline-test.log','frozen319.json':frozen_path};entries={name:sha(path) for name,path in files.items()};z=b/'task6-windows-job-race369.zip';assert not z.exists()
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as archive:
    for name,path in files.items():archive.write(path,name)
    archive.writestr('manifest.json',json.dumps(entries,indent=2))
with zipfile.ZipFile(z) as archive:assert all(hashlib.sha256(archive.read(name)).hexdigest()==h for name,h in entries.items())
receipt=b/'task6-windows-job-race369.summary.json';receipt.write_text(json.dumps(dict(sha256=sha(z),verified_entries=len(entries),descendants_observed=summary['descendants_observed_before_cleanup'],original_test_passed=result.wasSuccessful(),production_applied=False),indent=2)+'\n',encoding='utf-8')
for item in (z,receipt):
    target=e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'/item.name;assert not target.exists();shutil.copyfile(item,target);assert sha(item)==sha(target)
note='2026-10-09 原0.1s测试私有Job诊断368/369：原测试PASS='+str(result.wasSuccessful())+'；清理点只读成员记录 '+json.dumps(records,ensure_ascii=False)+'。保持原私有Job Term、超时与断言，不探测/终止外部进程，无Cargo、未apply，1277冻结变化0，zip369 SHA '+sha(z)+'全部条目/E镜像核验。18顶层OPEN。'
for relative in ('.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md','docs/verification/rdbc-first/status.md','docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md'):
    with (e/relative).open('ab') as out:out.write(('\n\n'+note+'\n').encode('utf-8'))
print(json.dumps(dict(original_test_passed=result.wasSuccessful(),records=records,zip_sha256=sha(z)),ensure_ascii=False))
