# Windows执行器边界与归属失败验证

总输出恰好上限成功、多1字节拒绝；关闭两管道后仍执行0.1秒deadline；退出码259识别为终态；环境、Unicode和包含引号/反引号的字面参数原样传递。三次创建失败句柄计数不增。真实挂起子进程处注入AssignProcessToJobObject失败，确认用户代码未执行、该新建进程已终止、句柄计数不增。

原测试python3解析到WindowsApps别名，os.kill(pid,0)不适用于Windows只读存活查询。此验证使用同步/查询句柄及WaitForSingleObject，不调用TerminateProcess探测存活。原suite未通过，不以这些补充场景替代其验收。候选输入1277不变，无Cargo，补丁未apply。

Python官方依据：https://docs.python.org/3/library/os.html#os.kill
