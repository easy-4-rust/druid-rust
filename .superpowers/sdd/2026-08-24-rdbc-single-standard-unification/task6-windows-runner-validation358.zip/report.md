# Windows有界进程执行器草稿

私有Job在挂起子进程运行前接管归属，正常、非零、超时、输出超限及父进程结束后的后代清理均实测。stdout/stderr读取使用有界队列，保持原总输出限制与deadline；仅清理本次Job及新建句柄，保留POSIX实现。

原未改动bounded-runner测试：False；错误完整保留。补丁未apply，1277输入不变，无Cargo/LLVM认证。

官方依据：https://learn.microsoft.com/en-us/windows/win32/procthread/job-objects
