from pathlib import Path
import ctypes,difflib,hashlib,importlib.util,io,json,os,shutil,sys,time,types,unittest,zipfile
sys.dont_write_bytecode=True
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d177');e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust');d=b/'task6-windows-runner-validation357';d.mkdir(exist_ok=True);assert not (d/'summary.json').exists();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
frozen_path=b/'task7-final-candidate-workspace319/frozen-inputs.json';frozen=json.loads(frozen_path.read_text());assert len(frozen)==1277 and all(sha(w/p)==h for p,h in frozen.items())
module_path=b/'windows_bounded_process356.py';spec=importlib.util.spec_from_file_location('windows_bounded_process',module_path);native=importlib.util.module_from_spec(spec);sys.modules[spec.name]=native;spec.loader.exec_module(native)
kernel=ctypes.WinDLL('kernel32',use_last_error=True);kernel.OpenProcess.argtypes=[ctypes.c_ulong,ctypes.c_int,ctypes.c_ulong];kernel.OpenProcess.restype=ctypes.c_void_p;kernel.GetExitCodeProcess.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_ulong)];kernel.CloseHandle.argtypes=[ctypes.c_void_p]
def alive(pid):
    handle=kernel.OpenProcess(0x1000,False,pid)
    if not handle:return False
    try:
        code=ctypes.c_ulong();assert kernel.GetExitCodeProcess(handle,ctypes.byref(code));return code.value==259
    finally:kernel.CloseHandle(handle)
checks=[]
def execute(name,source,limit=4096,timeout=5,expected_error=None,expected_code=0,pid_file=None):
    started=time.monotonic()
    try:
        code,out,err=native.run_windows_bounded_process([sys.executable,'-c',source],cwd=d,timeout_seconds=timeout,output_limit=limit)
        assert expected_error is None and code==expected_code,(name,code,out,err)
        result=dict(name=name,outcome='PASS',exit_code=code,stdout=out,stderr=err)
    except RuntimeError as error:
        assert expected_error is not None and expected_error in str(error),(name,str(error))
        result=dict(name=name,outcome='EXPECTED_REJECTION',error=str(error))
    if pid_file is not None:
        assert pid_file.is_file(),name
        pid=int(pid_file.read_text());assert not alive(pid),(name,'descendant still live',pid)
        result.update(descendant_pid=pid,descendant_terminated=True)
    result['elapsed_seconds']=time.monotonic()-started;checks.append(result)
execute('stdout-stderr-exact',"import sys;print('out');print('err',file=sys.stderr)")
assert checks[-1]['stdout']=='out\r\n' and checks[-1]['stderr']=='err\r\n'
execute('nonzero-retained',"import sys;print('nonzero');sys.exit(7)",expected_code=7)
execute('timeout-owned-child',"import subprocess,sys,time;child=subprocess.Popen([sys.executable,'-c','import time;time.sleep(30)']);open('timeout-child.pid','w').write(str(child.pid));time.sleep(30)",timeout=1,expected_error='timed out',pid_file=d/'timeout-child.pid')
execute('output-overflow-owned-child',"import subprocess,sys;child=subprocess.Popen([sys.executable,'-c','import time;time.sleep(30)']);open('overflow-child.pid','w').write(str(child.pid));print('x'*100000,flush=True)",limit=1024,expected_error='output limit',pid_file=d/'overflow-child.pid')
execute('successful-parent-detached-child',"import subprocess,sys;child=subprocess.Popen([sys.executable,'-c','import time;time.sleep(30)'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);open('detached-child.pid','w').write(str(child.pid));print('finished')",pid_file=d/'detached-child.pid')
execute('successful-parent-inherited-pipes-child',"import subprocess,sys;child=subprocess.Popen([sys.executable,'-c','import time;time.sleep(30)']);open('inherited-child.pid','w').write(str(child.pid));print('root-finished')",pid_file=d/'inherited-child.pid')
execute('binary-output-replacement',"import os;os.write(1,b'\\xff')");assert checks[-1]['stdout']=='\ufffd'
for name,timeout,limit in [('zero-timeout',0,1),('zero-output',1,0)]:
    try:native.run_windows_bounded_process([sys.executable,'-c','pass'],cwd=d,timeout_seconds=timeout,output_limit=limit)
    except ValueError:checks.append(dict(name=name,outcome='EXPECTED_REJECTION'))
    else:raise AssertionError(name)
# 将修复作为未应用的独立Windows分支，保持POSIX实现及调用者接口原样。
sys.path.insert(0,str(w/'scripts'))
verifier_original=(w/'scripts/verify_wrapper_standard_impls.py').read_text(encoding='utf-8');verifier_base=(b/'task6-sqlx-gate-regression354/verify_wrapper_standard_impls.py').read_text(encoding='utf-8')
needle='''    if timeout_seconds <= 0 or output_limit <= 0:
        fail("bounded process requires positive timeout and output limit")
    process = subprocess.Popen(
'''
assert verifier_base.count(needle)==1
replacement='''    if timeout_seconds <= 0 or output_limit <= 0:
        fail("bounded process requires positive timeout and output limit")
    if os.name == "nt":
        from windows_bounded_process import run_windows_bounded_process
        try:
            return BoundedProcessResult(*run_windows_bounded_process(
                command, cwd=cwd, timeout_seconds=timeout_seconds,
                output_limit=output_limit, env=env,
            ))
        except (OSError, RuntimeError, ValueError) as error:
            fail(str(error))
    process = subprocess.Popen(
'''
verifier_draft=verifier_base.replace(needle,replacement)
draft=types.ModuleType('verify_wrapper_standard_impls');draft.__file__=str(w/'scripts/verify_wrapper_standard_impls.py');sys.modules[draft.__name__]=draft;exec(compile(verifier_draft,draft.__file__,'exec'),draft.__dict__)
test_path=w/'scripts/test_verify_wrapper_standard_impls.py';test_source=test_path.read_text(encoding='utf-8');test_module=types.ModuleType('original_windows_bounded_test357');test_module.__file__=str(test_path);sys.modules[test_module.__name__]=test_module;exec(compile(test_source,str(test_path),'exec'),test_module.__dict__)
output=io.StringIO();result=unittest.TextTestRunner(stream=output,verbosity=2).run(unittest.TestSuite([test_module.WrapperStandardVerifierTest('test_runner_is_offline_locked_bounded_and_kills_hanging_process_group')]))
(d/'original-bounded-runner-test.log').write_text(output.getvalue(),encoding='utf-8')
assert all(sha(w/p)==h for p,h in frozen.items())
summary=dict(scope='UNAPPLIED_WINDOWS_BOUNDED_PROCESS_NATIVE_JOB_VALIDATION',production_applied=False,checks=checks,original_test_run=result.testsRun,original_test_passed=result.wasSuccessful(),original_test_failures=[trace for _,trace in result.failures],original_test_errors=[trace for _,trace in result.errors],private_job_only=True,assign_before_resume=True,owned_descendant_cases=4,cargo_started=False,frozen_inputs_changed=0)
(d/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(d/'verify_wrapper_standard_impls.py').write_text(verifier_draft,encoding='utf-8',newline='\n');shutil.copyfile(module_path,d/'windows_bounded_process.py')
diff=''.join(difflib.unified_diff(verifier_original.splitlines(True),verifier_draft.splitlines(True),fromfile='a/scripts/verify_wrapper_standard_impls.py',tofile='b/scripts/verify_wrapper_standard_impls.py'));diff+=''.join(difflib.unified_diff([],module_path.read_text(encoding='utf-8').splitlines(True),fromfile='/dev/null',tofile='b/scripts/windows_bounded_process.py'));(d/'windows-runner.patch').write_text(diff,encoding='utf-8',newline='\n')
(d/'report.md').write_text('# Windows有界进程执行器草稿\n\n私有Job在挂起子进程运行前接管归属，正常、非零、超时、输出超限及父进程结束后的后代清理均实测。stdout/stderr读取使用有界队列，保持原总输出限制与deadline；仅清理本次Job及新建句柄，保留POSIX实现。\n\n原未改动bounded-runner测试：'+str(result.wasSuccessful())+'；错误完整保留。补丁未apply，1277输入不变，无Cargo/LLVM认证。\n\n官方依据：https://learn.microsoft.com/en-us/windows/win32/procthread/job-objects\n',encoding='utf-8')
files={p.name:p for p in d.iterdir() if p.is_file()};files.update({'runner357.py':Path(__file__),'original-verifier.py':w/'scripts/verify_wrapper_standard_impls.py','original-tests.py':test_path,'frozen319.json':frozen_path});entries={name:sha(path) for name,path in files.items()};z=b/'task6-windows-runner-validation358.zip';assert not z.exists()
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as archive:
    for name,path in files.items():archive.write(path,name)
    archive.writestr('manifest.json',json.dumps(entries,indent=2))
with zipfile.ZipFile(z) as archive:assert all(hashlib.sha256(archive.read(name)).hexdigest()==h for name,h in entries.items())
receipt=b/'task6-windows-runner-validation358.summary.json';receipt.write_text(json.dumps(dict(sha256=sha(z),verified_entries=len(entries),native_checks=len(checks),original_test_passed=result.wasSuccessful(),production_applied=False),indent=2)+'\n',encoding='utf-8')
for item in (z,receipt):
    target=e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'/item.name;assert not target.exists();shutil.copyfile(item,target);assert sha(item)==sha(target)
note='2026-10-09 Windows有界执行器草稿356/357/358：原WinError10038后新增Windows私有Job分支，挂起创建->先归属->恢复，9项原生实测通过（4项后代清理），总输出/deadline保留；原未改动bounded-runner测试 '+str(result.wasSuccessful())+'，全部错误日志保留，POSIX实现未改。无Cargo/LLVM/产品runtime认证、未apply，1277冻结变化0，zip358 SHA '+sha(z)+'全部条目/E镜像核验。18顶层OPEN。'
for relative in ('.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md','docs/verification/rdbc-first/status.md','docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md'):
    with (e/relative).open('ab') as out:out.write(('\n\n'+note+'\n').encode('utf-8'))
print(json.dumps(dict(native_checks=len(checks),original_test_passed=result.wasSuccessful(),original_errors=summary['original_test_errors'],original_failures=summary['original_test_failures'],zip_sha256=sha(z)),ensure_ascii=False))
