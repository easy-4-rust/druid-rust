#!/usr/bin/env python3
"""Verify exact function-level parity for tests deleted by P04 Task 6.

The BASE source is the denominator.  A file-level replacement claim is never
accepted: every BASE ``#[test]`` or ``#[tokio::test]`` function must have one
checked disposition and one executable canonical target (unless the BASE body
is proven to be removed-identity-only).
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import io
import re
import subprocess
import sys
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, NoReturn


TASK6_BASE = "5afe8609b177544ff7d18461aa84f69efe8ee90e"
TASK6_REVIEW_BASE = "6e2b108ca67bc79166eeae856381ba5aba3da6de"
EXPECTED_DELETED_FILES = 67
EXPECTED_BASE_TESTS = 1_283
DEFAULT_LEDGER = Path("docs/verification/rdbc-first/task6-deleted-test-migration.tsv")
DEFAULT_METHOD_CALL_INDEX = Path(
    "docs/verification/rdbc-first/task6-deleted-test-method-call-index.tsv"
)
TEST_ROOTS = ("crates/druid/tests/", "crates/druid-wrapper/tests/")
LIB_TEST_TARGETS = {
    "crates/druid/src/pool/druid_pool/lifetime_tests.rs": {
        "task6_pool_deep_branch_coverage_test_borrow_skips_lifetime_expired_idle": "pool::druid_pool::lifetime_tests::task6_pool_deep_branch_coverage_test_borrow_skips_lifetime_expired_idle",
    },
    "crates/druid/src/core/connection_defaults/complete_state_tests.rs": {
        "task6_connection_defaults_capture_compare_and_reset_complete_state": "core::connection_defaults::complete_state_tests::task6_connection_defaults_capture_compare_and_reset_complete_state",
    },
    "crates/druid-wrapper/src/sqlx/external_pool_connection_control/lease_complete_tests.rs": {
        "task6_lease_delegates_complete_spi": "sqlx::external_pool_connection_control::lease_complete_tests::task6_lease_delegates_complete_spi",
    },
    "crates/druid/src/core/druid_pooled_connection/result_set_error_lease_tests.rs": {
        "task6_result_set_errors_typed_getters_and_old_lease_are_observable": "core::druid_pooled_connection::result_set_error_lease_tests::task6_result_set_errors_typed_getters_and_old_lease_are_observable",
    },
    "crates/druid/src/core/result_set_meta_data_proxy.rs": {
        "result_set_meta_data_proxy_attributes": (
            "core::result_set_meta_data_proxy::tests::"
            "result_set_meta_data_proxy_attributes"
        ),
        "result_set_meta_data_proxy_put_and_clear": (
            "core::result_set_meta_data_proxy::tests::"
            "result_set_meta_data_proxy_put_and_clear"
        )
    },
    "crates/druid/src/core/result_set_meta_data_proxy/metadata_identity_tests.rs": {
        "task6_metadata_preserves_getter_error_and_wrapper_identity": (
            "core::result_set_meta_data_proxy::metadata_identity_tests::"
            "task6_metadata_preserves_getter_error_and_wrapper_identity"
        )
    },
    "crates/druid/src/core/druid_pooled_result_set/diagnostic_tests.rs": {
        name: f"core::druid_pooled_result_set::diagnostic_tests::{name}"
        for name in (
            "task6_close_count_zero_before_close",
            "task6_cursor_index_starts_at_zero",
            "task6_fetch_row_count_increments_with_next",
            "task6_construct_elapsed_returns_duration",
            "task6_result_set_id_is_nonzero",
            "task6_result_set_attributes_empty_initially",
            "task6_raw_result_set_returns_standard_driver_cursor",
            "task6_hidden_columns_none_by_default",
            "task6_physical_column_identity_without_map",
            "task6_set_logic_column_map_and_reverse",
            "task6_meta_data_proxy_returns_proxy_with_attributes",
            "task6_read_string_length_increments_on_string_get",
            "task6_sql_returns_some",
            "task6_stream_reader_counts_zero_initially",
            "task6_all_scalar_and_stream_update_overloads_preserve_raw_spi_argument_identity",
            "task6_all_strong_getter_overloads_preserve_raw_spi_argument_identity",
            "task6_sqlite_typed_get_object_converts_all_standard_scalar_targets",
            "task6_labeled_result_set_preserves_all_scalar_and_stream_overloads",
            "task6_map_get_object_overloads_preserve_index_label_and_nullable_map_identity",
            "task6_typed_get_object_overloads_preserve_raw_target_type_identity",
            "task6_strong_typed_getter_conversion_errors_follow_statement_check_exception_path",
            "task6_pooled_result_set_routes_lob_stream_updates_and_preserves_sqlite_capability_errors",
            "task6_result_set_scalar_update_filter_defaults_delegate_all_java_overloads",
            "task6_pooled_result_set_classifies_every_sparse_capability_at_the_java_call_site",
            "task6_pooled_scalar_getters_delegate_exact_overloads_and_classify_errors",
            "task6_rdbc_object_and_opaque_object_preserve_type_identity_and_display_contract",
            "task6_sql_warning_and_result_set_metadata_preserve_structured_fields",
            "task6_sqlite_rejects_every_scalar_and_stream_update_without_corrupting_cursor",
            "task6_sqlite_result_set_preserves_values_cursor_peak_and_wrapper_identity",
            "task6_statement_close_closes_traced_result_set_and_records_fetched_peak",
            "task6_strong_typed_getters_preserve_all_decimal_temporal_and_calendar_overloads",
            "task6_pooled_result_set_preserves_decimal_temporal_and_calendar_filter_overloads",
            "task6_pooled_result_set_preserves_distinct_n_string_filter_overloads",
            "task6_pooled_result_set_routes_all_object_overloads_and_preserves_argument_identity",
            "task6_pooled_result_set_routes_all_scalar_getters_through_java_filter_overloads",
            "task6_pooled_result_set_routes_dynamic_statement_identity_through_filter",
            "task6_pooled_result_set_routes_metadata_platform_handle_through_filter",
            "task6_pooled_result_set_routes_n_string_updates_and_preserves_sqlite_capability_errors",
            "task6_pooled_result_set_routes_navigation_properties_and_real_sqlite_state",
            "task6_pooled_result_set_routes_object_updates_and_preserves_sqlite_capability_errors",
            "task6_pooled_result_set_routes_resource_getters_and_real_sqlite_streams",
            "task6_pooled_result_set_routes_resource_updates_and_preserves_sqlite_capability_errors",
            "task6_pooled_result_set_routes_row_mutations_and_preserves_sqlite_capability_errors",
            "task6_pooled_result_set_routes_scalar_updates_and_preserves_sqlite_capability_errors",
            "task6_pooled_result_set_routes_stream_updates_and_preserves_sqlite_capability_errors",
            "task6_real_sqlite_result_sets_flow_through_stat_filter_and_statement_cascade",
            "task6_result_set_filter_chain_preserves_java_order_short_circuit_and_error_unwind",
            "task6_result_set_filter_defaults_delegate_and_context_defaults_are_observable",
            "task6_result_set_lob_stream_update_filter_defaults_preserve_all_twelve_overloads",
            "task6_result_set_navigation_filter_defaults_delegate_every_physical_method",
            "task6_result_set_resource_filter_defaults_preserve_all_physical_overload_identities",
            "task6_result_set_resource_update_filter_defaults_preserve_all_fourteen_overloads",
            "task6_result_set_row_mutation_filter_defaults_delegate_every_physical_method",
            "task6_result_set_stream_update_filter_defaults_preserve_all_twenty_two_overloads",
            "task6_stat_filter_commits_close_statistics_before_downstream_close_error",
        )
    },
}
LEDGER_HEADER = (
    "base_source_path",
    "base_function",
    "base_identity",
    "base_body_sha256",
    "behavioral_theme",
    "key_assertions",
    "key_calls",
    "disposition",
    "target_source_path",
    "target_function",
    "case_id",
)
METHOD_CALL_INDEX_HEADER = (
    "base_identity",
    "method_call",
    "base_call_count",
    "replacement_selector",
    "disposition",
    "behavioral_theme",
)
EXACT = "MIGRATED_EXACT"
PARAMETERIZED_PREFIX = "MERGED_PARAMETERIZED("
PURE_IDENTITY = "PURE_IDENTITY"
APPROVED_REMOVAL = "APPROVED_REMOVAL"
FORBIDDEN_TARGET_IDENTITY = re.compile(
    r"\bPhysical[A-Z][A-Za-z0-9_]*\b|\bdruid_rdbc\s*::\s*(?:r#)?spi\b|"
    r"\bSqlText(?:Prepared)?Statement\b|\bRowSetResultSet\b"
)
ZERO_TEST_IDENTITY_FILE = "crates/druid-wrapper/tests/common/mod.rs"
ZERO_TEST_BEHAVIOR_FILE = (
    "crates/druid-wrapper/tests/common/physical_connection_contract.rs"
)
ZERO_TEST_BEHAVIOR_HANDOFFS = (
    (
        "crates/druid-wrapper/tests/sqlx_bb8_pool_test.rs",
        "bb8_pool_executes_and_recycles_one_canonical_lease",
    ),
    (
        "crates/druid-wrapper/tests/sqlx_bb8_pool_test.rs",
        "bb8_transactional_close_resets_and_dirty_drop_discards",
    ),
    (
        "crates/druid-wrapper/tests/sqlx_bb8_pool_test.rs",
        "bb8_fatal_disposition_poison_rejects_transaction_dirty_connection",
    ),
    (
        "crates/druid-wrapper/tests/sqlx_bb8_pool_test.rs",
        "bb8_recycle_error_poison_rejects_transaction_dirty_connection",
    ),
    (
        "crates/druid-wrapper/tests/sqlx_deadpool_pool_test.rs",
        "deadpool_executes_recycles_and_resets_one_canonical_lease",
    ),
    (
        "crates/druid-wrapper/tests/sqlx_deadpool_pool_test.rs",
        "deadpool_dirty_transaction_drop_is_discarded",
    ),
    (
        "crates/druid-wrapper/tests/sqlx_deadpool_pool_test.rs",
        "deadpool_fatal_disposition_poison_rejects_transaction_dirty_connection",
    ),
    (
        "crates/druid-wrapper/tests/sqlx_deadpool_pool_test.rs",
        "deadpool_recycle_error_poison_rejects_transaction_dirty_connection",
    ),
)
TEST_ATTRIBUTE = re.compile(r"#\[\s*(?:tokio\s*::\s*)?test(?:\s*\([^]]*\))?\s*\]")
FUNCTION_AFTER_ATTRIBUTES = re.compile(
    r"(?:^[ \t]*#\[[^\n]*\][ \t]*\n)+"
    r"^[ \t]*(?:pub(?:\([^)]*\))?\s+)?(?:async\s+)?"
    r"fn\s+([A-Za-z_][A-Za-z0-9_]*)\b",
    re.MULTILINE,
)
ASSERTION_MACROS = {
    "assert",
    "assert_eq",
    "assert_ne",
    "debug_assert",
    "debug_assert_eq",
    "debug_assert_ne",
    "matches",
    "assert_impl_all",
    "assert_not_impl_any",
    "assert_type_eq_all",
    "assert_obj_safe",
}
IDENTITY_ONLY_MACROS = {
    "assert_impl_all",
    "assert_not_impl_any",
    "assert_type_eq_all",
    "assert_obj_safe",
}
CALL_STOP_WORDS = {
    "as",
    "async",
    "await",
    "else",
    "fn",
    "for",
    "if",
    "impl",
    "let",
    "loop",
    "match",
    "move",
    "return",
    "trait",
    "unsafe",
    "where",
    "while",
}


class VerificationError(RuntimeError):
    """Raised when deleted-test parity is missing, duplicated, or forgeable."""


def fail(message: str) -> NoReturn:
    """Raise one stable fail-closed diagnostic."""

    raise VerificationError(message)


@dataclass(frozen=True, order=True)
class BaseTest:
    """One exact test function parsed from the pinned BASE source."""

    source_path: str
    function: str
    body: str
    body_sha256: str
    behavioral_theme: str
    key_assertions: str
    key_calls: str

    @property
    def identity(self) -> str:
        """Return the path-qualified source identity."""

        return f"{self.source_path}#{self.function}"


@dataclass(frozen=True)
class LedgerRow:
    """One checked disposition for one BASE test function."""

    base_source_path: str
    base_function: str
    base_identity: str
    base_body_sha256: str
    behavioral_theme: str
    key_assertions: str
    key_calls: str
    disposition: str
    target_source_path: str
    target_function: str
    case_id: str


@dataclass(frozen=True)
class CurrentTest:
    """One current executable test and the canonical source body it compiles."""

    source_path: str
    function: str
    body: str
    observation_body: str
    helper_bodies: tuple[tuple[str, str], ...] = ()

    @property
    def identity(self) -> str:
        """Return the path-qualified target identity."""

        return f"{self.source_path}#{self.function}"


def repository_root() -> Path:
    """Resolve the repository root independently of the caller's CWD."""

    return Path(__file__).resolve().parent.parent


def run_git(root: Path, arguments: list[str]) -> str:
    """Run one read-only Git query against the pinned baseline."""

    result = subprocess.run(
        ["git", *arguments],
        cwd=root,
        check=False,
        capture_output=True,
        text=True,
        encoding="utf-8",
    )
    if result.returncode != 0:
        detail = (result.stderr or result.stdout).strip()
        fail(f"git {' '.join(arguments)} failed: {detail or result.returncode}")
    return result.stdout


def mask_non_code(source: str) -> str:
    """Blank Rust comments and literals while retaining byte offsets and braces."""

    masked = list(source)
    index = 0
    length = len(source)

    def blank(start: int, end: int) -> None:
        for offset in range(start, end):
            if masked[offset] != "\n":
                masked[offset] = " "

    while index < length:
        if source.startswith("//", index):
            end = source.find("\n", index + 2)
            end = length if end == -1 else end
            blank(index, end)
            index = end
            continue
        if source.startswith("/*", index):
            start = index
            depth = 1
            index += 2
            while index < length and depth:
                if source.startswith("/*", index):
                    depth += 1
                    index += 2
                elif source.startswith("*/", index):
                    depth -= 1
                    index += 2
                else:
                    index += 1
            if depth:
                fail("unterminated Rust block comment")
            blank(start, index)
            continue

        raw_match = re.match(r"(?:br|r)(?P<hashes>#{0,255})\"", source[index:])
        if raw_match:
            start = index
            hashes = raw_match.group("hashes")
            index += raw_match.end()
            terminator = '"' + hashes
            end = source.find(terminator, index)
            if end == -1:
                fail("unterminated Rust raw string")
            index = end + len(terminator)
            blank(start, index)
            continue

        prefix = 2 if source.startswith('b"', index) else 1
        if source[index] == '"' or prefix == 2:
            start = index
            index += prefix
            escaped = False
            while index < length:
                character = source[index]
                index += 1
                if escaped:
                    escaped = False
                elif character == "\\":
                    escaped = True
                elif character == '"':
                    break
            else:
                fail("unterminated Rust string")
            blank(start, index)
            continue

        # A quote followed by an identifier and no closing quote is a lifetime.
        if source[index] == "'":
            lifetime = re.match(r"'[A-Za-z_][A-Za-z0-9_]*", source[index:])
            if lifetime and (
                index + lifetime.end() >= length
                or source[index + lifetime.end()] != "'"
            ):
                index += lifetime.end()
                continue
            start = index
            index += 1
            escaped = False
            while index < length:
                character = source[index]
                index += 1
                if escaped:
                    escaped = False
                elif character == "\\":
                    escaped = True
                elif character == "'":
                    break
            else:
                fail("unterminated Rust character literal")
            blank(start, index)
            continue
        index += 1
    return "".join(masked)


def matching_brace(masked: str, opening: int) -> int:
    """Find the closing brace paired with one function-body opening brace."""

    if opening < 0 or masked[opening] != "{":
        fail("test function body opening brace is missing")
    depth = 0
    for index in range(opening, len(masked)):
        if masked[index] == "{":
            depth += 1
        elif masked[index] == "}":
            depth -= 1
            if depth == 0:
                return index
    fail("unterminated test function body")


def counted_names(names: Iterable[str]) -> str:
    """Render sorted identifier counts as a deterministic semicolon list."""

    counts = Counter(names)
    return ";".join(f"{name}:{counts[name]}" for name in sorted(counts)) or "-"


def parse_counted_names(value: str) -> Counter[str]:
    """Parse one verifier-derived identifier count field."""

    if value == "-":
        return Counter()
    counts: Counter[str] = Counter()
    for item in value.split(";"):
        name, separator, count = item.rpartition(":")
        if not separator or not name or not count.isdigit() or int(count) <= 0:
            fail(f"malformed BASE observation count: {value}")
        counts[name] += int(count)
    return counts


def observations(body: str) -> tuple[str, str]:
    """Derive key assertion macro and call names from one exact BASE body."""

    code = mask_non_code(body)
    assertions = re.findall(r"\b([A-Za-z_][A-Za-z0-9_]*)\s*!\s*\(", code)
    assertion_names = [name for name in assertions if name in ASSERTION_MACROS]
    calls: list[str] = []
    for match in re.finditer(r"\b([A-Za-z_][A-Za-z0-9_]*)\s*\(", code):
        name = match.group(1)
        suffix = code[match.end(1) : match.end()]
        if "!" in suffix or name in CALL_STOP_WORDS or name in ASSERTION_MACROS:
            continue
        calls.append(name)
    return counted_names(assertion_names), counted_names(calls)


def derive_theme(source_path: str, function: str) -> str:
    """Classify a BASE case by stable path/name behavior vocabulary."""

    haystack = f"{source_path} {function}".lower()
    themes = (
        (
            "prepared_input_parameter",
            ("prepared_input_parameter", "parameter_differential"),
        ),
        ("metadata", ("metadata", "meta_data")),
        ("callable", ("callable", "out_parameter")),
        ("result_set", ("result_set", "resultset")),
        ("batch", ("batch",)),
        ("transaction_recycle", ("transaction", "rollback", "recycle", "lease")),
        ("pool_lifecycle", ("pool", "holder", "maintenance", "data_source")),
        ("filter_sorter_stat", ("filter", "sorter", "stat", "wall", "log")),
        ("driver_adapter", ("driver", "adapter", "sqlx", "toasty", "jdbc")),
        ("warning_error", ("warning", "error", "exception")),
        ("wrapper_identity", ("wrapper", "unwrap")),
        (
            "value_conversion",
            ("value", "type", "conversion", "scalar", "lob", "stream"),
        ),
    )
    matched = [
        theme for theme, words in themes if any(word in haystack for word in words)
    ]
    theme = "+".join(matched[:3]) if matched else "rdbc_behavior"
    if (
        function
        == "test_connection_default_prepared_batch_reuses_one_statement_in_order"
    ):
        theme += "+owned_prepared_actor_typed_migration"
    return theme


def parse_test_functions(source_path: str, source: str) -> tuple[BaseTest, ...]:
    """Parse every root-level attributed Rust test with its complete body."""

    masked = mask_non_code(source)
    tests: list[BaseTest] = []
    for match in FUNCTION_AFTER_ATTRIBUTES.finditer(masked):
        attributes = masked[match.start() : match.start(1)]
        if not TEST_ATTRIBUTE.search(attributes):
            continue
        opening = masked.find("{", match.end(1))
        if opening == -1:
            fail(f"test function has no body: {source_path}#{match.group(1)}")
        closing = matching_brace(masked, opening)
        body = source[opening : closing + 1]
        assertions, calls = observations(body)
        tests.append(
            BaseTest(
                source_path=source_path,
                function=match.group(1),
                body=body,
                body_sha256=hashlib.sha256(body.encode("utf-8")).hexdigest(),
                behavioral_theme=derive_theme(source_path, match.group(1)),
                key_assertions=assertions,
                key_calls=calls,
            )
        )
    identities = [test.identity for test in tests]
    duplicates = sorted(
        identity for identity, count in Counter(identities).items() if count > 1
    )
    if duplicates:
        fail(f"duplicate test functions in {source_path}: {duplicates}")
    return tuple(tests)


def deleted_test_paths(root: Path) -> tuple[str, ...]:
    """Freeze the exact 67 files deleted between BASE and the review baseline."""

    output = run_git(
        root,
        [
            "diff",
            "--diff-filter=D",
            "--name-only",
            f"{TASK6_BASE}..{TASK6_REVIEW_BASE}",
            "--",
            "crates/druid/tests/**",
            "crates/druid-wrapper/tests/**",
        ],
    )
    paths = tuple(sorted(line for line in output.splitlines() if line.endswith(".rs")))
    if len(paths) != EXPECTED_DELETED_FILES:
        fail(
            f"deleted BASE test-file denominator drift: expected {EXPECTED_DELETED_FILES}, "
            f"observed {len(paths)}"
        )
    return paths


def derive_base_tests(root: Path) -> tuple[BaseTest, ...]:
    """Derive the exact 1,283-function denominator from the pinned BASE commit."""

    tests: list[BaseTest] = []
    for source_path in deleted_test_paths(root):
        source = run_git(root, ["show", f"{TASK6_BASE}:{source_path}"])
        tests.extend(parse_test_functions(source_path, source))
    tests.sort(key=lambda test: (test.source_path, test.function))
    if len(tests) != EXPECTED_BASE_TESTS:
        fail(
            f"BASE test-function denominator drift: expected {EXPECTED_BASE_TESTS}, "
            f"observed {len(tests)}"
        )
    return tuple(tests)


def verify_zero_test_support(root: Path) -> tuple[CurrentTest, ...]:
    """Classify both deleted zero-test files and bind the behavioral helper."""

    zero_files: list[str] = []
    sources: dict[str, str] = {}
    for source_path in deleted_test_paths(root):
        source = run_git(root, ["show", f"{TASK6_BASE}:{source_path}"])
        if not parse_test_functions(source_path, source):
            zero_files.append(source_path)
            sources[source_path] = source
    expected = sorted((ZERO_TEST_IDENTITY_FILE, ZERO_TEST_BEHAVIOR_FILE))
    if sorted(zero_files) != expected:
        fail(f"zero-test deleted support denominator drift: {zero_files}")
    identity_assertions, identity_calls = observations(sources[ZERO_TEST_IDENTITY_FILE])
    if (identity_assertions, identity_calls) != ("-", "-"):
        fail("common/mod.rs is not a pure module-identity shell")
    support_assertions, support_calls = observations(sources[ZERO_TEST_BEHAVIOR_FILE])
    if support_assertions == "-" or support_calls == "-":
        fail("connection-contract support file was misclassified as pure identity")

    target_paths = [path for path, _ in ZERO_TEST_BEHAVIOR_HANDOFFS]
    parsed = current_tests(root, target_paths)
    targets: list[CurrentTest] = []
    for source_path, function in ZERO_TEST_BEHAVIOR_HANDOFFS:
        identity = f"{source_path}#{function}"
        target = parsed.get(identity)
        if target is None:
            fail(f"behavioral zero-test support handoff is missing: {identity}")
        forbidden = FORBIDDEN_TARGET_IDENTITY.search(target.body)
        if forbidden:
            fail(f"behavioral support handoff retains retired identity: {identity}")
        targets.append(target)
    target_assertion_count = target_call_count = 0
    for target in targets:
        assertions, calls = observations(target.body)
        target_assertion_count += sum(parse_counted_names(assertions).values())
        target_call_count += sum(parse_counted_names(calls).values())
    if target_assertion_count < sum(parse_counted_names(support_assertions).values()):
        fail("behavioral support handoff weakens assertion density")
    if target_call_count < sum(parse_counted_names(support_calls).values()):
        fail("behavioral support handoff weakens call density")
    return tuple(targets)


def parse_ledger(path: Path) -> tuple[LedgerRow, ...]:
    """Parse a canonical UTF-8 TSV ledger without silently normalizing bytes."""

    try:
        payload = path.read_bytes()
    except FileNotFoundError:
        fail(f"deleted-test function ledger is missing: {path}")
    if not payload.endswith(b"\n") or payload.endswith(b"\n\n") or b"\r" in payload:
        fail("deleted-test function ledger must have one LF final newline")
    try:
        text = payload.decode("utf-8")
    except UnicodeDecodeError as error:
        fail(f"deleted-test function ledger is not UTF-8: {error}")
    reader = csv.DictReader(io.StringIO(text), delimiter="\t")
    if tuple(reader.fieldnames or ()) != LEDGER_HEADER:
        fail(f"deleted-test function ledger header drift: {reader.fieldnames}")
    rows: list[LedgerRow] = []
    for line_number, record in enumerate(reader, start=2):
        if None in record or any(
            value is None or not value for value in record.values()
        ):
            fail(f"deleted-test ledger row {line_number} has empty or extra fields")
        rows.append(LedgerRow(**record))
    return tuple(rows)


def identity_only(test: BaseTest) -> bool:
    """Prove that a BASE body asserted only a removed type/path identity.

    This deliberately rejects mixed canonical capability, runtime TypeId/error,
    value, pool, or lifecycle assertions.  A reviewer may keep such a case, but
    cannot waive it as removed identity.
    """

    if not FORBIDDEN_TARGET_IDENTITY.search(test.body):
        return False
    assertions = {
        name
        for name in re.findall(
            r"\b([A-Za-z_][A-Za-z0-9_]*)\s*!\s*\(", mask_non_code(test.body)
        )
        if name in ASSERTION_MACROS
    }
    if not assertions or not assertions.issubset(IDENTITY_ONLY_MACROS):
        return False
    _, calls = observations(test.body)
    return calls == "-"


def current_tests(root: Path, source_paths: Iterable[str]) -> dict[str, CurrentTest]:
    """Parse every referenced current target and retain executable test bodies."""

    result: dict[str, CurrentTest] = {}
    for source_path in sorted(set(source_paths)):
        path = root / source_path
        if not path.is_file():
            fail(f"target test source does not exist: {source_path}")
        if not any(source_path.startswith(prefix) for prefix in TEST_ROOTS) and (
            source_path not in LIB_TEST_TARGETS
        ):
            fail(f"target test source is outside the owned test roots: {source_path}")
        source = expanded_target_source(root, path)
        helper_bodies = task6_helper_bodies(source_path, source)
        for test in parse_test_functions(source_path, source):
            observation_body = reachable_task6_body(test.function, helper_bodies)
            function = LIB_TEST_TARGETS.get(source_path, {}).get(
                test.function, test.function
            )
            current = CurrentTest(
                source_path,
                function,
                test.body,
                observation_body or test.body,
                tuple(sorted(helper_bodies.items())),
            )
            result[current.identity] = current
    return result


def task6_helper_bodies(source_path: str, source: str) -> dict[str, str]:
    """Parse uniquely named Task 6 helper functions for assertion-closure checks."""

    masked = mask_non_code(source)
    pattern = re.compile(r"\b(?:async\s+)?fn\s+(task6_[A-Za-z0-9_]+)\b")
    bodies: dict[str, str] = {}
    for match in pattern.finditer(masked):
        opening = masked.find("{", match.end())
        if opening == -1:
            fail(f"Task 6 helper has no body: {source_path}#{match.group(1)}")
        closing = matching_brace(masked, opening)
        name = match.group(1)
        if name in bodies:
            fail(f"duplicate Task 6 helper function: {source_path}#{name}")
        bodies[name] = source[opening : closing + 1]
    return bodies


def reachable_task6_body(function: str, bodies: dict[str, str]) -> str:
    """Return one test plus every uniquely reachable Task 6 helper body."""

    if function not in bodies:
        return ""
    visited: set[str] = set()
    ordered: list[str] = []

    def visit(name: str) -> None:
        if name in visited:
            return
        visited.add(name)
        body = bodies[name]
        ordered.append(body)
        code = mask_non_code(body)
        calls = {
            match.group(1)
            for match in re.finditer(r"\b(task6_[A-Za-z0-9_]+)\s*\(", code)
        }
        for called in sorted(calls):
            if called in bodies:
                visit(called)

    visit(function)
    return "\n".join(ordered)


def expanded_target_source(
    root: Path, path: Path, active: tuple[Path, ...] = ()
) -> str:
    """Expand literal local ``include!`` files into one checked target closure."""

    resolved = path.resolve()
    test_roots = tuple((root / prefix).resolve() for prefix in TEST_ROOTS)
    lib_test_files = {(root / source_path).resolve() for source_path in LIB_TEST_TARGETS}
    if not any(resolved.is_relative_to(test_root) for test_root in test_roots) and (
        resolved not in lib_test_files
    ):
        fail(f"included test source escapes owned test roots: {resolved}")
    if resolved in active:
        fail(f"included test source cycle: {resolved}")
    try:
        source = resolved.read_text(encoding="utf-8")
    except FileNotFoundError:
        fail(f"included test source does not exist: {resolved}")
    include_pattern = re.compile(r'include\s*!\s*\(\s*"([^"\n]+)"\s*\)\s*;')
    unsupported = re.search(r"\binclude\s*!\s*\(", mask_non_code(source))
    if unsupported and not include_pattern.search(source):
        fail(f"non-literal include! is forbidden in parity target: {resolved}")

    def expand(match: re.Match[str]) -> str:
        included = (resolved.parent / match.group(1)).resolve()
        return expanded_target_source(root, included, (*active, resolved))

    return include_pattern.sub(expand, source)


def disposition_case_id(row: LedgerRow) -> str | None:
    """Return and validate the case ID encoded by a parameterized disposition."""

    if not row.disposition.startswith(
        PARAMETERIZED_PREFIX
    ) or not row.disposition.endswith(")"):
        return None
    encoded = row.disposition[len(PARAMETERIZED_PREFIX) : -1]
    if (
        not encoded
        or encoded != row.case_id
        or not re.fullmatch(r"[A-Za-z0-9_.:/-]+", encoded)
    ):
        fail(
            f"invalid parameterized case id for {row.base_identity}: {row.disposition}"
        )
    return encoded


def parameterized_case_body(target: CurrentTest, case_id: str) -> str:
    """Return one explicit literal match arm plus its reachable Task 6 helpers."""

    pattern = re.compile(rf'"{re.escape(case_id)}"\s*=>\s*\{{')
    matches = list(pattern.finditer(target.body))
    if len(matches) != 1:
        fail(
            f"parameterized case requires one explicit case arm: "
            f"{target.identity}::{case_id}"
        )
    opening = matches[0].end() - 1
    masked = mask_non_code(target.body)
    closing = matching_brace(masked, opening)
    arm = target.body[opening : closing + 1]
    code = mask_non_code(arm)
    if re.search(
        r"\.is_err\s*\(\s*\)\s*\|\|\s*[A-Za-z_][A-Za-z0-9_]*\.is_ok\s*\(\s*\)|"
        r"\.is_ok\s*\(\s*\)\s*\|\|\s*[A-Za-z_][A-Za-z0-9_]*\.is_err\s*\(\s*\)",
        code,
    ):
        fail(f"parameterized case contains tautological result masking: {case_id}")

    helpers = dict(target.helper_bodies)
    visited: set[str] = set()
    ordered = [arm]

    def visit(body: str) -> None:
        calls = {
            match.group(1)
            for match in re.finditer(
                r"\b(task6_[A-Za-z0-9_]+)\s*\(", mask_non_code(body)
            )
        }
        for name in sorted(calls):
            if name in visited or name not in helpers:
                continue
            visited.add(name)
            helper = helpers[name]
            ordered.append(helper)
            visit(helper)

    visit(arm)
    return "\n".join(ordered)


def verify_parameterized_observation_floor(base: BaseTest, body: str) -> None:
    """Reject explicit cases that weaken BASE assertion kinds or execute no calls."""

    target_assertions, target_calls = observations(body)
    base_assertions = parse_counted_names(base.key_assertions)
    actual_assertions = parse_counted_names(target_assertions)
    for name, count in base_assertions.items():
        if actual_assertions[name] < count:
            fail(
                f"parameterized case weakens BASE assertion floor: {base.identity}: "
                f"{name} base={count} target={actual_assertions[name]}"
            )
    if target_calls == "-":
        fail(
            f"parameterized case has no executable call: {base.identity}"
        )


def verify_observation_floor(base: BaseTest, target: CurrentTest) -> None:
    """Reject name-only targets that drop BASE assertion/call density."""

    target_assertions, target_calls = observations(target.observation_body)
    base_assertion_counts = parse_counted_names(base.key_assertions)
    target_assertion_counts = parse_counted_names(target_assertions)
    base_call_counts = parse_counted_names(base.key_calls)
    target_call_counts = parse_counted_names(target_calls)
    if sum(target_assertion_counts.values()) < sum(base_assertion_counts.values()):
        fail(
            f"target weakens BASE assertion count: {base.identity}: "
            f"base={base.key_assertions} target={target_assertions}"
        )
    if sum(target_call_counts.values()) < sum(base_call_counts.values()):
        fail(
            f"target weakens BASE call count: {base.identity}: "
            f"base={base.key_calls} target={target_calls}"
        )


def verify_ledger(
    base_tests: tuple[BaseTest, ...], rows: tuple[LedgerRow, ...], root: Path
) -> tuple[LedgerRow, ...]:
    """Verify exact denominator metadata, dispositions, and current target bindings."""

    base_by_identity = {test.identity: test for test in base_tests}
    counts = Counter(row.base_identity for row in rows)
    duplicate = sorted(identity for identity, count in counts.items() if count != 1)
    if duplicate:
        fail(f"deleted-test ledger has duplicate BASE identities: {duplicate[:10]}")
    observed = set(counts)
    missing = sorted(set(base_by_identity).difference(observed))
    fabricated = sorted(observed.difference(base_by_identity))
    if missing or fabricated:
        fail(
            "deleted-test function denominator mismatch: "
            f"missing={missing[:10]} ({len(missing)}), "
            f"fabricated={fabricated[:10]} ({len(fabricated)})"
        )
    expected_order = sorted(
        rows, key=lambda row: (row.base_source_path, row.base_function)
    )
    if list(rows) != expected_order:
        fail("deleted-test ledger rows are not canonically sorted")

    target_paths: list[str] = []
    for row in rows:
        test = base_by_identity[row.base_identity]
        expected_fields = (
            test.source_path,
            test.function,
            test.identity,
            test.body_sha256,
            test.behavioral_theme,
            test.key_assertions,
            test.key_calls,
        )
        actual_fields = (
            row.base_source_path,
            row.base_function,
            row.base_identity,
            row.base_body_sha256,
            row.behavioral_theme,
            row.key_assertions,
            row.key_calls,
        )
        if actual_fields != expected_fields:
            fail(f"BASE-derived metadata drift for {row.base_identity}")

        parameterized = disposition_case_id(row)
        if row.disposition in {PURE_IDENTITY, APPROVED_REMOVAL}:
            if not identity_only(test):
                fail(
                    f"behavioral BASE test cannot be removed as identity: {row.base_identity}"
                )
            if (row.target_source_path, row.target_function, row.case_id) != (
                "-",
                "-",
                "-",
            ):
                fail(f"removed identity must not name a target: {row.base_identity}")
            continue
        if row.disposition != EXACT and parameterized is None:
            fail(
                f"unknown deleted-test disposition: {row.base_identity}: {row.disposition}"
            )
        if row.target_source_path == "-" or row.target_function == "-":
            fail(f"migrated BASE test has no target: {row.base_identity}")
        if row.disposition == EXACT and row.case_id != "-":
            fail(f"exact migration cannot declare a case id: {row.base_identity}")
        target_paths.append(row.target_source_path)

    parsed_targets = current_tests(root, target_paths)
    exact_targets: list[str] = []
    parameterized_targets: list[tuple[str, str]] = []
    for row in rows:
        if row.disposition in {PURE_IDENTITY, APPROVED_REMOVAL}:
            continue
        target_identity = f"{row.target_source_path}#{row.target_function}"
        target = parsed_targets.get(target_identity)
        if target is None:
            fail(f"target is not an executable attributed test: {target_identity}")
        forbidden = FORBIDDEN_TARGET_IDENTITY.search(target.observation_body)
        if forbidden:
            fail(
                f"target retains a retired identity: {target_identity}: {forbidden.group(0)}"
            )
        case_id = disposition_case_id(row)
        if case_id is None:
            verify_observation_floor(base_by_identity[row.base_identity], target)
            exact_targets.append(target_identity)
        else:
            case_body = parameterized_case_body(target, case_id)
            verify_parameterized_observation_floor(
                base_by_identity[row.base_identity], case_body
            )
            parameterized_targets.append((target_identity, case_id))

    exact_duplicates = sorted(
        identity for identity, count in Counter(exact_targets).items() if count != 1
    )
    if exact_duplicates:
        fail(
            f"exact targets are reused by multiple BASE tests: {exact_duplicates[:10]}"
        )
    parameter_duplicates = sorted(
        identity
        for identity, count in Counter(parameterized_targets).items()
        if count != 1
    )
    if parameter_duplicates:
        fail(
            f"parameterized target/case bindings are duplicated: {parameter_duplicates[:10]}"
        )
    return rows


def render_template(base_tests: tuple[BaseTest, ...]) -> str:
    """Render a deterministic intentionally-RED ledger template to stdout."""

    buffer = io.StringIO()
    writer = csv.writer(buffer, delimiter="\t", lineterminator="\n")
    writer.writerow(LEDGER_HEADER)
    for test in base_tests:
        writer.writerow(
            (
                test.source_path,
                test.function,
                test.identity,
                test.body_sha256,
                test.behavioral_theme,
                test.key_assertions,
                test.key_calls,
                "MISSING",
                "-",
                "-",
                "-",
            )
        )
    return buffer.getvalue()


def replacement_selector(row: LedgerRow) -> str:
    """Return the stable exact or parameterized replacement selector."""

    selector = f"{row.target_source_path}#{row.target_function}"
    case_id = disposition_case_id(row)
    return selector if case_id is None else f"{selector}::{case_id}"


def render_method_call_index(rows: tuple[LedgerRow, ...]) -> str:
    """Render the BASE-call to replacement-selector reverse index."""

    buffer = io.StringIO()
    writer = csv.writer(buffer, delimiter="\t", lineterminator="\n")
    writer.writerow(METHOD_CALL_INDEX_HEADER)
    for row in rows:
        if row.disposition in {PURE_IDENTITY, APPROVED_REMOVAL}:
            continue
        for method_call, count in sorted(parse_counted_names(row.key_calls).items()):
            writer.writerow(
                (
                    row.base_identity,
                    method_call,
                    count,
                    replacement_selector(row),
                    row.disposition,
                    row.behavioral_theme,
                )
            )
    return buffer.getvalue()


def verify_method_call_index(path: Path, rows: tuple[LedgerRow, ...]) -> None:
    """Reject a missing or stale BASE-call reverse index."""

    if not path.is_file():
        fail(f"method-call reverse index does not exist: {path}")
    expected = render_method_call_index(rows)
    actual = path.read_text(encoding="utf-8")
    if actual != expected:
        fail(f"method-call reverse index drift: {path}")


def target_package(source_path: str) -> tuple[str, str]:
    """Map one owned integration-test path to its Cargo package and target name."""

    for prefix, package in (
        ("crates/druid/tests/", "druid"),
        ("crates/druid-wrapper/tests/", "druid-wrapper"),
    ):
        if source_path.startswith(prefix):
            relative = source_path[len(prefix) :]
            if "/" in relative or not relative.endswith(".rs"):
                fail(
                    f"replacement test must be a root integration target: {source_path}"
                )
            return package, relative.removesuffix(".rs")
    if source_path in LIB_TEST_TARGETS:
        for prefix, package in (
            ("crates/druid/src/", "druid"),
            ("crates/druid-wrapper/src/", "druid-wrapper"),
        ):
            if source_path.startswith(prefix):
                return package, "__lib__"
    fail(f"unknown target test package: {source_path}")


def executed_functions(output: str) -> set[str]:
    """Parse libtest function identities that actually completed successfully."""

    return {
        match.group(1)
        for match in re.finditer(
            r"^test\s+([^\s]+)\s+\.\.\.\s+ok$", output, re.MULTILINE
        )
    }


def missing_target_functions(
    expected_by_target: dict[str, set[str]], output_by_target: dict[str, str]
) -> list[str]:
    """Return path-qualified functions not proven by their claimed target run."""

    missing: list[str] = []
    for target, expected in sorted(expected_by_target.items()):
        executed = executed_functions(output_by_target.get(target, ""))
        for function in sorted(expected):
            if not any(
                name == function or name.endswith(f"::{function}")
                for name in executed
            ):
                missing.append(f"{target}#{function}")
    return missing


def case_completion_digests(output: str) -> dict[str, str]:
    """Parse deterministic matrix completion digests emitted after equality checks."""

    digests: dict[str, str] = {}
    for match in re.finditer(
        r"^TASK6_CASE_DIGEST=([A-Za-z_][A-Za-z0-9_]*):(.*)$",
        output,
        re.MULTILINE,
    ):
        function, digest = match.groups()
        if function in digests:
            fail(f"duplicate parameterized completion digest: {function}")
        digests[function] = digest
    return digests


def missing_parameterized_case_digests(
    expected_by_function: dict[str, list[str]], output: str
) -> list[str]:
    """Return matrices whose runtime-completed exact case sequence is missing."""

    actual = case_completion_digests(output)
    return sorted(
        f"{function}::{case_id}"
        for function, case_ids in expected_by_function.items()
        if actual.get(function) != "|".join(case_ids)
        for case_id in case_ids
    )


def execute_targets(
    root: Path,
    rows: tuple[LedgerRow, ...],
    support_targets: tuple[CurrentTest, ...] = (),
) -> None:
    """Run exact replacement targets and prove every named function executed."""

    expected_by_target: dict[tuple[str, str], set[str]] = defaultdict(set)
    expected_cases_by_target: dict[
        tuple[str, str], dict[str, list[str]]
    ] = defaultdict(lambda: defaultdict(list))
    for row in rows:
        if row.disposition in {PURE_IDENTITY, APPROVED_REMOVAL}:
            continue
        package, target = target_package(row.target_source_path)
        expected_by_target[(package, target)].add(row.target_function)
        case_id = disposition_case_id(row)
        if case_id is not None:
            expected_cases_by_target[(package, target)][row.target_function].append(
                case_id
            )
    for target in support_targets:
        package, test_target = target_package(target.source_path)
        expected_by_target[(package, test_target)].add(target.function)

    # Run every integration target independently. This makes the runtime proof
    # path-qualified, so a same-named function in another target cannot satisfy
    # the ledger. Parameterized cases are uniquely source-bound above; runtime
    # proof is the containing matrix function completing successfully.
    for (package, target), expected in sorted(expected_by_target.items()):
        command = [
            "cargo",
            "test",
            "--offline",
            "--locked",
            "-p",
            package,
            "--all-features",
        ]
        if target == "__lib__":
            command.append("--lib")
        else:
            command.extend(["--test", target])
        # 展示成功测试的 stdout，同时保持精确 libtest 成功行完整，供函数与案例双重验收。
        command.extend(["--", "--show-output"])
        try:
            result = subprocess.run(
                command,
                cwd=root,
                check=False,
                capture_output=True,
                text=True,
                timeout=1_800,
            )
        except (OSError, subprocess.TimeoutExpired) as error:
            fail(f"replacement tests NOT_RUN/ERROR for {package}: {error}")
        output = result.stdout + "\n" + result.stderr
        if result.returncode != 0:
            fail(
                f"replacement tests failed for {package}/{target}: "
                f"{output[-20_000:]}"
            )
        missing = missing_target_functions(
            {target: expected},
            {target: output},
        )
        if missing:
            fail(
                f"replacement tests were not executed in their claimed target "
                f"for {package}: {missing[:20]}"
            )
        missing_cases = missing_parameterized_case_digests(
            expected_cases_by_target.get((package, target), {}),
            output,
        )
        if missing_cases:
            fail(
                f"parameterized cases were not completed by their claimed matrix "
                f"for {package}/{target}: {missing_cases[:20]}"
            )


def disposition_counts(rows: Iterable[LedgerRow]) -> Counter[str]:
    """Collapse parameterized case suffixes for the final stable summary."""

    counts: Counter[str] = Counter()
    for row in rows:
        key = (
            "MERGED_PARAMETERIZED"
            if row.disposition.startswith(PARAMETERIZED_PREFIX)
            else row.disposition
        )
        counts[key] += 1
    return counts


def main(argv: list[str] | None = None) -> int:
    """Run the exact BASE/ledger/current-source/execution gate."""

    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=repository_root())
    parser.add_argument("--ledger", type=Path, default=DEFAULT_LEDGER)
    parser.add_argument(
        "--method-call-index", type=Path, default=DEFAULT_METHOD_CALL_INDEX
    )
    parser.add_argument("--write-method-call-index", action="store_true")
    parser.add_argument("--render-template", action="store_true")
    parser.add_argument(
        "--write-template",
        type=Path,
        help="mechanically write an intentionally-RED BASE-derived ledger template",
    )
    parser.add_argument(
        "--no-execute",
        action="store_true",
        help="validate source/ledger bindings only; cannot prove completion",
    )
    arguments = parser.parse_args(argv)
    root = arguments.root.resolve()
    base_tests = derive_base_tests(root)
    if arguments.render_template or arguments.write_template:
        template = render_template(base_tests)
        if arguments.render_template:
            sys.stdout.write(template)
        if arguments.write_template:
            target = arguments.write_template
            if not target.is_absolute():
                target = root / target
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(template, encoding="utf-8")
        return 0
    ledger = arguments.ledger
    if not ledger.is_absolute():
        ledger = root / ledger
    rows = verify_ledger(base_tests, parse_ledger(ledger), root)
    method_call_index = arguments.method_call_index
    if not method_call_index.is_absolute():
        method_call_index = root / method_call_index
    if arguments.write_method_call_index:
        method_call_index.write_text(
            render_method_call_index(rows), encoding="utf-8"
        )
    else:
        verify_method_call_index(method_call_index, rows)
    support_targets = verify_zero_test_support(root)
    if not arguments.no_execute:
        execute_targets(root, rows, support_targets)
    counts = disposition_counts(rows)
    print(
        "PASS task6 deleted-test parity: "
        f"files={EXPECTED_DELETED_FILES} base_tests={len(base_tests)} "
        f"migrated_exact={counts[EXACT]} "
        f"parameterized={counts['MERGED_PARAMETERIZED']} "
        f"pure_identity={counts[PURE_IDENTITY]} "
        f"approved_removal={counts[APPROVED_REMOVAL]} "
        "zero_test_identity=1 zero_test_behavioral_handoff=1 "
        f"executed={'no' if arguments.no_execute else 'yes'}"
    )
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except VerificationError as error:
        print(f"FAIL: {error}", file=sys.stderr)
        raise SystemExit(1) from error
