from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,shutil,subprocess,zipfile
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d177');e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust');d=b/'task7-e-integration-current-snapshot323';d.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=b/'task7-final-candidate-workspace319/frozen-inputs.json';f=json.loads(manifest.read_text());assert len(f)==1277 and all(sha(w/p)==h for p,h in f.items())
prior=json.loads((b/'task7-e-integration-protection-snapshot236.json').read_text());prior_rows={r['path']:r for r in prior['files']}
review_dirs=('task7-integration-clean-resolution244','task7-integration-module-resolution261','task7-integration-additive-resolution263','task7-integration-lease-context-resolution265','task7-integration-result-object-resolution267','task7-integration-resource-resolution269','task7-integration-test-resolution271','task7-integration-final-four-resolution278','task7-integration-prepared-resolution321','task7-integration-adapter-refresh324')
reviews={}
for name in review_dirs:
 root=b/name/'resolved-review';assert root.exists(),name
 for p in root.rglob('*'):
  if p.is_file():reviews[str(p.relative_to(root)).replace('\\','/')]=dict(artifact=str(p),sha256=sha(p))
rows=[]
for rel,h in sorted(f.items()):
 if not (rel.startswith(('crates/','vendor/','scripts/')) or rel in {'Cargo.toml','Cargo.lock','rust-toolchain.toml'}):continue
 p=e/rel;old=prior_rows.get(rel);actual=sha(p) if p.exists() else None
 state='IDENTICAL' if actual==h else ('DIFFERENT' if actual is not None else 'MISSING_IN_E')
 review=reviews.get(rel);review_state='CURRENT_STATIC_REVIEW' if review and review['sha256']==h else ('STALE_STATIC_REVIEW' if review else 'NO_EXISTING_STATIC_REVIEW')
 rows.append(dict(path=rel,candidate_sha256=h,e_preimage_sha256=actual,state=state,prior236_e_preimage_sha256=old['e_sha256'] if old else None,e_changed_since236=old is not None and old['e_sha256']!=actual,candidate_changed_since236=old is None or old['candidate_sha256']!=h,review=review,review_state=review_state,applied=False))
candidate_paths={r['path'] for r in rows}
listing=subprocess.run(['rg','--files','--hidden','crates','vendor','scripts'],cwd=e,capture_output=True,text=True,check=True).stdout.splitlines();e_only=sorted(set(p.replace('\\','/') for p in listing)-candidate_paths)
retired=json.loads((b/'task7-integration-retirement-disposition247.json').read_text());retired_rows={r['path']:r for r in retired['rows']};retirement=[]
for rel in e_only:
 old=retired_rows.get(rel);p=e/rel;replacement={r:sha(w/r) for r in old['replacement_sources']} if old else {}
 retirement.append(dict(path=rel,e_preimage_sha256=sha(p),prior_disposition='RETIRE_ONLY_WITH_FINAL_INTEGRATED_VALIDATION' if old else 'NEW_E_ONLY_REQUIRES_DISPOSITION',e_preimage_unchanged=bool(old and sha(p)==old['e_preimage_sha256']),replacement_sources=replacement,required_gates=old['required_gates'] if old else ['explicit ownership and purpose review'],retired=False))
head=subprocess.run(['git','-C',str(e),'rev-parse','HEAD'],capture_output=True,text=True,check=True).stdout.strip();status=subprocess.run(['git','-C',str(e),'status','--porcelain'],capture_output=True,text=True,check=True).stdout
counts={state:sum(r['state']==state for r in rows) for state in ('IDENTICAL','DIFFERENT','MISSING_IN_E')}
s=dict(scope='CURRENT_FROZEN_CANDIDATE_E_PREIMAGE_AND_REVIEW_SNAPSHOT_NOT_APPLY_OR_ACCEPTANCE',observed_at=datetime.now(timezone.utc).isoformat(),production_applied=False,head=head,git_status_sha256=hashlib.sha256(status.encode()).hexdigest(),candidate_frozen_manifest_sha256=sha(manifest),candidate_frozen_count=len(f),selected_source_count=len(rows),counts=counts,current_static_review_count=sum(r['review_state']=='CURRENT_STATIC_REVIEW' for r in rows),stale_static_reviews=[r['path'] for r in rows if r['review_state']=='STALE_STATIC_REVIEW'],e_changes_since236=[r['path'] for r in rows if r['e_changed_since236']],candidate_changes_since236=[r['path'] for r in rows if r['candidate_changed_since236']],e_only=retirement,files=rows,requirements=['Revalidate all E preimages and final candidate hashes immediately before integration.','Do not integrate while319 compilation runs; do not modify its frozen input.','All static review drafts require fresh integrated compile/runtime/API/C1/C2 gates.','Preserve E append-only ledgers and unrelated files.','Conditional retirement rows are not deletion approval or completion.'])
assert all(sha(w/p)==h for p,h in f.items());assert all((sha(e/r['path']) if (e/r['path']).exists() else None)==r['e_preimage_sha256'] for r in rows);assert all(sha(e/r['path'])==r['e_preimage_sha256'] for r in retirement)
(d/'summary.json').write_text(json.dumps(s,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
files={'summary.json':d/'summary.json','runner323.py':Path(__file__),'frozen-inputs319.json':manifest};z=b/'task7-e-integration-current-snapshot326.zip';assert not z.exists();zip_manifest={n:sha(p) for n,p in files.items()}
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as out:
 for n,p in files.items():out.write(p,n)
 out.writestr('manifest.json',json.dumps(zip_manifest,indent=2))
with zipfile.ZipFile(z) as out:assert all(hashlib.sha256(out.read(n)).hexdigest()==h for n,h in zip_manifest.items())
receipt=b/'task7-e-integration-current-snapshot326.summary.json';receipt.write_text(json.dumps(dict(scope=s['scope'],sha256=sha(z),counts=counts,e_only_count=len(retirement),stale_static_reviews=s['stale_static_reviews'],verified_entries=len(zip_manifest),production_applied=False),indent=2)+'\n',encoding='utf-8')
for p in (z,receipt):
 q=e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'/p.name;assert not q.exists();shutil.copyfile(p,q);assert sha(p)==sha(q)
note='2026-10-09 当前冻结候选集成清单刷新323/326：基于319的1277输入，逐项保护'+str(len(rows))+'源码/支持路径E preimage，状态'+json.dumps(counts)+'；已有静态审阅匹配当前desired SHA '+str(s['current_static_review_count'])+'项，过时审阅'+str(len(s['stale_static_reviews']))+'项，E-only '+str(len(retirement))+'项保留条件退休及替代源当前SHA。候选较236变化'+str(len(s['candidate_changes_since236']))+'项，E较236源码变化'+str(len(s['e_changes_since236']))+'项。zip326 SHA '+sha(z)+'全部条目/E镜像核验；这是审阅/保护清单，不是apply或验收，319全仓仍待终态，正式业务源码未改，18顶层OPEN。'
for rel in ('.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md','docs/verification/rdbc-first/status.md','docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md'):
 with (e/rel).open('ab') as out:out.write(('\n\n'+note+'\n').encode('utf-8'))
print(json.dumps(dict(counts=counts,selected_source_count=len(rows),current_static_review_count=s['current_static_review_count'],stale_static_reviews=s['stale_static_reviews'],e_changes_since236=s['e_changes_since236'],candidate_changes_since236=s['candidate_changes_since236'],e_only_count=len(retirement),zip_sha256=sha(z))))
