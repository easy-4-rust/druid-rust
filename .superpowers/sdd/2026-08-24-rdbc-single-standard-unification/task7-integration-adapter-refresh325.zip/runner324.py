from pathlib import Path
import hashlib,importlib.util,json,shutil,sys,zipfile
sys.dont_write_bytecode=True
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d177');e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust');d=b/'task7-integration-adapter-refresh324';d.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rel='crates/druid-wrapper/src/sqlx/sqlx_connection_adapter.rs';review=b/'task7-integration-three-way242';record=next(x for x in json.loads((review/'summary.json').read_text())['files'] if x['path']==rel);old_path=review/'merge-inputs'/rel/'candidate'
assert sha(old_path)==record['candidate_sha256'] and sha(e/rel)==record['e_sha256']
clean=next(x for x in json.loads((b/'task7-integration-clean-resolution244/summary.json').read_text())['resolved'] if x['path']==rel);assert clean['resolved_review_sha256']==record['candidate_sha256']
f=json.loads((b/'task7-final-candidate-workspace319/frozen-inputs.json').read_text());assert all(sha(w/p)==h for p,h in f.items())
old,new=old_path.read_text(),(w/rel).read_text();normalized=new
old_control='''            SqlxConnectionBackend::MySql(connection) => {
                sqlx::query(sql)
                    .execute(connection)
                    .await
                    .map_err(Self::driver_error)?;
            }'''
new_control='''            SqlxConnectionBackend::MySql(connection) => {
                // MySQL 的 SAVEPOINT 等控制命令不支持 prepared protocol。
                // 此入口只接收已校验的无绑定控制 SQL，使用原连接的 text protocol。
                connection.execute(sql).await.map_err(Self::driver_error)?;
            }'''
old_time='''                "DATETIME" | "TIMESTAMP" => {
                    Value::Timestamp(row.try_get(index).map_err(Self::driver_error)?)
                }'''
new_time='''                "DATETIME" => Value::Timestamp(row.try_get(index).map_err(Self::driver_error)?),
                "TIMESTAMP" => {
                    // 仅在 MySQL 列类型已确认为 TIMESTAMP 后使用其日期时间解码器。
                    // SQLx 的 NaiveDateTime 类型检查只接受 DATETIME，但两者共享该解码器；
                    // 保留会话返回的年月日时分秒，不额外转换时区或绕过其他列的类型检查。
                    Value::Timestamp(
                        row.try_get_unchecked::<NaiveDateTime, _>(index)
                            .map_err(Self::driver_error)?,
                    )
                }'''
for after,before in ((new_control,old_control),(new_time,old_time)):
 assert normalized.count(after)==1 and old.count(before)==1;normalized=normalized.replace(after,before,1)
spec=importlib.util.spec_from_file_location('lexer324',w/'scripts/verify_rdbc_public_paths.py');lexer=importlib.util.module_from_spec(spec);sys.modules[spec.name]=lexer;spec.loader.exec_module(lexer);tokens=lambda text:[(t.kind,t.text) for t in lexer.tokenize(text)]
assert tokens(normalized)==tokens(old),'Unexpected changes beyond the two real-DB repairs'
dest=d/'resolved-review'/rel;dest.parent.mkdir(parents=True);shutil.copyfile(w/rel,dest)
summary=dict(scope='REFRESH_STALE_CLEAN_ADAPTER_REVIEW_FOR_TWO_REAL_DB_FIXES_NOT_INTEGRATION_ACCEPTANCE',path=rel,e_preimage_sha256=record['e_sha256'],old242_candidate_sha256=record['candidate_sha256'],candidate_sha256=sha(w/rel),resolved_review_sha256=sha(dest),explicit_disposition=['Only MySQL validated no-bind control SQL uses Executor text protocol for SAVEPOINT; other driver branches unchanged.','MySQL DATETIME retains checked conversion; verified TIMESTAMP type uses the same SQLx NaiveDateTime decoder without DATETIME-only compatibility rejection, preserving session fields. Other types unchanged.'],whole_old_candidate_tokens_preserved_after_two_reversals=True,parent317_sha256=sha(b/'task7-live-db-cancel-green-terminal317.zip'),production_applied=False,limitations=['Original244 clean byte merge is static only.','317 full real-DB contracts and required three-timezone timestamp contract validate recorded runtime scope.','Current319 full allfeatures and final integration/API gates remain required.'])
assert sha(e/rel)==record['e_sha256'] and all(sha(w/p)==h for p,h in f.items());(d/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
files={str(p.relative_to(d)).replace('\\','/'):p for p in d.rglob('*') if p.is_file()};files['runner324.py']=Path(__file__);files['old242-candidate.rs']=old_path
z=b/'task7-integration-adapter-refresh325.zip';assert not z.exists();manifest={n:sha(p) for n,p in files.items()}
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as out:
 for n,p in files.items():out.write(p,n)
 out.writestr('manifest.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(z) as out:assert all(hashlib.sha256(out.read(n)).hexdigest()==h for n,h in manifest.items())
receipt=b/'task7-integration-adapter-refresh325.summary.json';receipt.write_text(json.dumps(dict(scope=summary['scope'],sha256=sha(z),verified_entries=len(manifest),production_applied=False),indent=2)+'\n',encoding='utf-8')
for p in (z,receipt):
 q=e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'/p.name;assert not q.exists();shutil.copyfile(p,q);assert sha(p)==sha(q)
note='2026-10-09 旧clean适配器审阅刷新324/325：SqlxConnectionAdapter相对242旧候选仅两处MySQL实库修正，分别保存点无绑定text protocol与已确认TIMESTAMP类型的NaiveDateTime解码。逐项逆转后完整旧候选token相同，E preimage与1277冻结前后一致；317完整实库及三时区微秒/NULL/缓冲/流式补充已通过。zip325 SHA '+sha(z)+'全部条目/E镜像核验。旧244 clean SHA已过时，最终集成必须使用本轮desired SHA；不认证最终API/allfeatures，正式源码未apply，18顶层OPEN。'
for rel in ('.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md','docs/verification/rdbc-first/status.md','docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md'):
 with (e/rel).open('ab') as out:out.write(('\n\n'+note+'\n').encode('utf-8'))
print(json.dumps(dict(zip_sha256=sha(z),verified_entries=len(manifest))))
