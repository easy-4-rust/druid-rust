from pathlib import Path
import hashlib
import importlib.util
import json
import re
import shutil
import sys
import zipfile

sys.dont_write_bytecode = True
b = Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
w = Path('F:/codex_build_cache/d177')
e = Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust')
review = b / 'task7-integration-three-way242'
out = b / 'task7-integration-additive-resolution263'
out.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
lexer_path = w / 'scripts/verify_rdbc_public_paths.py'
spec = importlib.util.spec_from_file_location('integration_lexer263', lexer_path)
lexer = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = lexer
spec.loader.exec_module(lexer)
tokens = lambda text: [(t.kind, t.text) for t in lexer.tokenize(text)]
inventory = json.loads((review / 'summary.json').read_text())

def remove_function(text, name):
    pattern = r'(?m)^\s*(?:pub(?:\(crate\))?\s+)?(?:async\s+)?fn\s+' + re.escape(name) + r'\s*\('
    found = list(re.finditer(pattern, text))
    assert len(found) == 1, (name, len(found))
    start = found[0].start()
    body = text.index('{', found[0].end())
    depth = 1
    end = body + 1
    # These three reviewed method bodies contain no string/comment brace tokens.
    while depth:
        depth += (text[end] == '{') - (text[end] == '}')
        end += 1
    return text[:start] + text[end:]

paths = {
    'crates/druid/src/core/standard_resource_registration.rs': ['belongs_to', 'request_cleanup'],
    'crates/druid/src/core/resource_owner.rs': ['ensure_open'],
    'crates/druid-rdbc/src/wrapper/standard_unwrapped.rs': [],
}
rows = []
for rel, additions in paths.items():
    record = next(x for x in inventory['files'] if x['path'] == rel)
    assert record['merge_status'] == 'TEXT_MERGE_CONFLICT'
    current = review / 'merge-inputs' / rel / 'current'
    candidate = review / 'merge-inputs' / rel / 'candidate'
    assert sha(current) == record['e_sha256'] == sha(e / rel)
    assert sha(candidate) == record['candidate_sha256'] == sha(w / rel)
    old, new = current.read_text(), candidate.read_text()
    normalized = new
    for name in additions:
        normalized = remove_function(normalized, name)
    if rel.endswith('standard_resource_registration.rs'):
        assert normalized.count('use std::sync::{Arc, Weak};') == 1
        normalized = normalized.replace('use std::sync::{Arc, Weak};', 'use std::sync::Weak;')
    if rel.endswith('standard_unwrapped.rs'):
        assert normalized.count('use crate::extensions::{RowSet, RowSetMetaData};') == 1
        normalized = normalized.replace('use crate::extensions::{RowSet, RowSetMetaData};', '')
        for name in ('RowSet', 'RowSetMetaData'):
            normalized, enum_count = re.subn(r'(?m)^\s*' + name + r"\(&'a dyn " + name + r'\),\s*$', '', normalized)
            normalized, arm_count = re.subn(r'(?m)^\s*Self::' + name + r'\(_\) => TypeId::of::<dyn ' + name + r'>\(\),\s*$', '', normalized)
            assert enum_count == 1 and arm_count == 1
    assert tokens(old) == tokens(normalized), rel
    dest = out / 'resolved-review' / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(candidate, dest)
    rows.append(dict(
        path=rel, e_preimage_sha256=sha(current), candidate_sha256=sha(candidate),
        resolved_review_sha256=sha(dest),
        existing_signature_body_and_structure_tokens_preserved=True,
        retained_tokens_sha256=hashlib.sha256(json.dumps(tokens(old)).encode()).hexdigest(),
        explicitly_removed_from_comparison=additions if additions else ['RowSet/RowSetMetaData import, enum variants and matching type_id arms'],
        applied=False,
    ))
for row in rows:
    assert sha(e / row['path']) == row['e_preimage_sha256']
    assert sha(w / row['path']) == row['candidate_sha256']
summary = dict(
    scope='THREE_ADDITIVE_CONFLICT_DISPOSITIONS_LEXICAL_REVIEW_NOT_RUNTIME_ACCEPTANCE',
    production_applied=False,
    lexer_sha256=sha(lexer_path),
    previous262_sha256=sha(b / 'task7-integration-module-resolution262.zip'),
    rows=rows, unresolved_of_original43=35,
    limitations=['Lexical preservation does not certify correctness of added behavior.', 'Final integrated compiler, behavioral, API and complete C1/C2 gates remain required.'],
)
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
z = b / 'task7-integration-additive-resolution264.zip'
assert not z.exists()
files = {str(p.relative_to(out)).replace('\\', '/'): p for p in out.rglob('*') if p.is_file()}
files['runner263.py'] = Path(__file__)
manifest = {name: sha(p) for name, p in files.items()}
with zipfile.ZipFile(z, 'w', zipfile.ZIP_DEFLATED) as archive:
    for name, p in files.items():
        archive.write(p, name)
    archive.writestr('manifest.json', json.dumps(manifest, indent=2))
with zipfile.ZipFile(z) as archive:
    assert all(hashlib.sha256(archive.read(name)).hexdigest() == digest for name, digest in manifest.items())
receipt = b / 'task7-integration-additive-resolution264.summary.json'
receipt.write_text(json.dumps(dict(scope=summary['scope'], sha256=sha(z), verified_entries=len(manifest), production_applied=False), indent=2) + '\n')
for p in (z, receipt):
    dest = e / '.superpowers/sdd/2026-08-24-rdbc-single-standard-unification' / p.name
    assert not dest.exists()
    shutil.copyfile(p, dest)
    assert sha(p) == sha(dest)
note = ('2026-10-09 三项增量冲突处置263/264：standard_resource_registration仅增加belongs_to/request_cleanup及Arc导入，resource_owner仅增加ensure_open默认钩子，standard_unwrapped仅增加RowSet/RowSetMetaData两variant与对应type_id映射。逐项明确移除新增部分后，使用现有Rust词法器核验其余完整文件token与E原件完全相同；E preimage、候选与归档源SHA前后核验一致。保存三份完整resolved-review，zip264 SHA ' + sha(z) + '，全部条目/E镜像核验。连同261原43冲突已有八项静态处置草稿，另35项待审阅；保留原代码不代表新增行为正确，未apply、未替代最终编译/行为/API/C1/C2验收。18顶层OPEN。')
for rel in ('.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md', 'docs/verification/rdbc-first/status.md', 'docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md'):
    with (e / rel).open('ab') as stream:
        stream.write(('\n\n' + note + '\n').encode('utf-8'))
print(json.dumps(dict(reviewed=len(rows), unresolved=35, zip_sha256=sha(z), verified_entries=len(manifest), applied=False)))
