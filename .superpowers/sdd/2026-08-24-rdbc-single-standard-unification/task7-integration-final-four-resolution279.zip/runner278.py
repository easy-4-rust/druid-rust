from pathlib import Path
import hashlib, importlib.util, json, re, shutil, sys, zipfile

sys.dont_write_bytecode=True
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d177');e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust');review=b/'task7-integration-three-way242';out=b/'task7-integration-final-four-resolution278';out.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
lexer_path=w/'scripts/verify_rdbc_public_paths.py';spec=importlib.util.spec_from_file_location('lexer278',lexer_path);lexer=importlib.util.module_from_spec(spec);sys.modules[spec.name]=lexer;spec.loader.exec_module(lexer)
tokens=lambda text:[(t.kind,t.text) for t in lexer.tokenize(text)]
inventory=json.loads((review/'summary.json').read_text())

def replace_once(text,old,new):
 assert text.count(old)==1,(old[:100],text.count(old))
 return text.replace(old,new,1)

def function(text,name):
 matches=list(re.finditer(r'(?m)^    (?:pub(?:\([^\n]+\))?\s+)?(?:async\s+)?fn\s+'+re.escape(name)+r'(?:<[^>]+>)?\s*\(',text));assert len(matches)==1,(name,len(matches))
 start=matches[0].start();body=text.index('{',matches[0].end());depth,end=1,body+1
 while depth:
  depth+=(text[end]=='{')-(text[end]=='}');end+=1
 return start,body,end,text[start:end]

def remove_function(text,name):
 start,body,end,source=function(text,name)
 return text[:start]+text[end:]

rows=[]
paths=('crates/druid-rdbc/src/wrapper/wrapper.rs','crates/druid/src/pool/active_connection_lease.rs','crates/druid/src/core/druid_pooled_result_set.rs','crates/druid/src/core/standard_resource_registry.rs')
for rel in paths:
 record=next(x for x in inventory['files'] if x['path']==rel);assert record['merge_status']=='TEXT_MERGE_CONFLICT'
 current,candidate=(review/'merge-inputs'/rel/name for name in ('current','candidate'))
 assert sha(current)==record['e_sha256']==sha(e/rel)
 assert sha(candidate)==record['candidate_sha256']==sha(w/rel)
 old,new=current.read_text(),candidate.read_text();normalized=new
 if rel.endswith('/wrapper.rs'):
  start=normalized.index('macro_rules! impl_standard_wrapper {')+len('macro_rules! impl_standard_wrapper {')
  end=normalized.index('    (generics [$($generics:tt)*]',start)
  added=normalized[start:end]
  assert added.count('    (@emit ')==3
  assert added.count('=> RowSet)')==2 and added.count('=> RowSetMetaData)')==1
  for role in ('RowSet','RowSetMetaData','ResultSet','ResultSetMetaData','Wrapper'):
   assert role in added
  normalized=normalized[:start]+'\n'+normalized[end:]
  changes=['Add three RowSet/RowSetMetaData macro arms with ResultSet/ResultSetMetaData inheritance and original object views. All old macro arms, standard wrapper methods and imports are unchanged.']
 elif rel.endswith('/active_connection_lease.rs'):
  normalized=replace_once(normalized,'        let connect_stack_trace = std::backtrace::Backtrace::force_capture().to_string();','')
  normalized=replace_once(normalized,'            connect_stack_trace,','            connect_stack_trace: std::backtrace::Backtrace::force_capture().to_string(),')
  changes=['Capture diagnostic backtrace before Instant::now; all fields and remaining logic unchanged. Timing behavior and claimed Java order need separate oracle/runtime proof.']
 elif rel.endswith('/druid_pooled_result_set.rs'):
  start=normalized.index('        Self::new_standard_auxiliary_with_handoff(statement, raw, admission, |_| {}).await')
  end=normalized.index('        let resources = Arc::clone(&statement.resources);',start)
  normalized=normalized[:start]+normalized[end:]
  normalized=replace_once(normalized,'        handoff(Arc::clone(&staged.resource));','')
  start=normalized.index('        Self::new_standard_metadata_with_handoff(')
  end=normalized.index('        let statement = DruidPooledStatement::new_standard(',start)
  normalized=normalized[:start]+normalized[end:]
  added='''        let mut result = Self::new_standard_auxiliary_with_handoff(
            Arc::clone(&statement.inner),
            raw,
            admission,
            handoff,
        )
        .await?;
        statement
            .inner
            .set_execution_results(vec![TrackedStatementResult::ResultSet(Arc::downgrade(
                &result.resource,
            ))]);'''
  normalized=replace_once(normalized,added,'        let mut result = Self::new_standard(statement.inner, raw, admission).await?;')
  normalized=remove_function(normalized,'release_owned')
  changes=['Existing auxiliary constructor delegates to new handoff constructor; synchronous owner handoff precedes asynchronous registration. Existing registration/open/error-cleanup body unchanged.', 'Metadata constructor delegates to handoff constructor; restore tracked result weak identity explicitly, preserving no creating-statement flag.', 'Add ResultSet::release_owned cleanup request to original registry; original close and other ResultSet behavior unchanged.']
 else:
  normalized=replace_once(normalized,'    coordinator_runtime: Option<tokio::runtime::Handle>,','')
  normalized=replace_once(normalized,'            coordinator_runtime: tokio::runtime::Handle::try_current().ok(),','')
  _,_,_,old_close=function(old,'close_registered_after_admission')
  _,queue_body,queue_end,_=function(normalized,'queue_registered_cleanup')
  _,old_body,old_end,_=function(old,'close_registered_after_admission')
  queue=normalized[queue_body:queue_end]
  queue=replace_once(queue,'        if let Some(admission) = admission {\n            admission.finish();\n        }','        admission.finish();')
  queue=replace_once(queue,'        receivers\n    }','        Self::await_cleanup(receivers).await\n    }')
  assert tokens(queue)==tokens(old[old_body:old_end]),'Old cleanup enqueue/wait behavior changed beyond admission optionalization'
  start,body,end,_=function(normalized,'close_registered_after_admission')
  assert tokens(normalized[body:end])==tokens('{ self.close_registered_inner(registrations, Some(admission)).await }')
  normalized=normalized[:start]+old_close+normalized[end:]
  for name in ('close_registered','close_registered_inner','request_registered_cleanup','queue_registered_cleanup'):
   normalized=remove_function(normalized,name)
  start,body,end,_=function(normalized,'spawn_coordinator');_,_,_,original=function(old,'spawn_coordinator')
  normalized=normalized[:start]+original+normalized[end:]
  changes=['Factor original enqueue section into shared synchronous queue; old body matches exactly after explicit optional-admission reversal.', 'Add whole-batch registry ownership validation and no-admission close/wait path.', 'Add synchronous request path that drops receivers, preserving registered coordinator ownership.', 'Capture runtime handle at registry creation; coordinator uses captured handle or original current-runtime fallback. Runtime availability/shutdown still needs integrated behavior verification.']
 assert tokens(normalized)==tokens(old),(rel,'Unexpected old token change outside explicit disposition')
 dest=out/'resolved-review'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(candidate,dest)
 rows.append(dict(path=rel,e_preimage_sha256=sha(current),candidate_sha256=sha(candidate),resolved_review_sha256=sha(dest),explicit_disposition=changes,old_tokens_preserved_after_explicit_reversal=True,applied=False))
for row in rows:
 assert sha(e/row['path'])==row['e_preimage_sha256'] and sha(w/row['path'])==row['candidate_sha256']
summary=dict(scope='FOUR_PRODUCTION_CONFLICT_STATIC_DISPOSITIONS_NOT_RUNTIME_OR_PARITY_CERTIFICATION',production_applied=False,parent272_sha256=sha(b/'task7-integration-test-resolution272.zip'),rows=rows,unresolved_of_original43=1,remaining_path='crates/druid-wrapper/src/sqlx/sqlx_prepared_statement.rs',limitations=['Whole-file old-token preservation is static evidence; added behavior still requires original complete C1/C2, lifecycle, wrapper, compiler and public API gates.', 'Active lease timing and Java ordering are not certified by this comparison.', 'SQLx prepared statement candidate changed for real database failure repair and remains pending.'])
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
z=b/'task7-integration-final-four-resolution279.zip';assert not z.exists();files={str(p.relative_to(out)).replace('\\','/'):p for p in out.rglob('*') if p.is_file()};files['runner278.py']=Path(__file__);manifest={name:sha(p) for name,p in files.items()}
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as archive:
 for name,p in files.items():archive.write(p,name)
 archive.writestr('manifest.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(z) as archive:assert all(hashlib.sha256(archive.read(name)).hexdigest()==digest for name,digest in manifest.items())
receipt=b/'task7-integration-final-four-resolution279.summary.json';receipt.write_text(json.dumps(dict(scope=summary['scope'],sha256=sha(z),verified_entries=len(manifest),unresolved=1,production_applied=False),indent=2)+'\n',encoding='utf-8')
for p in (z,receipt):
 dest=e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'/p.name;assert not dest.exists();shutil.copyfile(p,dest);assert sha(p)==sha(dest)
note='2026-10-09 四处剩余生产冲突静态处置278/279：Wrapper仅新增三RowSet/metadata继承宏分支；ActiveLease仅将堆栈捕获提前至借用计时之前；PooledResultSet显式增加owner同步handoff与owning Stream清理请求；Registry抽出共享同步入队、身份检查及捕获runtime。逐项逆转明确变更后四份完整原token与E preimage一致，另单独核验原registry入队体仅admission可选化与等待位置改变。zip279 SHA '+sha(z)+'，全部条目/E镜像核验。原43冲突累计42项静态处置草稿，剩SQLxPreparedStatement实库修正中；不认证新增运行行为、Java计时顺序或最终集成/API/C1/C2。未apply正式/运行中候选源码，18顶层OPEN。'
for rel in ('.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md','docs/verification/rdbc-first/status.md','docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md'):
 with (e/rel).open('ab') as stream:stream.write(('\n\n'+note+'\n').encode('utf-8'))
print(json.dumps(dict(reviewed=len(rows),unresolved=1,zip_sha256=sha(z),production_applied=False)))
