from pathlib import Path
import hashlib
import importlib.util
import json
import re
import shutil
import sys
import zipfile

sys.dont_write_bytecode = True
b = Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
w = Path('F:/codex_build_cache/d177')
e = Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust')
review = b / 'task7-integration-three-way242'
out = b / 'task7-integration-lease-context-resolution265'
out.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
lexer_path = w / 'scripts/verify_rdbc_public_paths.py'
spec = importlib.util.spec_from_file_location('integration_lexer265', lexer_path)
lexer = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = lexer
spec.loader.exec_module(lexer)
tokens = lambda text: [(t.kind, t.text) for t in lexer.tokenize(text)]
inventory = json.loads((review / 'summary.json').read_text())

def remove_function(text, name):
    found = list(re.finditer(r'(?m)^\s*(?:pub(?:\(crate\))?\s+)?(?:async\s+)?fn\s+' + re.escape(name) + r'(?:<[^>]+>)?\s*\(', text))
    assert len(found) == 1, (name, len(found))
    start = found[0].start()
    body = text.index('{', found[0].end())
    depth, end = 1, body + 1
    while depth:
        depth += (text[end] == '{') - (text[end] == '}')
        end += 1
    return text[:start] + text[end:]

rows = []
for rel in ('crates/druid/src/core/external_connection_lease.rs', 'crates/druid/src/core/resource_context.rs'):
    record = next(x for x in inventory['files'] if x['path'] == rel)
    assert record['merge_status'] == 'TEXT_MERGE_CONFLICT'
    current, candidate = (review / 'merge-inputs' / rel / name for name in ('current', 'candidate'))
    assert sha(current) == record['e_sha256'] == sha(e / rel)
    assert sha(candidate) == record['candidate_sha256'] == sha(w / rel)
    old, new = current.read_text(), candidate.read_text()
    normalized = new
    if rel.endswith('external_connection_lease.rs'):
        for name in ('create_sql_xml', 'create_struct', 'create_array_of'):
            normalized = remove_function(normalized, name)
        assert normalized.count('use druid_rdbc::resource::{Array, Blob, Clob, NClob, SqlXml};') == 1
        normalized = normalized.replace('use druid_rdbc::resource::{Array, Blob, Clob, NClob, SqlXml};', '')
        assert normalized.count('use druid_rdbc::types::{RdbcObject, RdbcTypeMap, Row, Savepoint, Value};') == 1
        normalized = normalized.replace('use druid_rdbc::types::{RdbcObject, RdbcTypeMap, Row, Savepoint, Value};', 'use druid_rdbc::types::{RdbcBlob, RdbcClob, RdbcNClob, RdbcTypeMap, Row, Savepoint, Value};')
        for kind in ('Blob', 'Clob', 'NClob'):
            assert normalized.count('Result<Box<dyn ' + kind + '>, RdbcError>') == 1
            normalized = normalized.replace('Result<Box<dyn ' + kind + '>, RdbcError>', 'Result<Rdbc' + kind + ', RdbcError>')
        proof = {
            'explicit_signature_migration': ['create_blob: RdbcBlob -> Box<dyn Blob>', 'create_clob: RdbcClob -> Box<dyn Clob>', 'create_n_clob: RdbcNClob -> Box<dyn NClob>'],
            'added_direct_delegations': ['create_sql_xml', 'create_struct', 'create_array_of'],
            'original_delegation_bodies_and_other_file_tokens_preserved': True,
        }
    else:
        normalized = remove_function(normalized, 'classify_operation_result')
        addition = '        if let Some(owner) = &self.owner {\n            owner.ensure_open()?;\n        }\n'
        assert normalized.count(addition) == 1
        normalized = normalized.replace(addition, '')
        proof = {
            'explicit_added_check': 'require checks owner.ensure_open after local resource state and before capability',
            'added_method': 'classify_operation_result reports the original driver error to the owner and returns the original Result',
            'all_other_file_tokens_preserved': True,
        }
    assert tokens(old) == tokens(normalized), rel
    dest = out / 'resolved-review' / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(candidate, dest)
    rows.append(dict(path=rel, e_preimage_sha256=sha(current), candidate_sha256=sha(candidate), resolved_review_sha256=sha(dest), proof=proof, retained_tokens_sha256=hashlib.sha256(json.dumps(tokens(old)).encode()).hexdigest(), applied=False))

for row in rows:
    assert sha(e / row['path']) == row['e_preimage_sha256']
    assert sha(w / row['path']) == row['candidate_sha256']
formal_spec = e / 'docs/superpowers/specs/2026-08-24-rdbc-single-standard-trait-tree.md'
summary = dict(scope='LEASE_AND_RESOURCE_CONTEXT_CONFLICT_STATIC_DISPOSITION_NOT_ACCEPTANCE', production_applied=False, previous264_sha256=sha(b / 'task7-integration-additive-resolution264.zip'), lexer_sha256=sha(lexer_path), formal_spec_sha256=sha(formal_spec), rows=rows, unresolved_of_original43=33, limitations=['Explicitly changed return signatures are intentional standard migration, not backward API compatibility certification.', 'Owner check ordering and failure classification require final runtime regression.', 'Complete C1/C2, API/SemVer and final integrated workspace validation remain required.'])
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
z = b / 'task7-integration-lease-context-resolution266.zip'
assert not z.exists()
files = {str(p.relative_to(out)).replace('\\', '/'): p for p in out.rglob('*') if p.is_file()}
files['runner265.py'] = Path(__file__)
manifest = {name: sha(p) for name, p in files.items()}
with zipfile.ZipFile(z, 'w', zipfile.ZIP_DEFLATED) as archive:
    for name, p in files.items():
        archive.write(p, name)
    archive.writestr('manifest.json', json.dumps(manifest, indent=2))
with zipfile.ZipFile(z) as archive:
    assert all(hashlib.sha256(archive.read(name)).hexdigest() == digest for name, digest in manifest.items())
receipt = b / 'task7-integration-lease-context-resolution266.summary.json'
receipt.write_text(json.dumps(dict(scope=summary['scope'], sha256=sha(z), verified_entries=len(manifest), production_applied=False), indent=2) + '\n')
for p in (z, receipt):
    dest = e / '.superpowers/sdd/2026-08-24-rdbc-single-standard-unification' / p.name
    assert not dest.exists()
    shutil.copyfile(p, dest)
    assert sha(p) == sha(dest)
note = ('2026-10-09 外部租约/资源上下文冲突处置265/266：ExternalConnectionLease三个LOB返回签名迁移至Box<dyn标准trait>，原委托体不变，新增SQLXML/Struct/Array直接委托；ResourceContext明确增加owner有效性检查及原错误分类通知。仅逆转这份明确变更清单后，两个完整文件其余Rust token与E原件完全相同；源SHA前后核验。zip266 SHA ' + sha(z) + '，全部条目/E镜像核验。原43冲突累计十项静态处置草稿，另33项待审阅；签名迁移不是SemVer兼容证明，新增行为仍须完整运行门禁。未apply正式业务源码；18顶层OPEN。')
for rel in ('.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md', 'docs/verification/rdbc-first/status.md', 'docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md'):
    with (e / rel).open('ab') as stream:
        stream.write(('\n\n' + note + '\n').encode('utf-8'))
print(json.dumps(dict(reviewed=len(rows), unresolved=33, zip_sha256=sha(z), verified_entries=len(manifest), applied=False)))
