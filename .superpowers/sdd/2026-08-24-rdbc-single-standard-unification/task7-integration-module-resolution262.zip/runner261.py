from pathlib import Path
import hashlib
import json
import re
import shutil
import tomllib
import zipfile

b = Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
e = Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust')
w = Path('F:/codex_build_cache/d177')
review = b / 'task7-integration-three-way242'
out = b / 'task7-integration-module-resolution261'
out.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
inventory = json.loads((review / 'summary.json').read_text())
retirement = json.loads((b / 'task7-integration-retirement-disposition247.json').read_text())
retired = {row['path'] for row in retirement['rows']}
paths = [
    'crates/druid-rdbc/Cargo.toml',
    'crates/druid-rdbc/src/data_source/mod.rs',
    'crates/druid-rdbc/src/extensions/mod.rs',
    'crates/druid-rdbc/src/resource/mod.rs',
    'crates/druid-wrapper/src/sqlx/mod.rs',
]

def declarations(text):
    return set(re.findall(r'(?m)^\s*(?:pub(?:\(crate\))?\s+)?mod\s+(\w+)\s*;', text))

def exports(text):
    result = set()
    for target in re.findall(r'(?m)^\s*pub(?:\(crate\))?\s+use\s+([^;]+);', text):
        if '{' in target:
            result.update(part.strip().split(' as ')[-1] for part in target.split('{', 1)[1].rstrip().rstrip('}').split(',') if part.strip())
        else:
            result.add(target.strip().split(' as ')[-1].split('::')[-1])
    return result

rows = []
for rel in paths:
    record = next(x for x in inventory['files'] if x['path'] == rel)
    assert record['merge_status'] == 'TEXT_MERGE_CONFLICT'
    inputs = review / 'merge-inputs' / rel
    current, candidate = inputs / 'current', inputs / 'candidate'
    assert sha(current) == record['e_sha256'] == sha(e / rel)
    assert sha(candidate) == record['candidate_sha256'] == sha(w / rel)
    old, new = current.read_text(), candidate.read_text()
    proof = {}
    if rel.endswith('Cargo.toml'):
        before, after = tomllib.loads(old), tomllib.loads(new)
        assert after['dependencies'].pop('futures') == {'workspace': True}
        assert before == after
        proof = {'existing_toml_values_preserved': True, 'only_added_dependency': 'futures.workspace=true'}
    else:
        removed_modules = declarations(old) - declarations(new)
        removed_exports = exports(old) - exports(new)
        expected_modules, expected_exports = set(), set()
        if rel == 'crates/druid-rdbc/src/resource/mod.rs':
            expected_modules = {
                'rdbc_array_access', 'rdbc_blob_access', 'rdbc_clob_access',
                'rdbc_n_clob_access', 'rdbc_ref_access', 'rdbc_sql_xml_access',
                'rdbc_resource_access', 'rdbc_resource_context',
                'rdbc_resource_kind', 'rdbc_resource_state',
            }
            expected_exports = {
                'RdbcArrayAccess', 'RdbcBlobAccess', 'RdbcClobAccess',
                'RdbcNClobAccess', 'RdbcRefAccess', 'RdbcSqlXmlAccess',
                'RdbcResourceAccess', 'ResourceLifecycle', 'ResourceType',
                'ResourceLifecycleState',
            }
        if rel == 'crates/druid-wrapper/src/sqlx/mod.rs':
            expected_modules = {'sqlx_streaming_result_set'}
        assert removed_modules == expected_modules
        assert removed_exports == expected_exports
        for module in removed_modules:
            assert str(Path(rel).parent / (module + '.rs')).replace('\\', '/') in retired
        assert '*' not in '\n'.join(re.findall(r'(?m)^\s*pub(?:\(crate\))?\s+use\s+([^;]+);', new))
        proof = {
            'removed_modules': sorted(removed_modules),
            'removed_exports': sorted(removed_exports),
            'removed_modules_all_have_explicit_retirement_dispositions': True,
            'added_modules': sorted(declarations(new) - declarations(old)),
            'added_exports': sorted(exports(new) - exports(old)),
            'all_other_existing_module_and_export_names_preserved': True,
        }
    dest = out / 'resolved-review' / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(candidate, dest)
    rows.append(dict(path=rel, e_preimage_sha256=sha(current), candidate_sha256=sha(candidate), resolved_review_sha256=sha(dest), proof=proof, applied=False))

# Revalidate source preimages after creating review artifacts; no source writes.
for row in rows:
    assert sha(e / row['path']) == row['e_preimage_sha256']
    assert sha(w / row['path']) == row['candidate_sha256']
summary = dict(
    scope='FIVE_TEXT_CONFLICT_DISPOSITIONS_STATIC_REVIEW_ONLY_NOT_APPLY_OR_ACCEPTANCE',
    production_applied=False,
    parent243_sha256=sha(b / 'task7-integration-three-way243.zip'),
    retirement248_sha256=sha(b / 'task7-integration-retirement248.zip'),
    rows=rows,
    unresolved_of_original43=38,
    limitations=[
        'Declarations and exports are checked by name, not a compiler or behavioral proof.',
        'Retirement remains conditional on final integrated validation.',
        'Current candidate all-workspace, C1/C2, API and semantic gates must pass.',
        'Final application must revalidate current E and final candidate source hashes.',
    ],
)
(out / 'summary.json').write_text(json.dumps(summary, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
z = b / 'task7-integration-module-resolution262.zip'
assert not z.exists()
files = {str(p.relative_to(out)).replace('\\', '/'): p for p in out.rglob('*') if p.is_file()}
files['runner261.py'] = Path(__file__)
manifest = {name: sha(p) for name, p in files.items()}
with zipfile.ZipFile(z, 'w', zipfile.ZIP_DEFLATED) as archive:
    for name, p in files.items():
        archive.write(p, name)
    archive.writestr('manifest.json', json.dumps(manifest, indent=2))
with zipfile.ZipFile(z) as archive:
    assert all(hashlib.sha256(archive.read(name)).hexdigest() == digest for name, digest in manifest.items())
receipt = b / 'task7-integration-module-resolution262.summary.json'
receipt.write_text(json.dumps(dict(scope=summary['scope'], sha256=sha(z), verified_entries=len(manifest), production_applied=False), indent=2) + '\n')
for p in (z, receipt):
    dest = e / '.superpowers/sdd/2026-08-24-rdbc-single-standard-unification' / p.name
    assert not dest.exists()
    shutil.copyfile(p, dest)
    assert sha(p) == sha(dest)
note = ('2026-10-09 五项文本冲突静态处置261/262：对原242的RDBC Cargo、data_source/extensions/resource模块和SQLx模块分别核验E preimage、候选及归档原件SHA。Cargo仅新增futures.workspace；两个纯增量mod保留全部原声明/导出；resource十个旧模块与SQLx旧streaming模块均对应247/248已记录条件退休处置，其他原导出名称保留。生成五份完整resolved-review，未写E/F业务源码。zip262 SHA ' + sha(z) + '，全部条目/E镜像核验。原43冲突中五项取得静态处置草稿，另38项仍需逐项审阅；不是编译、行为或最终集成验收，退休仍须最终门禁。18顶层OPEN。')
for rel in ('.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md', 'docs/verification/rdbc-first/status.md', 'docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md'):
    with (e / rel).open('ab') as stream:
        stream.write(('\n\n' + note + '\n').encode('utf-8'))
print(json.dumps(dict(reviewed=len(rows), unresolved=38, zip_sha256=sha(z), verified_entries=len(manifest), applied=False)))
