from pathlib import Path

class IntegrationRefused(RuntimeError):
    pass

def validate_preflight(candidate: Path, formal: Path, frozen: dict, snapshot: dict, summary: dict):
    raise IntegrationRefused('integration preflight not implemented')
