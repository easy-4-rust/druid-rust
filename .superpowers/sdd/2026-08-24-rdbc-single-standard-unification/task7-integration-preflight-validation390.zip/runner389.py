from pathlib import Path
import hashlib,io,json,shutil,unittest,zipfile
import integration_preflight387 as gate
import test_integration_preflight388 as tests
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d177');e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust');d=b/'task7-integration-preflight-validation389';d.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
frozen_path=b/'task7-final-candidate-workspace319/frozen-inputs.json';frozen=json.loads(frozen_path.read_text());assert len(frozen)==1277 and all(sha(w/p)==h for p,h in frozen.items())
output=io.StringIO();result=unittest.TextTestRunner(stream=output,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(tests));(d/'tests.log').write_text(output.getvalue(),encoding='utf-8');assert result.wasSuccessful(),output.getvalue()
snapshot_path=b/'task7-e-integration-current-snapshot383/summary.json';snapshot=json.loads(snapshot_path.read_text());running_path=b/'task7-final-candidate-workspace319/summary.json';running=json.loads(running_path.read_text())
try:preview=gate.validate_preflight(w,e,frozen,snapshot,running)
except gate.IntegrationRefused as error:preview=dict(state='REFUSED',reason=str(error))
else:assert running.get('terminal') and running.get('exit_code')==0
assert all(sha(w/p)==h for p,h in frozen.items());assert all((sha(e/r['path']) if (e/r['path']).exists() else None)==r['e_preimage_sha256'] for r in snapshot['files'])
s=dict(scope='READ_ONLY_INTEGRATION_PRECONDITION_CHECKER_NOT_APPLY',tests_run=result.testsRun,failed=len(result.failures),errors=len(result.errors),actual_current_preview=preview,production_applied=False,retirement_authorized=False,compiler_api_or_release_certified=False,frozen_inputs_changed=0,red_evidence=dict(tool_chunk='f111a5',exit_code=1,tests_run=17,positive_preview_rejected_by_unimplemented_checker=True),positive_fixture_expanded_to_exact_selected_count=1257)
(d/'summary.json').write_text(json.dumps(s,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');(d/'running-summary.json').write_text(json.dumps(running,indent=2)+'\n',encoding='utf-8')
(d/'report.md').write_text('# 集成前只读检查器\n\n初始有效预览因未实现而RED；正例fixture扩为实际1257选中路径，原1277输入分母不减。完成'+str(result.testsRun)+'测试：验收LIVE/失败、缺项/重复、allfeatures/严格模式/no-execute缩减、日志替换、源码漂移、E preimage变化、新路径占用、路径越界、分母缩减及C1 executed=no均拒绝；正例确认不写E原件、不创建新文件。\n\n当前真实319检查结果：'+json.dumps(preview,ensure_ascii=False)+'。这是合并审阅前条件，不能授权旧文件退休、证明新LLVM/API或发布；不存在apply入口。1277冻结和1257正式preimage复核不变，无第二Cargo。\n',encoding='utf-8')
files={'integration_preflight387.py':b/'integration_preflight387.py','test_integration_preflight388.py':b/'test_integration_preflight388.py','red-checker.py':b/'integration_preflight387.red.py','red-tests.py':b/'test_integration_preflight388.red.py','runner389.py':Path(__file__),'tests.log':d/'tests.log','summary.json':d/'summary.json','report.md':d/'report.md','running-summary.json':d/'running-summary.json','frozen319.json':frozen_path,'preimages383.json':snapshot_path};entries={name:sha(path) for name,path in files.items()};z=b/'task7-integration-preflight-validation390.zip';assert not z.exists()
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as archive:
 for name,path in files.items():archive.write(path,name)
 archive.writestr('manifest.json',json.dumps(entries,indent=2))
with zipfile.ZipFile(z) as archive:assert all(hashlib.sha256(archive.read(name)).hexdigest()==h for name,h in entries.items())
receipt=b/'task7-integration-preflight-validation390.summary.json';receipt.write_text(json.dumps(dict(sha256=sha(z),verified_entries=len(entries),tests=result.testsRun,actual_preview=preview,production_applied=False),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for item in (z,receipt):
 target=e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'/item.name;assert not target.exists();shutil.copyfile(item,target);assert sha(item)==sha(target)
note='2026-10-09 集成前只读检查器387/388/389/390：有效预览初始RED，补 exact1277/1257分母及原5命令scope、逐日志SHA/C1 executed=yes、源码/E preimage/新路径/path检查后'+str(result.testsRun)+'测试PASS；当前真实319 '+json.dumps(preview,ensure_ascii=False)+'，未apply/退休/认证LLVM/API，1277及1257正式preimage不变，无第二Cargo。zip390 SHA '+sha(z)+'全部条目/E镜像核验；18顶层OPEN。'
for rel in ('.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md','docs/verification/rdbc-first/status.md','docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md'):
 with (e/rel).open('ab') as out:out.write(('\n\n'+note+'\n').encode('utf-8'))
print(json.dumps(dict(tests=result.testsRun,actual_preview=preview,zip_sha256=sha(z)),ensure_ascii=False))
