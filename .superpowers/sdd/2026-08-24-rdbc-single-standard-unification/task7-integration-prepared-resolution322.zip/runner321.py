from pathlib import Path
import hashlib,importlib.util,json,re,shutil,sys,zipfile
sys.dont_write_bytecode=True
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d177');e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust');d=b/'task7-integration-prepared-resolution321';d.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rel='crates/druid-wrapper/src/sqlx/sqlx_prepared_statement.rs';review=b/'task7-integration-three-way242';record=next(x for x in json.loads((review/'summary.json').read_text())['files'] if x['path']==rel)
current=review/'merge-inputs'/rel/'current';candidate=w/rel
assert record['merge_status']=='TEXT_MERGE_CONFLICT' and sha(current)==record['e_sha256']==sha(e/rel)
frozen=json.loads((b/'task7-final-candidate-workspace319/frozen-inputs.json').read_text());assert len(frozen)==1277 and all(sha(w/p)==h for p,h in frozen.items())
receipt=json.loads((b/'task7-live-db-cancel-green-terminal317.summary.json').read_text());assert sha(b/'task7-live-db-cancel-green-terminal317.zip')==receipt['sha256'] and sha(candidate)==frozen[rel]
spec=importlib.util.spec_from_file_location('lexer321',w/'scripts/verify_rdbc_public_paths.py');lexer=importlib.util.module_from_spec(spec);sys.modules[spec.name]=lexer;spec.loader.exec_module(lexer)
tokens=lambda text:[(t.kind,t.text) for t in lexer.tokenize(text)]
def replace_once(text,old,new):
 assert text.count(old)==1,(old[:100],text.count(old));return text.replace(old,new,1)
def function(text,name):
 matches=list(re.finditer(r'(?m)^    (?:pub(?:\([^\n]+\))?\s+)?(?:async\s+)?fn\s+'+re.escape(name)+r'(?:<[^>]+>)?\s*\(',text));assert len(matches)==1,(name,len(matches))
 start=matches[0].start();body=text.index('{',matches[0].end());depth,end=1,body+1
 while depth:depth+=(text[end]=='{')-(text[end]=='}');end+=1
 return start,end,text[start:end]
def transform_function(text,name,transform):
 start,end,source=function(text,name);return text[:start]+transform(source)+text[end:]
old,new=current.read_text(),candidate.read_text();normalized=new
old_names=re.findall(r'(?m)^    (?:pub(?:\([^\n]+\))?\s+)?(?:async\s+)?fn\s+(\w+)',old);new_names=re.findall(r'(?m)^    (?:pub(?:\([^\n]+\))?\s+)?(?:async\s+)?fn\s+(\w+)',new)
assert set(new_names)-set(old_names)=={'cancel','execute_query_values'} and not set(old_names)-set(new_names)
normalized=replace_once(normalized,'use druid_rdbc::error::{RdbcError, SqlException};','use druid_rdbc::error::RdbcError;')
normalized=replace_once(normalized,'ExecutionResult, FetchDirection, GeneratedKeys, PreparedParameter, ResultSetType,\n    StatementOptions,','ExecutionResult, FetchDirection, GeneratedKeys, PreparedParameter, StatementOptions,')
for fragment in ('    cursor_shutdown: tokio::sync::watch::Sender<bool>,','    cancel_pending: bool,','            cursor_shutdown: tokio::sync::watch::channel(false).0,','            cancel_pending: false,'):normalized=replace_once(normalized,fragment,'')
for name in ('bounded','reset_execution_results'):
 original=function(old,name)[2];normalized=transform_function(normalized,name,lambda source,original=original:original)
for name in ('cancel','execute_query_values'):normalized=transform_function(normalized,name,lambda source:'')
normalized=transform_function(normalized,'execute_prepared_query_values',lambda source:replace_once(replace_once(source,'        allow_stream: bool,',''),'self.execute_query_values(actor, &self.sql, values, allow_stream)\n                    .await?','self.bounded(actor.execute_query(&self.sql, values)).await?'))
ordinary=('execute_query','execute_update','execute','execute_batch','execute_values')
prepared=('execute_prepared_query','execute_prepared_update','execute_prepared','execute_prepared_batch')
for name in ordinary:
 normalized=transform_function(normalized,name,lambda source:replace_once(source,'        self.reset_execution_results()?;',''))
for name in prepared:
 normalized=transform_function(normalized,name,lambda source:replace_once(source,'self.reset_execution_results()?;','self.reset_execution_results();'))
normalized=transform_function(normalized,'execute_query',lambda source:replace_once(source,'self.execute_query_values(&actor, sql, Vec::new(), true)\n            .await','self.bounded(actor.execute_query(sql, Vec::new())).await'))
normalized=transform_function(normalized,'execute_values',lambda source:replace_once(source,'self.execute_query_values(&actor, sql, values, true).await','self.bounded(actor.execute_query(sql, values)).await'))
normalized=replace_once(normalized,'self\n            .execute_prepared_query_values(&actor, values, true)\n            .await?','self.execute_prepared_query_values(&actor, values).await?')
normalized=replace_once(normalized,'self.execute_prepared_query_values(&actor, values, false)\n                    .await?','self.execute_prepared_query_values(&actor, values).await?')
normalized=transform_function(normalized,'close',lambda source:replace_once(source,'        self.cursor_shutdown.send_replace(true);',''))
assert tokens(normalized)==tokens(old),'Unexpected old token change outside explicit disposition'
(d/'reversed-for-comparison.rs').write_text(normalized,encoding='utf-8');dest=d/'resolved-review'/rel;dest.parent.mkdir(parents=True);shutil.copyfile(candidate,dest)
changes=['Add generation-specific watch shutdown and one-shot pending cancel; active cursor stops without statement/connection close.', 'Map local deadline to SQLTimeoutException HYT00; driver errors unchanged.', 'Execution admission validates actor, clears old generated keys/update count, invalidates old cursor generation, and rejects pending cancel HY008 before materialization or driver I/O.', 'Five ordinary execution entry points now invoke admission; original four prepared entry points retain result reset with fallible admission.', 'Positive fetch size plus ForwardOnly uses bounded async cursor for query/value/prepared query; default, scroll and generic prepared execution remain buffered; generated-key request branch unchanged.', 'Close sends cursor shutdown before original closed flag and actor release.']
summary=dict(scope='LAST_ORIGINAL43_CONFLICT_STATIC_DISPOSITION_NOT_APPLY_OR_FULL_ACCEPTANCE',path=rel,e_preimage_sha256=sha(current),candidate_sha256=sha(candidate),original242_candidate_sha256=record['candidate_sha256'],resolved_review_sha256=sha(dest),explicit_disposition=changes,all_old_tokens_preserved_after_explicit_reversal=True,old_method_count=len(old_names),added_methods=['cancel','execute_query_values'],all_original43_static_drafts=43,unresolved_original43_static_drafts=0,parent317_sha256=receipt['sha256'],production_applied=False,limitations=['Static reversal proves retained source outside listed changes, not behavior equivalence.', '317 original DB cancel test sends request before execution; concurrent server-side interrupt remains uncertified.', 'Current 319 full allfeatures/C1/C2 validation still required; final desired manifest must be refreshed before E integration.'])
assert sha(e/rel)==record['e_sha256'] and all(sha(w/p)==h for p,h in frozen.items());(d/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
files={str(p.relative_to(d)).replace('\\','/'):p for p in d.rglob('*') if p.is_file()};files['runner321.py']=Path(__file__);files['preimage-current.rs']=current;files['original242-candidate.rs']=review/'merge-inputs'/rel/'candidate'
z=b/'task7-integration-prepared-resolution322.zip';assert not z.exists();manifest={n:sha(p) for n,p in files.items()}
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as archive:
 for n,p in files.items():archive.write(p,n)
 archive.writestr('manifest.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(z) as archive:assert all(hashlib.sha256(archive.read(n)).hexdigest()==h for n,h in manifest.items())
receipt=b/'task7-integration-prepared-resolution322.summary.json';receipt.write_text(json.dumps(dict(scope=summary['scope'],sha256=sha(z),verified_entries=len(manifest),all_original43_static_drafts=43,production_applied=False),indent=2)+'\n',encoding='utf-8')
for p in (z,receipt):
 target=e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'/p.name;assert not target.exists();shutil.copyfile(p,target);assert sha(p)==sha(target)
note='2026-10-09 最后一处原43集成冲突321/322静态处置：SQLxPreparedStatement明确列出异步查询分流、超时HYT00、取消代次/预取消HY008、九执行入口准入及close停止游标。逐项逆转后完整文件token与242 E preimage完全相同，原方法名全部保留，仅新增cancel/execute_query_values；1277冻结候选及E preimage前后核验一致。zip322 SHA '+sha(z)+'全部条目/E镜像核验。原43冲突全部取得静态草稿，不等于集成/编译/行为/API/SemVer认证；当前319全仓验证仍待终态，正式E源码未apply，18顶层OPEN。'
for path in ('.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md','docs/verification/rdbc-first/status.md','docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md'):
 with (e/path).open('ab') as out:out.write(('\n\n'+note+'\n').encode('utf-8'))
print(json.dumps(dict(original43_static_drafts=43,zip_sha256=sha(z),verified_entries=len(manifest),old_method_count=len(old_names))))
