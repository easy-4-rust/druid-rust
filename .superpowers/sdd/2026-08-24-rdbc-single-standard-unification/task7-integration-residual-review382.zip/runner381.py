from pathlib import Path
from collections import Counter
import difflib,hashlib,json,re,shutil,zipfile
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d177');e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust');d=b/'task7-integration-residual-review381';d.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
snapshot=json.loads((b/'task7-e-integration-current-snapshot323/summary.json').read_text());frozen=json.loads((b/'task7-final-candidate-workspace319/frozen-inputs.json').read_text());assert len(frozen)==1277 and all(sha(w/p)==h for p,h in frozen.items())
selected=[r for r in snapshot['files'] if r['state']=='DIFFERENT' and r['review_state']!='CURRENT_STATIC_REVIEW'];assert len(selected)==13
def assertion_tokens(source):
 tokens=re.findall(r'"(?:\\.|[^"\\])*"|[A-Za-z_][A-Za-z_0-9]*|\d+|[^\s]',source)
 results=[]
 for index,token in enumerate(tokens):
  if token not in ('assert','assert_eq','assert_ne') or tokens[index+1:index+2]!=['!']:continue
  assert tokens[index+2] in ('(','[','{')
  stack=[];pairs={')':'(',']':'[','}':'{'}
  for end in range(index+2,len(tokens)):
   value=tokens[end]
   if value in ('(','[','{'):stack.append(value)
   elif value in pairs:
    assert stack.pop()==pairs[value]
    if not stack:results.append(tuple(tokens[index:end+1]));break
  else:raise AssertionError('unclosed assertion')
 return results
notes={
 'standard_unwrapped_mut.rs':'仅新增RowSet/RowSetMetaData mutable视图和导入；原变体与Debug体保留。',
 'connection.inc.rs':'仅三个resource创建返回值改canonical Box<dyn Trait>；错误trace和原方法身份保留。',
 'lease_complete_tests.rs':'原三LOB等价断言迁移为同一Box数据地址；额外三length=4断言；其余44断言逐token相同。',
 'delegation_resources.rs':'三个资源由handle改Option<Box<dyn Trait>>；预分配对象只移动一次，其余Statement地址观察保留。',
 'lease_contract_connection.rs':'资源创建委托由clone改take；计数、原15断言和其他连接合同保留。',
 'lease_blob_access.rs':'访问接口合并为Blob，保留length=4和(1,4)范围断言；显式不支持其余方法，能力仅READ/RANGE/FREE；非零身份字段。',
 'lease_clob_access.rs':'访问接口合并为Clob/NClob，保留length=4和(1,4)范围断言；显式不支持其余方法，能力仅READ/RANGE/FREE；非零身份字段。',
 'test_array_access.rs':'Array canonical mutable方法，原值/type_map/range及ResultSet拒绝保留；补原默认free、能力位显式准确。',
 'test_blob_access.rs':'Blob canonical mutable方法；保留范围、释放和只读拒绝；SameResource/Other搜索分支映射旧pattern；factory接受Box。',
 'test_callable_statement.rs':'全部OUT键和值及操作保留；factory接受Box；名称SQLXML改独立同内容对象以保留索引读取后的名称读取，身份改变需运行合同。',
 'test_clob_access.rs':'Clob/NClob canonical mutable方法；UTF16/范围/释放/拒绝保留；同资源pattern分支，factory接受Box。',
 'test_ref_access.rs':'Ref canonical mutable方法；原schema.kind/ref-value/type_map/set_object语义保留。',
 'test_sql_xml_access.rs':'SqlXml canonical mutable方法；source/result nullable参数，原内容和拒绝保留；补无外部资源夹具默认free。'}
rows=[];assertions_old=0;assertions_new=0
for r in selected:
 rel=r['path'];original=e/rel;candidate=w/rel;assert sha(original)==r['e_preimage_sha256'] and sha(candidate)==r['candidate_sha256']
 a=original.read_text(encoding='utf-8');z=candidate.read_text(encoding='utf-8');old_functions=Counter(re.findall(r'\bfn\s+(\w+)\s*\(',a));new_functions=Counter(re.findall(r'\bfn\s+(\w+)\s*\(',z));assert not old_functions-new_functions,(rel,old_functions-new_functions)
 old_assert=assertion_tokens(a);new_assert=assertion_tokens(z);missing=Counter(old_assert)-Counter(new_assert)
 if candidate.name=='lease_complete_tests.rs':
  assert sum(missing.values())==3
  for kind in ('blob','clob','n_clob'):
   expected='expected_'+kind;old=[x for x in missing if expected in x];new=[x for x in new_assert if expected in x]
   assert len(old)==len(new)==1 and 'create_'+kind in old[0] and 'from_ref' in new[0]
   assert 'actual_'+kind in new[0] and 'usize' in new[0]
  assert len(old_assert)==47 and len(new_assert)==50
 else:assert not missing,(rel,missing)
 if candidate.name=='standard_unwrapped_mut.rs':
  restored=z.replace('use crate::extensions::{RowSet, RowSetMetaData};\n','').replace('    /// 同一行集的标准接口，继承 ResultSet。\n    RowSet(&\'a mut dyn RowSet),\n','').replace('    /// 行集元数据标准接口；setter作用于同一原对象。\n    RowSetMetaData(&\'a mut dyn RowSetMetaData),\n','');assert restored==a
 if candidate.name=='connection.inc.rs':
  restored=z
  for kind in ('Blob','Clob','NClob'):restored=restored.replace('Result<Box<dyn '+kind+'>, RdbcError>','Result<Rdbc'+kind+', RdbcError>')
  assert restored==a
 assertions_old+=len(old_assert);assertions_new+=len(new_assert)
 for root,source in (('e-preimage',original),('resolved-review',candidate)):
  target=d/root/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target);assert sha(target)==sha(source)
 patch=d/'diffs'/(rel+'.patch');patch.parent.mkdir(parents=True,exist_ok=True);patch.write_text(''.join(difflib.unified_diff(a.splitlines(True),z.splitlines(True),fromfile='E/'+rel,tofile='desired/'+rel)),encoding='utf-8')
 rows.append(dict(path=rel,e_preimage_sha256=sha(original),desired_sha256=sha(candidate),original_function_count=sum(old_functions.values()),missing_functions=[],added_functions=list((new_functions-old_functions).elements()),assertions_before=len(old_assert),assertions_after=len(new_assert),original_assertions_token_exact=len(old_assert)-sum(missing.values()),identity_assertions_migrated=sum(missing.values()),review=notes[candidate.name],state='STATIC_RECONCILIATION_DRAFT_NOT_RUNTIME_ACCEPTANCE',applied=False))
assert all(sha(w/p)==h for p,h in frozen.items());assert all(sha(e/r['path'])==r['e_preimage_sha256'] for r in rows)
s=dict(scope='THIRTEEN_RESIDUAL_EXISTING_FILE_RECONCILIATIONS',production_applied=False,files=rows,reviewed=13,prior_static_reviews=55,current_differing_source_reviews=68,assertions_before=assertions_old,assertions_after=assertions_new,token_exact_original_assertions=assertions_old-3,migrated_identity_assertions=3,frozen_inputs_changed=0,original_methods_removed=0,compiler_or_runtime_certified=False,sqlxml_fixture_identity_change_explicit=True)
(d/'summary.json').write_text(json.dumps(s,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(d/'report.md').write_text('# 剩余13文件静态集成审阅\n\n12个E已存在未跟踪文件与1个HEAD原件均逐项保存preimage，候选desired及完整diff。原方法名计数无删除；原'+str(assertions_old)+'断言中'+str(assertions_old-3)+'逐token保留，三项LOB等价迁移为同Box数据地址并补三项长度断言。Wrapper mutable视图和生成Connection夹具分别逆变换到完整E原字节。\n\n资源接口mutable/Box/同资源pattern与SQLXML名称OUT独立对象属于显式迁移，不能由静态审阅认证行为。仍需当前完整C1/C2、Wrapper及Callable回归、API与正式集成验证。13项审阅使68个差异源码都有静态处置依据，未覆盖任何E修改，未apply、无Cargo、1277冻结不变。\n',encoding='utf-8')
files={str(p.relative_to(d)).replace('\\','/'):p for p in d.rglob('*') if p.is_file()};files['runner381.py']=Path(__file__);entries={n:sha(p) for n,p in files.items()};z=b/'task7-integration-residual-review382.zip';assert not z.exists()
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as archive:
 for n,p in files.items():archive.write(p,n)
 archive.writestr('manifest.json',json.dumps(entries,indent=2))
with zipfile.ZipFile(z) as archive:assert all(hashlib.sha256(archive.read(n)).hexdigest()==h for n,h in entries.items())
receipt=b/'task7-integration-residual-review382.summary.json';receipt.write_text(json.dumps(dict(sha256=sha(z),verified_entries=len(entries),reviewed=13,production_applied=False),indent=2)+'\n',encoding='utf-8')
for p in (z,receipt):
 target=e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'/p.name;assert not target.exists();shutil.copyfile(p,target);assert sha(p)==sha(target)
note='2026-10-09 剩余13文件静态集成审阅381/382：12个E已有未跟踪文件及1个HEAD原件逐项保存preimage/desired/diff；原方法无删除，'+str(assertions_old-3)+'/'+str(assertions_old)+'断言逐token保留，3个LOB身份断言迁移为同Box数据地址并补3个长度断言。两文件完整逆变换相同；SQLXML名称OUT独立对象迁移明确保留运行待验收边界。68个差异源码均有静态草稿，不等于行为/API/正式集成通过；1277冻结变化0、无Cargo、未apply。zip382 SHA '+sha(z)+'全部条目/E镜像核验，319仍继续、18顶层OPEN。'
for rel in ('.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md','docs/verification/rdbc-first/status.md','docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md'):
 with (e/rel).open('ab') as out:out.write(('\n\n'+note+'\n').encode('utf-8'))
print(json.dumps(dict(reviewed=len(rows),assertions_before=assertions_old,assertions_after=assertions_new,zip_sha256=sha(z))))
