from pathlib import Path
import hashlib
import json
import re
import shutil
import zipfile

b = Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
w = Path('F:/codex_build_cache/d177')
e = Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust')
review = b / 'task7-integration-three-way242'
out = b / 'task7-integration-resource-resolution269'
out.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
inventory = json.loads((review / 'summary.json').read_text())
frozen = json.loads((b / 'task7-unconfirmed-release-queued-green238/frozen-inputs.json').read_text())

def methods(text):
    return {m.group(1): ' '.join(m.group(0).split()) for m in re.finditer(r'pub\s+(?:(?:async|const)\s+)?fn\s+(\w+)\s*\([^{}]*?(?:\{|;)', text)}

mapping = [
    ('array.rs', 'rdbc_array.rs', 'Array', 17),
    ('blob.rs', 'rdbc_blob.rs', 'Blob', 14),
    ('clob.rs', 'rdbc_clob.rs', 'Clob', 16),
    ('n_clob.rs', 'rdbc_n_clob.rs', 'NClob', 17),
    ('ref_value.rs', 'rdbc_ref.rs', 'Ref', 9),
    ('sql_xml.rs', 'rdbc_sql_xml.rs', 'SqlXml', 15),
]
rows = []
support = {}
for old_name, new_name, trait, count in mapping:
    rel = 'crates/druid-rdbc/src/resource/' + old_name
    record = next(x for x in inventory['files'] if x['path'] == rel)
    assert record['merge_status'] == 'TEXT_MERGE_CONFLICT'
    current, candidate = (review / 'merge-inputs' / rel / name for name in ('current', 'candidate'))
    assert sha(current) == record['e_sha256'] == sha(e / rel)
    assert sha(candidate) == record['candidate_sha256'] == sha(w / rel) == frozen[rel]
    handle_rel = 'crates/druid-rdbc/src/resource/' + new_name
    assert sha(w / handle_rel) == frozen[handle_rel]
    before, after = methods(current.read_text()), methods((w / handle_rel).read_text())
    assert len(before) == count and not (before.keys() - after.keys())
    changes = {name: dict(old=before[name], new=after[name]) for name in before if before[name] != after[name]}
    additions = sorted(after.keys() - before.keys())
    if trait == 'SqlXml':
        assert set(changes) == {'source', 'result'}
        assert additions == ['validate_for_binding']
        for change in changes.values():
            assert change['new'].replace('Option<&RdbcXmlRepresentationType>', '&RdbcXmlRepresentationType') == change['old']
    else:
        assert not changes and not additions
    assert re.search(r'pub trait ' + trait + r'\b', candidate.read_text())
    assert not re.search(r'\bRdbc\w*Access\b', candidate.read_text())
    dest = out / 'resolved-review' / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(candidate, dest)
    rows.append(dict(path=rel, e_preimage_sha256=sha(current), candidate_sha256=sha(candidate), resolved_review_sha256=sha(dest), handle_path=handle_rel, handle_sha256=sha(w / handle_rel), original_public_method_count=count, original_method_names_all_present=True, original_signature_changes=changes, added_handle_methods=additions, resolution='Standard trait replaces alias/access layer; original value-handle public methods move to one-type-per-file implementation.', applied=False))
    support[handle_rel] = w / handle_rel

rel = 'crates/druid-rdbc/src/resource/rdbc_resource_factory.rs'
record = next(x for x in inventory['files'] if x['path'] == rel)
current, candidate = (review / 'merge-inputs' / rel / name for name in ('current', 'candidate'))
assert record['merge_status'] == 'TEXT_MERGE_CONFLICT'
assert sha(current) == record['e_sha256'] == sha(e / rel)
assert sha(candidate) == record['candidate_sha256'] == sha(w / rel) == frozen[rel]
before, after = methods(current.read_text()), methods(candidate.read_text())
assert set(before) == {'array', 'blob', 'clob', 'n_clob', 'reference', 'sql_xml'}
assert set(after) == set(before) | {'structure'}
traits = dict(array='Array', blob='Blob', clob='Clob', n_clob='NClob', reference='Ref', sql_xml='SqlXml', structure='Struct')
for name, trait in traits.items():
    expected = 'pub fn ' + name + '(value: Box<dyn ' + trait + '>) -> Rdbc' + trait + ' {'
    assert after[name] == expected
    assert ('Rdbc' + trait + '::from_standard(value)') in candidate.read_text()
dest = out / 'resolved-review' / rel
dest.parent.mkdir(parents=True, exist_ok=True)
shutil.copyfile(candidate, dest)
rows.append(dict(path=rel, e_preimage_sha256=sha(current), candidate_sha256=sha(candidate), resolved_review_sha256=sha(dest), original_public_method_names_all_present=True, original_public_methods=before, final_public_methods=after, resolution='Factory takes exclusive standard trait objects; Druid connection-bound runtime ownership remains above the standard crate.', applied=False))
for name in ('standard_resource_value.rs', 'standard_resource_release_guard.rs'):
    rel = 'crates/druid-rdbc/src/resource/' + name
    assert sha(w / rel) == frozen[rel]
    support[rel] = w / rel

for row in rows:
    assert sha(e / row['path']) == row['e_preimage_sha256']
    assert sha(w / row['path']) == row['candidate_sha256']
for rel, p in support.items():
    assert sha(p) == frozen[rel]
summary = dict(scope='SEVEN_RESOURCE_CONFLICT_STATIC_DISPOSITIONS_NOT_API_OR_BEHAVIOR_CERTIFICATION', production_applied=False, previous268_sha256=sha(b / 'task7-integration-result-object-resolution268.zip'), parent240_sha256=sha(b / 'task7-unconfirmed-release-terminal240.zip'), rows=rows, support_sources={rel: sha(p) for rel, p in support.items()}, original_handle_methods=88, unchanged_handle_signatures=86, explicitly_changed_nullable_sqlxml_signatures=2, unresolved_of_original43=22, limitations=['Method identity/signature correspondence is not implementation behavior equivalence.', 'Old alias-to-trait and factory parameter changes require final public API/SemVer allowlist.', 'Private old context constructors retire only with approved runtime ownership migration and final integrated tests.', 'Complete C1/C2 and final integrated workspace validation remain required.'])
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
z = b / 'task7-integration-resource-resolution270.zip'
assert not z.exists()
files = {str(p.relative_to(out)).replace('\\', '/'): p for p in out.rglob('*') if p.is_file()}
files.update({'support-sources/' + rel: p for rel, p in support.items()})
files['runner269.py'] = Path(__file__)
manifest = {name: sha(p) for name, p in files.items()}
with zipfile.ZipFile(z, 'w', zipfile.ZIP_DEFLATED) as archive:
    for name, p in files.items():
        archive.write(p, name)
    archive.writestr('manifest.json', json.dumps(manifest, indent=2))
with zipfile.ZipFile(z) as archive:
    assert all(hashlib.sha256(archive.read(name)).hexdigest() == digest for name, digest in manifest.items())
receipt = b / 'task7-integration-resource-resolution270.summary.json'
receipt.write_text(json.dumps(dict(scope=summary['scope'], sha256=sha(z), verified_entries=len(manifest), production_applied=False), indent=2) + '\n')
for p in (z, receipt):
    dest = e / '.superpowers/sdd/2026-08-24-rdbc-single-standard-unification' / p.name
    assert not dest.exists()
    shutil.copyfile(p, dest)
    assert sha(p) == sha(dest)
note = ('2026-10-09 七项资源冲突静态处置269/270：Array/Blob/Clob/NClob/Ref/SQLXML旧值句柄88个公开方法全部在新一对象一文件实现中找到，86签名不变，仅SQLXML source/result显式接纳nullable表示请求；新增validate_for_binding。Factory原六公开名称保留并明确迁移Box<dyn标准trait>参数，新增Struct入口。逐项冻结E preimage、242标准trait稿、新值句柄及240同源生命周期实现SHA；zip270 SHA ' + sha(z) + '，全部条目/E镜像核验。此为方法对应及迁移处置，不证明行为等价或SemVer兼容，旧私有context构造器退休仍依赖正式owner迁移与最终门禁。原43冲突累计21项处置草稿，另22项待审阅；未apply正式源码；18顶层OPEN。')
for rel in ('.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md', 'docs/verification/rdbc-first/status.md', 'docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md'):
    with (e / rel).open('ab') as stream:
        stream.write(('\n\n' + note + '\n').encode('utf-8'))
print(json.dumps(dict(reviewed=len(rows), unresolved=22, old_handle_methods=88, unchanged_signatures=86, zip_sha256=sha(z), applied=False)))
