from pathlib import Path
import hashlib
import importlib.util
import json
import re
import shutil
import sys
import zipfile

sys.dont_write_bytecode = True
b = Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
w = Path('F:/codex_build_cache/d177')
e = Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust')
review = b / 'task7-integration-three-way242'
out = b / 'task7-integration-result-object-resolution267'
out.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
lexer_path = w / 'scripts/verify_rdbc_public_paths.py'
spec = importlib.util.spec_from_file_location('integration_lexer267', lexer_path)
lexer = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = lexer
spec.loader.exec_module(lexer)
tokens = lambda text: [(t.kind, t.text) for t in lexer.tokenize(text)]
inventory = json.loads((review / 'summary.json').read_text())

def remove_function(text, name):
    found = list(re.finditer(r'(?m)^\s*(?:pub(?:\(crate\))?\s+)?(?:async\s+)?fn\s+' + re.escape(name) + r'(?:<[^>]+>)?\s*\(', text))
    assert len(found) == 1, (name, len(found))
    start = found[0].start()
    body = text.index('{', found[0].end())
    depth, end = 1, body + 1
    while depth:
        depth += (text[end] == '{') - (text[end] == '}')
        end += 1
    return text[:start] + text[end:]

paths = [
    'crates/druid-rdbc/src/result_set/result_set.rs',
    'crates/druid-rdbc/src/result_set/result_set_ext.rs',
    'crates/druid-rdbc/src/statement/prepared_input_parameter.rs',
    'crates/druid-rdbc/src/types/rdbc_object.rs',
]
rows = []
for rel in paths:
    record = next(x for x in inventory['files'] if x['path'] == rel)
    assert record['merge_status'] == 'TEXT_MERGE_CONFLICT'
    current, candidate = (review / 'merge-inputs' / rel / name for name in ('current', 'candidate'))
    assert sha(current) == record['e_sha256'] == sha(e / rel)
    assert sha(candidate) == record['candidate_sha256'] == sha(w / rel)
    old, new = current.read_text(), candidate.read_text()
    normalized = new
    if rel.endswith('/result_set.rs'):
        normalized = remove_function(normalized, 'release_owned')
        changes = ['added consuming release_owned default drops the unique cursor; pooled implementations may override cleanup handoff']
    elif rel.endswith('/result_set_ext.rs'):
        normalized = remove_function(normalized, 'into_stream')
        addition = 'use super::owned_result_set::OwnedResultSet;'
        assert normalized.count(addition) == 1
        normalized = normalized.replace(addition, '')
        changes = ['added owning into_stream adapter and OwnedResultSet import; original getters/conversions remain unchanged']
    elif rel.endswith('/prepared_input_parameter.rs'):
        addition = '            | RdbcObject::Struct(_)\n'
        assert normalized.count(addition) == 1
        normalized = normalized.replace(addition, '')
        changes = ['added Struct to existing scalar-conversion refusal arm; original resource/opaque-value refusal cases unchanged']
    else:
        normalized, count = re.subn(r'use crate::resource::\{[^}]+\};', 'use crate::resource::{RdbcArray, RdbcBlob, RdbcClob, RdbcNClob, RdbcReader, RdbcRef, RdbcSqlXml};', normalized, count=1)
        assert count == 1
        for addition in ('    Struct(RdbcStruct),\n', '            Self::Struct(_) => formatter.write_str("<Struct>"),\n'):
            assert normalized.count(addition) == 1
            normalized = normalized.replace(addition, '')
        changes = ['added RdbcStruct import, Struct enum variant and non-materializing Display arm; original variants unchanged']
    assert tokens(old) == tokens(normalized), rel
    dest = out / 'resolved-review' / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(candidate, dest)
    rows.append(dict(path=rel, e_preimage_sha256=sha(current), candidate_sha256=sha(candidate), resolved_review_sha256=sha(dest), explicit_changes=changes, other_complete_file_tokens_preserved=True, retained_tokens_sha256=hashlib.sha256(json.dumps(tokens(old)).encode()).hexdigest(), applied=False))

for row in rows:
    assert sha(e / row['path']) == row['e_preimage_sha256']
    assert sha(w / row['path']) == row['candidate_sha256']
summary = dict(scope='FOUR_RESULT_AND_OBJECT_CONFLICT_DISPOSITIONS_STATIC_NOT_ACCEPTANCE', production_applied=False, previous266_sha256=sha(b / 'task7-integration-lease-context-resolution266.zip'), lexer_sha256=sha(lexer_path), rows=rows, unresolved_of_original43=29, limitations=['Existing token preservation does not prove new cursor ownership/drop behavior.', 'Struct variant addition requires public API/SemVer verification.', 'Final integrated runtime, complete C1/C2 and workspace gates remain required.'])
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
z = b / 'task7-integration-result-object-resolution268.zip'
assert not z.exists()
files = {str(p.relative_to(out)).replace('\\', '/'): p for p in out.rglob('*') if p.is_file()}
files['runner267.py'] = Path(__file__)
manifest = {name: sha(p) for name, p in files.items()}
with zipfile.ZipFile(z, 'w', zipfile.ZIP_DEFLATED) as archive:
    for name, p in files.items():
        archive.write(p, name)
    archive.writestr('manifest.json', json.dumps(manifest, indent=2))
with zipfile.ZipFile(z) as archive:
    assert all(hashlib.sha256(archive.read(name)).hexdigest() == digest for name, digest in manifest.items())
receipt = b / 'task7-integration-result-object-resolution268.summary.json'
receipt.write_text(json.dumps(dict(scope=summary['scope'], sha256=sha(z), verified_entries=len(manifest), production_applied=False), indent=2) + '\n')
for p in (z, receipt):
    dest = e / '.superpowers/sdd/2026-08-24-rdbc-single-standard-unification' / p.name
    assert not dest.exists()
    shutil.copyfile(p, dest)
    assert sha(p) == sha(dest)
note = ('2026-10-09 四项结果集/对象冲突处置267/268：ResultSet新增release_owned，ResultSetExt新增owning Stream适配；PreparedInputParameter仅把Struct加入原标量拒绝分支；RdbcObject新增Struct variant及不物化Display。逐项明确排除这些新增部分后，四份完整文件其余token与E原件完全相同；preimage/候选SHA前后核验。zip268 SHA ' + sha(z) + '，全部条目/E镜像核验。原43冲突累计14项静态处置草稿，另29项待审阅；新增游标释放行为与enum API仍须最终runtime/SemVer/C1/C2门禁。未apply正式源码；18顶层OPEN。')
for rel in ('.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md', 'docs/verification/rdbc-first/status.md', 'docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md'):
    with (e / rel).open('ab') as stream:
        stream.write(('\n\n' + note + '\n').encode('utf-8'))
print(json.dumps(dict(reviewed=len(rows), unresolved=29, zip_sha256=sha(z), verified_entries=len(manifest), applied=False)))
