from pathlib import Path
import collections
import hashlib
import importlib.util
import json
import shutil
import sys
import zipfile

sys.dont_write_bytecode = True
b = Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
w = Path('F:/codex_build_cache/d177')
e = Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust')
review = b / 'task7-integration-three-way242'
out = b / 'task7-integration-test-resolution271'
out.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
lexer_path = w / 'scripts/verify_rdbc_public_paths.py'
spec = importlib.util.spec_from_file_location('integration_lexer271', lexer_path)
lexer = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = lexer
spec.loader.exec_module(lexer)
lex = lambda text: [t.text for t in lexer.tokenize(text)]
inventory = json.loads((review / 'summary.json').read_text())
frozen = json.loads((b / 'task7-unconfirmed-release-queued-green238/frozen-inputs.json').read_text())

def functions(text):
    tokens = lex(text)
    result = collections.defaultdict(list)
    for i, token in enumerate(tokens[:-1]):
        if token != 'fn':
            continue
        name = tokens[i + 1]
        j = i + 2
        while j < len(tokens) and tokens[j] not in ('{', ';'):
            j += 1
        if j == len(tokens) or tokens[j] == ';':
            continue
        start, depth = j, 1
        j += 1
        while depth and j < len(tokens):
            depth += (tokens[j] == '{') - (tokens[j] == '}')
            j += 1
        assert depth == 0
        result[name].append(tokens[start:j])
    return result

def assertions(bodies):
    result = collections.Counter()
    for tokens in bodies:
        for i, token in enumerate(tokens[:-2]):
            if token not in ('assert', 'assert_eq', 'assert_ne', 'assert_matches', 'debug_assert', 'debug_assert_eq', 'debug_assert_ne') or tokens[i + 1] != '!':
                continue
            assert tokens[i + 2] in ('(', '[', '{')
            j, depth = i + 2, 0
            while j < len(tokens):
                depth += (tokens[j] in ('(', '[', '{')) - (tokens[j] in (')', ']', '}'))
                j += 1
                if depth == 0:
                    break
            assert depth == 0
            result[tuple(tokens[i:j])] += 1
    return result

migration_function = 'task6_pool_deep_branch_coverage_test_spi_resource_access_default_free_returns_ok'
old_assertion = tuple(lex('assert!(<StubArrayAccess as RdbcResourceAccess>::free(&access).await.is_ok())'))
new_assertion = tuple(lex('assert!(<StubArrayAccess as Array>::free(&mut access).await.is_ok())'))
rows = []
for record in inventory['files']:
    rel = record['path']
    if record.get('merge_status') != 'TEXT_MERGE_CONFLICT' or '/tests/' not in rel:
        continue
    current, candidate = (review / 'merge-inputs' / rel / name for name in ('current', 'candidate'))
    assert sha(current) == record['e_sha256'] == sha(e / rel)
    assert sha(candidate) == record['candidate_sha256'] == sha(w / rel) == frozen[rel]
    before, after = functions(current.read_text()), functions(candidate.read_text())
    removed = set(before) - set(after)
    assert removed <= {'fmt'}
    if removed:
        assert len(before['fmt']) == 6
        assert candidate.read_text().count('#[derive(Debug)]') >= 6
    details = []
    for name, bodies in before.items():
        old = assertions(bodies)
        new = assertions(after.get(name, []))
        migrated = False
        if rel.endswith('task6_pool_deep_branch_coverage_test_parity_part_06.rs') and name == migration_function:
            assert old == collections.Counter({old_assertion: 1})
            assert new == collections.Counter({new_assertion: 1})
            new = collections.Counter({old_assertion: 1})
            migrated = True
        assert not (old - new), (rel, name, old - new)
        if old:
            details.append(dict(function=name, old_assertion_count=sum(old.values()), preserved_at_same_function=True, explicit_standard_port_migration=migrated, original_assertion_tokens_sha256=hashlib.sha256(json.dumps(sorted((list(key), value) for key, value in old.items())).encode()).hexdigest()))
    dest = out / 'resolved-review' / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(candidate, dest)
    rows.append(dict(path=rel, e_preimage_sha256=sha(current), candidate_sha256=sha(candidate), resolved_review_sha256=sha(dest), removed_function_names=sorted(removed), removed_debug_fmt_count=len(before.get('fmt', [])) if removed else 0, original_assertion_count=sum(x['old_assertion_count'] for x in details), original_assertions_by_function=details, added_function_names=sorted(set(after) - set(before)), applied=False))

assert len(rows) == 17
assert sum(row['removed_debug_fmt_count'] for row in rows) == 42
assert sum(x['explicit_standard_port_migration'] for row in rows for x in row['original_assertions_by_function']) == 1
for row in rows:
    assert sha(e / row['path']) == row['e_preimage_sha256']
    assert sha(w / row['path']) == row['candidate_sha256']
total = sum(row['original_assertion_count'] for row in rows)
summary = dict(scope='SEVENTEEN_TEST_CONFLICT_STATIC_ASSERTION_DISPOSITIONS_NOT_EXECUTION_OR_PARITY_CERTIFICATION', production_applied=False, previous270_sha256=sha(b / 'task7-integration-resource-resolution270.zip'), lexer_sha256=sha(lexer_path), rows=rows, original_assertions_checked_at_same_function=total, explicitly_migrated_assertions=1, removed_debug_formatter_helpers=42, unresolved_of_original43=5, limitations=['Assertions at the same function do not prove fixtures, setup, cfg, reachability or runtime behavior equivalence.', 'Old default Access free is now explicit standard Array fixture free; this migration is recorded rather than hidden as identical.', 'Generated/inc files require their actual parent runtime test entrypoints.', 'Complete original C1/C2 and final integrated compiler/runtime validation remain required.'])
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
z = b / 'task7-integration-test-resolution272.zip'
assert not z.exists()
files = {str(p.relative_to(out)).replace('\\', '/'): p for p in out.rglob('*') if p.is_file()}
files['runner271.py'] = Path(__file__)
manifest = {name: sha(p) for name, p in files.items()}
with zipfile.ZipFile(z, 'w', zipfile.ZIP_DEFLATED) as archive:
    for name, p in files.items():
        archive.write(p, name)
    archive.writestr('manifest.json', json.dumps(manifest, indent=2))
with zipfile.ZipFile(z) as archive:
    assert all(hashlib.sha256(archive.read(name)).hexdigest() == digest for name, digest in manifest.items())
receipt = b / 'task7-integration-test-resolution272.summary.json'
receipt.write_text(json.dumps(dict(scope=summary['scope'], sha256=sha(z), verified_entries=len(manifest), production_applied=False), indent=2) + '\n')
for p in (z, receipt):
    dest = e / '.superpowers/sdd/2026-08-24-rdbc-single-standard-unification' / p.name
    assert not dest.exists()
    shutil.copyfile(p, dest)
    assert sha(p) == sha(dest)
note = ('2026-10-09 十七项测试冲突静态处置271/272：按所属函数逐项核验原' + str(total) + '个assert宏，除唯一旧Access free调用迁移为标准Array free的明确记录外，原断言token/重复次数均在同名函数保留；未用全文件总数替代所属函数。原函数名仅移除42个Debug fmt helper并改derive，测试名未发现删除。保存17份完整resolved-review，zip272 SHA ' + sha(z) + '，全部条目/E镜像核验。此检查不证明夹具、setup、cfg、可达性或运行行为等价，仍须原完整C1/C2及最终集成编译运行。原43冲突累计38项静态处置草稿，剩五处生产冲突待审阅；未apply正式源码；18顶层OPEN。')
for rel in ('.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md', 'docs/verification/rdbc-first/status.md', 'docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md'):
    with (e / rel).open('ab') as stream:
        stream.write(('\n\n' + note + '\n').encode('utf-8'))
print(json.dumps(dict(reviewed=len(rows), unresolved=5, original_assertions=total, explicit_migrations=1, zip_sha256=sha(z), applied=False)))
