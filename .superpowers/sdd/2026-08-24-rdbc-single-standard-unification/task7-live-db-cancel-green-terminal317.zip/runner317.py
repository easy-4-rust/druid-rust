from pathlib import Path
import hashlib,json,shutil,subprocess,zipfile
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d177');e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
d=b/'task7-live-db-contracts315';s=json.loads((d/'summary.json').read_text());assert s['terminal'] and s['exit_code']==0 and len(s['commands'])==3
for c in s['commands']:
 assert c['exit_code']==0 and c['passed']==1 and c['failed']==0 and not c['changed_inputs'] and sha(Path(c['log']))==c['sha256']
 if c['profile']!='mysql-session-timestamp':assert 'owned database restart readiness and unchanged published endpoint confirmed' in Path(c['log']).read_text()
for c in s['containers']:
 assert c['explicit_stable_port'] and c['removed'] and subprocess.run(['docker','inspect',c['container_id']],capture_output=True).returncode!=0
f=json.loads((d/'frozen-inputs.json').read_text());assert len(f)==1277 and all(sha(w/p)==h for p,h in f.items())
files={'runner317.py':Path(__file__)}
for p in d.iterdir():
 if p.is_file():files['evidence/'+p.name]=p
for name in ('task7-live-db-stable-port-builder313.py','task7-live-db-contracts315.py','task7-live-db-restart314.py'):files['runners/'+name]=b/name
for rel in ('crates/druid-wrapper/src/sqlx/sqlx_prepared_statement.rs','crates/druid-wrapper/src/sqlx/sqlx_connection_adapter.rs','crates/druid-wrapper/tests/sqlx_statement_cancel_contract_test.rs','crates/druid-wrapper/tests/sqlx_mysql_timestamp_session_contract_test.rs'):files['candidate/'+rel]=w/rel
scope=dict(scope='ORIGINAL_REQUIRED_POSTGRESQL_MYSQL_FULL_CONTRACTS_AND_MYSQL_TIMESTAMP_GREEN',production_applied=False,parent308_sha256=sha(b/'task7-sqlx-cancel-validation-terminal308.zip'),parent312_sha256=sha(b/'task7-live-db-port-drift-terminal312.zip'),frozen_input_count=len(f),original_database_contract_unchanged=True,fixture_only_retry='EXPLICIT_STABLE_LOOPBACK_PORT_AND_RESTART_HOST_ENDPOINT',full_workspace='NOT_CERTIFIED',concurrent_server_side_cancel='NOT_CERTIFIED')
z=b/'task7-live-db-cancel-green-terminal317.zip';assert not z.exists();manifest={n:sha(p) for n,p in files.items()}
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as out:
 for n,p in files.items():out.write(p,n)
 out.writestr('manifest.json',json.dumps(manifest,indent=2));out.writestr('scope.json',json.dumps(scope,indent=2))
with zipfile.ZipFile(z) as out:assert all(hashlib.sha256(out.read(n)).hexdigest()==h for n,h in manifest.items())
receipt=b/'task7-live-db-cancel-green-terminal317.summary.json';receipt.write_text(json.dumps(dict(scope,sha256=sha(z),verified_entries=len(manifest)),indent=2)+'\n',encoding='utf-8')
for p in (z,receipt):
 q=e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'/p.name;assert not q.exists();shutil.copyfile(p,q);assert sha(p)==sha(q)
note='2026-10-09 取消候选配置实库315完整GREEN终态317：原PG/MySQL完整合同各1/0，独立必配MySQL时间合同1/0；原超时、显式cancel、坏凭据、类型、事务/保存点、batch、回收/缓存、重启读已提交数据及清理断言保留。仅修夹具显式随机loopback端口，重启前后映射及主机TCP现场核验，原306漂移中止312保留。1277冻结输入变化0，两自有容器移除并inspect确认。zip317 SHA '+sha(z)+'全部条目/E镜像核验。原实库cancel合同为执行前请求，不扩大为server-side并发中断；完整全仓/API/C1/C2仍须新鲜后继，正式E源码未apply，18顶层OPEN。'
for rel in ('.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md','docs/verification/rdbc-first/status.md','docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md'):
 with (e/rel).open('ab') as out:out.write(('\n\n'+note+'\n').encode('utf-8'))
print(json.dumps(dict(zip_sha256=sha(z),verified_entries=len(manifest))))
