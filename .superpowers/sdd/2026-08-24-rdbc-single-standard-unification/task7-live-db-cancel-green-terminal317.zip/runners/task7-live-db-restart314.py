import json,os,socket,subprocess,sys,time
container,profile,expected_port=sys.argv[1:]
internal='5432/tcp' if profile=='postgresql' else '3306/tcp'
def verify_endpoint():
 info=json.loads(subprocess.check_output(['docker','inspect',container],text=True))[0]
 assert info['Config']['Labels'].get('codex.druid.task')=='task7-live-db315'
 assert info['Config']['Labels'].get('codex.druid.profile')==profile
 ports=info['NetworkSettings']['Ports'][internal]
 assert len(ports)==1 and ports[0]['HostIp']=='127.0.0.1' and ports[0]['HostPort']==expected_port,'owned published port drifted'
 return info
verify_endpoint()
subprocess.run(['docker','restart','--time','3',container],check=True,capture_output=True)
for attempt in range(120):
 command=['docker','exec',container,'pg_isready','-h','127.0.0.1','-U','druid','-d','druid_contract'] if profile=='postgresql' else ['docker','exec',container,'mysqladmin','--host=127.0.0.1','--protocol=tcp','-uroot','-p'+os.environ['DRUID_LIVE_DB_ROOT_PASSWORD'],'ping','--silent']
 result=subprocess.run(command,capture_output=True)
 if result.returncode==0:
  verify_endpoint()
  with socket.create_connection(('127.0.0.1',int(expected_port)),timeout=5):pass
  print('owned database restart readiness and unchanged published endpoint confirmed',profile,flush=True)
  break
 time.sleep(1)
else:raise RuntimeError('owned database not ready after restart')
