from pathlib import Path
import hashlib,json
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d177');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
s=json.loads((b/'task7-live-db-contracts306/summary.json').read_text());assert s['terminal'] and all(c['removed'] for c in s['containers'])
f=json.loads((b/'task7-live-db-contracts306/frozen-inputs.json').read_text());assert len(f)==1277 and all(sha(w/p)==h for p,h in f.items())
src=(b/'task7-live-db-contracts306.py').read_text().replace('import ctypes,hashlib,json,os,re,subprocess,sys,time,uuid','import ctypes,hashlib,json,os,re,socket,subprocess,sys,time,uuid').replace('task7-live-db-contracts306','task7-live-db-contracts315').replace('task7-live-db306','task7-live-db315').replace('codex-druid-306-','codex-druid-315-').replace('task7-live-db-restart307.py','task7-live-db-restart314.py').replace('LIVE_DB306_TERMINAL','LIVE_DB315_TERMINAL')
old="name='codex-druid-315-'+profile+'-'+uuid.uuid4().hex[:10];args="
new="reservation=socket.socket();reservation.bind(('127.0.0.1',0));requested_port=reservation.getsockname()[1]\n   name='codex-druid-315-'+profile+'-'+uuid.uuid4().hex[:10];args="
assert src.count(old)==1;src=src.replace(old,new)
old="'127.0.0.1::'+str(internal)";assert src.count(old)==1;src=src.replace(old,"'127.0.0.1:'+str(requested_port)+':'+str(internal)")
old="args.append(images[tag]['Id']);container=docker(args);";assert src.count(old)==1;src=src.replace(old,"args.append(images[tag]['Id']);\n   try:container=docker(args)\n   finally:reservation.close()\n   ")
old="host_port=port['HostPort'];record['host_port']=host_port;save()";assert src.count(old)==1;src=src.replace(old,"host_port=port['HostPort'];assert host_port==str(requested_port);record['host_port']=host_port;record['explicit_stable_port']=True;save()")
old="str(b/'task7-live-db-restart314.py'),container,profile]";assert src.count(old)==1;src=src.replace(old,"str(b/'task7-live-db-restart314.py'),container,profile,host_port]")
dest=b/'task7-live-db-contracts315.py';assert not dest.exists();compile(src,str(dest),'exec');dest.write_text(src,encoding='utf-8')
print(json.dumps(dict(scope='FIXTURE_ONLY_EXPLICIT_LOOPBACK_PORT_AND_RESTART_ENDPOINT_PROOF',production_delta=0,frozen_inputs=len(f),runner_sha256=sha(dest),hook_sha256=sha(b/'task7-live-db-restart314.py'))))
