from pathlib import Path
import hashlib,json,shutil,subprocess,zipfile
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d177');e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
d=b/'task7-live-db-contracts285';s=json.loads((d/'summary.json').read_text());assert s['terminal'] and s['exit_code']==1 and len(s['commands'])==3
for c in s['commands']:
 assert sha(Path(c['log']))==c['sha256'] and not c['changed_inputs']
 if c['profile']=='mysql-session-timestamp':assert c['exit_code']==0 and c['passed']==1 and c['failed']==0
 else:
  assert c['exit_code']==101 and c['passed']==0 and c['failed']==1
  assert 'statement_cancel' in Path(c['log']).read_text() and 'contract-stage: timeout-cancel' in Path(c['log']).read_text()
for c in s['containers']:
 assert c['removed'] and subprocess.run(['docker','inspect',c['container_id']],capture_output=True).returncode!=0
f=json.loads((d/'frozen-inputs.json').read_text());assert len(f)==1276 and all(sha(w/p)==h for p,h in f.items())
files={'evidence/'+p.name:p for p in d.iterdir() if p.is_file()}
for name in ('task7-live-db-contracts285.py','task7-live-db-restart286.py','task7-live-db-control-retry-builder284.py'):
 files['runners/'+name]=b/name
files['runner287.py']=Path(__file__)
for rel in ('crates/druid-wrapper/src/sqlx/sqlx_prepared_statement.rs','crates/druid-wrapper/src/sqlx/sqlx_connection_adapter.rs','crates/druid-wrapper/tests/sqlx_mysql_timestamp_session_contract_test.rs'):
 files['candidate/'+rel]=w/rel
scope=dict(scope='BOTH_ORIGINAL_REAL_DATABASE_CONTRACTS_EXPLICIT_CANCEL_RUNTIME_RED',production_applied=False,parent283_sha256=s['parent283_sha256'],mysql_control='Original named savepoint and following assertions reached timeout-cancel stage after text protocol repair',mysql_session_contract='1PASS0FAIL required configured three timezones microseconds NULL buffered streaming',original_full_database_contracts='NOT_PASSED',frozen_inputs=1276)
z=b/'task7-live-db-cancel-red-terminal287.zip';assert not z.exists();manifest={n:sha(p) for n,p in files.items()}
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as out:
 for n,p in files.items():out.write(p,n)
 out.writestr('manifest.json',json.dumps(manifest,indent=2));out.writestr('scope.json',json.dumps(scope,indent=2))
with zipfile.ZipFile(z) as out:assert all(hashlib.sha256(out.read(n)).hexdigest()==h for n,h in manifest.items())
receipt=b/'task7-live-db-cancel-red-terminal287.summary.json';receipt.write_text(json.dumps(dict(scope,sha256=sha(z),verified_entries=len(manifest)),indent=2)+'\n',encoding='utf-8')
for p in (z,receipt):
 q=e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'/p.name;assert not q.exists();shutil.copyfile(p,q);assert sha(p)==sha(q)
note='2026-10-09 MySQL控制SQL修正285终态287：仅原连接MySQL控制入口从query prepared改Executor &str text；两个原实库合同均实际0/1失败于显式statement_cancel，MySQL已越过原保存点断言，原超时SQLState检查继续通过。独立必配MySQL三个时区/微秒/NULL/缓冲/流式合同再次1/0。1276冻结变化0、两自有容器移除并inspect确认，zip287 SHA '+sha(z)+'全条目/E镜像核验。完整PG/MySQL仍RED；不以capability=false、cancel no-op或close替代，下一步定向验证取消与语句/连接复用。正式源码未apply，18顶层OPEN。'
for rel in ('.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md','docs/verification/rdbc-first/status.md','docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md'):
 with (e/rel).open('ab') as out:out.write(('\n\n'+note+'\n').encode('utf-8'))
print(json.dumps(dict(zip_sha256=sha(z),verified_entries=len(manifest),mysql_session_passed=1,original_contracts_passed=False)))
