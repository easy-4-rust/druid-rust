from pathlib import Path
import hashlib,json
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d177');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
s=json.loads((b/'task7-live-db-contracts281/summary.json').read_text());assert s['terminal'] and s['exit_code']==1 and all(c['removed'] for c in s['containers'])
receipt=json.loads((b/'task7-live-db-next-red-terminal283.summary.json').read_text());assert sha(b/'task7-live-db-next-red-terminal283.zip')==receipt['sha256']
old=json.loads((b/'task7-live-db-retry280-frozen-inputs.json').read_text());new={p:sha(w/p) for p in old};delta={p:h for p,h in new.items() if old[p]!=h};assert set(delta)=={'crates/druid-wrapper/src/sqlx/sqlx_connection_adapter.rs'}
(b/'task7-live-db-retry284-frozen-inputs.json').write_text(json.dumps(new,indent=2)+'\n',encoding='utf-8')
total=json.loads((b/'task7-live-db-retry280-delta.json').read_text());total['source_delta'].update(delta);total.update(parent283_sha256=receipt['sha256'],mysql_control_only_delta=delta)
(b/'task7-live-db-retry284-delta.json').write_text(json.dumps(total,indent=2)+'\n',encoding='utf-8')
hook=(b/'task7-live-db-restart282.py').read_text().replace('task7-live-db281','task7-live-db285');(b/'task7-live-db-restart286.py').write_text(hook,encoding='utf-8')
runner=(b/'task7-live-db-contracts281.py').read_text().replace('task7-live-db-contracts281','task7-live-db-contracts285').replace('task7-live-db281','task7-live-db285').replace('codex-druid-281-','codex-druid-285-').replace('task7-live-db-restart282.py','task7-live-db-restart286.py').replace('LIVE_DB281_TERMINAL','LIVE_DB285_TERMINAL').replace('task7-live-db-retry280-frozen-inputs.json','task7-live-db-retry284-frozen-inputs.json').replace('task7-live-db-retry280-delta.json','task7-live-db-retry284-delta.json')
needle=" images=json.loads((b/'task7-live-db-images251.json').read_text());";assert runner.count(needle)==1
runner=runner.replace(needle," previous281=json.loads((b/'task7-live-db-contracts281/summary.json').read_text());assert previous281['terminal'] and all(c['removed'] for c in previous281['containers'])\n s['parent283_sha256']='"+receipt['sha256']+"'\n"+needle)
dest=b/'task7-live-db-contracts285.py';assert not dest.exists();compile(runner,str(dest),'exec');dest.write_text(runner,encoding='utf-8');print(json.dumps(dict(frozen=len(new),mysql_control_only_delta=delta,runner_sha256=sha(dest))))
