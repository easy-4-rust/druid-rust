from pathlib import Path
import hashlib, json

b = Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
w = Path('F:/codex_build_cache/d177')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
receipt = json.loads((b / 'task7-live-db-red-terminal273.summary.json').read_text())
assert sha(b / 'task7-live-db-red-terminal273.zip') == receipt['sha256']
old = json.loads((b / 'task7-live-db-contracts253/frozen-inputs.json').read_text())
new = {rel: sha(w / rel) for rel in old}
delta = {rel: digest for rel, digest in new.items() if old[rel] != digest}
assert set(delta) == {'crates/druid-wrapper/src/sqlx/sqlx_prepared_statement.rs', 'crates/druid-wrapper/src/sqlx/sqlx_connection_adapter.rs'}
test = 'crates/druid-wrapper/tests/sqlx_mysql_timestamp_session_contract_test.rs'
assert test not in new
new[test] = sha(w / test)
(b / 'task7-live-db-retry274-frozen-inputs.json').write_text(json.dumps(new, indent=2) + '\n', encoding='utf-8')
(b / 'task7-live-db-retry274-delta.json').write_text(json.dumps(dict(parent273_sha256=receipt['sha256'], source_delta=delta, added_test={test: new[test]}, production_applied=False), indent=2) + '\n', encoding='utf-8')
hook = (b / 'task7-live-db-restart254.py').read_text().replace('task7-live-db253', 'task7-live-db275')
(b / 'task7-live-db-restart276.py').write_text(hook, encoding='utf-8')
runner = (b / 'task7-live-db-contracts253.py').read_text()
runner = runner.replace('task7-live-db-contracts253', 'task7-live-db-contracts275').replace('task7-live-db253', 'task7-live-db275').replace('codex-druid-253-', 'codex-druid-275-').replace('task7-live-db-restart254.py', 'task7-live-db-restart276.py').replace('LIVE_DB253_TERMINAL', 'LIVE_DB275_TERMINAL')
start = runner.index(' while True:\n')
end = runner.index(' rt=Path(', start)
runner = runner[:start] + ''' parent=json.loads((b/'task7-live-db-contracts253/summary.json').read_text())
 guard=json.loads((b/'task7-final-candidate-workspace258/summary.json').read_text())
 assert parent['terminal'] and parent['exit_code']==1 and guard['terminal'] and guard['commands']==[]
 archive_receipt=json.loads((b/'task7-live-db-red-terminal273.summary.json').read_text())
 assert sha(b/'task7-live-db-red-terminal273.zip')==archive_receipt['sha256']
 f=json.loads((b/'task7-live-db-retry274-frozen-inputs.json').read_text());assert len(f)==1276 and all(sha(w/p)==h for p,h in f.items());(d/'frozen-inputs.json').write_text(json.dumps(f,indent=2)+'\\n',encoding='utf-8')
 images=json.loads((b/'task7-live-db-images251.json').read_text());s.update(frozen_input_count=len(f),parent273_sha256=archive_receipt['sha256'],restart_hook_sha256=sha(b/'task7-live-db-restart276.py'),image_manifest=images,source_delta=json.loads((b/'task7-live-db-retry274-delta.json').read_text()));s.pop('waiting_for',None);save()
''' + runner[end:]
needle = "   if result.returncode or c['passed']!=1 or c['failed'] or changed:failed=True\n"
assert runner.count(needle) == 1
extra = '''   if profile=='mysql':
    env['DRUID_MYSQL_TIMESTAMP_CONTRACT_REQUIRED']='1'
    cmd=[str(rt/'cargo.exe'),'test','-p','druid-wrapper','--test','sqlx_mysql_timestamp_session_contract_test','--locked','--offline','-j1','--','--exact','timestamp_preserves_mysql_session_fields_and_datetime_does_not_shift','--nocapture'];s['running_command']='mysql-session-timestamp';save();log=d/'mysql-session-timestamp.log';started=time.monotonic()
    with log.open('wb') as out:result=subprocess.run(cmd,cwd=w,env=env,stdout=out,stderr=subprocess.STDOUT)
    text=log.read_text(encoding='utf-8',errors='replace');counts=re.findall(r'test result: (?:ok|FAILED)\\. (\\d+) passed; (\\d+) failed;',text);changed=[p for p,h in f.items() if sha(w/p)!=h];c=dict(profile='mysql-session-timestamp',command=cmd,exit_code=result.returncode,elapsed_seconds=time.monotonic()-started,log=str(log),sha256=sha(log),passed=sum(int(a) for a,z in counts),failed=sum(int(z) for a,z in counts),changed_inputs=changed,required_profile_flag=True);s['commands'].append(c);save();print(json.dumps(c),flush=True)
    if result.returncode or c['passed']!=1 or c['failed'] or changed:failed=True
'''
runner = runner.replace(needle, needle + extra)
dest = b / 'task7-live-db-contracts275.py'
assert not dest.exists()
compile(runner, str(dest), 'exec')
dest.write_text(runner, encoding='utf-8')
print(json.dumps(dict(frozen=len(new), changed=list(delta), added=test, runner_sha256=sha(dest), hook_sha256=sha(b / 'task7-live-db-restart276.py'))))
