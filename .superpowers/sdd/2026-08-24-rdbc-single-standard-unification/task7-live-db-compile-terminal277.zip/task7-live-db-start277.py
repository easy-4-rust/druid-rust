from pathlib import Path
import hashlib, json, shutil, subprocess, zipfile

b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d177');e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
s=json.loads((b/'task7-live-db-contracts275/summary.json').read_text())
assert s['terminal'] and s['exit_code']==1 and len(s['commands'])==3
for c in s['commands']:
 assert c['exit_code']==101 and c['passed']==0 and c['failed']==0 and not c['changed_inputs']
 assert sha(Path(c['log']))==c['sha256'] and 'E0308' in Path(c['log']).read_text()
for c in s['containers']:
 assert c['removed'] and subprocess.run(['docker','inspect',c['container_id']],capture_output=True).returncode!=0
f=json.loads((b/'task7-live-db-retry274-frozen-inputs.json').read_text());assert len(f)==1276 and all(sha(w/p)==digest for p,digest in f.items())
files={p.name:p for p in (Path(__file__),b/'task7-live-db-retry-builder274.py',b/'task7-live-db-contracts275.py',b/'task7-live-db-restart276.py',b/'task7-live-db-retry274-frozen-inputs.json',b/'task7-live-db-retry274-delta.json')}
for p in (b/'task7-live-db-contracts275').iterdir():
 if p.is_file():files['evidence/'+p.name]=p
for rel in ('crates/druid-wrapper/src/sqlx/sqlx_prepared_statement.rs','crates/druid-wrapper/src/sqlx/sqlx_connection_adapter.rs','crates/druid-wrapper/tests/sqlx_mysql_timestamp_session_contract_test.rs'):
 files['source-delta/'+rel]=w/rel
z=b/'task7-live-db-compile-terminal277.zip';assert not z.exists();manifest={name:sha(p) for name,p in files.items()}
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as out:
 for name,p in files.items():out.write(p,name)
 out.writestr('manifest.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(z) as out:assert all(hashlib.sha256(out.read(name)).hexdigest()==digest for name,digest in manifest.items())
receipt=b/'task7-live-db-compile-terminal277.summary.json';receipt.write_text(json.dumps(dict(scope='COMPILE_FAILURE_E0308_MISSING_BOX_NOT_RUNTIME_RED_OR_GREEN',sha256=sha(z),verified_entries=len(manifest),pid=s['pid'],production_applied=False,parent273_sha256=s['parent273_sha256']),indent=2)+'\n',encoding='utf-8')
for p in (z,receipt):
 q=e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'/p.name;assert not q.exists();shutil.copyfile(p,q);assert sha(q)==sha(p)
note='2026-10-09 实库修正首轮275编译失败归档277：三原命令均Cargo101/E0308，SqlException变体要求Box而候选构造遗漏；实际0PASS0FAIL，断言未执行，不作为产品runtime RED或GREEN。1276冻结变化0，两自有容器清理并inspect确认不存在。保存两生产修正、新MySQL时区/微秒/NULL/缓冲流式合同及全部原日志/summary/runner；原253两个实库RED273仍有效，原完整合同未缩减。zip277 SHA '+sha(z)+'，全部条目/E镜像核验。先前启动归档脚本因原275已终态拒绝LIVE声明，未产出伪启动记录；正式E业务源码未apply，18顶层OPEN。'
for rel in ('.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md','docs/verification/rdbc-first/status.md','docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md'):
 with (e/rel).open('ab') as out:out.write(('\n\n'+note+'\n').encode('utf-8'))
print(json.dumps(dict(pid=s['pid'],terminal_compile_failure=True,zip_sha256=sha(z),entries=len(manifest))))
