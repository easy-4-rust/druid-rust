from pathlib import Path
import hashlib,json,shutil,subprocess,zipfile
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d177');e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
d=b/'task7-live-db-contracts281';s=json.loads((d/'summary.json').read_text());assert s['terminal'] and s['exit_code']==1 and len(s['commands'])==3
for c in s['commands']:
 assert sha(Path(c['log']))==c['sha256'] and not c['changed_inputs']
 if c['profile']=='mysql-session-timestamp':assert c['exit_code']==0 and c['passed']==1 and c['failed']==0
 else:assert c['exit_code']==101 and c['passed']==0 and c['failed']==1
assert 'statement_cancel' in (d/'postgresql.log').read_text()
assert 'This command is not supported in the prepared statement protocol yet' in (d/'mysql.log').read_text()
for c in s['containers']:
 assert c['removed'] and subprocess.run(['docker','inspect',c['container_id']],capture_output=True).returncode!=0
f=json.loads((d/'frozen-inputs.json').read_text());assert len(f)==1276 and all(sha(w/p)==h for p,h in f.items())
files={'evidence/'+p.name:p for p in d.iterdir() if p.is_file()}
for name in ('task7-live-db-contracts281.py','task7-live-db-restart282.py','task7-live-db-box-retry-builder280.py'):
 files['runners/'+name]=b/name
files['runner283.py']=Path(__file__)
for rel in ('crates/druid-wrapper/src/sqlx/sqlx_prepared_statement.rs','crates/druid-wrapper/src/sqlx/sqlx_connection_adapter.rs','crates/druid-wrapper/tests/sqlx_mysql_timestamp_session_contract_test.rs'):
 files['candidate/'+rel]=w/rel
scope=dict(scope='PG_EXPLICIT_CANCEL_AND_MYSQL_SAVEPOINT_RUNTIME_RED_MYSQL_SESSION_GREEN',production_applied=False,parent277_sha256=s['parent277_sha256'],pg_next_red='statement_cancel unsupported',mysql_next_red='named savepoint uses unsupported prepared protocol',mysql_session_contract='1PASS0FAIL required configured, three session timezones, microseconds, NULL, buffered/streaming',original_full_database_contracts='NOT_PASSED',frozen_inputs=1276)
z=b/'task7-live-db-next-red-terminal283.zip';assert not z.exists();manifest={n:sha(p) for n,p in files.items()}
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as out:
 for n,p in files.items():out.write(p,n)
 out.writestr('manifest.json',json.dumps(manifest,indent=2));out.writestr('scope.json',json.dumps(scope,indent=2))
with zipfile.ZipFile(z) as out:assert all(hashlib.sha256(out.read(n)).hexdigest()==h for n,h in manifest.items())
receipt=b/'task7-live-db-next-red-terminal283.summary.json';receipt.write_text(json.dumps(dict(scope,sha256=sha(z),verified_entries=len(manifest)),indent=2)+'\n',encoding='utf-8')
for p in (z,receipt):
 q=e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'/p.name;assert not q.exists();shutil.copyfile(p,q);assert sha(p)==sha(q)
note='2026-10-09 实库281终态归档283：Box构造补正后PG原完整合同越过SQLState超时断言，实际0/1失败于statement_cancel UnsupportedOperation；MySQL原完整合同越过TIMESTAMP参数往返，实际0/1失败于命名SAVEPOINT走prepared protocol。独立必配MySQL三个会话时区/微秒/NULL/缓冲/流式合同实际1/0；不扩大为完整实库通过。1276冻结变化0、两自有容器移除并inspect确认。zip283 SHA '+sha(z)+'，全条目/E镜像核验。下一步控制SQL在MySQL使用text protocol；显式cancel需按原合同及完整生命周期设计，不能用no-op或把cancel偷换为close。正式源码未apply，18顶层OPEN。'
for rel in ('.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md','docs/verification/rdbc-first/status.md','docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md'):
 with (e/rel).open('ab') as out:out.write(('\n\n'+note+'\n').encode('utf-8'))
print(json.dumps(dict(zip_sha256=sha(z),verified_entries=len(manifest),mysql_session_passed=1,original_contracts_passed=False)))
