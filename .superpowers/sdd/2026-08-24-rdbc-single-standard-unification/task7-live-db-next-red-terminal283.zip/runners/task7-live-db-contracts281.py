from pathlib import Path
import ctypes,hashlib,json,os,re,subprocess,sys,time,uuid
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d177');d=b/'task7-live-db-contracts281';d.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
s=dict(terminal=False,production_applied=False,pid=os.getpid(),commands=[],containers=[],waiting_for='238 full successful four-command terminal',scope='CONFIGURED_POSTGRESQL_MYSQL_REAL_DATABASE_CONTRACT_NOT_RELEASE_CERTIFICATION')
def save():(d/'summary.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
k=ctypes.WinDLL('kernel32',use_last_error=True);k.OpenProcess.argtypes=[ctypes.c_ulong,ctypes.c_int,ctypes.c_ulong];k.OpenProcess.restype=ctypes.c_void_p;k.GetExitCodeProcess.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_ulong)];k.CloseHandle.argtypes=[ctypes.c_void_p]
def alive(pid):
 h=k.OpenProcess(0x1000,0,pid)
 if not h:return False
 try:
  c=ctypes.c_ulong();return bool(k.GetExitCodeProcess(h,ctypes.byref(c))) and c.value==259
 finally:k.CloseHandle(h)
def docker(args):
 result=subprocess.run(['docker']+args,capture_output=True,text=True);assert result.returncode==0,result.stderr;return result.stdout.strip()
def owned_info(container,profile):
 info=json.loads(docker(['inspect',container]))[0]
 assert info['Config']['Labels'].get('codex.druid.task')=='task7-live-db281'
 assert info['Config']['Labels'].get('codex.druid.profile')==profile
 return info
save()
try:
 parent=json.loads((b/'task7-live-db-contracts253/summary.json').read_text())
 guard=json.loads((b/'task7-final-candidate-workspace258/summary.json').read_text())
 assert parent['terminal'] and parent['exit_code']==1 and guard['terminal'] and guard['commands']==[]
 archive_receipt=json.loads((b/'task7-live-db-red-terminal273.summary.json').read_text())
 assert sha(b/'task7-live-db-red-terminal273.zip')==archive_receipt['sha256']
 f=json.loads((b/'task7-live-db-retry280-frozen-inputs.json').read_text());assert len(f)==1276 and all(sha(w/p)==h for p,h in f.items());(d/'frozen-inputs.json').write_text(json.dumps(f,indent=2)+'\n',encoding='utf-8')
 previous=json.loads((b/'task7-live-db-contracts275/summary.json').read_text());assert previous['terminal'] and all(c['removed'] for c in previous['containers'])
 s['parent277_sha256']='40201e75d277c1b2640d15718da39ea7c91bc148301648a6c9cf848157c46c90'
 images=json.loads((b/'task7-live-db-images251.json').read_text());s.update(frozen_input_count=len(f),parent273_sha256=archive_receipt['sha256'],restart_hook_sha256=sha(b/'task7-live-db-restart282.py'),image_manifest=images,source_delta=json.loads((b/'task7-live-db-retry280-delta.json').read_text()));s.pop('waiting_for',None);save()
 rt=Path('C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin');base_env=os.environ.copy();base_env.update(RUSTC=str(rt/'rustc.exe'),RUSTDOC=str(rt/'rustdoc.exe'),RUSTUP_TOOLCHAIN='1.97.1',RUSTUP_AUTO_INSTALL='0',CARGO_NET_OFFLINE='true',CARGO_TARGET_DIR='F:/codex_build_cache/druid_rust/task7_row_set177_target',DRUID_RDBC_EXTERNAL_TARGET_ROOT='F:/codex_build_cache/druid_rust/task7_row_set177_external',TMP='F:/codex_tmp/task7_standard_cargo13',TEMP='F:/codex_tmp/task7_standard_cargo13');base_env['PATH']=str(rt)+os.pathsep+base_env['PATH']
 # No inherited user database endpoints, credentials, report paths or hooks may enter this isolated run.
 for key in list(base_env):
  if key.startswith(('DRUID_DATABASE_','DRUID_CONTRACT_','DRUID_JDBC_','DRUID_REQUIRE_DATABASE_PROFILE_')):base_env.pop(key)
 failed=False
 for profile,tag,internal in [('postgresql','postgres:18.6',5432),('mysql','mysql:8.4',3306)]:
  assert all(sha(w/p)==h for p,h in f.items());password=uuid.uuid4().hex;root_password=uuid.uuid4().hex;container=None;record=dict(profile=profile,tag=tag,image_id=images[tag]['Id'],started=False,removed=False)
  try:
   name='codex-druid-281-'+profile+'-'+uuid.uuid4().hex[:10];args=['create','--pull','never','--name',name,'--label','codex.druid.task=task7-live-db281','--label','codex.druid.profile='+profile,'--memory','1g','--cpus','2','--publish','127.0.0.1::'+str(internal)]
   variables={'POSTGRES_USER':'druid','POSTGRES_PASSWORD':password,'POSTGRES_DB':'druid_contract'} if profile=='postgresql' else {'MYSQL_USER':'druid','MYSQL_PASSWORD':password,'MYSQL_ROOT_PASSWORD':root_password,'MYSQL_DATABASE':'druid_contract'}
   for key,value in variables.items():args+=['--env',key+'='+value]
   args.append(images[tag]['Id']);container=docker(args);record.update(container_id=container,container_name=name);s['containers'].append(record);save();docker(['start',container]);record['started']=True;info=owned_info(container,profile)
   port=info['NetworkSettings']['Ports'][str(internal)+'/tcp'][0];assert port['HostIp']=='127.0.0.1';host_port=port['HostPort'];record['host_port']=host_port;save()
   for attempt in range(120):
    ready=['exec',container,'pg_isready','-h','127.0.0.1','-U','druid','-d','druid_contract'] if profile=='postgresql' else ['exec',container,'mysqladmin','--host=127.0.0.1','--protocol=tcp','-uroot','-p'+root_password,'ping','--silent']
    if subprocess.run(['docker']+ready,capture_output=True).returncode==0:break
    time.sleep(1)
   else:raise RuntimeError('owned '+profile+' initial readiness timed out')
   env=base_env.copy();scheme='postgresql' if profile=='postgresql' else 'mysql';url=scheme+'://druid:'+password+'@127.0.0.1:'+host_port+'/druid_contract';bad=scheme+'://druid:'+uuid.uuid4().hex+'@127.0.0.1:'+host_port+'/druid_contract'
   env.update(DRUID_REQUIRE_DATABASE_PROFILE_CONTRACT='1',DRUID_DATABASE_PROFILE=profile,DRUID_DATABASE_URL=url,DRUID_DATABASE_BAD_URL=bad,DRUID_CONTRACT_LONG_QUERY='SELECT pg_sleep(5)' if profile=='postgresql' else 'SELECT SLEEP(5)',DRUID_CONTRACT_RESTART_PROGRAM=sys.executable,DRUID_CONTRACT_RESTART_ARGS_JSON=json.dumps(['-X','utf8',str(b/'task7-live-db-restart282.py'),container,profile]),DRUID_LIVE_DB_ROOT_PASSWORD=root_password)
   cmd=[str(rt/'cargo.exe'),'test','-p','druid-wrapper','--test','task6_database_profile_live_contract_test_parity','--locked','--offline','-j1','--','--exact','task6_database_profile_live_contract_test_database_profile_live_contract_when_configured','--nocapture'];s['running_command']=profile;save();log=d/(profile+'.log');started=time.monotonic()
   with log.open('wb') as out:result=subprocess.run(cmd,cwd=w,env=env,stdout=out,stderr=subprocess.STDOUT)
   text=log.read_text(encoding='utf-8',errors='replace');counts=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed;',text);changed=[p for p,h in f.items() if sha(w/p)!=h];c=dict(profile=profile,command=cmd,exit_code=result.returncode,elapsed_seconds=time.monotonic()-started,log=str(log),sha256=sha(log),passed=sum(int(a) for a,z in counts),failed=sum(int(z) for a,z in counts),changed_inputs=changed,required_profile_flag=True,configured_timeout_cancel=True,configured_owned_restart=True,configured_bad_credentials=True);s['commands'].append(c);save();print(json.dumps(c),flush=True)
   if result.returncode or c['passed']!=1 or c['failed'] or changed:failed=True
   if profile=='mysql':
    env['DRUID_MYSQL_TIMESTAMP_CONTRACT_REQUIRED']='1'
    cmd=[str(rt/'cargo.exe'),'test','-p','druid-wrapper','--test','sqlx_mysql_timestamp_session_contract_test','--locked','--offline','-j1','--','--exact','timestamp_preserves_mysql_session_fields_and_datetime_does_not_shift','--nocapture'];s['running_command']='mysql-session-timestamp';save();log=d/'mysql-session-timestamp.log';started=time.monotonic()
    with log.open('wb') as out:result=subprocess.run(cmd,cwd=w,env=env,stdout=out,stderr=subprocess.STDOUT)
    text=log.read_text(encoding='utf-8',errors='replace');counts=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed;',text);changed=[p for p,h in f.items() if sha(w/p)!=h];c=dict(profile='mysql-session-timestamp',command=cmd,exit_code=result.returncode,elapsed_seconds=time.monotonic()-started,log=str(log),sha256=sha(log),passed=sum(int(a) for a,z in counts),failed=sum(int(z) for a,z in counts),changed_inputs=changed,required_profile_flag=True);s['commands'].append(c);save();print(json.dumps(c),flush=True)
    if result.returncode or c['passed']!=1 or c['failed'] or changed:failed=True
  except Exception as error:
   record['error']=str(error);failed=True;save()
  finally:
   if container:
    owned_info(container,profile);docker(['rm','--force','--volumes',container]);record['removed']=True;save()
 s.update(terminal=True,exit_code=1 if failed else 0);s.pop('running_command',None);save();print('LIVE_DB281_TERMINAL',s['exit_code'],flush=True)
except Exception as error:
 s.update(terminal=True,exit_code=1,error=str(error));save();raise
