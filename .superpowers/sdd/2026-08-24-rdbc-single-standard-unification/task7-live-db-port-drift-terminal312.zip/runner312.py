from pathlib import Path
import hashlib,json,shutil,subprocess,zipfile
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d177');e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
d=b/'task7-live-db-contracts306';s=json.loads((d/'summary.json').read_text());assert s['terminal'] and s['exit_code']==1
for c in s['commands']:assert sha(Path(c['log']))==c['sha256'] and not c['changed_inputs']
for profile in ('postgresql','mysql'):
 c=next(c for c in s['commands'] if c['profile']==profile);assert c['exit_code']==4294967295 and c['passed']==0 and c['failed']==0
 proof=json.loads((b/'task7-live-db-port-drift311'/f'{profile}-port-drift-before-stop.json').read_text(encoding='utf-8-sig'));assert proof['OriginalPort']!=proof['CurrentPorts'][0]['HostPort']
for c in s['containers']:assert c['removed'] and subprocess.run(['docker','inspect',c['container_id']],capture_output=True).returncode!=0
f=json.loads((d/'frozen-inputs.json').read_text());assert len(f)==1277 and all(sha(w/p)==h for p,h in f.items())
files={'runner312.py':Path(__file__)}
for name in ('task7-live-db-contracts306','task7-live-db-port-drift311'):
 for p in (b/name).iterdir():
  if p.is_file():files[name+'/'+p.name]=p
for name in ('task7-live-db-cancel-retry-builder305.py','task7-live-db-contracts306.py','task7-live-db-restart307.py'):files['runners/'+name]=b/name
scope=dict(scope='FIXTURE_RESTART_DYNAMIC_PUBLISHED_PORT_DRIFT_NOT_PRODUCT_RUNTIME_RED',production_applied=False,parent308_sha256=sha(b/'task7-sqlx-cancel-validation-terminal308.zip'),original_contracts='ABORTED_VERIFIED_OWNED_TEST_PROCESSES_AFTER_RESTART_ENDPOINT_DRIFT',supplemental='OLD_ENDPOINT_AFTER_RESTART_NOT_PRODUCT_CERTIFICATION',frozen_input_count=len(f),full_candidate_workspace='NOT_STARTED')
z=b/'task7-live-db-port-drift-terminal312.zip';assert not z.exists();manifest={n:sha(p) for n,p in files.items()}
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as out:
 for n,p in files.items():out.write(p,n)
 out.writestr('manifest.json',json.dumps(manifest,indent=2));out.writestr('scope.json',json.dumps(scope,indent=2))
with zipfile.ZipFile(z) as out:assert all(hashlib.sha256(out.read(n)).hexdigest()==h for n,h in manifest.items())
receipt=b/'task7-live-db-port-drift-terminal312.summary.json';receipt.write_text(json.dumps(dict(scope,sha256=sha(z),verified_entries=len(manifest)),indent=2)+'\n',encoding='utf-8')
for p in (z,receipt):
 q=e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'/p.name;assert not q.exists();shutil.copyfile(p,q);assert sha(p)==sha(q)
note='2026-10-09 实库306重启夹具端口漂移终态312：原PG/MySQL完整合同均越过timeout/cancel进入database-restart；Docker随机发布端口实际59558到60619、61939到54782，原URL仍指向旧端点。保存inspect端口证据与已核验本任务Python->Cargo->测试exe链后，仅停止两个等待旧端口的测试，原exit0xffffffff/0PASS0FAIL，属于夹具中止，不记产品runtime RED或GREEN。后续时间补充合同也指向旧端点，不能做产品认证。1277输入不变，自有容器清理并inspect确认；zip312 SHA '+sha(z)+'全部条目/E镜像核验。下一轮只修夹具显式固定随机loopback端口和重启前后endpoint核验，原产品代码/合同不改，完整全仓尚未启动；18顶层OPEN。'
for rel in ('.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md','docs/verification/rdbc-first/status.md','docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md'):
 with (e/rel).open('ab') as out:out.write(('\n\n'+note+'\n').encode('utf-8'))
print(json.dumps(dict(zip_sha256=sha(z),verified_entries=len(manifest))))
