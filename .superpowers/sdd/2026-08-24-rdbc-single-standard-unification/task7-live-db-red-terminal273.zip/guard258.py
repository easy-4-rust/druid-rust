from pathlib import Path
import ctypes,hashlib,json,os,re,subprocess,time
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d177');e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust');d=b/'task7-final-candidate-workspace258';d.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();s=dict(terminal=False,production_applied=False,pid=os.getpid(),commands=[],waiting_for='253 both configured real databases successful terminal and owned-container cleanup')
def save():(d/'summary.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
k=ctypes.WinDLL('kernel32');k.OpenProcess.argtypes=[ctypes.c_ulong,ctypes.c_int,ctypes.c_ulong];k.OpenProcess.restype=ctypes.c_void_p;k.GetExitCodeProcess.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_ulong)];k.CloseHandle.argtypes=[ctypes.c_void_p]
def alive(pid):
 h=k.OpenProcess(0x1000,0,pid)
 if not h:return False
 try:
  c=ctypes.c_ulong();return bool(k.GetExitCodeProcess(h,ctypes.byref(c))) and c.value==259
 finally:k.CloseHandle(h)
save()
try:
 while True:
  parent=json.loads((b/'task7-live-db-contracts253/summary.json').read_text())
  if parent['terminal']:break
  if not alive(parent['pid']):
   parent=json.loads((b/'task7-live-db-contracts253/summary.json').read_text())
   if parent['terminal']:break
   raise RuntimeError('253 process absent without terminal evidence; no compilation started')
  time.sleep(30)
 assert parent['exit_code']==0 and len(parent['commands'])==2
 assert {c['profile'] for c in parent['commands']}=={'postgresql','mysql'}
 assert all(c['exit_code']==0 and c['passed']==1 and c['failed']==0 and not c['changed_inputs'] and sha(Path(c['log']))==c['sha256'] for c in parent['commands'])
 assert len(parent['containers'])==2 and all(c['removed'] for c in parent['containers'])
 frozen=json.loads((b/'task7-live-db-contracts253/frozen-inputs.json').read_text());assert len(frozen)==1275 and all(sha(w/p)==h for p,h in frozen.items());(d/'frozen-inputs.json').write_text(json.dumps(frozen,indent=2)+'\n',encoding='utf-8')
 s.update(workspace=str(w),frozen_input_count=len(frozen),parent253_summary_sha256=sha(b/'task7-live-db-contracts253/summary.json'),original_c1_c2_and_timeouts_preserved=True);s.pop('waiting_for',None);save()
 tool=Path('C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin');env=os.environ.copy();env.update(RUSTC=str(tool/'rustc.exe'),RUSTDOC=str(tool/'rustdoc.exe'),RUSTUP_TOOLCHAIN='1.97.1-x86_64-pc-windows-msvc',RUSTUP_AUTO_INSTALL='0',CARGO_BUILD_JOBS='1',CARGO_TARGET_DIR='F:/codex_build_cache/druid_rust/task7_row_set177_target',DRUID_RDBC_EXTERNAL_TARGET_ROOT='F:/codex_build_cache/druid_rust/task7_row_set177_external',TMP='F:/codex_tmp/task7_standard_cargo13',TEMP='F:/codex_tmp/task7_standard_cargo13',GIT_DIR=str(e/'.git'),GIT_WORK_TREE=str(w),PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1');env['PATH']=str(tool)+os.pathsep+env['PATH'];common=['--workspace','--all-features','--locked','--offline','-j1']
 for key in list(env):
  if key.startswith(('DRUID_DATABASE_','DRUID_CONTRACT_','DRUID_JDBC_','DRUID_REQUIRE_DATABASE_PROFILE_','DRUID_LIVE_DB_')):env.pop(key)
 commands=[('workspace-complete',[str(tool/'cargo.exe'),'test']+common+['--no-fail-fast']),('workspace-strict',[str(tool/'cargo.exe'),'clippy']+common+['--all-targets','--','-D','warnings']),('workspace-doc',[str(tool/'cargo.exe'),'doc']+common+['--no-deps']),('format-check',[str(tool/'cargo.exe'),'fmt','--all','--','--check']),('c1-complete-runtime',['C:/Espressif/tools/python/python.exe','-X','utf8','scripts/verify_task6_method_parity.py','--repository-root',str(w)])]
 for name,cmd in commands:
  assert all(sha(w/p)==h for p,h in frozen.items());s['running_command']=name;save();log=d/(name+'.log');started=time.monotonic()
  with log.open('wb') as out:result=subprocess.run(cmd,cwd=w,env=env,stdout=out,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
  text=log.read_text(encoding='utf-8',errors='replace');blocks=re.findall(r'^test result: .*?(\d+) passed; (\d+) failed; (\d+) ignored;',text,re.M);changed=[p for p,h in frozen.items() if sha(w/p)!=h];record=dict(name=name,command=cmd,exit_code=result.returncode,elapsed_seconds=time.monotonic()-started,log=str(log),sha256=sha(log),passed=sum(int(x) for x,y,z in blocks),failed=sum(int(y) for x,y,z in blocks),ignored=sum(int(z) for x,y,z in blocks),failing_tests=re.findall(r'^test (\S+) \.\.\. FAILED$',text,re.M),changed_inputs=changed);s['commands'].append(record);save();print(json.dumps(record),flush=True)
  if changed:raise RuntimeError('frozen final candidate input changed')
 s.update(terminal=True,exit_code=0 if all(c['exit_code']==0 for c in s['commands']) else 1);s.pop('running_command',None);save();print('WORKSPACE258_TERMINAL',s['exit_code'],flush=True)
except Exception as error:
 s.update(terminal=True,exit_code=1,error=str(error));save();raise
