from pathlib import Path
import hashlib, json, shutil, subprocess, zipfile

b = Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
w = Path('F:/codex_build_cache/d177')
e = Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
parent = json.loads((b / 'task7-live-db-contracts253/summary.json').read_text())
guard = json.loads((b / 'task7-final-candidate-workspace258/summary.json').read_text())
assert parent['terminal'] and parent['exit_code'] == 1
assert guard['terminal'] and guard['exit_code'] == 1 and guard['commands'] == []
assert len(parent['commands']) == 2
for c in parent['commands']:
    assert c['exit_code'] == 101 and c['failed'] == 1 and c['passed'] == 0
    assert not c['changed_inputs'] and sha(Path(c['log'])) == c['sha256']
for c in parent['containers']:
    assert c['removed']
    assert subprocess.run(['docker', 'inspect', c['container_id']], capture_output=True).returncode != 0
frozen = json.loads((b / 'task7-live-db-contracts253/frozen-inputs.json').read_text())
assert len(frozen) == 1275 and all(sha(w / rel) == digest for rel, digest in frozen.items())
files = {'runner273.py': Path(__file__), 'runner253.py': b / 'task7-live-db-contracts253.py', 'restart254.py': b / 'task7-live-db-restart254.py', 'guard258.py': b / 'task7-final-candidate-workspace258.py'}
for directory in ('task7-live-db-contracts253', 'task7-final-candidate-workspace258'):
    for p in (b / directory).iterdir():
        if p.is_file():
            files['evidence/' + directory + '/' + p.name] = p
for rel in ('crates/druid-wrapper/src/sqlx/sqlx_prepared_statement.rs', 'crates/druid-wrapper/src/sqlx/sqlx_connection_adapter.rs', 'crates/druid-wrapper/tests/task6_generated/database_profile_live_contract_test/part_01.inc.rs', 'crates/druid-wrapper/tests/task6_generated/database_profile_live_contract_test/part_02.inc.rs'):
    files['candidate-before/' + rel] = w / rel
    files['formal-before/' + rel] = e / rel
scope = dict(scope='ORIGINAL_CONFIGURED_PG_MYSQL_CONTRACT_RED_AND_FINAL_GUARD_NOT_RUN', production_applied=False, frozen_inputs=len(frozen), failures={'postgresql': 'timeout lost SQLState: Other(statement query timed out)', 'mysql': 'TIMESTAMP decoding rejects NaiveDateTime/DATETIME'}, final258='NOT_RUN_PRECONDITION_FAILED', parent240_sha256=parent['parent240_sha256'])
z = b / 'task7-live-db-red-terminal273.zip'
assert not z.exists()
manifest = {name: sha(p) for name, p in files.items()}
with zipfile.ZipFile(z, 'w', zipfile.ZIP_DEFLATED) as out:
    for name, p in files.items():
        out.write(p, name)
    out.writestr('manifest.json', json.dumps(manifest, indent=2))
    out.writestr('scope.json', json.dumps(scope, indent=2))
with zipfile.ZipFile(z) as archive:
    assert all(hashlib.sha256(archive.read(name)).hexdigest() == digest for name, digest in manifest.items())
receipt = b / 'task7-live-db-red-terminal273.summary.json'
receipt.write_text(json.dumps(dict(scope, sha256=sha(z), verified_entries=len(manifest)), indent=2) + '\n', encoding='utf-8')
for p in (z, receipt):
    dest = e / '.superpowers/sdd/2026-08-24-rdbc-single-standard-unification' / p.name
    assert not dest.exists()
    shutil.copyfile(p, dest)
    assert sha(p) == sha(dest)
note = '2026-10-09 原配置实库253终态RED归档273：PG与MySQL均实际Cargo101/0PASS1FAIL；PG超时丢失标准SQLState，MySQL TIMESTAMP与NaiveDateTime/DATETIME不兼容。1275冻结输入变化0，两自有容器移除并再次inspect确认不存在。258因实库成功前置不成立终态exit1、commands为空，明确NOT_RUN而非全仓测试失败。保存完整原日志、summary、runner、冻结清单及候选/正式四文件preimage；zip273 SHA ' + sha(z) + '，全部条目与E镜像核验。尚未修复或获得GREEN；正式源码未apply，18顶层OPEN。'
for rel in ('.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md', 'docs/verification/rdbc-first/status.md', 'docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md'):
    with (e / rel).open('ab') as out:
        out.write(('\n\n' + note + '\n').encode('utf-8'))
print(json.dumps(dict(sha256=sha(z), entries=len(manifest), frozen_unchanged=True, containers_absent=True, production_applied=False)))
