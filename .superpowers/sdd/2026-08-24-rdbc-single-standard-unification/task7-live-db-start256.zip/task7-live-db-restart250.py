import json,os,subprocess,sys,time
container,profile=sys.argv[1:]
info=json.loads(subprocess.check_output(['docker','inspect',container],text=True))[0]
assert info['Config']['Labels'].get('codex.druid.task')=='task7-live-db249'
assert info['Config']['Labels'].get('codex.druid.profile')==profile
subprocess.run(['docker','restart','--time','3',container],check=True,capture_output=True)
for attempt in range(120):
 if profile=='postgresql':
  command=['docker','exec',container,'pg_isready','-U','druid','-d','druid_contract']
 else:
  command=['docker','exec',container,'mysqladmin','-uroot','-p'+os.environ['DRUID_LIVE_DB_ROOT_PASSWORD'],'ping','--silent']
 result=subprocess.run(command,capture_output=True)
 if result.returncode==0:
  print('owned database restart readiness confirmed',profile,flush=True)
  break
 time.sleep(1)
else:raise RuntimeError('owned database not ready after restart')
