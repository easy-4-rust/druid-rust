import ctypes,json,os
from ctypes import wintypes

class UnicodeString(ctypes.Structure):
    _fields_=[('Length',ctypes.c_uint16),('MaximumLength',ctypes.c_uint16),('Buffer',ctypes.c_void_p)]
class Process(ctypes.Structure):
    _fields_=[('NextEntryOffset',ctypes.c_uint32),('NumberOfThreads',ctypes.c_uint32),('WorkingSetPrivateSize',ctypes.c_int64),('HardFaultCount',ctypes.c_uint32),('NumberOfThreadsHighWatermark',ctypes.c_uint32),('CycleTime',ctypes.c_uint64),('CreateTime',ctypes.c_int64),('UserTime',ctypes.c_int64),('KernelTime',ctypes.c_int64),('ImageName',UnicodeString),('BasePriority',ctypes.c_int32),('UniqueProcessId',ctypes.c_void_p),('InheritedFromUniqueProcessId',ctypes.c_void_p),('HandleCount',ctypes.c_uint32),('SessionId',ctypes.c_uint32),('UniqueProcessKey',ctypes.c_size_t),('PeakVirtualSize',ctypes.c_size_t),('VirtualSize',ctypes.c_size_t),('PageFaultCount',ctypes.c_uint32),('PeakWorkingSetSize',ctypes.c_size_t),('WorkingSetSize',ctypes.c_size_t),('QuotaPeakPagedPoolUsage',ctypes.c_size_t),('QuotaPagedPoolUsage',ctypes.c_size_t),('QuotaPeakNonPagedPoolUsage',ctypes.c_size_t),('QuotaNonPagedPoolUsage',ctypes.c_size_t),('PagefileUsage',ctypes.c_size_t),('PeakPagefileUsage',ctypes.c_size_t),('PrivatePageCount',ctypes.c_size_t),('ReadOperationCount',ctypes.c_int64),('WriteOperationCount',ctypes.c_int64),('OtherOperationCount',ctypes.c_int64),('ReadTransferCount',ctypes.c_int64),('WriteTransferCount',ctypes.c_int64),('OtherTransferCount',ctypes.c_int64)]
class Thread(ctypes.Structure):
    _fields_=[('KernelTime',ctypes.c_int64),('UserTime',ctypes.c_int64),('CreateTime',ctypes.c_int64),('WaitTime',ctypes.c_uint32),('StartAddress',ctypes.c_void_p),('UniqueProcess',ctypes.c_void_p),('UniqueThread',ctypes.c_void_p),('Priority',ctypes.c_int32),('BasePriority',ctypes.c_int32),('ContextSwitches',ctypes.c_uint32),('ThreadState',ctypes.c_uint32),('WaitReason',ctypes.c_uint32)]
assert ctypes.sizeof(ctypes.c_void_p)==8 and ctypes.sizeof(Process)==256 and ctypes.sizeof(Thread)==80
n=ctypes.WinDLL('ntdll');query=n.NtQuerySystemInformation;query.argtypes=[ctypes.c_uint32,ctypes.c_void_p,ctypes.c_uint32,ctypes.POINTER(ctypes.c_uint32)];query.restype=ctypes.c_int32
size=1<<20
for attempt in range(5):
    buffer=ctypes.create_string_buffer(size);needed=ctypes.c_uint32();status=query(5,buffer,size,ctypes.byref(needed))
    if status==0:break
    assert ctypes.c_uint32(status).value==0xc0000004
    size=max(size*2,needed.value+65536)
else:raise RuntimeError('process query did not complete')
base=ctypes.addressof(buffer);offset=0;records=[];own_record=None
targets={59264:'python.exe',26048:'cargo.exe',73904:'rustc.exe'}
while offset+256<=needed.value:
    process=Process.from_buffer_copy(buffer,offset);pid=int(process.UniqueProcessId or 0)
    span=process.NextEntryOffset or needed.value-offset
    assert span>=256 and offset+span<=needed.value
    if pid in targets or pid==os.getpid():
        assert process.ImageName.Buffer and base<=process.ImageName.Buffer<base+needed.value
        name=ctypes.wstring_at(process.ImageName.Buffer,process.ImageName.Length//2)
        assert process.ImageName.Buffer+process.ImageName.Length<=base+needed.value
        if pid in targets:assert name.lower()==targets[pid]
        threads=[];assert 256+process.NumberOfThreads*80<=span
        for index in range(process.NumberOfThreads):
            thread=Thread.from_buffer_copy(buffer,offset+256+80*index);assert int(thread.UniqueProcess or 0)==pid
            threads.append(dict(tid=int(thread.UniqueThread or 0),state=thread.ThreadState,wait_reason=thread.WaitReason,cpu_seconds=(thread.KernelTime+thread.UserTime)/10000000,context_switches=thread.ContextSwitches))
        record=dict(pid=pid,parent=int(process.InheritedFromUniqueProcessId or 0),name=name,cpu_seconds=(process.UserTime+process.KernelTime)/10000000,read_bytes=process.ReadTransferCount,write_bytes=process.WriteTransferCount,threads=threads)
        if pid==os.getpid():own_record=record
        else:records.append(record)
    if not process.NextEntryOffset:break
    offset+=process.NextEntryOffset
assert own_record and own_record['name'].lower()=='python.exe'
for record in records:
    if record['pid']==26048:assert record['parent']==59264
    if record['pid']==73904:assert record['parent']==26048
print(json.dumps(dict(scope='READ_ONLY_OWN_BUILD_PROCESS_THREAD_NUMERIC_STATES',records=records),indent=2))
