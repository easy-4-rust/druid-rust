from pathlib import Path
import datetime,hashlib,json,shutil,subprocess,zipfile
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d177');e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust');d=b/'task7-native-wait-evidence343';d.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
frozen_path=b/'task7-final-candidate-workspace319/frozen-inputs.json';frozen=json.loads(frozen_path.read_text());assert len(frozen)==1277 and all(sha(w/p)==h for p,h in frozen.items())
log=d/'native-process-threads.json';runner=b/'task7-native-wait-diagnostic342.py'
with log.open('wb') as out:result=subprocess.run(['C:/Espressif/tools/python/python.exe','-B','-X','utf8',str(runner)],stdout=out,stderr=subprocess.STDOUT)
assert result.returncode==0;data=json.loads(log.read_text());records={row['pid']:row for row in data['records']};assert 59264 in records and 26048 in records and records[26048]['parent']==59264
parent=b/'task7-final-candidate-workspace319/summary.json';snapshot=json.loads(parent.read_text());assert not snapshot['terminal'] and snapshot['pid']==59264
(d/'observed-workspace319-summary.json').write_text(json.dumps(snapshot,indent=2)+'\n',encoding='utf-8')
summary=dict(scope='LIVE_ORIGINAL_WORKSPACE319_READ_ONLY_THREAD_DIAGNOSTIC_NOT_TERMINAL_OR_PRODUCT_RESULT',observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),workspace319_pid=59264,cargo_pid=26048,cargo_parent_verified=True,live_processes=list(records),ready_threads=[dict(pid=row['pid'],tid=thread['tid']) for row in records.values() for thread in row['threads'] if thread['state']==1],terminal=False,source_mutated=False,priority_changed=False,process_stopped=False,frozen_inputs=1277,changed_inputs=[p for p,h in frozen.items() if sha(w/p)!=h],thread_state_source='https://learn.microsoft.com/en-us/dotnet/api/system.diagnostics.threadstate?view=netframework-4.8.1',interpretation_limit='Single thread-state snapshot is diagnostic only; it neither proves root cause or deadlock nor synchronizes the build. Retain original process, scope and timeouts.')
assert not summary['changed_inputs'];(d/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
files={'runner343.py':Path(__file__),'native-runner342.py':runner,'native-process-threads.json':log,'summary.json':d/'summary.json','observed-workspace319-summary.json':d/'observed-workspace319-summary.json','frozen319.json':frozen_path};manifest={n:sha(p) for n,p in files.items()};z=b/'task7-native-wait-evidence344.zip';assert not z.exists()
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as out:
 for n,p in files.items():out.write(p,n)
 out.writestr('manifest.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(z) as out:assert all(hashlib.sha256(out.read(n)).hexdigest()==h for n,h in manifest.items())
receipt=b/'task7-native-wait-evidence344.summary.json';receipt.write_text(json.dumps(dict(scope=summary['scope'],sha256=sha(z),verified_entries=len(manifest),terminal=False,priority_changed=False,production_applied=False),indent=2)+'\n',encoding='utf-8')
for p in (z,receipt):
 q=e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'/p.name;assert not q.exists();shutil.copyfile(p,q);assert sha(p)==sha(q)
note='2026-10-09 原完整验收319原生线程诊断342/343/344：直接系统进程快照验证Python59264/Cargo26048父链及本任务rustc线程数值状态，保留完整原始记录；Ready只是调度诊断，单快照不证明根因/死锁，不以无新增日志或低CPU认定终态。1277冻结变化0，未改优先级/停止/重启原任务，zip344 SHA '+sha(z)+'全部条目/E镜像核验。仍STARTED_NOT_PASSED、18顶层OPEN。'
for rel in ('.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md','docs/verification/rdbc-first/status.md','docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md'):
 with (e/rel).open('ab') as out:out.write(('\n\n'+note+'\n').encode('utf-8'))
print(json.dumps(dict(live_processes=summary['live_processes'],ready_threads=summary['ready_threads'],zip_sha256=sha(z),verified_entries=len(manifest),frozen_inputs_unchanged=True)))
