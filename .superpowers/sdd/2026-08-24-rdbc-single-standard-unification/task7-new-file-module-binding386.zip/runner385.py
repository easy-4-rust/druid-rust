from pathlib import Path
import ast,collections,hashlib,json,re,shutil,tomllib,zipfile
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d177');e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust');d=b/'task7-new-file-module-binding385';d.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
frozen_path=b/'task7-final-candidate-workspace319/frozen-inputs.json';frozen=json.loads(frozen_path.read_text());assert len(frozen)==1277 and all(sha(w/p)==h for p,h in frozen.items())
snapshot=json.loads((b/'task7-e-integration-current-snapshot383/summary.json').read_text());new=[r for r in snapshot['files'] if r['state']=='MISSING_IN_E'];assert len(new)==99
workspace=tomllib.loads((w/'Cargo.toml').read_text());roots=[];root_kinds={};manifests={}
for member in workspace['workspace']['members']:
 crate=w/member;manifest=tomllib.loads((crate/'Cargo.toml').read_text());manifests[member+'/Cargo.toml']=sha(crate/'Cargo.toml')
 for name,path in (('lib',crate/manifest.get('lib',{}).get('path','src/lib.rs')),('main',crate/'src/main.rs')):
  if path.exists():roots.append(path);root_kinds[str(path.relative_to(w)).replace('\\','/')]='CARGO_'+name.upper()+'_SOURCE'
 assert manifest['package'].get('autotests',True),member
 for path in (crate/'tests').glob('*.rs'):
  roots.append(path);root_kinds[str(path.relative_to(w)).replace('\\','/')]='DEFAULT_CARGO_INTEGRATION_TEST_SOURCE'
parent={str(p.relative_to(w)).replace('\\','/'):None for p in roots};todo=collections.deque(roots);unresolved=[]
while todo:
 path=todo.popleft();source=path.read_text(encoding='utf-8');base=path.parent if path.name in ('lib.rs','main.rs','mod.rs') or path in roots else path.parent/path.stem
 for match in re.finditer(r'(?m)^\s*(?:pub(?:\([^\n]*\))?\s+)?mod\s+(\w+)\s*;',source):
  lines=source[max(0,match.start()-300):match.start()].rstrip().splitlines();path_attr=None
  for line in reversed(lines):
   if line.strip().startswith('#['):
    found=re.search(r'#\[path\s*=\s*"([^"]+)"\]',line)
    if found:path_attr=found.group(1)
   elif line.strip():break
  child=path.parent/path_attr if path_attr else base/(match.group(1)+'.rs')
  if not child.exists() and path_attr is None:child=base/match.group(1)/'mod.rs'
  if child.exists():
   rel=str(child.relative_to(w)).replace('\\','/')
   if rel not in parent:parent[rel]=str(path.relative_to(w)).replace('\\','/');todo.append(child)
  else:unresolved.append(dict(path=str(path.relative_to(w)),module=match.group(1),path_attribute=path_attr))
rows=[];binding_paths=set()
for r in new:
 rel=r['path'];assert not (e/rel).exists() and sha(w/rel)==r['candidate_sha256']
 if rel.endswith('.rs'):
  assert rel in parent,rel
  chain=[];current=rel
  while current is not None:
   chain.append(dict(path=current,sha256=sha(w/current)));binding_paths.add(current);current=parent[current]
  chain.reverse();rows.append(dict(path=rel,sha256=sha(w/rel),state='STATIC_MODULE_PATH_REACHABLE',root_kind=root_kinds[chain[0]['path']],source_chain=chain,cfg_compiler_runtime_certified=False))
 else:
  assert rel.endswith('.py');module=ast.parse((w/rel).read_text(encoding='utf-8'),filename=rel)
  rows.append(dict(path=rel,sha256=sha(w/rel),state='PYTHON_AST_VALID_NOT_EXECUTION_PROOF',functions=[node.name for node in module.body if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef))],runtime_certified=False))
assert len([r for r in rows if r['state']=='STATIC_MODULE_PATH_REACHABLE'])==96
s=dict(scope='99_NEW_SOURCE_FILES_STATIC_MODULE_BINDING_NOT_ACCEPTANCE',production_applied=False,files=rows,rust_module_path_reachable=96,python_ast_valid=3,unresolved_declared_modules=unresolved,manifest_bindings=manifests,source_binding_count=len(binding_paths),frozen_inputs_changed=0,scope_limit='Source mod/path declarations and default integration test discovery only; cfg, public visibility, compiler types and runtime semantics require fresh full gates.')
(d/'summary.json').write_text(json.dumps(s,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');(d/'report.md').write_text('# 99个新增文件源模块绑定\n\n96个Rust新增源文件均有从Cargo lib/main或默认集成测试根至目标文件的mod/path声明路径，链路每个文件SHA绑定；三Python文件AST有效。Workspace成员和autotests由真实Cargo manifest读取，未调用第二个Cargo。\n\n这只证明静态源码接线，不能证明cfg公开API、编译或运行语义。未apply/退休E文件、1277输入不变。319全仓继续，18顶层OPEN。\n',encoding='utf-8')
files={'runner385.py':Path(__file__),'summary.json':d/'summary.json','report.md':d/'report.md','frozen319.json':frozen_path}
files.update({'candidate/'+r['path']:w/r['path'] for r in rows});files.update({'binding/'+p:w/p for p in binding_paths});files.update({'binding/'+p:w/p for p in manifests});files['binding/Cargo.toml']=w/'Cargo.toml'
assert all(sha(w/p)==h for p,h in frozen.items()) and all(not (e/r['path']).exists() for r in new)
entries={name:sha(path) for name,path in files.items()};z=b/'task7-new-file-module-binding386.zip';assert not z.exists()
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as archive:
 for name,path in files.items():archive.write(path,name)
 archive.writestr('manifest.json',json.dumps(entries,indent=2))
with zipfile.ZipFile(z) as archive:assert all(hashlib.sha256(archive.read(name)).hexdigest()==h for name,h in entries.items())
receipt=b/'task7-new-file-module-binding386.summary.json';receipt.write_text(json.dumps(dict(sha256=sha(z),verified_entries=len(entries),rust_source_paths=96,python_ast=3,production_applied=False),indent=2)+'\n',encoding='utf-8')
for item in (z,receipt):
 target=e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'/item.name;assert not target.exists();shutil.copyfile(item,target);assert sha(item)==sha(target)
note='2026-10-09 新增99文件接线预检385/386：96个Rust文件有真实Cargo lib/main/默认tests根至mod/path的逐文件SHA路径，三Python AST有效，解析到的声明缺失'+str(len(unresolved))+'项；仅静态接线，不证明cfg/compiler/public API/runtime。无第二Cargo、未apply/退休E文件，1277冻结变化0。zip386 SHA '+sha(z)+'全部条目/E镜像核验，319继续、18顶层OPEN。'
for rel in ('.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md','docs/verification/rdbc-first/status.md','docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md'):
 with (e/rel).open('ab') as out:out.write(('\n\n'+note+'\n').encode('utf-8'))
print(json.dumps(dict(rust_reachable=96,python_ast=3,source_bindings=len(binding_paths),unresolved=len(unresolved),zip_sha256=sha(z))))
