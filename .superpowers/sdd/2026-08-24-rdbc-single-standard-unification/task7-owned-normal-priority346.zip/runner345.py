from pathlib import Path
import contextlib,ctypes,datetime,hashlib,io,json,os,shutil,time,zipfile
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d177');e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust');d=b/'task7-owned-normal-priority345';d.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
frozen_path=b/'task7-final-candidate-workspace319/frozen-inputs.json';frozen=json.loads(frozen_path.read_text());assert len(frozen)==1277 and all(sha(w/p)==h for p,h in frozen.items())
parent_path=b/'task7-final-candidate-workspace319/summary.json';parent=json.loads(parent_path.read_text());assert not parent['terminal'] and parent['pid']==59264 and parent['running_command']=='workspace-complete'
diagnostic=b/'task7-native-wait-diagnostic342.py';code=diagnostic.read_text();code=code.replace('if pid in targets or pid==os.getpid():','if pid in targets or pid==os.getpid() or int(process.InheritedFromUniqueProcessId or 0)==26048:');code=code.replace('record=dict(pid=pid,','record=dict(creation_time=process.CreateTime,pid=pid,');ns={}
with contextlib.redirect_stdout(io.StringIO()):exec(compile(code,str(diagnostic),'exec'),ns)
records={row['pid']:row for row in ns['records']};assert 59264 in records and 26048 in records and records[26048]['parent']==59264
selected=[records[26048]]+[row for row in records.values() if row['parent']==26048 and row['name'].lower()=='rustc.exe'];assert len(selected)>=2
k=ctypes.WinDLL('kernel32',use_last_error=True);k.OpenProcess.argtypes=[ctypes.c_ulong,ctypes.c_int,ctypes.c_ulong];k.OpenProcess.restype=ctypes.c_void_p;k.CloseHandle.argtypes=[ctypes.c_void_p];k.GetExitCodeProcess.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_ulong)];k.GetPriorityClass.argtypes=[ctypes.c_void_p];k.GetPriorityClass.restype=ctypes.c_ulong;k.SetPriorityClass.argtypes=[ctypes.c_void_p,ctypes.c_ulong];k.GetProcessTimes.argtypes=[ctypes.c_void_p]+[ctypes.POINTER(ctypes.c_ulonglong)]*4;k.QueryFullProcessImageNameW.argtypes=[ctypes.c_void_p,ctypes.c_ulong,ctypes.c_wchar_p,ctypes.POINTER(ctypes.c_ulong)]
handles=[];changes=[]
def times(h):
 values=[ctypes.c_ulonglong() for _ in range(4)];assert k.GetProcessTimes(h,*[ctypes.byref(v) for v in values]);return [v.value for v in values]
try:
 for row in selected:
  h=k.OpenProcess(0x1200,False,row['pid']);assert h,ctypes.get_last_error();handles.append(h);exit_code=ctypes.c_ulong();assert k.GetExitCodeProcess(h,ctypes.byref(exit_code)) and exit_code.value==259
  image=ctypes.create_unicode_buffer(32768);length=ctypes.c_ulong(len(image));assert k.QueryFullProcessImageNameW(h,0,image,ctypes.byref(length));expected=Path('C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin')/row['name'];assert os.path.normcase(image.value)==os.path.normcase(str(expected))
  before=times(h);assert before[0]==row['creation_time'];priority=k.GetPriorityClass(h);assert priority in (0x4000,0x20)
  changes.append(dict(pid=row['pid'],parent=row['parent'],image=image.value,creation_time=before[0],before_priority=priority,before_cpu_seconds=(before[2]+before[3])/10000000,requested_priority=0x20))
 for h,row in zip(handles,changes):
  assert k.SetPriorityClass(h,0x20),ctypes.get_last_error();row['after_priority']=k.GetPriorityClass(h);assert row['after_priority']==0x20
 (d/'adjustment.json').write_text(json.dumps(changes,indent=2)+'\n',encoding='utf-8')
 time.sleep(10)
 for h,row in zip(handles,changes):
  after=times(h);row['observed_cpu_seconds']=(after[2]+after[3])/10000000;row['observed_cpu_delta']=row['observed_cpu_seconds']-row['before_cpu_seconds'];status=ctypes.c_ulong();assert k.GetExitCodeProcess(h,ctypes.byref(status));row['observed_exit_code']=status.value
finally:
 for h in handles:k.CloseHandle(h)
summary=dict(scope='OWN_VERIFIED_WORKSPACE319_CARGO_RUSTC_NORMAL_PRIORITY_ENVIRONMENT_ADJUSTMENT_NOT_PRODUCT_PASS',observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),parent_pid=59264,processes=changes,source_mutated=False,command_scope_changed=False,timeouts_changed=False,process_restarted=False,rollback_priorities={str(row['pid']):row['before_priority'] for row in changes},frozen_inputs=1277,changed_inputs=[p for p,h in frozen.items() if sha(w/p)!=h],terminal=False,priority_api_source='https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-setpriorityclass',interpretation_limit='CPU delta is an observation; no benchmark or final validation claim. Only matching image/creation-time/parent-chain owned processes were changed; no other process priority or system policy changed.')
assert not summary['changed_inputs'];(d/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8');files={'runner345.py':Path(__file__),'native-diagnostic342.py':diagnostic,'adjustment.json':d/'adjustment.json','summary.json':d/'summary.json','frozen319.json':frozen_path};manifest={n:sha(p) for n,p in files.items()};z=b/'task7-owned-normal-priority346.zip';assert not z.exists()
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as out:
 for n,p in files.items():out.write(p,n)
 out.writestr('manifest.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(z) as out:assert all(hashlib.sha256(out.read(n)).hexdigest()==h for n,h in manifest.items())
receipt=b/'task7-owned-normal-priority346.summary.json';receipt.write_text(json.dumps(dict(scope=summary['scope'],sha256=sha(z),verified_entries=len(manifest),processes=changes,production_applied=False),indent=2)+'\n',encoding='utf-8')
for p in (z,receipt):
 q=e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'/p.name;assert not q.exists();shutil.copyfile(p,q);assert sha(p)==sha(q)
note='2026-10-09 原全仓319调度环境345/346：仅现场核验PID/父链/完整1.97.1映像路径/创建时间的本任务Cargo及rustc从BelowNormal设为Normal，逐项保留原优先级及10秒CPU观察；未改全局策略、其他进程、源码/原命令范围/超时/断言，未停止或重启任务。1277冻结变化0，zip346 SHA '+sha(z)+'全部条目/E镜像核验。观察不是性能或产品PASS，319仍待终态，18顶层OPEN。'
for rel in ('.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md','docs/verification/rdbc-first/status.md','docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md'):
 with (e/rel).open('ab') as out:out.write(('\n\n'+note+'\n').encode('utf-8'))
print(json.dumps(dict(processes=changes,zip_sha256=sha(z),verified_entries=len(manifest))))
