from pathlib import Path
import hashlib,json,shutil,zipfile
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d177');e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
d=b/'task7-sqlx-cancel-green299';s=json.loads((d/'summary.json').read_text());assert s['terminal'] and s['exit_code']==0 and s['passed']==2 and not s['failed'] and not s['changed_inputs'];assert sha(Path(s['log']))==s['sha256']
f=json.loads((d/'frozen-inputs.json').read_text());assert len(f)==1277 and all(sha(w/p)==h for p,h in f.items())
files={'evidence/'+p.name:p for p in d.iterdir() if p.is_file()}
for name in ('task7-sqlx-cancel-green-builder298.py','task7-sqlx-cancel-green299.py'):files['runners/'+name]=b/name
files['runner300.py']=Path(__file__)
for rel in ('crates/druid-wrapper/src/sqlx/sqlx_prepared_statement.rs','crates/druid-wrapper/tests/sqlx_statement_cancel_contract_test.rs'):files['candidate/'+rel]=w/rel
scope=dict(scope='TWO_SQLX_CANCEL_CONTRACTS_GREEN_NOT_FULL_DATABASE_OR_TASK7_CERTIFICATION',production_applied=False,parent296_sha256=sha(b/'task7-sqlx-cancel-red-terminal296.zip'),frozen_input_count=len(f),real_database='NOT_RERUN_YET',server_side_concurrent_cancel='NOT_CERTIFIED')
z=b/'task7-sqlx-cancel-green-terminal300.zip';assert not z.exists();manifest={n:sha(p) for n,p in files.items()}
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as out:
 for n,p in files.items():out.write(p,n)
 out.writestr('manifest.json',json.dumps(manifest,indent=2));out.writestr('scope.json',json.dumps(scope,indent=2))
with zipfile.ZipFile(z) as out:assert all(hashlib.sha256(out.read(n)).hexdigest()==h for n,h in manifest.items())
receipt=b/'task7-sqlx-cancel-green-terminal300.summary.json';receipt.write_text(json.dumps(dict(scope,sha256=sha(z),verified_entries=len(manifest)),indent=2)+'\n',encoding='utf-8')
for p in (z,receipt):
 q=e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'/p.name;assert not q.exists();shutil.copyfile(p,q);assert sha(p)==sha(q)
note='2026-10-09 SQLx取消候选299定向GREEN归档300：原295两个失败合同原字节保留，实际2PASS0FAIL；预取消准入HY008且写入0、下一次执行成功，活动游标停止后语句复用。1277输入变化0，zip300 SHA '+sha(z)+'全部条目/E镜像核验。仅F候选增加取消请求与执行代次隔离；尚未重跑完整PG/MySQL，不认证同一借用的并发server-side cancel，不关闭Task7。正式E源码未apply，18顶层OPEN。'
for rel in ('.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md','docs/verification/rdbc-first/status.md','docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md'):
 with (e/rel).open('ab') as out:out.write(('\n\n'+note+'\n').encode('utf-8'))
print(json.dumps(dict(zip_sha256=sha(z),verified_entries=len(manifest))))
