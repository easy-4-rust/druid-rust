from pathlib import Path
import hashlib,json
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d177');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
f=json.loads((b/'task7-sqlx-cancel-red295/frozen-inputs.json').read_text());rel='crates/druid-wrapper/src/sqlx/sqlx_prepared_statement.rs'
assert [p for p,h in f.items() if sha(w/p)!=h]==[rel]
assert sha(b/'task7-sqlx-cancel-red-terminal296.zip')=='529123cec2b7c1ce6c0cb0ec370df4ed6d7cd46e4d507545feb4b77783346e8d'
src=(b/'task7-sqlx-cancel-red295.py').read_text()
old="f=json.loads((b/'task7-live-db-contracts285/frozen-inputs.json').read_text());assert all(sha(w/p)==h for p,h in f.items())"
new="f=json.loads((b/'task7-sqlx-cancel-red295/frozen-inputs.json').read_text());rel='crates/druid-wrapper/src/sqlx/sqlx_prepared_statement.rs';assert [p for p,h in f.items() if sha(w/p)!=h]==[rel];f[rel]=sha(w/rel)"
assert old in src
src=src.replace(old,new).replace("d=b/'task7-sqlx-cancel-red295'","d=b/'task7-sqlx-cancel-green299'")
(b/'task7-sqlx-cancel-green299.py').write_text(src,encoding='utf-8')
print(json.dumps(dict(changed_production=rel,sha256=sha(w/rel),runner='task7-sqlx-cancel-green299.py')))
