from pathlib import Path
import hashlib,json,shutil,zipfile
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d177');e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
d=b/'task7-sqlx-cancel-red295';s=json.loads((d/'summary.json').read_text())
assert s['terminal'] and s['exit_code']==101 and s['passed']==0 and s['failed']==2 and not s['changed_inputs']
assert sha(Path(s['log']))==s['sha256'] and Path(s['log']).read_text().count('UnsupportedOperation { operation: "statement_cancel" }')==2
f=json.loads((d/'frozen-inputs.json').read_text());assert len(f)==1277 and all(sha(w/p)==h for p,h in f.items())
files={'runner296.py':Path(__file__)}
for name in ('task7-sqlx-cancel-red289','task7-sqlx-cancel-fixture-repair294','task7-sqlx-cancel-red295'):
 for p in (b/name).iterdir():
  if p.is_file():files[name+'/'+p.name]=p
for name in ('task7-sqlx-cancel-red289.py','task7-sqlx-cancel-fixture-repair294.py','task7-sqlx-cancel-red295.py','task7-old-validation-handle-audit297.json'):
 files['runners/'+name]=b/name
for rel in ('crates/druid-wrapper/src/sqlx/sqlx_prepared_statement.rs','crates/druid-wrapper/tests/sqlx_statement_cancel_contract_test.rs'):
 files['candidate/'+rel]=w/rel
scope=dict(scope='TWO_SQLX_CANCEL_CONTRACTS_RUNTIME_RED_AFTER_FIXTURE_API_REPAIR',production_applied=False,parent287_sha256=sha(b/'task7-live-db-cancel-red-terminal287.zip'),frozen_input_count=len(f),compile289='E0599_FIXTURE_NOT_RUNTIME_RED',runtime295='0PASS2FAIL_UNSUPPORTED_CANCEL',old_validation_jobs='113_129_215_ORIGINAL_HANDLES_MISSING_NO_SUCCESS_PROOF')
z=b/'task7-sqlx-cancel-red-terminal296.zip';assert not z.exists();manifest={n:sha(p) for n,p in files.items()}
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as out:
 for n,p in files.items():out.write(p,n)
 out.writestr('manifest.json',json.dumps(manifest,indent=2));out.writestr('scope.json',json.dumps(scope,indent=2))
with zipfile.ZipFile(z) as out:assert all(hashlib.sha256(out.read(n)).hexdigest()==h for n,h in manifest.items())
receipt=b/'task7-sqlx-cancel-red-terminal296.summary.json';receipt.write_text(json.dumps(dict(scope,sha256=sha(z),verified_entries=len(manifest)),indent=2)+'\n',encoding='utf-8')
for p in (z,receipt):
 q=e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'/p.name;assert not q.exists();shutil.copyfile(p,q);assert sha(p)==sha(q)
note='2026-10-09 SQLx取消定向RED295归档296：289首次因测试误用set_int编译E0599，不算运行RED；294仅改为实际set_parameter API，原行为断言不变。295实际0PASS2FAIL，均statement_cancel UnsupportedOperation，1277冻结输入变化0。zip296 SHA '+sha(z)+'全部条目/E镜像核验，保留生产preimage和完整日志。另原113/129/215进程handle已缺失且无成功终态，不再声称LIVE或PASS。正式E源码未apply，18顶层OPEN。'
for rel in ('.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md','docs/verification/rdbc-first/status.md','docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md'):
 with (e/rel).open('ab') as out:out.write(('\n\n'+note+'\n').encode('utf-8'))
print(json.dumps(dict(zip_sha256=sha(z),verified_entries=len(manifest))))
