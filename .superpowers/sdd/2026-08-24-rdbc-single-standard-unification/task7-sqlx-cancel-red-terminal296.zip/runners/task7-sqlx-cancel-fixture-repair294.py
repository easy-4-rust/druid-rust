from pathlib import Path
import hashlib,json,shutil
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d177');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
red=json.loads((b/'task7-sqlx-cancel-red289/summary.json').read_text());assert red['terminal'] and red['exit_code']==101 and red['passed']==0 and red['failed']==0 and not red['changed_inputs'] and sha(Path(red['log']))==red['sha256']
assert 'E0599' in Path(red['log']).read_text()
f=json.loads((b/'task7-sqlx-cancel-red289/frozen-inputs.json').read_text());assert all(sha(w/p)==h for p,h in f.items())
d=b/'task7-sqlx-cancel-fixture-repair294';d.mkdir(exist_ok=False);test='crates/druid-wrapper/tests/sqlx_statement_cancel_contract_test.rs';shutil.copyfile(w/test,d/'test.before.rs')
text=(w/test).read_text();assert text.count('.set_int(ParameterIndex::new(1).unwrap(), 7)')==1
text=text.replace('use druid_rdbc::statement::{ParameterIndex, StatementOptions};','use druid_rdbc::statement::{ParameterIndex, PreparedParameter, StatementOptions};').replace('.set_int(ParameterIndex::new(1).unwrap(), 7)','.set_parameter(PreparedParameter { index: ParameterIndex::new(1).unwrap(), value: Value::Int(7) })')
(w/test).write_text(text,encoding='utf-8')
runner=(b/'task7-sqlx-cancel-red289.py').read_text().replace("d=b/'task7-sqlx-cancel-red289'","d=b/'task7-sqlx-cancel-red295'")
start=runner.index("test='crates/druid-wrapper/tests/sqlx_statement_cancel_contract_test.rs';")
end=runner.index("(d/'frozen-inputs.json')",start)
runner=runner[:start]+"test='crates/druid-wrapper/tests/sqlx_statement_cancel_contract_test.rs';f[test]=sha(w/test);assert len(f)==1277\n"+runner[end:]
# Existing production input remains identical to the prior real-database snapshot.
dest=b/'task7-sqlx-cancel-red295.py';assert not dest.exists();compile(runner,str(dest),'exec');dest.write_text(runner,encoding='utf-8')
(d/'summary.json').write_text(json.dumps(dict(scope='TEST_FIXTURE_API_COMPILE_REPAIR_NOT_PRODUCT_RUNTIME_RED',original289_summary_sha256=sha(b/'task7-sqlx-cancel-red289/summary.json'),production_changed=False,before_sha256=f[test]),indent=2)+'\n',encoding='utf-8')
print('fixture uses actual PreparedStatement::set_parameter; behavior assertions unchanged')
