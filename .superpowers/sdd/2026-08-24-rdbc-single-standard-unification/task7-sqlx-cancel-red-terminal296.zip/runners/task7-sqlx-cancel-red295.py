from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,time
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d177');d=b/'task7-sqlx-cancel-red295';d.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
parent=json.loads((b/'task7-live-db-contracts285/summary.json').read_text());assert parent['terminal'] and all(c['removed'] for c in parent['containers'])
f=json.loads((b/'task7-live-db-contracts285/frozen-inputs.json').read_text());assert all(sha(w/p)==h for p,h in f.items())
test='crates/druid-wrapper/tests/sqlx_statement_cancel_contract_test.rs';f[test]=sha(w/test);assert len(f)==1277
(d/'frozen-inputs.json').write_text(json.dumps(f,indent=2)+'\n',encoding='utf-8')
s=dict(terminal=False,production_applied=False,pid=os.getpid(),frozen_input_count=len(f),test_sha256=f[test],original_database_contract_unchanged=True)
def save():(d/'summary.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
save();rt=Path('C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin');env=os.environ.copy();env.update(RUSTC=str(rt/'rustc.exe'),RUSTDOC=str(rt/'rustdoc.exe'),RUSTUP_TOOLCHAIN='1.97.1',RUSTUP_AUTO_INSTALL='0',CARGO_NET_OFFLINE='true',CARGO_TARGET_DIR='F:/codex_build_cache/druid_rust/task7_row_set177_target',DRUID_RDBC_EXTERNAL_TARGET_ROOT='F:/codex_build_cache/druid_rust/task7_row_set177_external',TMP='F:/codex_tmp/task7_standard_cargo13',TEMP='F:/codex_tmp/task7_standard_cargo13');env['PATH']=str(rt)+os.pathsep+env['PATH'];cmd=[str(rt/'cargo.exe'),'test','-p','druid-wrapper','--test','sqlx_statement_cancel_contract_test','--locked','--offline','-j1','--','--nocapture'];log=d/'cancel-contracts.log';start=time.monotonic()
with log.open('wb') as out:result=subprocess.run(cmd,cwd=w,env=env,stdout=out,stderr=subprocess.STDOUT)
text=log.read_text(encoding='utf-8',errors='replace');counts=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed;',text);s.update(terminal=True,exit_code=result.returncode,command=cmd,elapsed_seconds=time.monotonic()-start,log=str(log),sha256=sha(log),passed=sum(int(a) for a,z in counts),failed=sum(int(z) for a,z in counts),changed_inputs=[p for p,h in f.items() if sha(w/p)!=h]);save();print(json.dumps(s),flush=True)
