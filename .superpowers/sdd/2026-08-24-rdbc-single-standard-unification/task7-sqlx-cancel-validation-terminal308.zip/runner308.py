from pathlib import Path
import hashlib,json,shutil,zipfile
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d177');e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
d=b/'task7-sqlx-cancel-validation304';s=json.loads((d/'summary.json').read_text());assert s['terminal'] and s['exit_code']==0 and len(s['commands'])==4
assert s['commands'][0]['passed']==4 and s['commands'][1]['passed']==15
for c in s['commands']:assert c['exit_code']==0 and not c['failed'] and not c['changed_inputs'] and sha(Path(c['log']))==c['sha256']
f=json.loads((d/'frozen-inputs.json').read_text());assert len(f)==1277 and all(sha(w/p)==h for p,h in f.items())
files={'runner308.py':Path(__file__)}
for name in ('task7-sqlx-cancel-validation302','task7-sqlx-cancel-fixture-repair303','task7-sqlx-cancel-validation304'):
 for p in (b/name).iterdir():
  if p.is_file():files[name+'/'+p.name]=p
for name in ('task7-sqlx-cancel-additional301.rs','task7-sqlx-cancel-validation302.py','task7-sqlx-cancel-fixture-repair303.py','task7-sqlx-cancel-validation304.py'):files['runners/'+name]=b/name
for rel in ('crates/druid-wrapper/src/sqlx/sqlx_prepared_statement.rs','crates/druid-wrapper/tests/sqlx_statement_cancel_contract_test.rs'):files['candidate/'+rel]=w/rel
scope=dict(scope='FOUR_SQLX_CANCEL_AND_FIFTEEN_ORIGINAL_ASYNC_CONTRACTS_STRICT_FMT_PASS',production_applied=False,parent300_sha256=s['parent300_sha256'],compile302='E0277_TEST_FIXTURE_NOT_RUNTIME_FAILURE',cancel_contracts='4PASS0FAIL',async_original='15PASS0FAIL',strict_exit=0,fmt_exit=0,real_database='NOT_CERTIFIED_BY_THIS_ARTIFACT',frozen_input_count=len(f))
z=b/'task7-sqlx-cancel-validation-terminal308.zip';assert not z.exists();manifest={n:sha(p) for n,p in files.items()}
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as out:
 for n,p in files.items():out.write(p,n)
 out.writestr('manifest.json',json.dumps(manifest,indent=2));out.writestr('scope.json',json.dumps(scope,indent=2))
with zipfile.ZipFile(z) as out:assert all(hashlib.sha256(out.read(n)).hexdigest()==h for n,h in manifest.items())
receipt=b/'task7-sqlx-cancel-validation-terminal308.summary.json';receipt.write_text(json.dumps(dict(scope,sha256=sha(z),verified_entries=len(manifest)),indent=2)+'\n',encoding='utf-8')
for p in (z,receipt):
 q=e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'/p.name;assert not q.exists();shutil.copyfile(p,q);assert sha(p)==sha(q)
note='2026-10-09 SQLx取消扩展304完整终态308：四取消合同4/0、原异步结果集15/0、指定lib/两测试严格Clippy0、全fmt0；1277冻结输入变化0。新增保留旧游标时cancel自身释放actor、新代次不受旧close影响、重复预取消只消费一次且保留普通批次0写入/重试2写入。302新增夹具unwrap_err要求dyn ResultSet Debug的E0277编译失败保留，303只修错误提取与格式，原两个合同文本保留。zip308 SHA '+sha(z)+'全部条目/E镜像核验。完整实库/全Wrapper/全仓仍须新鲜后继，不认证并发server-side cancel或关闭Task7；正式E源码未apply，18顶层OPEN。'
for rel in ('.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md','docs/verification/rdbc-first/status.md','docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md'):
 with (e/rel).open('ab') as out:out.write(('\n\n'+note+'\n').encode('utf-8'))
print(json.dumps(dict(zip_sha256=sha(z),verified_entries=len(manifest))))
