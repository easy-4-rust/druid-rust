from pathlib import Path
import hashlib,json,subprocess
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d177');d=b/'task7-sqlx-cancel-fixture-repair303';d.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
s=json.loads((b/'task7-sqlx-cancel-validation302/summary.json').read_text());assert s['terminal'] and s['exit_code']==1 and len(s['commands'])==1 and s['commands'][0]['passed']==0 and s['commands'][0]['failed']==0
log=Path(s['commands'][0]['log']);assert sha(log)==s['commands'][0]['sha256'] and 'E0277' in log.read_text()
f=json.loads((b/'task7-sqlx-cancel-validation302/frozen-inputs.json').read_text());assert all(sha(w/p)==h for p,h in f.items())
rel='crates/druid-wrapper/tests/sqlx_statement_cancel_contract_test.rs';p=w/rel;(d/'test.before.rs').write_bytes(p.read_bytes());(d/'compile302.log').write_bytes(log.read_bytes())
old='let error = statement.execute_query("SELECT 3").await.unwrap_err();'
new='let error = match statement.execute_query("SELECT 3").await { Ok(_) => panic!("预取消必须拒绝本次查询"), Err(error) => error };'
text=p.read_text();assert text.count(old)==1;p.write_text(text.replace(old,new),encoding='utf-8')
subprocess.run(['C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin/rustfmt.exe','--edition','2021',str(p)],check=True)
assert p.read_text().startswith((b/'task7-sqlx-cancel-validation302/original-two-contracts.rs').read_text())
source=(b/'task7-sqlx-cancel-validation302.py').read_text();start=source.index('parent=json.loads');end=source.index("(d/'frozen-inputs.json')")
prefix="parent=json.loads((b/'task7-sqlx-cancel-validation302/summary.json').read_text());assert parent['terminal'] and parent['exit_code']==1\nreceipt=json.loads((b/'task7-sqlx-cancel-green-terminal300.summary.json').read_text());assert sha(b/'task7-sqlx-cancel-green-terminal300.zip')==receipt['sha256']\nf=json.loads((b/'task7-sqlx-cancel-validation302/frozen-inputs.json').read_text());rel='crates/druid-wrapper/tests/sqlx_statement_cancel_contract_test.rs';assert [p for p,h in f.items() if sha(w/p)!=h]==[rel];f[rel]=sha(w/rel)\n"
source=(source[:start]+prefix+source[end:]).replace("d=b/'task7-sqlx-cancel-validation302'","d=b/'task7-sqlx-cancel-validation304'")
runner=b/'task7-sqlx-cancel-validation304.py';assert not runner.exists();compile(source,str(runner),'exec');runner.write_text(source,encoding='utf-8')
(d/'summary.json').write_text(json.dumps(dict(scope='TEST_ONLY_E0277_FIXTURE_ERROR_EXTRACTION_AND_RUSTFMT',production_unchanged=all(sha(w/p)==h for p,h in f.items()),test_sha256=sha(p),original_two_contracts_preserved=True,runner_sha256=sha(runner)),indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(test_sha256=sha(p),runner=str(runner))))
