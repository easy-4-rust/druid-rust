from pathlib import Path
import hashlib,json,os,re,subprocess,time
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d177');d=b/'task7-sqlx-cancel-validation302';d.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
parent=json.loads((b/'task7-sqlx-cancel-green299/summary.json').read_text());assert parent['terminal'] and parent['exit_code']==0
receipt=json.loads((b/'task7-sqlx-cancel-green-terminal300.summary.json').read_text());assert sha(b/'task7-sqlx-cancel-green-terminal300.zip')==receipt['sha256']
f=json.loads((b/'task7-sqlx-cancel-green299/frozen-inputs.json').read_text());assert all(sha(w/p)==h for p,h in f.items())
rel='crates/druid-wrapper/tests/sqlx_statement_cancel_contract_test.rs';p=w/rel;old=p.read_bytes();(d/'original-two-contracts.rs').write_bytes(old)
p.write_bytes(old+b'\n'+(b/'task7-sqlx-cancel-additional301.rs').read_bytes());assert p.read_bytes().startswith(old);f[rel]=sha(p)
(d/'frozen-inputs.json').write_text(json.dumps(f,indent=2)+'\n',encoding='utf-8');s=dict(terminal=False,pid=os.getpid(),production_applied=False,parent300_sha256=receipt['sha256'],original_two_contracts_byte_preserved=True,frozen_input_count=len(f),commands=[])
def save():(d/'summary.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
save();rt=Path('C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin');env=os.environ.copy();env.update(RUSTC=str(rt/'rustc.exe'),RUSTDOC=str(rt/'rustdoc.exe'),RUSTUP_TOOLCHAIN='1.97.1',RUSTUP_AUTO_INSTALL='0',CARGO_NET_OFFLINE='true',CARGO_TARGET_DIR='F:/codex_build_cache/druid_rust/task7_row_set177_target',DRUID_RDBC_EXTERNAL_TARGET_ROOT='F:/codex_build_cache/druid_rust/task7_row_set177_external',TMP='F:/codex_tmp/task7_standard_cargo13',TEMP='F:/codex_tmp/task7_standard_cargo13');env['PATH']=str(rt)+os.pathsep+env['PATH']
commands=[('cancel-four',['test','-p','druid-wrapper','--test','sqlx_statement_cancel_contract_test','--locked','--offline','-j1','--','--nocapture']),('async-original',['test','-p','druid-wrapper','--test','async_result_set_test','--locked','--offline','-j1','--','--nocapture']),('cancel-strict',['clippy','-p','druid-wrapper','--lib','--test','sqlx_statement_cancel_contract_test','--test','async_result_set_test','--no-deps','--locked','--offline','-j1','--','-D','warnings']),('fmt',['fmt','--all','--','--check'])]
for name,args in commands:
 assert all(sha(w/p)==h for p,h in f.items());s['running_command']=name;save();log=d/(name+'.log');cmd=[str(rt/'cargo.exe')]+args;start=time.monotonic()
 with log.open('wb') as out:r=subprocess.run(cmd,cwd=w,env=env,stdout=out,stderr=subprocess.STDOUT)
 text=log.read_text(encoding='utf-8',errors='replace');counts=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed;',text);c=dict(name=name,command=cmd,exit_code=r.returncode,log=str(log),sha256=sha(log),elapsed_seconds=time.monotonic()-start,passed=sum(int(a) for a,z in counts),failed=sum(int(z) for a,z in counts),changed_inputs=[p for p,h in f.items() if sha(w/p)!=h]);s['commands'].append(c);save();print(json.dumps(c),flush=True)
 if r.returncode or c['changed_inputs']:break
s.update(terminal=True,exit_code=0 if len(s['commands'])==len(commands) and all(c['exit_code']==0 and not c['changed_inputs'] for c in s['commands']) else 1);s.pop('running_command',None);save()
