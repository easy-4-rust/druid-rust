from pathlib import Path
import ctypes,hashlib,json,os,re,shutil,subprocess,sys,time
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d177');d=b/'task7-unconfirmed-release-green231';d.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();out=d/'summary.json';s=dict(terminal=False,production_applied=False,candidate_applied=False,pid=os.getpid(),commands=[],waiting_for='225 successful terminal and archive232')
def save():out.write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
save();kernel=ctypes.WinDLL('kernel32',use_last_error=True);kernel.OpenProcess.argtypes=[ctypes.c_ulong,ctypes.c_int,ctypes.c_ulong];kernel.OpenProcess.restype=ctypes.c_void_p;kernel.GetExitCodeProcess.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_ulong)];kernel.CloseHandle.argtypes=[ctypes.c_void_p]
def alive(pid):
 handle=kernel.OpenProcess(0x1000,0,pid)
 if not handle:return False
 try:
  code=ctypes.c_ulong();return bool(kernel.GetExitCodeProcess(handle,ctypes.byref(code))) and code.value==259
 finally:kernel.CloseHandle(handle)
try:
 while True:
  parent=json.loads((b/'task7-sqlx-forward-green225/summary.json').read_text())
  if parent['terminal']:break
  if not alive(parent['pid']):
   parent=json.loads((b/'task7-sqlx-forward-green225/summary.json').read_text())
   if parent['terminal']:break
   raise RuntimeError('225 process missing without terminal receipt; no source mutation')
  time.sleep(30)
 assert parent['exit_code']==0 and len(parent['commands'])==5
 cmd=[sys.executable,'-X','utf8',str(b/'task7-sqlx-forward-terminal-archive232.py')];r=subprocess.run(cmd,capture_output=True);(d/'archive232.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0
 f0=json.loads((b/'task7-sqlx-forward-green225/frozen-inputs.json').read_text());assert len(f0)==1274 and all(sha(w/p)==h for p,h in f0.items())
 red=json.loads((b/'task7-unconfirmed-release-red228/summary.json').read_text());assert red['compile_exit_code']==0 and red['test_exit_code']==101 and not red['changed_inputs'] and not red['changed_sources']
 src='crates/druid-rdbc/src/resource/standard_resource_value.rs';test='crates/druid-rdbc/tests/standard_resource_unconfirmed_retry_contract_test.rs';draft=b/'task7-unconfirmed-release-fix229/standard_resource_value.rs';proposal=json.loads((b/'task7-unconfirmed-release-fix229/summary.json').read_text());assert sha(w/src)==proposal['source_sha256'] and sha(draft)==proposal['draft_sha256'];assert not (w/test).exists()
 (d/'standard_resource_value.before.rs').write_bytes((w/src).read_bytes());shutil.copyfile(draft,w/src);shutil.copyfile(b/'task7-unconfirmed-release-contract228.rs',w/test)
 f={p:sha(w/p) for p in f0};f[test]=sha(w/test);delta={p:h for p,h in f.items() if f0.get(p)!=h};assert set(delta)=={src,test};(d/'frozen-inputs.json').write_text(json.dumps(f,indent=2)+'\n',encoding='utf-8');s.update(candidate_applied=True,frozen_input_count=len(f),workspace=str(w),source_delta=delta);s.pop('waiting_for',None);save()
 rt=Path('C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin');env=os.environ.copy();env.update(RUSTC=str(rt/'rustc.exe'),RUSTDOC=str(rt/'rustdoc.exe'),RUSTUP_TOOLCHAIN='1.97.1',RUSTUP_AUTO_INSTALL='0',CARGO_NET_OFFLINE='true',CARGO_TARGET_DIR='F:/codex_build_cache/druid_rust/task7_row_set177_target',DRUID_RDBC_EXTERNAL_TARGET_ROOT='F:/codex_build_cache/druid_rust/task7_row_set177_external',TMP='F:/codex_tmp/task7_standard_cargo13',TEMP='F:/codex_tmp/task7_standard_cargo13');env['PATH']=str(rt)+os.pathsep+env['PATH'];common=['--locked','--offline','-j1']
 commands=[('retry-green',['test','-p','druid-rdbc','--test','standard_resource_unconfirmed_retry_contract_test','--all-features']+common),('strict-resource-contracts',['clippy','-p','druid-rdbc','--test','standard_resource_unconfirmed_retry_contract_test','--test','resource_standard_contract_test','--all-features']+common+['--','-D','warnings']),('rdbc-full',['test','-p','druid-rdbc','--all-features']+common+['--no-fail-fast']),('druid-owner-cancellation',['test','-p','druid','--test','resource_owner_cancellation_test']+common),('format-check',['fmt','--all','--','--check'])]
 for name,args in commands:
  s['running_command']=name;save();cmd=[str(rt/'cargo.exe')]+args;log=d/(name+'.log');started=time.monotonic()
  with log.open('wb') as stdout:r=subprocess.run(cmd,cwd=w,env=env,stdout=stdout,stderr=subprocess.STDOUT)
  changed=[p for p,h in f.items() if sha(w/p)!=h];counts=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed;',log.read_text(encoding='utf-8',errors='replace'));record=dict(name=name,command=cmd,exit_code=r.returncode,elapsed_seconds=time.monotonic()-started,log=str(log),sha256=sha(log),passed=sum(int(a) for a,_ in counts),failed=sum(int(a) for _,a in counts),changed_inputs=changed);s['commands'].append(record);save();print(json.dumps(record),flush=True)
  if r.returncode or changed:s.update(terminal=True,exit_code=r.returncode or 1);save();raise SystemExit(1)
 s.update(terminal=True,exit_code=0);s.pop('running_command',None);save();print('GREEN231_TERMINAL',flush=True)
except Exception as exc:
 s.update(terminal=True,exit_code=1,error=str(exc));save();raise
