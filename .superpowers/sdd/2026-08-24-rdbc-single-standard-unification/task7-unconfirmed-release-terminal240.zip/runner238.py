from pathlib import Path
import ctypes,hashlib,json,os,re,shutil,subprocess,time,zipfile
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d177');e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust');d=b/'task7-unconfirmed-release-queued-green238';d.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
s=dict(terminal=False,production_applied=False,candidate_applied=False,pid=os.getpid(),commands=[],waiting_for='231 successful five-command terminal and immutable archive239')
def save():(d/'summary.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
def note(text):
 for rel in ('.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md','docs/verification/rdbc-first/status.md','docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md'):
  with (e/rel).open('ab') as out:out.write(('\n\n'+text+'\n').encode('utf-8'))
def archive(number,files,scope):
 z=b/('task7-unconfirmed-release-terminal'+str(number)+'.zip');assert not z.exists();manifest={n:sha(p) for n,p in files.items()}
 with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as out:
  for n,p in files.items():out.write(p,n)
  out.writestr('manifest.json',json.dumps(manifest,indent=2));out.writestr('scope.json',json.dumps(scope,indent=2))
 with zipfile.ZipFile(z) as out:assert all(hashlib.sha256(out.read(n)).hexdigest()==h for n,h in manifest.items())
 result=dict(scope,sha256=sha(z),verified_entries=len(manifest));receipt=b/('task7-unconfirmed-release-terminal'+str(number)+'.summary.json');receipt.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
 for p in (z,receipt):
  q=e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'/p.name;assert not q.exists();shutil.copyfile(p,q);assert sha(p)==sha(q)
 return result
kernel=ctypes.WinDLL('kernel32',use_last_error=True);kernel.OpenProcess.argtypes=[ctypes.c_ulong,ctypes.c_int,ctypes.c_ulong];kernel.OpenProcess.restype=ctypes.c_void_p;kernel.GetExitCodeProcess.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_ulong)];kernel.CloseHandle.argtypes=[ctypes.c_void_p]
def alive(pid):
 h=kernel.OpenProcess(0x1000,0,pid)
 if not h:return False
 try:
  c=ctypes.c_ulong();return bool(kernel.GetExitCodeProcess(h,ctypes.byref(c))) and c.value==259
 finally:kernel.CloseHandle(h)
save()
try:
 while True:
  parent=json.loads((b/'task7-unconfirmed-release-green231/summary.json').read_text())
  if parent['terminal']:break
  if not alive(parent['pid']):
   parent=json.loads((b/'task7-unconfirmed-release-green231/summary.json').read_text())
   if parent['terminal']:break
   raise RuntimeError('231 process absent without terminal receipt; no source mutation')
  time.sleep(30)
 assert parent['exit_code']==0 and parent['candidate_applied'] and len(parent['commands'])==5
 assert all(c['exit_code']==0 and not c['changed_inputs'] and sha(Path(c['log']))==c['sha256'] for c in parent['commands'])
 f0=json.loads((b/'task7-unconfirmed-release-green231/frozen-inputs.json').read_text());assert len(f0)==1275 and all(sha(w/p)==h for p,h in f0.items())
 test='crates/druid-rdbc/tests/standard_resource_unconfirmed_retry_contract_test.rs';src='crates/druid-rdbc/src/resource/standard_resource_value.rs';assert sha(w/test)==sha(b/'task7-unconfirmed-release-contract228.rs')
 expanded=b/'task7-unconfirmed-release-contract235.rs';assert sha(expanded)=='04575d0d0277f7a899a20755c5201d6dccb03eeeae6b77181db34f0ece96dd25'
 old=(w/test).read_text();new=expanded.read_text();assert new.split('#[test]\nfn queued_failed_retry_keeps_unconfirmed_state_observed_after_lock')[0].rstrip()==old.rstrip();assert new.count('#[test]')==5
 red=json.loads((b/'task7-unconfirmed-release-red235/summary.json').read_text());assert red['compile_exit_code']==0 and red['test_exit_code']==101 and not red['changed_inputs'] and not red['changed_sources']
 predecessor=b/'task7-sqlx-forward-terminal232.zip';assert predecessor.exists()
 files={'evidence/'+p.name:p for p in (b/'task7-unconfirmed-release-green231').iterdir() if p.is_file()};files.update({'runner231.py':b/'task7-unconfirmed-release-green231.py','source-delta/'+src:w/src,'source-delta/'+test:w/test})
 a=archive(239,files,dict(scope='RESOURCE_UNCONFIRMED_RETRY_THREE_CONTRACT_FULL_TERMINAL',production_applied=False,parent_sha256=sha(predecessor),source_delta=parent['source_delta'],commands=parent['commands'],frozen_input_count=len(f0)))
 note('2026-10-09 资源失败重试修正原三合同完整终态239：231五命令全部exit0，原三合同'+str(parent['commands'][0]['passed'])+'/0、资源strict0、完整RDBC'+str(parent['commands'][2]['passed'])+'/0、Druid owner取消'+str(parent['commands'][3]['passed'])+'/0、fmt0；1275冻结输入变化0。zip239 SHA '+a['sha256']+'，父232，全部条目/E镜像SHA核验。原235排队路径尚未通过；238将在此成功终态后仅扩展原测试至五合同，保留原三合同全部字节语义。正式Rust未apply；18顶层OPEN。')
 (d/'test.before.rs').write_bytes((w/test).read_bytes());shutil.copyfile(expanded,w/test);f={p:sha(w/p) for p in f0};delta={p:h for p,h in f.items() if f0[p]!=h};assert set(delta)=={test};(d/'frozen-inputs.json').write_text(json.dumps(f,indent=2)+'\n');s.update(candidate_applied=True,workspace=str(w),source_delta=delta,frozen_input_count=len(f),parent_archive_sha256=a['sha256']);s.pop('waiting_for',None);save()
 rt=Path('C:/Users/hnxyh/.rustup/toolchains/1.97.1-x86_64-pc-windows-msvc/bin');env=os.environ.copy();env.update(RUSTC=str(rt/'rustc.exe'),RUSTDOC=str(rt/'rustdoc.exe'),RUSTUP_TOOLCHAIN='1.97.1',RUSTUP_AUTO_INSTALL='0',CARGO_NET_OFFLINE='true',CARGO_TARGET_DIR='F:/codex_build_cache/druid_rust/task7_row_set177_target',DRUID_RDBC_EXTERNAL_TARGET_ROOT='F:/codex_build_cache/druid_rust/task7_row_set177_external',TMP='F:/codex_tmp/task7_standard_cargo13',TEMP='F:/codex_tmp/task7_standard_cargo13');env['PATH']=str(rt)+os.pathsep+env['PATH'];common=['--locked','--offline','-j1']
 commands=[('five-contracts',['test','-p','druid-rdbc','--test','standard_resource_unconfirmed_retry_contract_test','--all-features']+common),('strict-five-contracts',['clippy','-p','druid-rdbc','--test','standard_resource_unconfirmed_retry_contract_test','--all-features']+common+['--','-D','warnings']),('rdbc-full',['test','-p','druid-rdbc','--all-features']+common+['--no-fail-fast']),('format-check',['fmt','--all','--','--check'])]
 for name,args in commands:
  assert all(sha(w/p)==h for p,h in f.items());s['running_command']=name;save();cmd=[str(rt/'cargo.exe')]+args;log=d/(name+'.log');started=time.monotonic()
  with log.open('wb') as out:result=subprocess.run(cmd,cwd=w,env=env,stdout=out,stderr=subprocess.STDOUT)
  changed=[p for p,h in f.items() if sha(w/p)!=h];counts=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed;',log.read_text(encoding='utf-8',errors='replace'));c=dict(name=name,command=cmd,exit_code=result.returncode,elapsed_seconds=time.monotonic()-started,log=str(log),sha256=sha(log),passed=sum(int(x) for x,y in counts),failed=sum(int(y) for x,y in counts),changed_inputs=changed);s['commands'].append(c);save();print(json.dumps(c),flush=True)
  assert result.returncode==0 and not changed
  if name=='five-contracts':assert c['passed']==5 and c['failed']==0
 s.update(terminal=True,exit_code=0);s.pop('running_command',None);save()
 files={'evidence/'+p.name:p for p in d.iterdir() if p.is_file()};files.update({'runner238.py':Path(__file__),'source-delta/'+test:w/test,'original-five-red235.rs':expanded})
 a=archive(240,files,dict(scope='RESOURCE_UNCONFIRMED_DIRECT_AND_QUEUED_RETRY_FIVE_CONTRACT_FULL_TERMINAL',production_applied=False,parent_sha256=s['parent_archive_sha256'],source_delta=delta,commands=s['commands'],frozen_input_count=len(f)))
 note('2026-10-09 取消后直接与排队失败重试完整五合同终态240：238原235全部五合同5/0、strict0、完整RDBC'+str(s['commands'][2]['passed'])+'/0、fmt0；1275输入变化0，生产代码相对231未变，唯一delta为测试从三扩展至五。zip240 SHA '+a['sha256']+'，父239，全部条目/E镜像核验；原235的3/2 RED及234夹具失败保留在237。正式Rust未apply；Task6 FIX_REQUIRED/Task7八义务/Task8 INCOMPLETE/18顶层OPEN。')
except Exception as exc:
 s.update(terminal=True,exit_code=1,error=str(exc));save();raise
