from pathlib import Path
import hashlib,json,shutil,zipfile
b=Path(__file__).parent
w=Path('F:/codex_build_cache/d177')
e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust')
d=b/'task7-final-candidate-workspace319'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
s=json.loads((d/'summary.json').read_text())
records={r['name']:r for r in s['commands']}
assert all(records[n]['exit_code']==code for n,code in [('workspace-complete',0),('workspace-strict',101),('workspace-doc',0),('format-check',0)])
assert all(not r['changed_inputs'] and sha(Path(r['log']))==r['sha256'] for r in records.values())
frozen=json.loads((d/'frozen-inputs.json').read_text())
assert len(frozen)==1277 and all(sha(w/p)==h for p,h in frozen.items())
files={'runner399.py':Path(__file__),'runner319.py':b/'task7-final-candidate-workspace319.py','frozen319.json':d/'frozen-inputs.json'}
for name in ('workspace-strict','workspace-doc','format-check'):files[name+'.log']=Path(records[name]['log'])
files['lifetime_tests.before.rs']=b/'task7-lifetime-clippy-draft398/lifetime_tests.before.rs'
files['lifetime_tests.desired.rs']=b/'task7-lifetime-clippy-draft398/lifetime_tests.rs'
files['checked-sub.patch']=b/'task7-lifetime-clippy-draft398/checked-sub.patch'
files['draft-summary.json']=b/'task7-lifetime-clippy-draft398/summary.json'
entries={name:sha(path) for name,path in files.items()}
z=b/'task7-workspace-gates400.zip'
assert not z.exists()
receipt=b/'task7-workspace-gates400.summary.json'
state=dict(scope='FOUR_GATE_TERMINALS_WITH_C1_STILL_PENDING',commands=list(records.values()),frozen_inputs_changed=0,production_applied=False,repair_draft_applied=False,c1_complete_certified=False,remaining_top_level_tasks=18)
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as archive:
 for name,path in files.items():archive.write(path,name)
 archive.writestr('gate-status.json',json.dumps(state,indent=2))
 archive.writestr('manifest.json',json.dumps(entries,indent=2))
with zipfile.ZipFile(z) as archive:assert all(hashlib.sha256(archive.read(name)).hexdigest()==h for name,h in entries.items())
receipt.write_text(json.dumps(dict(sha256=sha(z),verified_entries=len(entries),state=state),indent=2)+'\n',encoding='utf-8')
for item in (z,receipt):
 target=e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'/item.name
 assert not target.exists()
 shutil.copyfile(item,target)
 assert sha(item)==sha(target)
note='2026-10-09 原319四门禁终态399/400：全仓allfeatures测试4198/0 exit0；strict/alltargets/-D warnings实际exit101，lifetime_tests.rs两处unchecked_time_subtraction；doc/no-deps与fmt/all/check实际exit0。两处checked_sub草稿rustfmt通过、逆变换逐字节相等，原年龄/阈值/断言保留，未apply或宣称修复后Clippy/runtime GREEN。1277冻结变化0；原完整C1/C2继续。zip400 SHA '+sha(z)+'逐条目及E镜像核验，18顶层OPEN。'
for rel in ('.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md','docs/verification/rdbc-first/status.md','docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md'):
 with (e/rel).open('ab') as out:out.write(('\n\n'+note+'\n').encode('utf-8'))
print(json.dumps(dict(zip_sha256=sha(z),frozen_changed=0,production_applied=False)))
