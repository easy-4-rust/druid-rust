from pathlib import Path
import hashlib,json,shutil,zipfile

b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
w=Path('F:/codex_build_cache/d177')
e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust')
source=b/'task7-final-candidate-workspace319'
d=b/'task7-workspace-pass391'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
summary=json.loads((source/'summary.json').read_text())
record=next(c for c in summary['commands'] if c['name']=='workspace-complete')
expected=['test','--workspace','--all-features','--locked','--offline','-j1','--no-fail-fast']
assert record['command'][1:]==expected
assert record['exit_code']==0 and record['passed']==4198 and record['failed']==0 and record['ignored']==0
assert not record['changed_inputs'] and not record['failing_tests']
assert sha(Path(record['log']))==record['sha256']
frozen=json.loads((source/'frozen-inputs.json').read_text())
assert len(frozen)==1277 and all(sha(w/p)==h for p,h in frozen.items())
d.mkdir(exist_ok=False)
state=dict(scope='FULL_WORKSPACE_ALL_FEATURES_TEST_ONLY',record=record,frozen_inputs=1277,changed_inputs=0,production_applied=False,other_four_gates_not_certified=True,remaining_top_level_tasks=18)
(d/'summary.json').write_text(json.dumps(state,indent=2)+'\n',encoding='utf-8')
(d/'report.md').write_text('# 全仓全功能测试终态\n\n原319全范围 cargo test --workspace --all-features --locked --offline -j1 --no-fail-fast 实际exit0，4198 PASS/0 FAIL/0 ignored。包含doctest，原1277冻结输入逐项hash不变。\n\n只关闭本轮全仓测试项：严格Clippy、doc、fmt、完整C1/C2由原执行器继续，尚未声明全部通过；未集成E正式源码，不证明LLVM/API/MSRV/发布。18顶层任务保持OPEN。\n',encoding='utf-8')
files={'runner391.py':Path(__file__),'summary.json':d/'summary.json','report.md':d/'report.md','workspace-complete.log':Path(record['log']),'frozen319.json':source/'frozen-inputs.json'}
entries={name:sha(p) for name,p in files.items()}
z=b/'task7-workspace-pass392.zip'
assert not z.exists()
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as archive:
 for name,p in files.items():archive.write(p,name)
 archive.writestr('manifest.json',json.dumps(entries,indent=2))
with zipfile.ZipFile(z) as archive:assert all(hashlib.sha256(archive.read(name)).hexdigest()==h for name,h in entries.items())
receipt=b/'task7-workspace-pass392.summary.json'
receipt.write_text(json.dumps(dict(sha256=sha(z),verified_entries=len(entries),passed=4198,failed=0,production_applied=False),indent=2)+'\n',encoding='utf-8')
for item in (z,receipt):
 target=e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'/item.name
 assert not target.exists()
 shutil.copyfile(item,target)
 assert sha(item)==sha(target)
note='2026-10-09 原319完整workspace/all-features测试终态391/392：原命令含locked/offline/-j1/no-fail-fast实际exit0，4198 PASS/0 FAIL/0 ignored，原1277冻结输入hash逐项不变，日志SHA '+record['sha256']+'。原执行器继续strict/doc/fmt/完整C1-C2，不能提前声明其他四门禁PASS；未apply正式源码，LLVM/API/MSRV及18顶层任务仍OPEN。zip392 SHA '+sha(z)+'全部条目及E镜像核验。'
for rel in ('.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md','docs/verification/rdbc-first/status.md','docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md'):
 with (e/rel).open('ab') as out:out.write(('\n\n'+note+'\n').encode('utf-8'))
print(json.dumps(dict(passed=4198,failed=0,zip_sha256=sha(z),frozen_changed=0)))
