from pathlib import Path
import subprocess
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
source=(b/'task8-all69-source-shapes338.py').read_text(encoding='utf-8')
for old,new in [('task8-all69-source-shapes338','task8-all69-reexport-shapes340'),('task8-all69-source-shapes339','task8-all69-reexport-shapes341'),('runner338.py','runner340.py'),('69行源码形态预检338/339','69行重导出形态补证340/341'),('zip339 SHA','zip341 SHA')]:
 assert old in source;source=source.replace(old,new)
anchor=" record['declarations']=matches\n"
extra=""" if not matches and len(parts)==3:
  facade=src/domain/'mod.rs'
  if facade in cache:
   reexport=re.search(r'^pub use crate::([a-z_][a-z0-9_]*)::'+re.escape(symbol)+r';$',cache[facade],re.M)
   if reexport:
    destination=reexport[1];destination_facade=src/destination/'mod.rs'
    assert destination_facade in cache
    assert re.search(r'^pub use [a-z_][a-z0-9_]*::'+re.escape(symbol)+r';$',cache[destination_facade],re.M)
    for path,text in cache.items():
     if path.relative_to(src).parts[0]!=destination:continue
     for declaration in re.finditer(r'^pub (struct|enum|trait|type) '+re.escape(symbol)+r'\\b',text,re.M):
      matches.append(dict(kind=declaration[1],path=path.relative_to(w).as_posix(),line=text[:declaration.start()].count('\\n')+1,sha256=sha(path)))
      source_files.add(path)
    source_files.update((facade,destination_facade))
    record['explicit_reexport_chain']=[dict(path=p.relative_to(w).as_posix(),sha256=sha(p)) for p in (facade,destination_facade)]
"""
assert anchor in source;source=source.replace(anchor,extra+anchor)
source=source.replace("'runner340.py':Path(__file__)","'runner340.py':Path(__file__),'builder340.py':b/'task8-all69-reexport-shapes340-builder.py','parent338-runner.py':b/'task8-all69-source-shapes338.py'")
source=source.replace("直接源码查找不证明公开可见性/cfg/alias/compiler/API/runtime。", "Savepoint显式connection->types重导出两级及源声明已SHA绑定；339直接查找未解析不表示产品缺失。源码预检仍不证明cfg/compiler/API/runtime。")
target=b/'task8-all69-reexport-shapes340.py';assert not target.exists();target.write_text(source,encoding='utf-8')
raise SystemExit(subprocess.run(['C:/Espressif/tools/python/python.exe','-X','utf8',str(target)]).returncode)
