# 69行当前源码形态预检

本报告不替代编译器 public API、feature 可见性或最终运行验收。

| Java 对象 | 原形态 / 草稿形态 | 源码声明 | 状态 |
| --- | --- | --- | --- |
| java.sql.Array | TRAIT / TRAIT | trait crates/druid-rdbc/src/resource/array.rs:9 | DRAFT_SOURCE_KIND_MATCH |
| java.sql.BatchUpdateException | ENUM_KIND / DTO | struct crates/druid-rdbc/src/error/batch_update_exception.rs:8 | DRAFT_SOURCE_KIND_MATCH |
| java.sql.Blob | TRAIT / TRAIT | trait crates/druid-rdbc/src/resource/blob.rs:8 | DRAFT_SOURCE_KIND_MATCH |
| java.sql.CallableStatement | TRAIT / TRAIT | trait crates/druid-rdbc/src/statement/callable_statement.rs:269 | DRAFT_SOURCE_KIND_MATCH |
| java.sql.ClientInfoStatus | ENUM_KIND / ENUM_KIND | enum crates/druid-rdbc/src/connection/client_info_status.rs:6 | DRAFT_SOURCE_KIND_MATCH |
| java.sql.Clob | TRAIT / TRAIT | trait crates/druid-rdbc/src/resource/clob.rs:9 | DRAFT_SOURCE_KIND_MATCH |
| java.sql.Connection | TRAIT / TRAIT | trait crates/druid-rdbc/src/connection/connection.rs:47 | DRAFT_SOURCE_KIND_MATCH |
| java.sql.DataTruncation | ENUM_KIND / DTO | struct crates/druid-rdbc/src/error/data_truncation.rs:6 | DRAFT_SOURCE_KIND_MATCH |
| java.sql.DatabaseMetaData | TRAIT / TRAIT | trait crates/druid-rdbc/src/metadata/database_meta_data.rs:28 | DRAFT_SOURCE_KIND_MATCH |
| java.sql.Date | DTO / DTO | struct crates/druid-rdbc/src/types/date.rs:11 | DRAFT_SOURCE_KIND_MATCH |
| java.sql.Driver | TRAIT / TRAIT | trait crates/druid-rdbc/src/driver/driver.rs:38 | DRAFT_SOURCE_KIND_MATCH |
| java.sql.DriverAction | CALLBACK / CALLBACK | trait crates/druid-rdbc/src/driver/driver_action.rs:4 | DRAFT_SOURCE_KIND_MATCH |
| java.sql.DriverManager | MODULE / DTO | struct crates/druid-rdbc/src/driver/driver_registry.rs:9 | DRAFT_SOURCE_KIND_MATCH |
| java.sql.DriverPropertyInfo | DTO / DTO | struct crates/druid-rdbc/src/driver/driver.rs:10 | DRAFT_SOURCE_KIND_MATCH |
| java.sql.JDBCType | ENUM_KIND / ENUM_KIND | enum crates/druid-rdbc/src/types/jdbc_type.rs:9 | DRAFT_SOURCE_KIND_MATCH |
| java.sql.NClob | TRAIT / TRAIT | trait crates/druid-rdbc/src/resource/n_clob.rs:3 | DRAFT_SOURCE_KIND_MATCH |
| java.sql.ParameterMetaData | TRAIT / TRAIT | trait crates/druid-rdbc/src/metadata/parameter_meta_data.rs:70 | DRAFT_SOURCE_KIND_MATCH |
| java.sql.PreparedStatement | TRAIT / TRAIT | trait crates/druid-rdbc/src/statement/prepared_statement.rs:65 | DRAFT_SOURCE_KIND_MATCH |
| java.sql.PseudoColumnUsage | ENUM_KIND / ENUM_KIND | enum crates/druid-rdbc/src/metadata/pseudo_column_usage.rs:5 | DRAFT_SOURCE_KIND_MATCH |
| java.sql.Ref | TRAIT / TRAIT | trait crates/druid-rdbc/src/resource/ref_value.rs:10 | DRAFT_SOURCE_KIND_MATCH |
| java.sql.ResultSet | TRAIT / TRAIT | trait crates/druid-rdbc/src/result_set/result_set.rs:93 | DRAFT_SOURCE_KIND_MATCH |
| java.sql.ResultSetMetaData | TRAIT / TRAIT | trait crates/druid-rdbc/src/metadata/result_set_meta_data.rs:377 | DRAFT_SOURCE_KIND_MATCH |
| java.sql.RowId | DTO / DTO | struct crates/druid-rdbc/src/types/row_id.rs:9 | DRAFT_SOURCE_KIND_MATCH |
| java.sql.RowIdLifetime | ENUM_KIND / ENUM_KIND | enum crates/druid-rdbc/src/metadata/result_set_meta_data.rs:33 | DRAFT_SOURCE_KIND_MATCH |
| java.sql.SQLClientInfoException | ENUM_KIND / DTO | struct crates/druid-rdbc/src/error/sql_client_info_exception.rs:9 | DRAFT_SOURCE_KIND_MATCH |
| java.sql.SQLData | TRAIT / TRAIT | trait crates/druid-rdbc/src/resource/sql_data.rs:9 | DRAFT_SOURCE_KIND_MATCH |
| java.sql.SQLDataException | ENUM_KIND / ENUM_KIND | enum_variant crates/druid-rdbc/src/error/sql_exception_kind.rs:18 | DRAFT_SOURCE_KIND_MATCH |
| java.sql.SQLException | ENUM_KIND / DTO | struct crates/druid-rdbc/src/error/sql_exception.rs:25 | DRAFT_SOURCE_KIND_MATCH |
| java.sql.SQLFeatureNotSupportedException | ENUM_KIND / ENUM_KIND | enum_variant crates/druid-rdbc/src/error/sql_exception_kind.rs:28 | DRAFT_SOURCE_KIND_MATCH |
| java.sql.SQLInput | TRAIT / TRAIT | trait crates/druid-rdbc/src/resource/sql_input.rs:13 | DRAFT_SOURCE_KIND_MATCH |
| java.sql.SQLIntegrityConstraintViolationException | ENUM_KIND / ENUM_KIND | enum_variant crates/druid-rdbc/src/error/sql_exception_kind.rs:20 | DRAFT_SOURCE_KIND_MATCH |
| java.sql.SQLInvalidAuthorizationSpecException | ENUM_KIND / ENUM_KIND | enum_variant crates/druid-rdbc/src/error/sql_exception_kind.rs:22 | DRAFT_SOURCE_KIND_MATCH |
| java.sql.SQLNonTransientConnectionException | ENUM_KIND / ENUM_KIND | enum_variant crates/druid-rdbc/src/error/sql_exception_kind.rs:14 | DRAFT_SOURCE_KIND_MATCH |
| java.sql.SQLNonTransientException | ENUM_KIND / ENUM_KIND | enum_variant crates/druid-rdbc/src/error/sql_exception_kind.rs:12 | DRAFT_SOURCE_KIND_MATCH |
| java.sql.SQLOutput | TRAIT / TRAIT | trait crates/druid-rdbc/src/resource/sql_output.rs:16 | DRAFT_SOURCE_KIND_MATCH |
| java.sql.SQLPermission | EXCLUDED_RUNTIME / EXCLUDED_RUNTIME |  | EXCLUDED_HOST_RUNTIME |
| java.sql.SQLRecoverableException | ENUM_KIND / ENUM_KIND | enum_variant crates/druid-rdbc/src/error/sql_exception_kind.rs:16 | DRAFT_SOURCE_KIND_MATCH |
| java.sql.SQLSyntaxErrorException | ENUM_KIND / ENUM_KIND | enum_variant crates/druid-rdbc/src/error/sql_exception_kind.rs:24 | DRAFT_SOURCE_KIND_MATCH |
| java.sql.SQLTimeoutException | ENUM_KIND / ENUM_KIND | enum_variant crates/druid-rdbc/src/error/sql_exception_kind.rs:30 | DRAFT_SOURCE_KIND_MATCH |
| java.sql.SQLTransactionRollbackException | ENUM_KIND / ENUM_KIND | enum_variant crates/druid-rdbc/src/error/sql_exception_kind.rs:26 | DRAFT_SOURCE_KIND_MATCH |
| java.sql.SQLTransientConnectionException | ENUM_KIND / ENUM_KIND | enum_variant crates/druid-rdbc/src/error/sql_exception_kind.rs:10 | DRAFT_SOURCE_KIND_MATCH |
| java.sql.SQLTransientException | ENUM_KIND / ENUM_KIND | enum_variant crates/druid-rdbc/src/error/sql_exception_kind.rs:8 | DRAFT_SOURCE_KIND_MATCH |
| java.sql.SQLType | TRAIT / TRAIT | trait crates/druid-rdbc/src/types/rdbc_sql_type.rs:5 | DRAFT_SOURCE_KIND_MATCH |
| java.sql.SQLWarning | ENUM_KIND / DTO | struct crates/druid-rdbc/src/error/sql_warning.rs:8 | DRAFT_SOURCE_KIND_MATCH |
| java.sql.SQLXML | TRAIT / TRAIT | trait crates/druid-rdbc/src/resource/sql_xml.rs:12 | DRAFT_SOURCE_KIND_MATCH |
| java.sql.Savepoint | DTO / DTO |  | UNRESOLVED_SOURCE_DECLARATION |
| java.sql.Statement | TRAIT / TRAIT | trait crates/druid-rdbc/src/statement/statement.rs:254 | DRAFT_SOURCE_KIND_MATCH |
| java.sql.Struct | TRAIT / TRAIT | trait crates/druid-rdbc/src/resource/struct_value.rs:9 | DRAFT_SOURCE_KIND_MATCH |
| java.sql.Time | DTO / DTO | struct crates/druid-rdbc/src/types/time.rs:11 | DRAFT_SOURCE_KIND_MATCH |
| java.sql.Timestamp | DTO / DTO | struct crates/druid-rdbc/src/types/timestamp.rs:11 | DRAFT_SOURCE_KIND_MATCH |
| java.sql.Types | MODULE / MODULE | mod crates/druid-rdbc/src/types/mod.rs:29 | DRAFT_SOURCE_KIND_MATCH |
| java.sql.Wrapper | TRAIT / TRAIT | trait crates/druid-rdbc/src/wrapper/wrapper.rs:10 | DRAFT_SOURCE_KIND_MATCH |
| javax.sql.CommonDataSource | TRAIT / TRAIT | trait crates/druid-rdbc/src/data_source/common_data_source.rs:5 | DRAFT_SOURCE_KIND_MATCH |
| javax.sql.ConnectionEvent | DTO / DTO | struct crates/druid-rdbc/src/data_source/connection_event.rs:13 | DRAFT_SOURCE_KIND_MATCH |
| javax.sql.ConnectionEventListener | CALLBACK / CALLBACK | trait crates/druid-rdbc/src/data_source/connection_event_listener.rs:5 | DRAFT_SOURCE_KIND_MATCH |
| javax.sql.ConnectionPoolDataSource | TRAIT / TRAIT | trait crates/druid-rdbc/src/data_source/connection_pool_data_source.rs:6 | DRAFT_SOURCE_KIND_MATCH |
| javax.sql.DataSource | TRAIT / TRAIT | trait crates/druid-rdbc/src/data_source/data_source.rs:8 | DRAFT_SOURCE_KIND_MATCH |
| javax.sql.PooledConnection | TRAIT / TRAIT | trait crates/druid-rdbc/src/data_source/pooled_connection.rs:6 | DRAFT_SOURCE_KIND_MATCH |
| javax.sql.RowSet | TRAIT / TRAIT | trait crates/druid-rdbc/src/extensions/row_set.rs:16 | DRAFT_SOURCE_KIND_MATCH |
| javax.sql.RowSetEvent | DTO / DTO | struct crates/druid-rdbc/src/extensions/row_set_event.rs:7 | DRAFT_SOURCE_KIND_MATCH |
| javax.sql.RowSetInternal | TRAIT / TRAIT | trait crates/druid-rdbc/src/extensions/row_set_internal.rs:9 | DRAFT_SOURCE_KIND_MATCH |
| javax.sql.RowSetListener | CALLBACK / CALLBACK | trait crates/druid-rdbc/src/extensions/row_set_listener.rs:5 | DRAFT_SOURCE_KIND_MATCH |
| javax.sql.RowSetMetaData | TRAIT / TRAIT | trait crates/druid-rdbc/src/extensions/row_set_meta_data.rs:8 | DRAFT_SOURCE_KIND_MATCH |
| javax.sql.RowSetReader | CALLBACK / CALLBACK | trait crates/druid-rdbc/src/extensions/row_set_reader.rs:7 | DRAFT_SOURCE_KIND_MATCH |
| javax.sql.RowSetWriter | CALLBACK / CALLBACK | trait crates/druid-rdbc/src/extensions/row_set_writer.rs:7 | DRAFT_SOURCE_KIND_MATCH |
| javax.sql.StatementEvent | DTO / DTO | struct crates/druid-rdbc/src/data_source/statement_event.rs:14 | DRAFT_SOURCE_KIND_MATCH |
| javax.sql.StatementEventListener | CALLBACK / CALLBACK | trait crates/druid-rdbc/src/data_source/statement_event_listener.rs:5 | DRAFT_SOURCE_KIND_MATCH |
| javax.sql.XAConnection | TRAIT / TRAIT | trait crates/druid-rdbc/src/data_source/xa_connection.rs:4 | DRAFT_SOURCE_KIND_MATCH |
| javax.sql.XADataSource | TRAIT / TRAIT | trait crates/druid-rdbc/src/data_source/xa_data_source.rs:6 | DRAFT_SOURCE_KIND_MATCH |
