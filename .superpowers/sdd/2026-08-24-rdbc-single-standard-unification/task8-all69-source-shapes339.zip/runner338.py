from pathlib import Path
from collections import Counter
import hashlib,json,re,shutil,sys,zipfile
sys.dont_write_bytecode=True
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d177');e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust');d=b/'task8-all69-source-shapes338';d.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
frozen_path=b/'task7-final-candidate-workspace319/frozen-inputs.json';frozen=json.loads(frozen_path.read_text());assert len(frozen)==1277 and all(sha(w/p)==h for p,h in frozen.items())
sys.path.insert(0,str(w/'scripts'));import verify_jdbc42_semantic_inventory as verifier
inventory=w/verifier.DEFAULT_SEMANTIC;original=verifier.parse_semantic_payload(inventory.read_bytes());draft_path=b/'task8-canonical-shape-draft334/jdbc42-semantic-inventory.draft.tsv';draft=verifier.parse_semantic_payload(draft_path.read_bytes());assert len(original)==len(draft)==69
src=w/'crates/druid-rdbc/src';cache={p:p.read_text(encoding='utf-8') for p in src.rglob('*.rs')};findings=[];source_files=set()
allowed={'TRAIT':{'trait'},'CALLBACK':{'trait'},'DTO':{'struct','enum'},'ENUM_KIND':{'enum','enum_variant'},'MODULE':{'mod'}}
for line,(old,new) in enumerate(zip(original,draft),2):
 target=old[5];record=dict(line=line,java=old[1],target=target,original_shape=old[3],draft_shape=new[3],compiler_api_certified=False)
 if old[3]=='EXCLUDED_RUNTIME':
  assert target=='host::process_security_policy';record.update(status='EXCLUDED_HOST_RUNTIME',declarations=[]);findings.append(record);continue
 parts=target.split('::');assert parts[0]=='druid_rdbc' and len(parts) in (3,4)
 domain=parts[1];symbol=parts[2];matches=[]
 for path,text in cache.items():
  if path.relative_to(src).parts[0]!=domain:continue
  for match in re.finditer(r'^pub (struct|enum|trait|type|mod) '+re.escape(symbol)+r'\b',text,re.M):
   kind=match[1];source_line=text[:match.start()].count('\n')+1
   if len(parts)==4:
    if kind!='enum':continue
    start=text.index('{',match.end());depth=1;cursor=start+1
    while depth and cursor<len(text):
     depth+=(text[cursor]=='{')-(text[cursor]=='}');cursor+=1
    body=text[start+1:cursor-1];variant=re.search(r'^\s*'+re.escape(parts[3])+r'\s*(?:,|\(|\{|=)',body,re.M)
    if not variant:continue
    kind='enum_variant';source_line=text[:start+1+variant.start()].count('\n')+1
   matches.append(dict(kind=kind,path=path.relative_to(w).as_posix(),line=source_line,sha256=sha(path)))
   source_files.add(path)
 record['declarations']=matches
 if len(matches)!=1:record['status']='UNRESOLVED_SOURCE_DECLARATION' if not matches else 'AMBIGUOUS_SOURCE_DECLARATION'
 else:
  actual=matches[0]['kind'];record.update(source_kind=actual,original_kind_matches=actual in allowed[old[3]],draft_kind_matches=actual in allowed[new[3]])
  record['status']='DRAFT_SOURCE_KIND_MATCH' if record['draft_kind_matches'] else 'DRAFT_SOURCE_KIND_CONFLICT'
 findings.append(record)
counts=dict(Counter(row['status'] for row in findings));summary=dict(scope='ALL69_SOURCE_DECLARATION_PREFLIGHT_NOT_COMPILER_PUBLIC_API_OR_RUNTIME',production_applied=False,candidate_mutated=False,frozen_input_count=len(frozen),inventory_sha256=sha(inventory),draft_sha256=sha(draft_path),rows=69,status_counts=counts,findings=findings,source_resolution_caveat='Direct declaration lookup does not prove compiler visibility, cfg availability, alias resolution, auto traits, public API or runtime semantics.')
assert all(sha(w/p)==h for p,h in frozen.items());(d/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
report=['# 69行当前源码形态预检','','本报告不替代编译器 public API、feature 可见性或最终运行验收。','', '| Java 对象 | 原形态 / 草稿形态 | 源码声明 | 状态 |','| --- | --- | --- | --- |']
for row in findings:report.append('| '+row['java']+' | '+row['original_shape']+' / '+row['draft_shape']+' | '+'; '.join(x['kind']+' '+x['path']+':'+str(x['line']) for x in row['declarations'])+' | '+row['status']+' |')
(d/'report.md').write_text('\n'.join(report)+'\n',encoding='utf-8')
files={'runner338.py':Path(__file__),'summary.json':d/'summary.json','report.md':d/'report.md','original-inventory.tsv':inventory,'unapplied-six-shape-draft.tsv':draft_path,'frozen319.json':frozen_path}
for path in source_files:files[path.relative_to(w).as_posix()]=path
manifest={n:sha(p) for n,p in files.items()};z=b/'task8-all69-source-shapes339.zip';assert not z.exists()
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as out:
 for n,p in files.items():out.write(p,n)
 out.writestr('manifest.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(z) as out:assert all(hashlib.sha256(out.read(n)).hexdigest()==h for n,h in manifest.items())
receipt=b/'task8-all69-source-shapes339.summary.json';receipt.write_text(json.dumps(dict(scope=summary['scope'],sha256=sha(z),verified_entries=len(manifest),status_counts=counts,production_applied=False),indent=2)+'\n',encoding='utf-8')
for p in (z,receipt):
 q=e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'/p.name;assert not q.exists();shutil.copyfile(p,q);assert sha(p)==sha(q)
note='2026-10-09 69行源码形态预检338/339：针对原清单和未apply的六形态草稿，逐项绑定直接声明/枚举成员位置及SHA，状态 '+json.dumps(counts)+'；直接源码查找不证明公开可见性/cfg/alias/compiler/API/runtime。1277冻结变化0，zip339 SHA '+sha(z)+'全部条目/E镜像核验。未提升状态或改原门禁，319原全仓仍运行，18顶层OPEN。'
for rel in ('.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md','docs/verification/rdbc-first/status.md','docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md'):
 with (e/rel).open('ab') as out:out.write(('\n\n'+note+'\n').encode('utf-8'))
print(json.dumps(dict(status_counts=counts,zip_sha256=sha(z),verified_entries=len(manifest),unresolved=[row['java'] for row in findings if row['status'] not in ('DRAFT_SOURCE_KIND_MATCH','EXCLUDED_HOST_RUNTIME')]),ensure_ascii=False))
