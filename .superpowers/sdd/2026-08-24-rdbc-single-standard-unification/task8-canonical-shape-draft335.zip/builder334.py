from pathlib import Path
import subprocess
b = Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
source = (b / 'task8-exception-shape-draft332.py').read_text(encoding='utf-8')
replacements = {
    'task8-exception-shape-draft332': 'task8-canonical-shape-draft334',
    'task8-exception-shape-draft333': 'task8-canonical-shape-draft335',
    "if item['java'] != 'java.sql.DriverManager'": '',
    "assert old[3] == 'ENUM_KIND' and item['source_declared_kind'] == 'struct'": "assert old[3] in ('ENUM_KIND', 'MODULE') and item['source_declared_kind'] == 'struct'",
    'assert len(changes) == 5': 'assert len(changes) == 6',
    'UNAPPLIED_FIVE_EXCEPTION_DTO_SHAPE_DRAFT_WITH_ORIGINAL_JAVA_SOURCE_BINDING': 'UNAPPLIED_SIX_CANONICAL_STRUCT_DTO_DRAFT_WITH_FIXED_TASK3_ENTRIES_AND_SOURCE_BINDING',
    "unresolved_driver_manager=next(row for row in rows if row[1] == 'java.sql.DriverManager'),": "accepted_driver_registry_entry=verifier.TASK3_STANDARD_ENTRIES['java.sql.DriverManager'], static_kind_fixture=kind_fixture,",
    "'Resolve the static-manager module contract and fixed canonical registry path without weakening kind checks.'": "'Retain the specifically accepted DriverRegistry type extension and driver module organization; no registry behavioral changes or gate relaxation.'",
    "'runner332.py': Path(__file__)": "'runner334.py': Path(__file__), 'builder334.py': b / 'task8-canonical-shape-draft334-builder.py', 'parent332-runner.py': b / 'task8-exception-shape-draft332.py', 'source-declaration-fixture.txt': d / 'source-declaration-fixture.txt', 'approved-spec.md': e / 'docs/superpowers/specs/2026-08-24-rdbc-single-standard-trait-tree.md'",
    "'2026-10-09 五异常形态草稿332/333：仅五个现有struct payload的rust_shape由ENUM_KIND拟改DTO，其余18列逐字保留，69行/52+17Java来源不变；原load_oracle和verify_final_source_binding对原件及草稿均通过且冻结摘要一致。没有状态提升、验证器修改或生产apply；DriverManager MODULE/固定DriverRegistry入口冲突保留。1277输入变化0，zip333 SHA '": "'2026-10-09 六canonical形态草稿334/335：五异常payload及已批准固定DriverRegistry类型入口均保留，只有六行rust_shape拟改为实际struct的DTO；其余18列逐字保持、69行/52+17Java来源绑定通过。原形态策略对源码声明fixture六项逐行拒绝原形态、接受草稿形态，此为静态fixture而非compiler API认证。没有状态提升/门禁放宽/源码apply，规格第8节固定registry extension入口与原Task3映射保持。1277输入变化0，zip335 SHA '"
}
for old, new in replacements.items():
    assert old in source, old
    source = source.replace(old, new)
anchor = 'assert baseline_digest == draft_digest\n'
extra = '''assert all(new[5] == verifier.TASK3_STANDARD_ENTRIES[new[1]] for new in draft if new[1] in verifier.TASK3_STANDARD_ENTRIES)
from verify_jdbc42_final_runtime import verify_api_shapes
fixture = '\\n'.join('pub struct ' + row[5] for row in rows if row[1] in objects) + '\\n'
(d / 'source-declaration-fixture.txt').write_text(fixture, encoding='utf-8')
kind_fixture = dict(scope='SOURCE_DECLARATION_FIXTURE_ONLY_NOT_COMPILER_PUBLIC_API', original_rejected=0, draft_accepted=0)
for old, new in zip(rows, draft):
    if old[1] not in objects: continue
    try: verify_api_shapes([old], fixture)
    except verifier.VerificationError as error:
        assert 'kind mismatch' in str(error)
        kind_fixture['original_rejected'] += 1
    else: raise AssertionError('original conflicting source declaration unexpectedly accepted')
    verify_api_shapes([new], fixture)
    kind_fixture['draft_accepted'] += 1
assert kind_fixture['original_rejected'] == kind_fixture['draft_accepted'] == 6
'''
assert anchor in source
source = source.replace(anchor, anchor + extra)
target = b / 'task8-canonical-shape-draft334.py'
assert not target.exists()
target.write_text(source, encoding='utf-8')
result = subprocess.run(['C:/Espressif/tools/python/python.exe', '-X', 'utf8', str(target)])
raise SystemExit(result.returncode)
