from pathlib import Path
import hashlib,json,os,re,subprocess,time
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d177');d=b/'task8-current-final-semantic327';d.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
f=json.loads((b/'task7-final-candidate-workspace319/frozen-inputs.json').read_text());assert len(f)==1277 and all(sha(w/p)==h for p,h in f.items())
cmd=['C:/Espressif/tools/python/python.exe','-X','utf8','scripts/verify_jdbc42_semantic_inventory.py','--phase','logical-live','--require-standard-entries','--require-final-evidence'];env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',RUSTUP_AUTO_INSTALL='0',CARGO_NET_OFFLINE='true')
log=d/'final-semantic.log';start=time.monotonic()
with log.open('wb') as out:r=subprocess.run(cmd,cwd=w,env=env,stdout=out,stderr=subprocess.STDOUT)
text=log.read_text(encoding='utf-8',errors='replace');changed=[p for p,h in f.items() if sha(w/p)!=h]
s=dict(scope='CURRENT_FROZEN_CANDIDATE_ACTUAL_FINAL_SEMANTIC_GATE_NOT_RELEASE_CERTIFICATION',command=cmd,exit_code=r.returncode,elapsed_seconds=time.monotonic()-start,log=str(log),sha256=sha(log),frozen_input_count=len(f),changed_inputs=changed,production_applied=False,parent319_frozen_sha256=sha(b/'task7-final-candidate-workspace319/frozen-inputs.json'),task8_complete=False)
(d/'summary.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8');assert not changed;print(json.dumps(s));print(text[:3500])
