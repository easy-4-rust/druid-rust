from pathlib import Path
from collections import Counter
import hashlib,importlib.util,json,re,shutil,sys,zipfile
sys.dont_write_bytecode=True
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d177');e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust');d=b/'task8-current-final-state-matrix328';d.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sys.path.insert(0,str(w/'scripts'));import verify_jdbc42_semantic_inventory as verifier
f=json.loads((b/'task7-final-candidate-workspace319/frozen-inputs.json').read_text());assert len(f)==1277 and all(sha(w/p)==h for p,h in f.items())
s=json.loads((b/'task8-current-final-semantic327/summary.json').read_text());assert s['exit_code']==1 and not s['changed_inputs'] and sha(Path(s['log']))==s['sha256']
p=w/'docs/verification/rdbc-first/jdbc42-semantic-inventory.tsv';payload=p.read_bytes();rows=verifier.parse_semantic_payload(payload);fields=re.split(r'\\t|\t',verifier.SEMANTIC_HEADER);assert len(fields)==19 and len(rows)==69
findings=[];counts={fields[i]:dict(Counter(row[i] for row in rows)) for i in (6,13,15,16,17)}
for line,row in enumerate(rows,start=2):
 unresolved=[dict(field=field,value=value) for field,value in zip(fields,row) if re.search(r'\b(?:PLANNED(?:_[A-Z0-9_]+)?|MISSING|UNKNOWN|UNRESOLVED)\b',value,re.I)]
 try:verifier.verify_final_state_policy([row]);error=None
 except verifier.VerificationError as failure:error=str(failure)
 if not unresolved and error is None:continue
 requirements=[]
 if any(x['field']==fields[6] for x in unresolved):requirements.append('Current compiler-derived public declaration and correct canonical kind/path; import-only success is insufficient for enum/module shape.')
 if any(x['field']==fields[13] for x in unresolved):requirements.append('Production-bound wrapper implementation plus original runtime/coverage/capability evidence for this exact object or justified unsupported contract.')
 if any(x['field']==fields[15] for x in unresolved):requirements.append('Druid logical proxy/owner implementation and original behavior preservation, release/cancellation evidence for this object.')
 if any(x['field']==fields[17] for x in unresolved):requirements.append('Truthful capability=true behavior or specifically justified NOT_APPLICABLE; no blanket state promotion.')
 findings.append(dict(line=line,item_key=row[0],java_fqcn=row[1],rust_shape=row[3],canonical_target=row[5],unresolved_fields=unresolved,first_policy_error=error,required_evidence=requirements,achieved=False))
summary=dict(scope='CURRENT69_FINAL_STATE_REPAIR_MATRIX_NOT_CODE_OR_RUNTIME_CERTIFICATION',production_applied=False,frozen_input_count=len(f),parent319_frozen_sha256=sha(b/'task7-final-candidate-workspace319/frozen-inputs.json'),actual_final_gate_exit=s['exit_code'],inventory_sha256=sha(p),row_count=len(rows),state_counts=counts,rows_rejected=len(findings),rows_state_only_accepted=len(rows)-len(findings),rows=findings,requirements=['Preserve all69 Java source identities and immutable source oracle.','Do not promote PLANNED states based only on files, import success or aggregate tests.','Verify actual public API kinds, compiler coverage and full original C1/C2 against final current snapshot.','State-only accepted rows still require independent runtime evidence; this matrix is not final semantic pass.'])
assert sha(p)==hashlib.sha256(payload).hexdigest() and all(sha(w/p)==h for p,h in f.items());(d/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
report=['# 当前冻结候选最终语义状态修复清单','',f'实际最终门禁 exit1；69行中{len(findings)}行被状态策略拒绝，其他行仅状态检查通过，不代表类型、行为或最终语义验收。','', '| Java 对象 | 未闭合字段 | 需要的证据 |','| --- | --- | --- |']
for row in findings:report.append('| '+row['java_fqcn']+' | '+'; '.join(x['field']+'='+x['value'] for x in row['unresolved_fields'])+' | '+' '.join(row['required_evidence'])+' |')
(d/'repair-matrix.md').write_text('\n'.join(report)+'\n',encoding='utf-8')
files={'runner328.py':Path(__file__),'repair-matrix.md':d/'repair-matrix.md','summary.json':d/'summary.json','actual327-summary.json':b/'task8-current-final-semantic327/summary.json','actual327.log':Path(s['log']),'runner327.py':b/'task8-current-final-semantic327.py','frozen319.json':b/'task7-final-candidate-workspace319/frozen-inputs.json','inventory.tsv':p,'state-verifier.py':w/'scripts/verify_jdbc42_semantic_inventory.py'}
z=b/'task8-current-final-state-matrix329.zip';assert not z.exists();manifest={n:sha(p) for n,p in files.items()}
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as out:
 for n,p in files.items():out.write(p,n)
 out.writestr('manifest.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(z) as out:assert all(hashlib.sha256(out.read(n)).hexdigest()==h for n,h in manifest.items())
receipt=b/'task8-current-final-state-matrix329.summary.json';receipt.write_text(json.dumps(dict(scope=summary['scope'],sha256=sha(z),verified_entries=len(manifest),state_counts=counts,rows_rejected=len(findings),production_applied=False),indent=2)+'\n',encoding='utf-8')
for p in (z,receipt):
 q=e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'/p.name;assert not q.exists();shutil.copyfile(p,q);assert sha(p)==sha(q)
note='2026-10-09 当前冻结候选最终语义门禁327实际exit1：第2行PLANNED_TARGET拒绝。328逐行调用原状态策略，69行中'+str(len(findings))+'行拒绝，'+str(len(rows)-len(findings))+'行仅状态可接受；目标未声明、adapter/logical/capability未绑定证据逐项列入修复矩阵。未改状态/来源/验证器，不将候选源码或import通过当最终类型/运行证明。1277冻结输入前后不变，zip329 SHA '+sha(z)+'全部条目/E镜像核验；319全仓仍独立运行，Task8 INCOMPLETE/18顶层OPEN。'
for rel in ('.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md','docs/verification/rdbc-first/status.md','docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md'):
 with (e/rel).open('ab') as out:out.write(('\n\n'+note+'\n').encode('utf-8'))
print(json.dumps(dict(state_counts=counts,rows_rejected=len(findings),rows_state_only_accepted=len(rows)-len(findings),zip_sha256=sha(z),verified_entries=len(manifest))))
