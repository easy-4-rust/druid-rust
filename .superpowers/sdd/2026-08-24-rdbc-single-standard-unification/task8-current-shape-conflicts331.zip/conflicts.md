# 当前候选公开形态冲突

本报告是源码与重导出核对，不是编译器 public API 认证。69行清单中针对六个已定位对象复核，未修改源码、清单或验证器。

| Java 对象 | 清单要求 | 源码声明 | 源码位置 |
| --- | --- | --- |
| java.sql.BatchUpdateException | ENUM_KIND | struct | crates/druid-rdbc/src/error/batch_update_exception.rs:8 |
| java.sql.DataTruncation | ENUM_KIND | struct | crates/druid-rdbc/src/error/data_truncation.rs:6 |
| java.sql.DriverManager | MODULE | struct | crates/druid-rdbc/src/driver/driver_registry.rs:9 |
| java.sql.SQLClientInfoException | ENUM_KIND | struct | crates/druid-rdbc/src/error/sql_client_info_exception.rs:9 |
| java.sql.SQLException | ENUM_KIND | struct | crates/druid-rdbc/src/error/sql_exception.rs:25 |
| java.sql.SQLWarning | ENUM_KIND | struct | crates/druid-rdbc/src/error/sql_warning.rs:8 |

批准规格允许异常分类与 payload 组合，并要求 static manager 对应 registry/manager module。需保持 payload、公开消费者和 Java 来源身份，在当前全仓任务终态后处理一致性；不得放宽种类检查或据此批量提升状态。
