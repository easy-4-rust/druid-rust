from pathlib import Path
import hashlib, json, re, shutil, sys, zipfile

sys.dont_write_bytecode = True
b = Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
w = Path('F:/codex_build_cache/d177')
e = Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust')
d = b / 'task8-current-shape-conflicts330'
d.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
frozen_path = b / 'task7-final-candidate-workspace319/frozen-inputs.json'
frozen = json.loads(frozen_path.read_text())
assert len(frozen) == 1277 and all(sha(w / p) == h for p, h in frozen.items())
sys.path.insert(0, str(w / 'scripts'))
from verify_jdbc42_semantic_inventory import parse_semantic_payload
rows = parse_semantic_payload((w / 'docs/verification/rdbc-first/jdbc42-semantic-inventory.tsv').read_bytes())
expected = {
    'java.sql.BatchUpdateException': 'error/batch_update_exception.rs',
    'java.sql.DataTruncation': 'error/data_truncation.rs',
    'java.sql.SQLClientInfoException': 'error/sql_client_info_exception.rs',
    'java.sql.SQLException': 'error/sql_exception.rs',
    'java.sql.SQLWarning': 'error/sql_warning.rs',
    'java.sql.DriverManager': 'driver/driver_registry.rs',
}
findings = []
files = {'runner330.py': Path(__file__), 'frozen319.json': frozen_path,
         'inventory.tsv': w / 'docs/verification/rdbc-first/jdbc42-semantic-inventory.tsv',
         'original-final-runtime-verifier.py': w / 'scripts/verify_jdbc42_final_runtime.py',
         'original-inventory-verifier.py': w / 'scripts/verify_jdbc42_semantic_inventory.py',
         'approved-spec.md': e / 'docs/superpowers/specs/2026-08-24-rdbc-single-standard-trait-tree.md'}
for line, row in enumerate(rows, 2):
    if row[1] not in expected:
        continue
    rel = 'crates/druid-rdbc/src/' + expected[row[1]]
    path = w / rel
    text = path.read_text(encoding='utf-8')
    name = row[5].rsplit('::', 1)[1]
    pattern = r'^pub (struct|enum|trait|mod|type) ' + re.escape(name) + r'\b'
    match = re.search(pattern, text, re.M)
    assert match and match[1] == 'struct'
    assert row[3] in ('ENUM_KIND', 'MODULE')
    module = 'crates/druid-rdbc/src/' + expected[row[1]].split('/')[0] + '/mod.rs'
    assert re.search(r'^pub use .*\b' + re.escape(name) + r'\b', (w / module).read_text(), re.M)
    findings.append(dict(java=row[1], inventory_line=line, canonical_target=row[5],
                         required_shape=row[3], source_declared_kind=match[1],
                         source_path=rel, source_line=text[:match.start()].count('\n') + 1,
                         source_sha256=sha(path), public_reexport_path=module,
                         public_reexport_sha256=sha(w / module), final_shape_certified=False))
    files[rel] = path
    files[module] = w / module
assert len(findings) == 6
summary = dict(scope='CURRENT_FROZEN_SOURCE_SHAPE_CONFLICTS_NOT_COMPILER_API_CERTIFICATION',
               production_applied=False, candidate_mutated=False, frozen_input_count=len(frozen),
               frozen319_sha256=sha(frozen_path), row_count=len(rows), verified_conflicts=findings,
               immutable_java_identity_preserved=True,
               required_next_actions=[
                   'Resolve canonical mapping against approved exception-kind-plus-payload and manager-module semantics; do not merely broaden the verifier.',
                   'Retain Java source identity, exception payload behavior and canonical public consumers.',
                   'After active workspace validation terminates, implement the consistent mapping with targeted RED/GREEN and regenerate fresh compiler public API.',
                   'Do not promote any row to LIVE from this static inspection or claim final semantic pass.'])
assert all(sha(w / p) == h for p, h in frozen.items())
(d / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
report = ['# 当前候选公开形态冲突', '', '本报告是源码与重导出核对，不是编译器 public API 认证。69行清单中针对六个已定位对象复核，未修改源码、清单或验证器。', '',
          '| Java 对象 | 清单要求 | 源码声明 | 源码位置 |', '| --- | --- | --- |']
for item in findings:
    report.append(f"| {item['java']} | {item['required_shape']} | {item['source_declared_kind']} | {item['source_path']}:{item['source_line']} |")
report += ['', '批准规格允许异常分类与 payload 组合，并要求 static manager 对应 registry/manager module。需保持 payload、公开消费者和 Java 来源身份，在当前全仓任务终态后处理一致性；不得放宽种类检查或据此批量提升状态。']
(d / 'conflicts.md').write_text('\n'.join(report) + '\n', encoding='utf-8')
files.update({'summary.json': d / 'summary.json', 'conflicts.md': d / 'conflicts.md'})
z = b / 'task8-current-shape-conflicts331.zip'
assert not z.exists()
manifest = {name: sha(path) for name, path in files.items()}
with zipfile.ZipFile(z, 'w', zipfile.ZIP_DEFLATED) as archive:
    for name, path in files.items(): archive.write(path, name)
    archive.writestr('manifest.json', json.dumps(manifest, indent=2))
with zipfile.ZipFile(z) as archive:
    assert all(hashlib.sha256(archive.read(name)).hexdigest() == digest for name, digest in manifest.items())
receipt = b / 'task8-current-shape-conflicts331.summary.json'
receipt.write_text(json.dumps(dict(scope=summary['scope'], sha256=sha(z), verified_entries=len(manifest),
                                   conflicts=len(findings), production_applied=False), indent=2) + '\n', encoding='utf-8')
for path in (z, receipt):
    target = e / '.superpowers/sdd/2026-08-24-rdbc-single-standard-unification' / path.name
    assert not target.exists()
    shutil.copyfile(path, target)
    assert sha(path) == sha(target)
note = '2026-10-09 当前冻结1277候选形态复核330/331：五个异常payload对象为struct但清单ENUM_KIND，DriverManager映射DriverRegistry struct但清单MODULE；六项逐一源码与pub use重导出SHA绑定。仅静态冲突证据，不是compiler/API或最终门禁通过。批准异常kind+payload和manager module语义须保持，不放宽验证器、不提升LIVE；候选输入前后变化0。zip331 SHA ' + sha(z) + '全部条目/E镜像核验。319原完整全仓仍运行，正式E源码未apply，18顶层OPEN。'
for rel in ('.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md', 'docs/verification/rdbc-first/status.md', 'docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md'):
    with (e / rel).open('ab') as output: output.write(('\n\n' + note + '\n').encode('utf-8'))
print(json.dumps(dict(conflicts=len(findings), frozen_inputs_unchanged=True, zip_sha256=sha(z), verified_entries=len(manifest))))
