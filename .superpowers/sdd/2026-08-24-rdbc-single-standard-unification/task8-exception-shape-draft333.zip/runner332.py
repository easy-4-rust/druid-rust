from pathlib import Path
import difflib, hashlib, json, shutil, sys, zipfile
sys.dont_write_bytecode = True
b = Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008')
w = Path('F:/codex_build_cache/d177')
e = Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust')
d = b / 'task8-exception-shape-draft332'
d.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
frozen_path = b / 'task7-final-candidate-workspace319/frozen-inputs.json'
frozen = json.loads(frozen_path.read_text())
assert len(frozen) == 1277 and all(sha(w / p) == digest for p, digest in frozen.items())
sys.path.insert(0, str(w / 'scripts'))
import verify_jdbc42_semantic_inventory as verifier
p = w / 'docs/verification/rdbc-first/jdbc42-semantic-inventory.tsv'
original = p.read_bytes()
rows = verifier.parse_semantic_payload(original)
draft = [row.copy() for row in rows]
conflicts = json.loads((b / 'task8-current-shape-conflicts330/summary.json').read_text())
objects = {item['java']: item for item in conflicts['verified_conflicts'] if item['java'] != 'java.sql.DriverManager'}
changes = []
for line, (old, new) in enumerate(zip(rows, draft), 2):
    if old[1] not in objects:
        continue
    item = objects[old[1]]
    assert sha(w / item['source_path']) == item['source_sha256']
    assert old[3] == 'ENUM_KIND' and item['source_declared_kind'] == 'struct'
    new[3] = 'DTO'
    changes.append(dict(line=line, java=old[1], canonical_target=old[5], old_shape=old[3], new_shape=new[3], source_sha256=item['source_sha256']))
assert len(changes) == 5
for old, new in zip(rows, draft):
    assert [v for i, v in enumerate(old) if i != 3] == [v for i, v in enumerate(new) if i != 3]
records, hashes = verifier.load_oracle(w / verifier.DEFAULT_ORACLE, verifier.SOURCE_MANIFEST_SHA256)
baseline_digest = verifier.verify_final_source_binding(rows, records, hashes)
draft_digest = verifier.verify_final_source_binding(draft, records, hashes)
assert baseline_digest == draft_digest
payload = verifier.canonical_semantic_payload(draft)
assert verifier.parse_semantic_payload(payload) == draft
target = d / 'jdbc42-semantic-inventory.draft.tsv'
target.write_bytes(payload)
patch = ''.join(difflib.unified_diff(original.decode('utf-8').splitlines(True), payload.decode('utf-8').splitlines(True), fromfile='a/docs/verification/rdbc-first/jdbc42-semantic-inventory.tsv', tofile='b/docs/verification/rdbc-first/jdbc42-semantic-inventory.tsv'))
(d / 'exception-shape.patch').write_text(patch, encoding='utf-8')
summary = dict(scope='UNAPPLIED_FIVE_EXCEPTION_DTO_SHAPE_DRAFT_WITH_ORIGINAL_JAVA_SOURCE_BINDING', production_applied=False,
               candidate_mutated=False, original_inventory_sha256=sha(p), draft_sha256=sha(target), changes=changes,
               row_count=len(draft), source_counts={'java.sql': 52, 'javax.sql': 17}, source_binding_passed=True,
               frozen_semantic_source_digest=draft_digest, all_non_shape_fields_unchanged=True,
               states_promoted=0, original_verifier_modified=False, compiler_api_certified=False,
               unresolved_driver_manager=next(row for row in rows if row[1] == 'java.sql.DriverManager'),
               remaining_requirements=['Resolve the static-manager module contract and fixed canonical registry path without weakening kind checks.',
                                      'Apply only after active frozen workspace validation terminates and re-freeze inputs.',
                                      'Obtain fresh compiler public API and exact exception payload behavioral evidence.',
                                      'Complete all61 rejected state rows and original final runtime gates.'])
assert all(sha(w / path) == digest for path, digest in frozen.items()) and p.read_bytes() == original
(d / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
files = {'runner332.py': Path(__file__), 'draft.tsv': target, 'exception-shape.patch': d / 'exception-shape.patch',
         'summary.json': d / 'summary.json', 'original-inventory.tsv': p, 'oracle.json': w / verifier.DEFAULT_ORACLE,
         'original-source-binding-verifier.py': w / 'scripts/verify_jdbc42_semantic_inventory.py',
         'original-generator.py': w / 'scripts/generate_jdbc42_semantic_inventory.py',
         'parent330-summary.json': b / 'task8-current-shape-conflicts330/summary.json', 'frozen319.json': frozen_path}
z = b / 'task8-exception-shape-draft333.zip'
assert not z.exists()
manifest = {name: sha(path) for name, path in files.items()}
with zipfile.ZipFile(z, 'w', zipfile.ZIP_DEFLATED) as archive:
    for name, path in files.items(): archive.write(path, name)
    archive.writestr('manifest.json', json.dumps(manifest, indent=2))
with zipfile.ZipFile(z) as archive:
    assert all(hashlib.sha256(archive.read(name)).hexdigest() == digest for name, digest in manifest.items())
receipt = b / 'task8-exception-shape-draft333.summary.json'
receipt.write_text(json.dumps(dict(scope=summary['scope'], sha256=sha(z), verified_entries=len(manifest),
                                   changes=len(changes), source_binding_passed=True, production_applied=False), indent=2) + '\n', encoding='utf-8')
for path in (z, receipt):
    mirror = e / '.superpowers/sdd/2026-08-24-rdbc-single-standard-unification' / path.name
    assert not mirror.exists()
    shutil.copyfile(path, mirror)
    assert sha(path) == sha(mirror)
note = '2026-10-09 五异常形态草稿332/333：仅五个现有struct payload的rust_shape由ENUM_KIND拟改DTO，其余18列逐字保留，69行/52+17Java来源不变；原load_oracle和verify_final_source_binding对原件及草稿均通过且冻结摘要一致。没有状态提升、验证器修改或生产apply；DriverManager MODULE/固定DriverRegistry入口冲突保留。1277输入变化0，zip333 SHA ' + sha(z) + '全部条目/E镜像核验。新鲜compiler API与运行证据仍必需；319原全仓继续，18顶层OPEN。'
for rel in ('.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md', 'docs/verification/rdbc-first/status.md', 'docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md'):
    with (e / rel).open('ab') as out: out.write(('\n\n' + note + '\n').encode('utf-8'))
print(json.dumps(dict(changes=len(changes), source_binding_passed=True, states_promoted=0, zip_sha256=sha(z), verified_entries=len(manifest))))
