from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,time,zipfile
b=Path('F:/codex_build_cache/druid_rust/task6_e_disk_full_evidence_20261008');w=Path('F:/codex_build_cache/d177');e=Path('E:/workspaces/workspace-github-easy-4-rust/druid-rust');d=b/'task8-original-shape-guards336';d.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
frozen_path=b/'task7-final-candidate-workspace319/frozen-inputs.json';frozen=json.loads(frozen_path.read_text());assert len(frozen)==1277 and all(sha(w/p)==h for p,h in frozen.items())
prefix='test_verify_jdbc42_semantic_inventory.Jdbc42SemanticInventoryVerifierTest.'
names=['test_final_source_binding_reconstructs_accepted_frozen_mapping','test_final_source_binding_allows_evidence_progress_without_rewriting_oracle','test_final_source_binding_rejects_each_source_identity_drift','test_final_source_binding_rejects_missing_extra_and_duplicate_objects','test_final_source_binding_rejects_frozen_semantic_digest_drift','test_final_source_binding_rejects_modified_oracle_declaration','test_final_source_binding_rejects_malformed_field_count']
selectors=[prefix+name for name in names]+['test_jdbc42_final_cli.FinalCliTest.test_api_shape_accepts_declared_kinds_and_resolved_aliases','test_jdbc42_final_cli.FinalCliTest.test_api_import_success_does_not_certify_enum_shape']
env=os.environ.copy();env.update(PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1');cmd=['C:/Espressif/tools/python/python.exe','-B','-X','utf8','-m','unittest','-v']+selectors;log=d/'guards.log';started=time.monotonic()
with log.open('wb') as out:result=subprocess.run(cmd,cwd=w/'scripts',env=env,stdout=out,stderr=subprocess.STDOUT)
text=log.read_text(encoding='utf-8');changed=[p for p,h in frozen.items() if sha(w/p)!=h]
summary=dict(scope='ORIGINAL_NINE_SOURCE_BINDING_AND_API_KIND_GUARD_SELFTESTS_NOT_FINAL_RUNTIME',terminal=True,exit_code=result.returncode,command=cmd,elapsed_seconds=time.monotonic()-started,log_sha256=sha(log),selected_original_tests=len(selectors),reported_test_count=int(re.search(r'Ran (\d+) tests?',text)[1]),changed_inputs=changed,production_applied=False,cargo_started=False)
(d/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8');assert result.returncode==0 and summary['reported_test_count']==9 and not changed
files={'runner336.py':Path(__file__),'guards.log':log,'summary.json':d/'summary.json','frozen319.json':frozen_path}
for name in ('test_verify_jdbc42_semantic_inventory.py','test_jdbc42_final_cli.py','verify_jdbc42_semantic_inventory.py','verify_jdbc42_final_runtime.py'):files[name]=w/'scripts'/name
manifest={n:sha(p) for n,p in files.items()};z=b/'task8-original-shape-guards337.zip';assert not z.exists()
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as out:
 for n,p in files.items():out.write(p,n)
 out.writestr('manifest.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(z) as out:assert all(hashlib.sha256(out.read(n)).hexdigest()==h for n,h in manifest.items())
receipt=b/'task8-original-shape-guards337.summary.json';receipt.write_text(json.dumps(dict(scope=summary['scope'],sha256=sha(z),verified_entries=len(manifest),tests=9,exit_code=0,production_applied=False),indent=2)+'\n',encoding='utf-8')
for p in (z,receipt):
 q=e/'.superpowers/sdd/2026-08-24-rdbc-single-standard-unification'/p.name;assert not q.exists();shutil.copyfile(p,q);assert sha(p)==sha(q)
note='2026-10-09 原最终门禁防护自测336/337：七个来源绑定/身份/分母/摘要/声明篡改检查与两个API种类/alias/import不足检查，原九测试实际exit0；不改原测试或验证器、不启动Cargo、不作为最终API/runtime验收。1277冻结输入变化0，zip337 SHA '+sha(z)+'全部条目/E镜像核验。六形态草稿335尚未apply，61状态拒绝仍开放；319原全仓继续，18顶层OPEN。'
for rel in ('.superpowers/sdd/2026-08-24-rdbc-single-standard-unification/progress.md','docs/verification/rdbc-first/status.md','docs/verification/rdbc-first/task7-standard-resource-candidates-2026-10-08.md'):
 with (e/rel).open('ab') as out:out.write(('\n\n'+note+'\n').encode('utf-8'))
print(json.dumps(dict(exit_code=0,tests=9,frozen_inputs_unchanged=True,zip_sha256=sha(z),verified_entries=len(manifest))))
